/* ============================================================
   LOG POSE · 방문 기록 (Supabase visits 표 + 구글 애널리틱스 4)
   - config.json 에 Supabase 주소 · 공개 키가 있으면 visits 표에 한 줄씩 남겨요.
   - config.json 에 gaMeasurementId(G-…)가 있으면 GA4 에도 같은 행동을 이벤트로 보내요.
   - 둘 다 없으면(파일로 열기 · 연습용) 아무것도 보내지 않아요.
   보내는 것: 무작위 방문자 번호 · 시각 · 행동 · 공간 · PC/모바일 · 어디서 왔는지(사이트 도메인만)
   보내지 않는 것: 이름 · 이메일 · 닉네임 · 배 이름 · 대화 내용
   행동 이름: visit(사이트 열기) · area(공간 이동: cabin/deck/isle/tavern) · tour_done/tour_skip(절영도 한눈에 보기) · guide(가이드북 열기, detail=작품 id)
   팀이 숫자 보는 법: supabase/visits_queries.sql
   ============================================================ */
const LPTrack = (() => {
  const cfg = (typeof window !== 'undefined' && window.LP_CONFIG) || {};
  const SB = !!(cfg.supabaseUrl && cfg.supabaseAnonKey);
  const GA = !!cfg.gaId && typeof window.gtag === 'function';
  const rid = () => (Date.now().toString(36) + Math.random().toString(36).slice(2, 12)).slice(0, 20);
  const keep = (getStore, k) => { try { const s = getStore(); let v = s.getItem(k); if (!v){ v = rid(); s.setItem(k, v); } return v; } catch(e){ return rid(); } };
  const cut = (s, n) => s == null || s === '' ? null : String(s).slice(0, n);
  const device = () => { try { return matchMedia('(pointer:coarse)').matches ? 'mobile' : 'pc'; } catch(e){ return 'pc'; } };
  const refDomain = () => { try { const r = document.referrer; if (!r) return null; const h = new URL(r).hostname; return h && h !== location.hostname ? h.slice(0, 200) : null; } catch(e){ return null; } };
  let visitor = null, session = null, lastKey = '';
  function send(event, area, detail){
    if (!SB && !GA) return;
    const key = event + '|' + (area || '') + '|' + (detail || '');
    if (key === lastKey) return;   /* 같은 기록을 연달아 두 번 보내지 않아요 */
    lastKey = key;
    if (!visitor){ visitor = keep(() => window.localStorage, 'logpose.vid'); session = keep(() => window.sessionStorage, 'logpose.sid'); }
    if (SB){
      const k = cfg.supabaseAnonKey, headers = { 'apikey':k, 'Content-Type':'application/json', 'Prefer':'return=minimal' };
      if (!/^sb_/.test(k)) headers.Authorization = 'Bearer ' + k;   /* 예전 anon 키(JWT)일 때만 Authorization 에도 넣어요 */
      try {
        fetch(String(cfg.supabaseUrl).replace(/\/+$/, '') + '/rest/v1/visits', { method:'POST', headers, keepalive:true,
          body:JSON.stringify({ visitor, session, event:cut(event, 20), area:cut(area, 20), detail:cut(detail, 60), referrer:event === 'visit' ? refDomain() : null, device:device() }) })
          .then(r => { if (!r.ok && r.status !== 409) console.warn('[LOG POSE] 방문 기록 실패', r.status); }).catch(() => {});
      } catch(e){}
    }
    if (GA && event !== 'visit'){ try { window.gtag('event', 'lp_' + event, { lp_area:area || undefined, lp_detail:detail || undefined }); } catch(e){} }   /* 사이트 열기는 GA4 가 page_view 로 따로 세요 */
  }
  /* 첫 화면에 수집 안내 한 줄 (기록이 켜졌을 때만) */
  if (SB || GA){
    try {
      const card = document.querySelector('#gate .gate-card');
      if (card){ const p = document.createElement('p'); p.className = 'lp-stat-note';
        p.textContent = '이 사이트는 이용 통계(무작위 방문 번호 · 시각 · 이동한 공간)를 모아요' + (GA ? ' · Google 애널리틱스 사용' : '') + '. 이름 · 이메일은 모으지 않아요.';
        card.appendChild(p); }
    } catch(e){}
    send('visit');
  }
  return { event:send, on:SB || GA };
})();
