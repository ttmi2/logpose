"""LOG POSE 빌드: 원본 데이터 + 추가 정보 + 연결부 + 선장실을 dist/logpose.html 한 장으로 합쳐요.
사용법: python3 build.py   (먼저 데이터가 원본과 같은지 확인해요)
"""
import os, subprocess, sys
ROOT = os.path.dirname(os.path.abspath(__file__))
P = lambda *a: os.path.join(ROOT, *a)
R = lambda p: open(p, encoding='utf-8').read()

# 0) 데이터 점검 (체크섬 + 63편). 실패하면 빌드하지 않아요.
if subprocess.run(['node', P('tools', 'check_data.js')], stdout=subprocess.DEVNULL).returncode != 0:
    sys.exit('데이터 점검 실패: node tools/check_data.js 를 실행해 보세요')

ORIG = P('data', 'original')
guides = sorted(f for f in os.listdir(ORIG) if f.startswith('guides_') and f.endswith('.js') and f != 'guides_post.js')
DATA = ['data.js', 'data_fix.js', 'data_ep3.js', 'data_ep45.js', 'catalog.js'] + guides + ['guides_post.js']
data_js = '\n'.join(R(os.path.join(ORIG, f)) for f in DATA)
app_js = R(P('data', 'extra', 'extra.js')) + '\n' + R(P('data', 'extra', 'strengths_draft.js')) + '\n' + R(P('data', 'extra', 'cheer_chars.js')) + '\n' + R(P('app', 'works.js')) + '\n' + R(P('app', 'profile.js')) + '\n' + R(P('app', 'backend.js')) + '\n' + R(P('app', 'track.js')) + '\n' + R(P('app', 'share.js')) + '\n' + R(P('app', 'recommend.js')) + '\n' + R(P('app', 'vendor', 'guide.js'))
scene_js = '\n'.join(R(P('app', f)) for f in ['cabin.js', 'intro.js', 'deck.js', 'scope.js', 'seas.js', 'taste.js', 'recs.js', 'desk.js', 'menu.js', 'shelf.js', 'chart.js', 'nest.js', 'fish.js', 'isle.js', 'fishpier.js', 'tavern.js', 'market.js', 'marketplace.js', 'wardrobe.js', 'rest.js', 'gym.js', 'letters.js', 'board.js', 'net.js', 'ambience.js', 'isletour.js', 'gate.js'])

js = ("(() => {\n'use strict';\n" + data_js + '\n' + app_js +
      "\nif (typeof THREE === 'undefined') {\n"
      "  document.getElementById('loadMsg').textContent = '3D 엔진을 불러오지 못했어요. 네트워크를 확인하고 새로고침해 주세요.';\n"
      "} else {\n" + scene_js + "\n}\n})();\n")
# 우리 웹사이트용: config.json 이 있으면 Supabase 주소 · 공개 키를 넣고 supabase-js 를 불러요 (없으면 예전과 똑같아요)
import json, re
cfg, ga = {}, ''
if os.path.exists(P('config.json')):
    raw = json.load(open(P('config.json'), encoding='utf-8'))
    if raw.get('supabaseUrl') and raw.get('supabaseAnonKey') and 'YOUR' not in raw['supabaseUrl'] and 'YOUR' not in raw['supabaseAnonKey']:
        cfg = { 'supabaseUrl': raw['supabaseUrl'].strip(), 'supabaseAnonKey': raw['supabaseAnonKey'].strip(), 'shared': raw.get('shared') is True }
    # 구글 애널리틱스 4: "gaMeasurementId": "G-XXXXXXX" (비워 두면 꺼져요)
    ga = str(raw.get('gaMeasurementId') or '').strip().upper()
    if not re.fullmatch(r'G-[A-Z0-9]{4,20}', ga): ga = ''
net = ''
if ga:
    cfg['gaId'] = ga
    net += ('<script async src="https://www.googletagmanager.com/gtag/js?id=' + ga + '"></script>\n'
            "<script>window.dataLayer = window.dataLayer || []; function gtag(){ dataLayer.push(arguments); } gtag('js', new Date()); gtag('config', '" + ga + "');</script>\n")
if cfg:
    net += '<script>window.LP_CONFIG = ' + json.dumps(cfg) + ';</script>\n'
if cfg.get('supabaseUrl'):
    net += '<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>\n'
html = R(P('web', 'head.html')).replace('</head>', R(P('web', 'guide.css')) + '</head>') + R(P('web', 'body.html')).replace('<!--GUIDE-->', R(P('web', 'guide.html'))) + net + '<script>\n' + js + '</script>\n</body>\n</html>\n'
os.makedirs(P('dist'), exist_ok=True)
open(P('dist', 'logpose.html'), 'w', encoding='utf-8').write(html)
if os.path.exists(P('dist', 'index.html')): os.remove(P('dist', 'index.html'))   # 예전 복사본 정리 (웹사이트 배포 땐 deploy.yml 이 index.html 로 복사해요)
print('built dist/logpose.html', len(html.encode('utf-8')), 'bytes', '· Supabase 연결 · 방문 기록' if cfg.get('supabaseUrl') else '· 연습용(파일) 모드', '· GA4 ' + ga if ga else '')
