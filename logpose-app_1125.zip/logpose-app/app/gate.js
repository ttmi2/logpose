/* ============================================================
   LOG POSE · 입구 (단계 2)
   처음 온 사람: 로그인(라프텔 체험 / 비회원) → 닉네임 → 선미 창으로 날아가 선장실
   다시 온 사람: "이어서 항해하기" 한 번 → 선장실 (취향 질문 없이)
   선장실의 '나가기' → 다시 첫 화면 (기록은 남아요)
   ============================================================ */
let MODE = 'gate';   // 'gate' | 'fly' | 'cabin'
const G = {
  root:$('#gate'), choose:$('#gChoose'), name:$('#gName'), ret:$('#gReturn'),
  note:$('#gNote'), nick:$('#gNick'), err:$('#gErr'), who:$('#gWho'), kind:$('#gKind'), confirm:$('#gConfirm')
};
let pendingKind = 'guest';
const NOTES = {
  'laftel-demo':'<b>체험용 연동</b>이에요. 실제 라프텔에 로그인하지 않고, 아이디와 비밀번호도 받지 않아요. 닉네임만 정하면 ‘라프텔 연동 · 체험’ 선장으로 시작해요.',
  guest:'비회원으로 시작해요. 기록은 <b>이 브라우저에만</b> 저장돼요.'
};
function showStep(step){
  G.choose.hidden = step !== 'choose'; G.name.hidden = step !== 'name'; G.ret.hidden = step !== 'return'; G.confirm.hidden = true;
  const focus = { choose:'#gLaftel', name:'#gNick', return:'#gContinue' }[step];
  setTimeout(() => { const el = $(focus); if (el) el.focus({ preventScroll:true }); }, 60);
}
function showGate(){
  closeAllPanels();
  MODE = 'gate'; IN.fly = null; uiOpen = true; keys.clear(); auto = null;
  document.body.classList.add('in-gate');
  G.root.hidden = false; G.root.classList.remove('leaving');
  const p = LPProfile.get();
  if (p){ G.who.textContent = p.nickname; G.kind.textContent = `${p.ship ? p.ship + ' · ' : ''}${LPProfile.kindLabel(p)} 선장`; showStep('return'); }
  else showStep('choose');
}
function setWho(){
  const p = LPProfile.get(), who = $('#who');
  who.innerHTML = p ? `${escHTML({ cabin:'선장실', deck:'갑판', isle:'다모였섬', tavern:'주점' }[AREA.id] || '')} · ${p.ship ? `<small>${escHTML(p.ship)}</small> ` : ''}<b class="${isLaftelCaptain(p) ? 'lf' : 'gs'}">${escHTML(p.nickname)} 선장</b>` : '선장실';
  who.title = p ? (isLaftelCaptain(p) ? '라프텔 선장 (보라색 이름표)' : '비회원 선장 (회색 이름표)') : '';
  menuSync(); applyLooks(); updateNameTag(); tpSync();
}

/* 선장실로 들어가기: 카드가 사라지고 → 선미 창으로 날아가 → 어두워졌다가 → 선장실 */
function enterCabin(instant){
  const go = () => {
    MODE = 'cabin'; G.root.hidden = true; document.body.classList.remove('in-gate');
    uiOpen = false; setArea('cabin'); setWho();
    player.x = 0; player.z = 3.6; player.r = Math.PI; cam.yaw = 0; cam.pitch = 0.32; camPos.set(0, 2.4, 7.2);
    const p = LPProfile.get();
    if (p && !p.onboarded){
      /* 처음 선장: 잠깐 둘러본 뒤 손목 로그포스가 반짝이며 취향 질문 */
      setTimeout(() => toast(`<strong>${p.nickname}</strong> 선장님, 선장실이에요.<br>손목의 로그포스가 반짝이네요…`, 2600), instant ? 300 : 700);
      setTimeout(() => { if (MODE === 'cabin' && Q.root.hidden) lookWrist(() => { if (Q.root.hidden) openQuiz(); }, 0.3); }, instant ? 1600 : 2400);
    } else setTimeout(() => toast(`다시 오셨네요, <strong>${p ? p.nickname : ''}</strong> 선장님. 항해를 이어가요.`, 4200), instant ? 300 : 700);
    if (p && p.onboarded && !p.ship) setTimeout(askShipIfNeeded, instant ? 500 : 1200);
  };
  if (instant){ go(); return; }
  MODE = 'fly'; G.root.classList.add('leaving');
  flyIntoCabin(() => {
    $('#fade').classList.add('on');
    setTimeout(() => { go(); setTimeout(() => $('#fade').classList.remove('on'), 80); }, 520);
  });
}

/* 버튼들 */
$('#gLaftel').addEventListener('click', () => { pendingKind = 'laftel-demo'; G.note.innerHTML = NOTES['laftel-demo']; G.err.textContent = ''; showStep('name'); });
$('#gGuest').addEventListener('click', () => { pendingKind = 'guest'; G.note.innerHTML = NOTES.guest; G.err.textContent = ''; showStep('name'); });
$('#gBack').addEventListener('click', () => showStep('choose'));
G.name.addEventListener('submit', e => {
  e.preventDefault();
  const r = LPProfile.checkName(G.nick.value);
  if (!r.ok){ G.err.textContent = r.msg; G.nick.focus(); return; }
  const sh = LPProfile.checkShip($('#gShip').value);
  if (!sh.ok){ G.err.textContent = sh.msg; $('#gShip').focus(); return; }
  LPProfile.create(r.name, pendingKind, sh.name); LPProfile.signIn();
  G.nick.value = ''; $('#gShip').value = ''; enterCabin(false);
});
$('#gContinue').addEventListener('click', () => { LPProfile.signIn(); enterCabin(false); });
$('#gNew').addEventListener('click', () => { G.confirm.hidden = false; $('#gCancel').focus(); });
$('#gCancel').addEventListener('click', () => { G.confirm.hidden = true; $('#gNew').focus(); });
$('#gWipe').addEventListener('click', () => { LPProfile.clear(); showStep('choose'); });
/* 열려 있는 창을 모두 닫아요 (나가기 · 첫 화면으로 돌아갈 때) */
function closeAllPanels(){
  if (!Q.root.hidden) closeQuiz(true);
  closeMenu(true); closeScope(); closeChart(); closeNest(true); closeFishing(true); cancelSail(); closeHelm(true); closeShop(); closeBoard(); if (typeof closeInbox === 'function') closeInbox(); closeWardrobe(); closeLetters(); netLeave();
  if (!RC.root.hidden) closeRecs();
  if (Guide.isOpen()){ Guide.close(); document.body.classList.remove('guide-open'); }
  if (!DK.root.hidden || dkWork) closeDeskInfo();
  RC.fx.hidden = true; RC.fx.className = 'lpfx'; RC.fx.innerHTML = '';
  $('#toast').hidden = true; deskView = null;
}
$('#logoutPill').addEventListener('click', () => {
  if (MODE !== 'cabin') return;
  closeAllPanels();
  LPProfile.signOut();
  $('#fade').classList.add('on');
  setTimeout(() => { showGate(); setTimeout(() => $('#fade').classList.remove('on'), 80); }, 480);
});
/* 창밖 낮/밤 버튼은 첫 화면 바다에도 같이 적용 */
$('#timePill').addEventListener('click', () => introTime(timeMode));

/* ---------- 하나의 루프: 지금 장면만 그려요 ---------- */
function frame(){
  const dt = Math.min(0.05, clock.getDelta()), time = clock.elapsedTime;
  if (MODE === 'cabin'){ renderer.toneMappingExposure = AREA.exposure; cabinStep(dt, time); tickerStep(dt); netStep(dt, time); renderer.render(AREA.scene, camera); }
  else { renderer.toneMappingExposure = 0.9; introStep(dt, time); renderer.render(introScene, introCam); }
  requestAnimationFrame(frame);
}
async function boot(){
  try { await Promise.race([document.fonts.load(`700 40px ${FD}`), new Promise(r => setTimeout(r, 1500))]); } catch(e){}
  buildCabin(); buildIntro(); buildDeck(); buildIsle(); setArea('cabin');
  if (LPProfile.isIn()) enterCabin(true);   // 같은 창에서 새로고침: 바로 선장실
  else showGate();
  $('#loading').classList.add('done');
  requestAnimationFrame(frame);
}

/* ---------- 머리 위 이름표: 작게 ○○호 · 크게 ○○ 선장 (라프텔 선장은 보라, 비회원은 회색) ---------- */
let tagKey = '';
function updateNameTag(){
  const p = LPProfile.get(), pm = player.mesh; if (!pm) return;
  const k = p ? `${p.ship}|${p.nickname}|${p.kind}` : ''; if (k === tagKey && pm.userData.tag) return; tagKey = k;
  if (pm.userData.tag){ pm.remove(pm.userData.tag); pm.userData.tag.material.map.dispose(); pm.userData.tag = null; }
  if (!p) return;
  const sp = makeNameTag(p.ship || '', p.nickname, isLaftelCaptain(p)); pm.add(sp); pm.userData.tag = sp;
}
/* 이름표 스프라이트: 한 줄 알약 모양 · 작게 ○○호 + 크게 ○○ 선장 (라프텔 선장 보라 · 비회원 회색) — 다른 선장님 캐릭터도 같이 써요 */
function makeNameTag(ship, nickname, lf){
  const name = `${nickname} 선장`;
  const H = 72, SF = `600 26px ${FB}`, NF = `700 36px ${FB}`, GAP = 10, PAD = 26;
  const mg = document.createElement('canvas').getContext('2d');
  mg.font = SF; const sw = ship ? mg.measureText(ship).width : 0; mg.font = NF; const nw = mg.measureText(name).width;
  const W = Math.ceil(PAD * 2 + sw + (ship ? GAP : 0) + nw) + 4;
  const tex = canvasTex(W, H, (g, w, h) => {
    const r = (h - 4) / 2, x0 = 2, x1 = w - 2, y0 = 2, y1 = h - 2;
    g.fillStyle = lf ? 'rgba(124,77,255,.9)' : 'rgba(96,102,112,.86)';
    g.beginPath(); g.moveTo(x0 + r, y0); g.lineTo(x1 - r, y0); g.arc(x1 - r, y0 + r, r, -Math.PI / 2, Math.PI / 2); g.lineTo(x0 + r, y1); g.arc(x0 + r, y0 + r, r, Math.PI / 2, Math.PI * 1.5); g.closePath(); g.fill();
    g.strokeStyle = lf ? 'rgba(220,205,255,.85)' : 'rgba(220,224,230,.6)'; g.lineWidth = 2; g.stroke();
    g.textBaseline = 'middle'; g.textAlign = 'left'; let x = PAD;
    if (ship){ g.font = SF; g.fillStyle = lf ? '#e6dcff' : '#e4e7ec'; g.fillText(ship, x, h / 2 + 1); x += sw + GAP; }
    g.font = NF; g.fillStyle = '#ffffff'; g.fillText(name, x, h / 2 + 1);
  });
  const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map:tex, transparent:true, depthTest:false, depthWrite:false }));
  const th = 0.2; sp.scale.set(th * W / H, th, 1); sp.position.set(0, 1.7, 0); sp.renderOrder = 10;
  return sp;
}
/* 배 이름이 없는 예전 선장: 처음 들어올 때 한 번만 물어봐요 */
function askShipIfNeeded(){
  const p = LPProfile.get(); if (!p || p.ship) return;
  uiOpen = true; $('#shipAsk').hidden = false; document.body.classList.add('shipask-open');
  setTimeout(() => { try { $('#saShip').focus(); } catch(e){} }, 60);
}
$('#saForm').addEventListener('submit', e => {
  e.preventDefault();
  const r = LPProfile.checkShip($('#saShip').value); if (!r.ok){ $('#saErr').textContent = r.msg; $('#saShip').focus(); return; }
  LPProfile.update({ ship:r.name }); $('#shipAsk').hidden = true; document.body.classList.remove('shipask-open'); uiOpen = false; setWho();
  toast(`<strong>${escHTML(r.name)}</strong> 출항! 머리 위 이름표를 확인해 보세요.`, 3000);
});

/* ---------- 위쪽 빠른 이동 (순간이동 · 타륜 장면 없이) ---------- */
function tpSync(){ document.querySelectorAll('#tpBar [data-tp]').forEach(b => { const on = b.dataset.tp === AREA.id || (b.dataset.tp === 'isle' && AREA.id === 'tavern'); b.setAttribute('aria-current', on ? 'true' : 'false'); }); }
document.querySelectorAll('#tpBar [data-tp]').forEach(b => b.addEventListener('click', () => {
  const to = b.dataset.tp;
  if (to === 'laftel'){ const url = typeof LP_EXTRA !== 'undefined' && LP_EXTRA.laftelHome; if (url) window.location.href = url; else toast('<strong>라프텔로 가기</strong>는 준비 중이에요. 주소가 연결되면 열려요!', 2800); return; }
  if (MODE !== 'cabin') return;
  if (uiOpen || areaBusy || sail.on){ toast('지금 열린 창을 닫고 이동해 주세요.', 2000); return; }
  if (to === AREA.id){ toast(`이미 <strong>${{ cabin:'선장실이에요', deck:'갑판이에요', isle:'다모였섬이에요' }[to]}</strong>.`, 1600); return; }
  goArea(to);
}));

/* ---------- 점프 (Space · 휴대폰은 점프 버튼) ---------- */
function tryJump(){
  if (MODE !== 'cabin' || uiOpen || player.pose === 'steer' || (player.jy || 0) > 0.001) return;
  if (player.pose === 'sit') player.pose = null;
  player.vy = 4.4;
}
window.addEventListener('keydown', e => {
  if ((e.key === ' ' || e.code === 'Space') && !e.repeat && MODE === 'cabin' && !uiOpen){
    const a = document.activeElement; if (a && (a.tagName === 'INPUT' || a.tagName === 'BUTTON' || a.tagName === 'TEXTAREA')) return;
    e.preventDefault(); tryJump();
  }
});
$('#jumpBtn').addEventListener('click', () => tryJump());

/* ---------- 안내 자막: 30분 항해할 때마다 아래로 빠르게 지나가요 ---------- */
const TICKS = [
  '⚓ 너무 많은 항해는 3D 뱃멀미가 날 수도 있어요! 잠깐 쉬어 가요.',
  '🌊 꽤 오래 항해 중이에요. 먼 바다를 보듯 창밖을 20초만 바라봐 주세요.',
  '🍵 선장님, 물 한 잔 마시고 기지개 한 번 켜고 와요!',
  '🧭 어지러우면 망원경 대신 잠깐 눈을 감아요. 바다는 기다려 줘요.',
  '📜 유리병에는 다른 선장님의 개인정보를 담지 말아 주세요.'
];
/* 안내 자막: 항해 30분마다 (확인할 땐 TICK_FIRST=5, TICK_EVERY=120 처럼 줄여 보세요) */
const TICK_FIRST = 1800, TICK_EVERY = 1800;
const tick = { played:0, next:TICK_FIRST, i:0 };
function showTicker(){
  const el = $('#ticker'), tx = $('#tkText'); tx.textContent = TICKS[tick.i % TICKS.length]; tick.i++;
  el.hidden = false; el.classList.remove('run'); void el.offsetWidth; el.classList.add('run');
  clearTimeout(tick.t); tick.t = setTimeout(() => { el.hidden = true; el.classList.remove('run'); }, reduceMotion ? 9000 : 16500);
}
function tickerStep(dt){ if (MODE !== 'cabin' || document.hidden) return; tick.played += dt; if (tick.played >= tick.next){ tick.next += TICK_EVERY; showTicker(); } }

/* 점검용 (주소 끝에 ?lpdebug 를 붙였을 때만) */
if (/[?&]lpdebug\b/.test(location.search)) window.__lpArt = { drawPoster, glassesDraw, GLASSES, blushAvatar, setAvatarGlasses, LPData, openShop, openWardrobe, openBoard, setTipsy, seaSeen, SEA_ZONES, Guide, openInbox };
if (/[?&]lpdebug\b/.test(location.search)) window.__lp = { get p(){ return { x:+player.x.toFixed(2), z:+player.z.toFixed(2), y:+AREA.heightAt(player.x, player.z).toFixed(2), area:AREA.id, pose:player.pose || '', jy:+(player.jy || 0).toFixed(2), wk:+wrist.k.toFixed(2), tag:!!(player.mesh && player.mesh.userData.tag) }; },
  go:(x, z) => goTo(x, z), set:(x, z) => { player.x = x; player.z = z; }, spot:() => { const s = nearSpot(); return s && s.label; }, cam:() => ({ x:+camPos.x.toFixed(2), y:+camPos.y.toFixed(2), z:+camPos.z.toFixed(2) }), ticker:() => showTicker(), boardPic:() => BD.frontCanvas && BD.frontCanvas.toDataURL(), wallPic:() => BD.wallCanvas && BD.wallCanvas.toDataURL() };
boot();
