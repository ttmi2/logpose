/* ============================================================
   LOG POSE · 함께 쓰는 기능의 연결 고리 (lpUse)
   share.js(유리병 · 게시판)와 net.js(절영도에서 서로 보이기)는 lpUse('db' | 'user' | 'room') 만 불러요.
   어디서 열었느냐에 따라 뒤에서 이어 주는 곳이 달라요.
     ① claude.ai 공유 링크  → 페이지의 공유 저장소 · 실시간 방 (window.claude)
     ② 우리 웹사이트       → Supabase (config.json 의 주소 · 공개 키, 방문자는 익명 선장으로 자동 로그인)
     ③ 파일로 열기          → 없음(null) → 각자 브라우저 안의 연습용으로 동작
   Supabase 쪽 표: supabase/schema.sql · 설정 방법: DEPLOY.md
   ============================================================ */
/* ★ 함께 쓰기 스위치: 지금은 꺼 둔 상태(혼자 쓰기). 켜는 방법은 SERVER_NOTES.md
     - claude.ai 공유 링크에서 켜기: 아래 LP_SHARED 를 true 로 (+ 링크에 db · user · room 권한 선언)
     - 우리 웹사이트(Supabase)에서 켜기: config.json 에 "shared": true 와 주소 · 공개 키 */
const LP_SHARED = false;
const lpUse = (() => {
  const cfg = (typeof window !== 'undefined' && window.LP_CONFIG) || {};
  const ON = LP_SHARED || cfg.shared === true;
  const hasClaude = () => typeof window !== 'undefined' && window.claude && typeof window.claude.use === 'function';
  const hasSupa = () => !!(cfg.supabaseUrl && cfg.supabaseAnonKey && typeof window !== 'undefined' && window.supabase && typeof window.supabase.createClient === 'function');

  /* ---------- ② Supabase ---------- */
  let SB = null;
  const supa = () => SB || (SB = (async () => {
    const sb = window.supabase.createClient(cfg.supabaseUrl, cfg.supabaseAnonKey, { auth:{ persistSession:true, autoRefreshToken:true } });
    let { data } = await sb.auth.getSession();
    let user = data && data.session && data.session.user;
    if (!user){ const r = await sb.auth.signInAnonymously(); if (r.error) throw r.error; user = r.data && r.data.user; }
    if (!user) throw new Error('no user');
    return { sb, uid:user.id };
  })().catch(e => { console.warn('[LOG POSE] Supabase 연결 실패 — 연습용으로 동작해요', e); return null; }));

  /* 공유 저장소 흉내: 'docs' 표 한 장에 (col, owner) 마다 문서 하나. 경로는 'col/owner' 꼴만 써요 */
  const snap = (id, data) => ({ id, exists:data != null, data:() => data == null ? undefined : data });
  function supaDb(S){
    const { sb, uid } = S;
    const doc = path => { const [col, owner] = path.split('/');
      return {
        async get(){ const { data, error } = await sb.from('docs').select('data').eq('col', col).eq('owner', owner).maybeSingle(); if (error) throw error; return snap(owner, data ? data.data : null); },
        async set(body){ if (owner !== uid) throw { code:'invalid_argument', message:'own document only' };
          const { error } = await sb.from('docs').upsert({ col, owner:uid, data:body, updated_at:new Date().toISOString() }); if (error) throw error; }
      }; };
    const collection = col => { let n = 400; const q = {
        limit(k){ n = Math.max(1, Math.min(1000, k | 0)); return q; },
        async get(){ const { data, error } = await sb.from('docs').select('owner,data').eq('col', col).order('updated_at', { ascending:false }).limit(n); if (error) throw error;
          const docs = (data || []).map(r => snap(r.owner, r.data)); return { docs, size:docs.length, empty:!docs.length }; },
        doc:id => doc(col + '/' + id) };
      return q; };
    return { doc, collection };
  }
  /* 실시간 방 흉내: Supabase Realtime 채널 하나('logpose-isle')
     ⚠️ Supabase 는 접속 하나당 Presence 업데이트를 30초에 5번까지만 받아요. 넘으면 채널을 닫아 버려요.
     그래서 둘로 나눠 보내요.
       · Presence  = 누가 있는지 + 잘 안 바뀌는 것(장소 · 이름 · 배 · 옷 · 모자). 바뀔 때만, 최소 7초 간격.
       · Broadcast = 자주 바뀌는 것(위치 · 방향 · 점프 · 앉기 · 지금 장소). 최대 1초에 약 3번, 그대로면 3초마다 한 번.
     연결이 끊기면 3초 뒤 저절로 다시 들어가요. net.js 쪽 쓰는 법(presence · onPeers)은 그대로예요. */
  function supaRoom(S){
    const { sb, uid } = S, key = uid + '-' + Math.random().toString(36).slice(2, 8);
    const SLOW = ['a', 'n', 's', 'k', 'o', 'h'];          /* Presence 로 보내는 값 */
    const PRES_GAP = 7000, MOVE_GAP = 300, MOVE_KEEP = 3000, PEER_STALE = 15000;
    let ch = null, alive = true, subscribed = false, retry = 0;
    let mine = {}, peers = [];
    let presSent = '', presAt = 0, presTimer = 0;
    let moveSent = '', moveAt = 0, moveTimer = 0;
    const moves = new Map();                              /* peer key → { m:{...}, t:받은 시각 } */
    const listeners = new Set();
    const slowOf = o => { const r = {}; SLOW.forEach(k => { if (o[k] != null) r[k] = o[k]; }); return r; };
    const fastOf = o => { const r = {}; Object.keys(o).forEach(k => { if (SLOW.indexOf(k) < 0 || k === 'a') r[k] = o[k]; }); if (r.a == null) r.a = null; return r; };

    const rebuild = () => {
      if (!ch) return;
      const st = ch.presenceState(), now = Date.now();
      peers = Object.keys(st).map(k => { const metas = st[k] || [], m = metas[metas.length - 1] || {};
        const { presence_ref, ...slow } = m; void presence_ref;
        if (k === key) return { peer:k, by:null, isMe:true, sameTab:true, kind:'viewer', guest:false, presence:{ ...slow, ...fastOf(mine) }, updatedAt:now };
        const mv = moves.get(k);
        /* 위치를 아직 못 받았거나 오래 소식이 없으면 그리지 않아요 */
        const fresh = mv && now - mv.t < PEER_STALE;
        return { peer:k, by:null, isMe:false, sameTab:false, kind:fresh ? 'viewer' : 'waiting', guest:false,
          presence:fresh ? { ...slow, ...mv.m } : slow, updatedAt:fresh ? mv.t : now };
      });
      [...moves.keys()].forEach(k => { if (!st[k]) moves.delete(k); });
      listeners.forEach(fn => { try { fn({ peers, joined:[], left:[], updated:[] }); } catch(e){} });
    };

    /* Presence: 바뀌었을 때만, 최소 PRES_GAP 간격 */
    const flushPres = () => {
      presTimer = 0; if (!subscribed || !ch) return;
      const want = mine.a ? JSON.stringify(slowOf(mine)) : '';
      if (want === presSent) return;
      const wait = PRES_GAP - (Date.now() - presAt);
      if (wait > 0){ presTimer = setTimeout(flushPres, wait); return; }
      presSent = want; presAt = Date.now();
      (want ? ch.track(slowOf(mine)) : ch.untrack()).catch(() => {});
    };
    /* Broadcast: 위치 · 장소 (최대 MOVE_GAP 간격, 그대로면 MOVE_KEEP 마다 한 번) */
    const sendMove = force => {
      moveTimer = 0; if (!subscribed || !ch) return;
      const body = fastOf(mine), txt = JSON.stringify(body), now = Date.now();
      if (!force && txt === moveSent) return;
      const wait = MOVE_GAP - (now - moveAt);
      if (wait > 0){ moveTimer = setTimeout(() => sendMove(force), wait); return; }
      moveSent = txt; moveAt = now;
      ch.send({ type:'broadcast', event:'mv', payload:{ k:key, m:body } }).catch(() => {});
    };
    const keepTimer = setInterval(() => { if (mine.a && Date.now() - moveAt > MOVE_KEEP) sendMove(true); rebuild(); }, 1000);

    const connect = () => {
      if (!alive) return;
      subscribed = false; presSent = ''; presAt = 0; moveSent = '';
      const c = sb.channel('logpose-isle', { config:{ presence:{ key }, broadcast:{ self:false } } });
      ch = c;
      c.on('presence', { event:'sync' }, rebuild);
      c.on('presence', { event:'join' }, ({ key:k }) => { if (k !== key && mine.a) setTimeout(() => sendMove(true), 300); });
      c.on('broadcast', { event:'mv' }, ({ payload }) => {
        if (!payload || typeof payload.k !== 'string' || payload.k === key || !payload.m || typeof payload.m !== 'object') return;
        moves.set(payload.k, { m:payload.m, t:Date.now() }); rebuild();
      });
      c.subscribe(status => {
        if (c !== ch) return;
        if (status === 'SUBSCRIBED'){ subscribed = true; retry = 0; flushPres(); sendMove(true); }
        else if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT' || status === 'CLOSED'){
          subscribed = false;
          if (!alive) return;
          ch = null; try { sb.removeChannel(c); } catch(e){}
          retry = Math.min(retry + 1, 5);
          setTimeout(connect, 3000 * retry);   /* 3초 · 6초 · … 최대 15초 뒤 다시 들어가요 */
        }
      });
    };
    connect();
    window.addEventListener('pagehide', () => { alive = false; clearInterval(keepTimer); try { if (ch){ ch.untrack(); sb.removeChannel(ch); } } catch(e){} });
    return {
      presence(patch){
        Object.keys(patch || {}).forEach(k => { if (patch[k] === null) delete mine[k]; else mine[k] = patch[k]; });
        if (!presTimer) presTimer = setTimeout(flushPres, 0);
        if (!moveTimer) moveTimer = setTimeout(() => sendMove(false), 0);
        return Promise.resolve(); },
      onPeers(fn){ listeners.add(fn); setTimeout(() => fn({ peers, joined:[], left:[], updated:[] }), 0); return () => listeners.delete(fn); },
      peers:() => peers, connected:() => subscribed
    };
  }

  const cache = {};
  return name => cache[name] || (cache[name] = (async () => {
    if (!ON) return null;   /* 꺼져 있으면 모두 혼자 쓰기(각자 브라우저) */
    if (hasClaude()){ try { return await window.claude.use(name); } catch(e){ return null; } }
    if (!hasSupa()) return null;
    const S = await supa(); if (!S) return null;
    if (name === 'db') return supaDb(S);
    if (name === 'user') return { id:async () => S.uid, can:async () => true };
    if (name === 'room') return supaRoom(S);
    return null;
  })());
})();
/* 지금 함께 쓰는 곳 이름 (화면 표시용) */
const lpBackendLabel = () => (typeof window !== 'undefined' && window.claude && typeof window.claude.use === 'function') ? '이 링크로 들어온 선장님들과 함께 쓰는 바다' : '공용 바다 · 모든 선장님과 함께';
