-- LOG POSE · Supabase 표 만들기 (Supabase → SQL Editor 에 통째로 붙여 넣고 Run)
-- ⚠️ 브라우저 자동 번역을 끄고 붙여 넣으세요. 번역이 명령어까지 바꿔 버려요.
-- 여러 번 실행해도 괜찮아요 (이미 있으면 건너뛰어요).

-- ① 유리병 · 게시판 응원 · 현상금 선장: 선장마다 자기 문서 하나씩 (col, owner)
--    모두 읽을 수 있고, 쓰기 · 고치기 · 지우기는 자기 것만 돼요. 관리자는 대시보드(Table Editor)에서 직접 지워요.
create table if not exists public.docs (
  col        text        not null check (col in ('bottles', 'reports', 'cheers', 'captains')),
  owner      uuid        not null default auth.uid(),
  data       jsonb       not null default '{}'::jsonb check (pg_column_size(data) < 64000),
  updated_at timestamptz not null default now(),
  primary key (col, owner)
);
create index if not exists docs_col_updated on public.docs (col, updated_at desc);
alter table public.docs enable row level security;
drop policy if exists "docs read all"   on public.docs;
drop policy if exists "docs insert own" on public.docs;
drop policy if exists "docs update own" on public.docs;
drop policy if exists "docs delete own" on public.docs;
create policy "docs read all"   on public.docs for select using (true);
create policy "docs insert own" on public.docs for insert to authenticated with check (owner = auth.uid());
create policy "docs update own" on public.docs for update to authenticated using (owner = auth.uid()) with check (owner = auth.uid());
create policy "docs delete own" on public.docs for delete to authenticated using (owner = auth.uid());
grant select on public.docs to anon, authenticated;
grant insert, update, delete on public.docs to authenticated;

-- ② 방문자 기록 (app/track.js 가 남겨요): 누가(무작위 번호) · 언제 · 어디
--    방문자는 쓰기만 되고 읽기는 막아요 → 기록은 팀만 대시보드에서 봐요 (supabase/visits_queries.sql)
create table if not exists public.visits (
  id       uuid        primary key default gen_random_uuid(),
  at       timestamptz not null default now(),
  visitor  text        not null check (char_length(visitor) between 4 and 40),
  session  text        not null check (char_length(session) between 4 and 40),
  event    text        not null default 'visit' check (char_length(event) <= 20),
  area     text        check (char_length(area) <= 20),
  detail   text        check (char_length(detail) <= 60),
  referrer text        check (char_length(referrer) <= 200),
  device   text        check (device in ('pc', 'mobile'))
);
create index if not exists visits_at on public.visits (at desc);
alter table public.visits enable row level security;
drop policy if exists "visits insert anyone" on public.visits;
create policy "visits insert anyone" on public.visits for insert to anon, authenticated
  with check (at > now() - interval '5 minutes' and at < now() + interval '5 minutes');
grant insert on public.visits to anon, authenticated;

-- ③ 공용 섬에서 서로 보이기(실시간)는 표가 필요 없어요. 채널 이름: 'logpose-isle'
