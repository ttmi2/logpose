# 나만의 LOG POSE 만들기 (팀원용 수정 가이드)

> 이 폴더 하나만 있으면 각자 자기 버전의 LOG POSE를 만들고 고칠 수 있어요.
> 다른 사람 버전과는 완전히 따로 움직여요 (기록 · 게시판 · 링크 모두 각자).

## 0. 제일 쉬운 방법: Claude에게 맡기기 (코딩 몰라도 OK)

1. 이 폴더를 **zip 그대로** Claude 대화창에 올려요.
2. 아래 문장을 복사해서 보내요.

```
이 zip은 LOG POSE · 그뭔SHIP 소스야. CUSTOMIZE.md랑 README.md 읽고
똑같이 빌드해서 아티팩트로 게시해 줘. 그다음 내가 말하는 대로 고쳐 줘.
원칙: 공식 이미지·캐릭터·노래 저작권 있는 건 쓰지 말 것, data/original 은 수정 금지.
```

3. 그다음부터는 "주점 노래 바꿔 줘", "강자 ZONE에 운동기구 하나 더" 처럼 말로 시키면 돼요.
4. Claude가 게시한 링크는 **내 계정에서만** 열려요. 남에게 보여주려면 그 페이지의 공유(Share) 메뉴에서 공유하세요.

> 컴퓨터와 Claude 데스크톱 앱을 연결해 두면, Claude가 고친 파일을 이 폴더에 바로 저장해 줘요.

## 1. 직접 고치는 기본 흐름

필요한 것: **Python 3.9+**, **Node.js 18+** (빌드 전에 데이터 점검을 돌려요)

1. `app/` · `web/` · `data/extra/` 안의 파일을 고친다
2. `python3 build.py` 실행 (윈도우: `py build.py`)
3. `dist/logpose.html` 을 브라우저로 열어 확인 (새로고침)

- `dist/` 파일을 직접 고치면 다음 빌드 때 덮어써져요. 항상 원본 파일을 고치세요.
- 빌드 없이 구경만 할 거면 들어 있는 `dist/logpose.html` 을 바로 열어도 돼요.
- 3D 엔진은 인터넷(CDN)에서 받아요. 오프라인이면 안 열려요.

## 2. 바꾸기 쉬운 것 → 어려운 것

| 바꾸고 싶은 것 | 파일 | 위치 / 방법 | 난이도 |
|---|---|---|---|
| 모자 · 옷 · 해적기 가격 | `app/market.js`, `app/cabin.js` | `HATS` · `FLAGS` · `OUTFITS` | ★ |
| 시험용 전부 무료 | `app/market.js` | `TEST_FREE = true` | ★ |
| 물고기 종류 · 값 · 낮/밤 | `app/fish.js` | `FISH` (`night:true` = 밤에만, `day:true` = 낮에만), 보물 물고기 확률 `TREASURE_CATCH` | ★ |
| 도움말('?') 문구 | `app/ambience.js` | `HELP` (공간별 설명) | ★ |
| 방문 기록 · GA4 켜고 끄기 | 저장소 맨 위 `config.json` | `supabaseUrl` · `supabaseAnonKey`(방문 기록) · `gaMeasurementId`(GA4). 비우면 꺼져요. `DEPLOY.md` 맨 위 참고 | ★ |
| 다모였섬 첫 방문 안내(한눈에 보기) 문구 · 카메라 위치 | `app/isletour.js` | `TOUR` (장소마다 제목 · 설명 · 카메라 `pos` · 바라볼 곳 `look`) | ★★ |
| AI 없이 답하는 가이드북 질문 종류 | `app/vendor/guide.js` | `fbFree()` (인사 · 장면 · 인물 · 관계 · 작품 소개 · 추천 · 팁 · 화수 · 다른 작품) | ★★★ |
| 전체 소리 크기 | `app/ambience.js` | `VOL` (지금 0.4) | ★ |
| 현상금 수배서 해적 4명 (이름 · 현상금 · FAMOUS/INFAMOUS) | `app/board.js` | `WANTED_PIRATES` | ★ |
| 강자 ZONE 앵무새 · 원숭이 응원 대사 | `app/gym.js` | `CHEERS` | ★ |
| 강자 ZONE 운동 이름 · 시간 | `app/gym.js` | `GYM_MOVES` | ★★ |
| 미니맵 아이콘 · 이름 | `app/ambience.js` | 맨 아래 `drawBase()` 안 `icon(x, z, '이모지', '이름')` | ★★ |
| 은화 표시 모양 | `web/head.html` | `.lp-silver` CSS | ★★ |
| 주점 노래 (멜로디 · 베이스) | `app/ambience.js` | `TUNE` · `BASS` (MIDI 음 번호, 60 = 가운데 도) | ★★★ |
| 강자 ZONE 노래 | `app/ambience.js` | `G16`(빠르기: `60 / BPM / 4`), `G_DROP`(코드), `G_HOOK`(리드 멜로디), `gymSchedule()`(구간 구성) | ★★★ |
| 바다 · 갈매기 소리 | `app/ambience.js` | `build()` 안 파도 · `gulls()` | ★★★ |
| 강자 ZONE 기구 배치 | `app/gym.js` | `buildPirateGym()` (좌표 x, z / 단위 m) | ★★★ |
| 공용 섬 건물 위치 | `app/isle.js` | `PL` (시장 · 게시판 · 주점 좌표) — 미니맵 아이콘도 같이 바뀌어요 | ★★★ |
| 캐릭터 동작(운동 자세 등) | `app/cabin.js` | `gymLift` · `gymSquat` 같은 pose 처리 | ★★★ |

파일 전체 지도와 자주 바꾸는 값 표는 `README.md` 에 있어요.

## 3. 건드리면 깨지기 쉬운 것 (주의)

- `data/original/` 은 **절대 수정 금지**. 바뀌면 빌드가 멈춰요 (`data/ORIGINAL.sha256` 로 검사).
- `web/body.html` 의 **id 이름**(`id="actBtn"`, `id="toast"` 등)은 바꾸지 마세요. JS가 그 이름으로 찾아요. 문구만 바꾸세요.
- `build.py` 의 `scene_js` **파일 순서**는 바꾸지 마세요. 앞 파일에서 만든 걸 뒤 파일이 써요.
- 새 파일을 만들면 `build.py` 의 `scene_js` 목록에 넣어야 해요 (`gate.js` 앞에).
- 모든 장면 코드는 한 덩어리로 합쳐져요 → **같은 이름의 `const` 를 두 번 만들면** 화면이 안 떠요 (`Identifier 'X' has already been declared` 오류).

## 4. 지켜야 할 원칙

- **저작권**: 공식 이미지 · 캐릭터 · 작품 의상 · 노래(가사 · 멜로디 포함)는 쓰지 않아요. 전부 직접 만든 오리지널만.
- **공용 섬은 평화지대**예요. 특정 해적단이 지배하는 섬처럼 쓰지 않아요 (헬스장 이름도 '강자 ZONE').
- 라프텔 주소 · 작품 정보는 지어내지 않아요. 모르면 비워 두고 '준비 중'.
- 스포일러 방지 규칙은 `README.md` 의 '원칙' 참고.

## 5. 파일로 열 때 안 되는 기능

게시판 공유 · 실시간 접속자(미니맵의 다른 선장 점) · AI 질문은 **claude.ai 아티팩트로 게시했을 때만** 돼요.
`dist/logpose.html` 을 그냥 열면 혼자 쓰기 모드로 동작하고, 기록은 각자 브라우저에만 저장돼요.
자기 링크가 필요하면 Claude에 `dist/logpose.html` 을 올리고 "이 파일을 아티팩트로 게시해 줘"라고 하면 새 링크와 새 게시판이 생겨요.

## 6. 이번 개조판에서 추가된 것 (원본 대비)

- 배경 소리: 바다 · 갈매기 · 주점 노래(오리지널) · 강자 ZONE 운동 노래(오리지널, 빌드업 → 드롭) — 위쪽 🔊 버튼으로 켜고 끄기
- 위쪽 '?' 도움말, 화질 자동/높음/낮음(⚙)
- 망루 오르기 · 항해 지도 펼치기 연출
- 낮/밤에 따라 다른 물고기
- 현상금 게시판 옆 오리지널 해적 수배서 4장
- 게시판 뒤 해적 헬스장 **강자 ZONE** (밧줄 오르기 · 턱걸이 · 덤벨 · 스쿼트 · 배틀로프 · 캡스턴 · 키 돌리기 · 벤치, 앵무새/원숭이 응원)
- 위쪽 '나가기' 아래 **은화 보유액**
- 공용 섬 **미니맵** (내 위치 실시간 · 누르면 그쪽으로 이동 · 접기 가능)
- '응원할 캐릭터 찾기' 한글 입력 오류 수정

## 7. 11/24 팀 회의 수정 (Claude)

| 바뀐 것 | 고치는 곳 |
| --- | --- |
| 공용 섬 이름 절영도 → **다모였섬** | 화면 문구 전체 (`app/*.js`, `web/*.html`) |
| 첫 화면에 기획 의도 + 세 기둥(로그포스 · 항해일지 · 다모였섬) | `web/body.html` 의 `.g-why`, 스타일은 `web/head.html` |
| 유리병: 등장인물 이름 허용, 흔한 말('웃겨 죽겠다', '노스포')은 통과, 다모였섬에서 낚기 켬 | `app/fish.js` `SPOIL_SAFE` · `ISLE_BOTTLES` · `BOTTLE_CATCH`(1%), `app/works.js` `laterOf` |
| 주점 맥주: 마실수록 얼굴이 빨개짐 (4단계, 4잔이면 휘청) · 다른 선장에게도 보임 | `app/market.js` `setTipsy` · `blushAvatar` |
| 생선 가게 칠판 이젤 다리가 칠판을 뚫던 것 수정 | `app/marketplace.js` '생선 삽니다 칠판' |
| **안경** 6종 (시장 모자·옷 가게 '안경' 탭 · 선장실 옷장 · 다른 선장에게도 보임) | `app/market.js` `GLASSES` · `glassesMesh` · `glassesDraw` |
| 주점 현상금 수배서: 기본은 **내 캐릭터 모습**(옷·모자·안경), 원하면 **사진**으로 | `app/board.js` `captainArt` · `posterEditor`, 저장은 `app/share.js` `putCaptain` |
| 갑판 바다를 **장르 6해역(A~F)**으로 나눔: 해역마다 작은 섬 · 이정표 · 깃발, 경계에 부표 · 망루에서 해역 이름 | `app/seas.js` (위치 `SEA_ANGLES` · `SEA_R`) · `app/nest.js` |
| 공용 섬 실시간 위치: Supabase 한도에 맞게 Presence + Broadcast 로 나눔 | `app/backend.js` `supaRoom` |
| 라프텔 항해일지(AI 길잡이) 답변: "○○ 장면 설명해 줘"를 인물 소개 대신 **그 장면**으로 답함 · 못 찾을 땐 장면 줄거리에서 비슷한 곳을 찾아 답함 | `app/vendor/guide.js` `sceneHits` · `SC_SYN`(말 바꿔 찾기) · `SCENE_ASK` |
