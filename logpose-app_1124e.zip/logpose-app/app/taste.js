/* ============================================================
   LOG POSE · 취향 탐색 (단계 3)
   게임 상태창처럼 뜨는 세 질문. 답은 선장 기록(LPProfile)에 저장해요.
   Q1 본 작품(검색 · 최대 3 · '없어요')  Q2 중요하게 보는 것(1~2)  Q3 좋아하는 장르(1~2)
   ============================================================ */
const VALUES = [
  { id:'world',     name:'탄탄한 세계관', desc:'설정과 규칙이 촘촘해서 빠져드는 세계',
    icon:'<svg viewBox="0 0 32 32" aria-hidden="true"><circle cx="16" cy="16" r="11" fill="none" stroke="currentColor" stroke-width="2"/><path d="M5 16h22M16 5c4 4 4 18 0 22M16 5c-4 4-4 18 0 22" fill="none" stroke="currentColor" stroke-width="1.6"/></svg>' },
  { id:'art',       name:'작화',         desc:'그림과 연출, 전투 장면이 눈을 사로잡는 작품',
    icon:'<svg viewBox="0 0 32 32" aria-hidden="true"><path d="M22 4l6 6-13 13-7 2 2-7z" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/><path d="M19 7l6 6" stroke="currentColor" stroke-width="1.6"/></svg>' },
  { id:'character', name:'캐릭터',       desc:'정이 가고 응원하게 되는 인물들',
    icon:'<svg viewBox="0 0 32 32" aria-hidden="true"><circle cx="16" cy="11" r="5.5" fill="none" stroke="currentColor" stroke-width="2"/><path d="M6 27c1.5-6 5.5-9 10-9s8.5 3 10 9" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>' }
];
const MAX_SEEN = 3, MAX_PICK = 2;
const escHTML = s => String(s).replace(/[&<>"']/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c]));
const Q = { root:$('#quiz'), title:$('#qTitle'), hint:$('#qHint'), body:$('#qBody'), prev:$('#qPrev'), next:$('#qNext'), count:$('#qCount'), dots:$('#qDots') };
let qStep = 0, qDraft = null, qQuery = '';

const blankDraft = () => ({ seen:[], none:false, values:[], genres:[] });
function saveDraft(){ LPProfile.update({ tasteDraft:qDraft }); }

function openQuiz(){
  const p = LPProfile.get(); if (!p) return;
  qDraft = Object.assign(blankDraft(), p.tasteDraft || {});
  qStep = 0; qQuery = '';
  uiOpen = true; keys.clear(); auto = null;
  Q.root.hidden = false; document.body.classList.add('quiz-open'); $('#toast').hidden = true;
  pulseLogpose(); renderQuiz();
}
function closeQuiz(done){
  Q.root.hidden = true; document.body.classList.remove('quiz-open');
  uiOpen = false;
  if (!done){
    const p = LPProfile.get();
    if (p && p.onboarded){ LPProfile.update({ tasteDraft:null }); toast('취향은 <strong>그대로</strong> 두었어요.'); }
    else toast('언제든 오른쪽 <strong>로그포스</strong> 버튼으로 이어서 답할 수 있어요.');
  }
}
function finishQuiz(){
  const taste = { seen:qDraft.none ? [] : qDraft.seen.slice(), none:qDraft.none, values:qDraft.values.slice(), genres:qDraft.genres.slice(), at:new Date().toISOString() };
  LPProfile.update({ taste, tasteDraft:null, onboarded:true });
  closeQuiz(true); pulseLogpose();
  toast('기록 완료! 손목의 <strong>로그포스</strong>가 선장님의 취향을 읽고 있어요.', 4200);
  if (typeof onTasteDone === 'function') onTasteDone(taste);   // 단계 4에서 추천으로 이어져요
}

/* 단계별 화면 */
const STEPS = [
  { title:'지금까지 본 애니메이션을 골라 주세요', hint:`최대 ${MAX_SEEN}개까지 고를 수 있어요. 제목이나 초성으로 찾아보세요.`, ok:() => qDraft.none || qDraft.seen.length > 0, render:renderSeen },
  { title:'애니메이션을 볼 때 무엇을 중요하게 보나요?', hint:`1~${MAX_PICK}개를 골라 주세요.`, ok:() => qDraft.values.length > 0, render:renderValues },
  { title:'평소 좋아하는 장르는 무엇인가요?', hint:`1~${MAX_PICK}개를 골라 주세요.`, ok:() => qDraft.genres.length > 0, render:renderGenres }
];
function renderQuiz(){
  const st = STEPS[qStep];
  Q.title.textContent = st.title; Q.hint.textContent = st.hint;
  Q.dots.innerHTML = STEPS.map((_, i) => `<li class="${i < qStep ? 'done' : i === qStep ? 'now' : ''}" aria-label="${i + 1}단계${i === qStep ? ' (지금)' : ''}"></li>`).join('');
  Q.count.textContent = `${qStep + 1} / ${STEPS.length}`;
  Q.prev.disabled = qStep === 0;
  Q.next.textContent = qStep === STEPS.length - 1 ? '기록 완료' : '다음';
  st.render();
  Q.next.disabled = !st.ok();
}

/* Q1: 본 작품 */
function renderSeen(){
  const chips = qDraft.seen.map(id => { const w = LPData.get(id); return w ? `<button type="button" class="q-chip" data-rm="${id}" aria-label="${escHTML(w.title)} 빼기">${escHTML(w.title)} <span aria-hidden="true">✕</span></button>` : ''; }).join('');
  Q.body.innerHTML = `
    <div class="q-chips" aria-live="polite">${chips || '<span class="q-empty">아직 고른 작품이 없어요</span>'}</div>
    <label class="q-search"><span class="sr">작품 찾기</span>
      <input id="qSearch" type="search" placeholder="예: 진격, ㄱㅁ, 프리렌" autocomplete="off" value="${escHTML(qQuery)}" ${qDraft.none ? 'disabled' : ''}>
    </label>
    <div class="q-results" id="qResults"></div>
    <button type="button" class="q-none" id="qNone" aria-pressed="${qDraft.none}">본 작품이 없어요</button>`;
  renderResults();
  const inp = $('#qSearch');
  inp.addEventListener('input', () => { qQuery = inp.value; renderResults(); });
  Q.body.querySelectorAll('[data-rm]').forEach(b => b.addEventListener('click', () => { qDraft.seen = qDraft.seen.filter(x => x !== b.dataset.rm); saveDraft(); renderQuiz(); }));
  $('#qNone').addEventListener('click', () => {
    qDraft.none = !qDraft.none; if (qDraft.none) qDraft.seen = [];
    saveDraft();
    if (qDraft.none){ qStep = 1; }
    renderQuiz();
  });
  if (!qDraft.none) setTimeout(() => { try { inp.focus({ preventScroll:true }); } catch(e){} }, 40);
}
function renderResults(){
  const box = $('#qResults'); if (!box) return;
  if (qDraft.none){ box.innerHTML = ''; return; }
  const full = qDraft.seen.length >= MAX_SEEN;
  const list = qQuery.trim() ? LPData.search(qQuery).slice(0, 6) : LPData.all().filter(w => w.isRep);
  const head = qQuery.trim() ? '' : '<p class="q-sub">장르별 대표작</p>';
  box.innerHTML = head + (list.length ? list.map(w => {
    const on = qDraft.seen.includes(w.id);
    return `<button type="button" class="q-res${on ? ' on' : ''}" data-add="${w.id}" ${!on && full ? 'disabled' : ''} aria-pressed="${on}">
      <span class="q-dot" style="background:hsl(${w.genre.hue},45%,42%)"></span><b>${escHTML(w.title)}</b><small>${escHTML(w.genre.name)}</small></button>`;
  }).join('') : `<p class="q-sub">"${escHTML(qQuery)}"에 맞는 작품이 아직 없어요.</p>`) + (full ? `<p class="q-sub">${MAX_SEEN}개를 모두 골랐어요. 바꾸려면 위에서 ✕를 눌러 주세요.</p>` : '');
  box.querySelectorAll('[data-add]').forEach(b => b.addEventListener('click', () => {
    const id = b.dataset.add;
    if (qDraft.seen.includes(id)) qDraft.seen = qDraft.seen.filter(x => x !== id);
    else if (qDraft.seen.length < MAX_SEEN){ qDraft.seen.push(id); qDraft.none = false; }
    saveDraft(); renderQuiz();
  }));
}

/* Q2 · Q3: 카드 고르기 (최대 2개) */
function pickCards(list, key, card){
  Q.body.innerHTML = `<div class="q-cards ${key}">${list.map(card).join('')}</div><p class="q-sub" id="qMax" role="status"></p>`;
  Q.body.querySelectorAll('[data-pick]').forEach(b => b.addEventListener('click', () => {
    const id = b.dataset.pick, arr = qDraft[key];
    if (arr.includes(id)) qDraft[key] = arr.filter(x => x !== id);
    else if (arr.length < MAX_PICK) arr.push(id);
    else { $('#qMax').textContent = `최대 ${MAX_PICK}개까지 고를 수 있어요. 하나를 먼저 빼 주세요.`; return; }
    saveDraft(); renderQuiz();
  }));
}
function renderValues(){
  pickCards(VALUES, 'values', v => { const on = qDraft.values.includes(v.id);
    return `<button type="button" class="q-card${on ? ' on' : ''}" data-pick="${v.id}" aria-pressed="${on}"><span class="q-ic">${v.icon}</span><b>${v.name}</b><small>${v.desc}</small></button>`; });
}
function renderGenres(){
  pickCards(LPData.genres(), 'genres', g => { const on = qDraft.genres.includes(g.id);
    return `<button type="button" class="q-card g${on ? ' on' : ''}" data-pick="${g.id}" aria-pressed="${on}" style="--gh:${g.hue}"><span class="q-sw"></span><b>${escHTML(g.name)}</b><small>${escHTML(g.tag)}</small></button>`; });
}

Q.prev.addEventListener('click', () => { if (qStep > 0){ qStep--; renderQuiz(); } });
Q.next.addEventListener('click', () => { if (!STEPS[qStep].ok()) return; if (qStep < STEPS.length - 1){ qStep++; renderQuiz(); } else finishQuiz(); });
$('#qLater').addEventListener('click', () => closeQuiz(false));
window.addEventListener('keydown', e => { if (!Q.root.hidden && e.key === 'Escape'){ e.preventDefault(); closeQuiz(false); } });

/* 오른쪽 로그포스 버튼: 취향 기록 전이면 질문, 끝났으면 로그포스 메뉴 (menu.js) */
function onLogposeButton(){
  const p = LPProfile.get(); if (!p) return;
  if (!p.onboarded){ lookWrist(openQuiz); return; }
  if (menuOpen()) closeMenu(); else lookWrist(() => openMenu());
}
