/* ============================================================
   LOG POSE · 작품 연결부
   기존 데이터(data/original, 수정 금지)를 읽어서 화면·추천이 쓰기 좋은 한 모양으로 꺼내요.
   - 데이터를 바꾸지 않아요. 읽기만 해요.
   - 팀이 나중에 주는 정보(라프텔 주소·이미지·작품별 강점)는 data/extra 의 LP_EXTRA 로 받아요.
   - 없는 정보는 null / 빈 배열로 둬요. 지어내지 않아요.
   ============================================================ */
const LPData = (() => {
  const EXTRA = (typeof LP_EXTRA !== 'undefined' && LP_EXTRA) ? LP_EXTRA : {};
  const extra = key => EXTRA[key] || {};
  const clean = s => String(s == null ? '' : s).replace(/\*\*/g, '').trim();

  /* 순서: 장르 순서 → 장르 안에서 대표작 먼저, 나머지는 기존 목록 순서 */
  const ORDER = [];
  for (const g of GENRES){
    const ids = CATALOG[g.id].map(r => r[0]);
    ORDER.push(g.rep, ...ids.filter(id => id !== g.rep));
  }
  const IDS = ORDER.filter((id, i) => WORKS[id] && ORDER.indexOf(id) === i);

  /* 1화에 처음 나오는 인물·용어만, 그것도 1화 시점 설명 첫 줄만 → 스포일러 없음 */
  const firstEp1Fact = o => { const f = (o.facts || []).find(x => x[0][0] === 1); return f ? clean(f[1]) : ''; };
  function castOf(G){
    if (!G || !G.chars) return [];
    return Object.values(G.chars)
      .filter(c => c.at && c.at[0] === 1)
      .sort((a, b) => a.at[1] - b.at[1])
      .map(c => ({ name:clean(c.name), intro:firstEp1Fact(c) }))
      .filter(c => c.intro);
  }
  /* 모든 등장인물 이름 (수배서 게시판용 · 설명 없이 이름과 처음 나오는 회차만) */
  function charsOf(G){
    if (!G || !G.chars) return [];
    const seen = new Set();
    return Object.values(G.chars).filter(c => c.at).sort((a, b) => a.at[0] - b.at[0] || a.at[1] - b.at[1])
      .map(c => ({ name:clean(c.name), ep:c.at[0] })).filter(c => c.name && !seen.has(c.name) && seen.add(c.name));
  }
  function termsOf(G){
    if (!G || !G.terms) return [];
    return Object.values(G.terms)
      .filter(t => t.at && t.at[0] === 1)
      .map(t => ({ name:clean(t.name), text:clean(t.easy) || firstEp1Fact(t) }))
      .filter(t => t.text);
  }

  /* 1화 뒤에 처음 나오는 용어 이름 (유리병 한줄평 스포일러 거르기용, 화면에는 안 보여요) */
  function laterOf(G){
    if (!G) return [];
    const ep1 = [G.chars, G.terms].flatMap(o => o ? Object.values(o).filter(x => x.at && x.at[0] === 1).map(x => clean(x.name)) : []).filter(Boolean);
    const out = new Set();
    /* 등장인물 이름은 써도 돼요 (팀 회의 11/24). 1화 뒤에 처음 나오는 '용어'만 걸러요 */
    [[G.terms, 3]].forEach(([o, min]) => o && Object.values(o).forEach(x => {
      if (!x.at || x.at[0] <= 1) return;
      const n = clean(x.name).replace(/\s*\(.*\)$/, '');
      if (!n || n.length < min) return;
      if (ep1.some(e => e.includes(n) || n.includes(e))) return;   /* 1화 인물과 겹치는 이름은 빼요 */
      out.add(n);
    }));
    return [...out];
  }
  const cache = {};
  function get(id){
    if (cache[id]) return cache[id];
    const W = WORKS[id]; if (!W) return null;
    const g = GENRE[W.shelf], B = W.book || {}, G = W.guide || null;
    const ep1 = G && G.episodes && G.episodes[1] ? { title:clean(G.episodes[1].title), summary:clean(G.episodes[1].summary) } : null;
    const w = {
      id, title:W.title,
      genre:{ id:g.id, name:g.name, zone:g.zone, hue:g.hue, tag:g.tag },
      isRep:!!W.rep,
      line:clean(W.line),                                        // 한 줄 소개 (63편 모두)
      summary:clean(B.lede || W.line),                           // 간단한 줄거리: 대표작은 소개글, 나머지는 한 줄 소개
      /* 주요 특징: 대표작의 관전 포인트만. 나머지 57편의 points 는 guides_post.js 가 1~2화 줄거리로 채운 것이라(스포일러) 쓰지 않아요 */
      features:W.rep ? (B.points || []).map(clean).filter(Boolean) : [],
      tips:(B.tips || []).map(clean).filter(Boolean),
      tags:(B.tags || []).filter(t => t !== g.name && !/^가이드북/.test(t)),
      later:laterOf(G),
      chars:charsOf(G),
      cast:castOf(G),                                            // 1화에 등장하는 인물의 1화 시점 설명
      terms:termsOf(G),                                          // 1화에 나오는 용어
      ep1,                                                       // 1화 미리보기 (접어서 보여줘요: 1화 결말까지 담겨 있음)
      eps:G ? G.eps : 0, season:G ? clean(G.season) : '',
      hasGuide:!!G,
      cover:W.cover || null,                                     // 코드로 그리는 표지 재료
      laftelUrl:extra('laftel')[id] || null,                     // 팀 제공 전까지 null
      image:extra('images')[id] || null,                         // 팀 제공 전까지 null
      strengths:extra('strengths')[id] || []                     // 'world' | 'art' | 'character'
    };
    return (cache[id] = w);
  }

  /* 한글 초성 검색 */
  const CHO = 'ㄱㄲㄴㄷㄸㄹㅁㅂㅃㅅㅆㅇㅈㅉㅊㅋㅌㅍㅎ';
  const choOf = s => Array.from(s).map(ch => { const c = ch.charCodeAt(0) - 0xAC00; return c >= 0 && c < 11172 ? CHO[Math.floor(c / 588)] : ch; }).join('');
  const norm = s => String(s).toLowerCase().replace(/[\s·:!?×()（）\-]/g, '');
  function search(q){
    const n = norm(q); if (!n) return [];
    const onlyCho = /^[ㄱ-ㅎ]+$/.test(n);
    const hits = [];
    for (const id of IDS){
      const w = get(id), t = norm(w.title);
      let score = -1;
      if (t.startsWith(n)) score = 3; else if (t.includes(n)) score = 2;
      else if (onlyCho && choOf(t).includes(n)) score = 1;
      else if (w.cast.some(c => norm(c.name).includes(n))) score = 0.5;
      if (score >= 0) hits.push([score, id]);
    }
    return hits.sort((a, b) => b[0] - a[0]).map(h => get(h[1]));
  }

  return {
    ids:() => IDS.slice(),
    all:() => IDS.map(get),
    get,
    byGenre:gid => IDS.map(get).filter(w => w.genre.id === gid),
    genres:() => GENRES.map(g => ({ id:g.id, name:g.name, zone:g.zone, hue:g.hue, tag:g.tag, rep:g.rep })),
    search
  };
})();
