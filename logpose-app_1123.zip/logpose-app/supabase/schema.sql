-- LOG POSE · Supabase 표 만들기 (Supabase → SQL Editor 에 통째로 붙여 넣고 Run)
-- 선장마다 자기 문서 하나씩만 써요: col = 'bottles' | 'reports' | 'cheers' | 'captains', owner = 익명 로그인 id
-- 모두 읽을 수 있고, 쓰기·고치기·지우기는 자기 것만 돼요. 관리자는 Supabase 대시보드(Table Editor)에서 직접 지워요.

create table if not exists public.docs (
  col        text        not null check (col in ('bottles', 'reports', 'cheers', 'captains')),
  owner      uuid        not null default auth.uid(),
  data       jsonb       not null default '{}'::jsonb check (pg_column_size(data) < 64000),
  updated_at timestamptz not null default now(),
  primary key (col, owner)
);
create index if not exists docs_col_updated on public.docs (col, updated_at desc);

alter table public.docs enable row level security;

drop policy if exists "docs read all"   on public.docs;
drop policy if exists "docs insert own" on public.docs;
drop policy if exists "docs update own" on public.docs;
drop policy if exists "docs delete own" on public.docs;

create policy "docs read all"   on public.docs for select using (true);
create policy "docs insert own" on public.docs for insert to authenticated with check (owner = auth.uid());
create policy "docs update own" on public.docs for update to authenticated using (owner = auth.uid()) with check (owner = auth.uid());
create policy "docs delete own" on public.docs for delete to authenticated using (owner = auth.uid());

-- 공용 섬에서 서로 보이기(Realtime Presence)는 표가 필요 없어요. 채널 이름: 'logpose-isle'
