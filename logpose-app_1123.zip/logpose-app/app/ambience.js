/* ============================================================
   LOG POSE · 바다 소리(배경음) + 카메라 연출 도우미
   - 바다 소리: 파도 · 바람 · 갈매기 · 배 삐걱임을 소리 파일 없이 브라우저에서 만들어요(Web Audio).
     주점 럼통에선 직접 만든 뱃노래(6/8박 아코디언 · 베이스 · 발 구르기)가 흘러요.
     절영도 강자 ZONE 근처에선 바다 소리가 서서히 사라지고 직접 만든 에픽 록 운동 음악(150BPM)이 깔려요.
     위쪽 '바다 소리' 버튼으로 켜고 꺼요. 선장실에선 벽 너머처럼 먹먹하게, 망루에선 바람이 세게 들려요.
   - camTween: 망루 오르기 · 항해 지도 펼치기 같은 카메라 이동을 부드럽게 그려요.
   ============================================================ */
const SEA_PREF_KEY = 'logpose.bgm';
const SeaSnd = (() => {
  let ctx = null, out = null, filt = null, sea = null, windG = null, padG = null, tav = null, built = false, timers = [];
  let on = (() => { try { return localStorage.getItem(SEA_PREF_KEY) !== '0'; } catch(e){ return true; } })();
  const VOL = 0.4;
  function noise(sec, pink){
    const n = Math.floor(ctx.sampleRate * sec), b = ctx.createBuffer(1, n, ctx.sampleRate), d = b.getChannelData(0);
    let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0;
    for (let i = 0; i < n; i++){ const w = Math.random()*2 - 1;
      if (!pink){ d[i] = w; continue; }
      b0 = .99886*b0 + w*.0555179; b1 = .99332*b1 + w*.0750759; b2 = .969*b2 + w*.153852; b3 = .8665*b3 + w*.3104856; b4 = .55*b4 + w*.5329522; b5 = -.7616*b5 - w*.016898;
      d[i] = (b0 + b1 + b2 + b3 + b4 + b5 + b6 + w*.5362)*0.11; b6 = w*.115926; }
    return b;
  }
  const src = buf => { const s = ctx.createBufferSource(); s.buffer = buf; s.loop = true; s.start(); return s; };
  function lfo(freq, depth, param, base){ param.value = base; const o = ctx.createOscillator(), g = ctx.createGain(); o.frequency.value = freq; g.gain.value = depth; o.connect(g); g.connect(param); o.start(); return o; }
  /* 갈매기: '끼룩—' 하고 올라갔다 떨어지는 소리. 가끔 두세 마리가 주고받아요 */
  function gullCall(t0, pitch, vol){
    const o = ctx.createOscillator(), o2 = ctx.createOscillator(), bp = ctx.createBiquadFilter(), g = ctx.createGain(), vib = ctx.createOscillator(), vg = ctx.createGain();
    o.type = 'sawtooth'; o2.type = 'square'; bp.type = 'bandpass'; bp.Q.value = 3.5;
    const f0 = 1150*pitch, f1 = 1900*pitch, f2 = 900*pitch, dur = 0.42 + Math.random()*0.18;
    [o, o2].forEach((x, i) => { x.frequency.setValueAtTime(f0*(i ? 1.005 : 1), t0); x.frequency.linearRampToValueAtTime(f1, t0 + dur*0.28); x.frequency.exponentialRampToValueAtTime(f2, t0 + dur); });
    bp.frequency.setValueAtTime(1700*pitch, t0); bp.frequency.linearRampToValueAtTime(2300*pitch, t0 + dur*0.3); bp.frequency.linearRampToValueAtTime(1300*pitch, t0 + dur);
    vib.frequency.value = 28; vg.gain.value = 40; vib.connect(vg); vg.connect(o.frequency); vg.connect(o2.frequency);
    g.gain.setValueAtTime(0, t0); g.gain.linearRampToValueAtTime(vol, t0 + 0.05); g.gain.setValueAtTime(vol*0.8, t0 + dur*0.5); g.gain.exponentialRampToValueAtTime(0.0005, t0 + dur);
    const mix = ctx.createGain(); mix.gain.value = 0.5; o2.connect(mix); o.connect(bp); mix.connect(bp); bp.connect(g); g.connect(sea);
    [o, o2, vib].forEach(x => { x.start(t0); x.stop(t0 + dur + 0.05); });
  }
  function gulls(){
    if (on && ctx.state === 'running' && (mode === 'deck' || mode === 'nest')){
      const t = ctx.currentTime + 0.05, birds = 1 + Math.floor(Math.random()*3);
      for (let b = 0; b < birds; b++){ const pitch = 0.85 + Math.random()*0.35, vol = (b ? 0.05 : 0.085) * (mode === 'nest' ? 1.2 : 1), calls = 2 + Math.floor(Math.random()*3), t1 = t + b*(0.6 + Math.random()*0.8);
        for (let c = 0; c < calls; c++) gullCall(t1 + c*(0.32 + Math.random()*0.12), pitch * (c ? 0.97 : 1), vol * (c ? 0.85 : 1)); }
    }
    timers.push(setTimeout(gulls, 5000 + Math.random()*8000));
  }
  /* ---------- 주점 럼통: 오리지널 뱃노래 (6/8박, 아코디언 · 베이스 · 발 구르기 + 웅성거림) ---------- */
  const N = m => 440 * Math.pow(2, (m - 69)/12);
  /* 그뭔쉽 주점가 — 직접 만든 곡이에요 (다른 노래를 베끼지 않았어요). [음높이, 8분음표 개수], 0은 쉼 */
  const TUNE = [
    [62,1],[65,1],[69,1],[69,2],[67,1], [65,1],[64,1],[62,1],[64,3],
    [65,1],[67,1],[69,1],[72,2],[70,1], [69,3],[0,3],
    [70,1],[69,1],[67,1],[65,2],[67,1], [69,1],[67,1],[65,1],[64,3],
    [62,1],[64,1],[65,1],[67,2],[64,1], [62,3],[0,3],
    [69,1],[72,1],[74,1],[74,2],[72,1], [70,1],[69,1],[67,1],[69,3],
    [65,1],[67,1],[69,1],[70,2],[69,1], [67,3],[0,3],
    [70,1],[69,1],[67,1],[65,2],[64,1], [65,1],[67,1],[64,1],[62,3],
    [61,2],[64,1],[69,3], [62,6],
  ];
  const BASS = [50, 46, 53, 57, 46, 48, 43, 50, 57, 53, 55, 52, 46, 45, 45, 50];   /* 마디마다 근음 */
  const E8 = 0.19;   /* 8분음표 길이(초) */
  let tavOn = false, tavNext = 0, tavIdx = 0, tavBeat = 0, tavLoop = null, crowd = null;
  function accordion(t, f, dur, vol){
    const g = ctx.createGain(), lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 2200; lp.Q.value = 0.8;
    [-6, 6].forEach(cents => { const o = ctx.createOscillator(); o.type = 'sawtooth'; o.frequency.value = f; o.detune.value = cents; o.connect(lp); o.start(t); o.stop(t + dur + 0.08); });
    const o3 = ctx.createOscillator(); o3.type = 'square'; o3.frequency.value = f/2; const g3 = ctx.createGain(); g3.gain.value = 0.25; o3.connect(g3); g3.connect(lp); o3.start(t); o3.stop(t + dur + 0.08);
    g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(vol, t + 0.03); g.gain.setValueAtTime(vol*0.85, t + dur*0.7); g.gain.linearRampToValueAtTime(0, t + dur + 0.06);
    lp.connect(g); g.connect(tav);
  }
  function pluck(t, f, vol){ const o = ctx.createOscillator(), g = ctx.createGain(); o.type = 'triangle'; o.frequency.value = f; g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.45); o.connect(g); g.connect(tav); o.start(t); o.stop(t + 0.5); }
  function stomp(t, vol){ const o = ctx.createOscillator(), g = ctx.createGain(); o.type = 'sine'; o.frequency.setValueAtTime(120, t); o.frequency.exponentialRampToValueAtTime(45, t + 0.12); g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.16); o.connect(g); g.connect(tav); o.start(t); o.stop(t + 0.2); }
  function clink(t){ const o = ctx.createOscillator(), g = ctx.createGain(); o.type = 'sine'; o.frequency.value = 2600 + Math.random()*900; g.gain.setValueAtTime(0.03, t); g.gain.exponentialRampToValueAtTime(0.0005, t + 0.25); o.connect(g); g.connect(tav); o.start(t); o.stop(t + 0.3); }
  function tavSchedule(){
    if (!tavOn) return;
    const ahead = ctx.currentTime + 0.35;
    while (tavNext < ahead){
      const [m, len] = TUNE[tavIdx], dur = len * E8;
      if (m) accordion(tavNext, N(m), dur - 0.03, 0.16);
      for (let k = 0; k < len; k++){ const t = tavNext + k*E8, beat = (tavBeat + k) % 6, bar = Math.floor((tavBeat + k) / 6) % BASS.length;
        if (beat === 0){ pluck(t, N(BASS[bar]), 0.32); stomp(t, 0.4); }
        if (beat === 3){ pluck(t, N(BASS[bar] + 7), 0.22); stomp(t, 0.25); }
        if ((beat === 2 || beat === 5) && Math.random() < 0.08) clink(t + 0.02); }
      tavBeat += len; tavNext += dur; tavIdx = (tavIdx + 1) % TUNE.length;
      if (tavIdx === 0){ tavBeat = 0; tavNext += E8 * 3; }
    }
  }
  function tavern(onNow){
    if (!built) return;
    const t = ctx.currentTime;
    if (onNow && !tavOn){ tavOn = true; tavIdx = 0; tavBeat = 0; tavNext = t + 0.4; tav.gain.setTargetAtTime(1.6, t, 0.4); crowd.gain.setTargetAtTime(0.05, t, 0.8); tavLoop = setInterval(tavSchedule, 90); }
    else if (!onNow && tavOn){ tavOn = false; clearInterval(tavLoop); tav.gain.setTargetAtTime(0, t, 0.3); crowd.gain.setTargetAtTime(0, t, 0.4); }
  }
  /* ---------- 강자 ZONE: 직접 만든 운동 음악 v3 "BREAK THE TIDE" ----------
     오리지널 에픽 록/일렉트로 (150BPM) — 특정 곡을 베끼지 않았어요.
     16마디 한 바퀴:  ① 빌드업 4마디(스네어 롤 가속 + 라이저 + 떼창)  →  0.1초 정적  →  ② 💥 드롭 8마디(임팩트 + 크래시,
     4비트 킥 + 사이드체인 펌핑, 2·4박 스네어, 갤럽 기타 리프, 그로울 베이스, 슈퍼소 리드 훅, 금관)  →  ③ 하프타임 스톰프 4마디 → 다시 빌드업 */
  const G16 = 60 / 150 / 4;
  const G_DROP = [38, 34, 41, 36];                    /* Dm  Bb  F  C  (i - VI - III - VII) */
  const G_STOMP = [38, 38, 34, 36];
  const G_GALLOP = [2, 0, 1, 1, 1, 0, 1, 1, 2, 0, 1, 1, 1, 0, 2, 0];   /* 1: 팜뮤트 칙 · 2: 크게 터지는 코드 */
  const G_HOOK = [                                     /* [16분 위치, 음, 길이] — 4마디 리드 훅 */
    [[0,74,3],[3,74,3],[6,77,2],[8,76,2],[10,74,2],[12,72,2],[14,69,2]],
    [[0,70,3],[3,74,3],[6,77,4],[10,74,2],[12,77,2],[14,79,2]],
    [[0,81,3],[3,79,3],[6,77,4],[10,76,2],[12,77,2],[14,76,2]],
    [[0,76,6],[6,72,2],[8,76,2],[10,79,4],[14,81,2]] ];
  let gymOn = false, gymNext = 0, gymStep16 = 0, gymLoop = null, gymG = null, hatB = null, gtr = null, echo = null, mus = null;
  const SAT = (() => { const n = 1024, c = new Float32Array(n); for (let i = 0; i < n; i++){ const x = i / (n - 1) * 2 - 1; c[i] = Math.tanh(x * 2.6); } return c; })();
  function env(g, t, a, peak, d){ g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(peak, t + a); g.gain.exponentialRampToValueAtTime(0.001, t + d); }
  function osc(type, f, t, dur, dst, detune){ const o = ctx.createOscillator(); o.type = type; o.frequency.value = f; if (detune) o.detune.value = detune; o.connect(dst); o.start(t); o.stop(t + dur + 0.05); return o; }
  function gNoise(t, dur, type, freq, vol, dst, q){ const s = ctx.createBufferSource(); s.buffer = hatB; const f = ctx.createBiquadFilter(); f.type = type; f.frequency.value = freq; if (q) f.Q.value = q; const g = ctx.createGain(); g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.001, t + dur); s.connect(f); f.connect(g); g.connect(dst || gymG); s.start(t, Math.random() * 2); s.stop(t + dur + 0.02); return f; }
  function pump(t, depth){ mus.gain.setValueAtTime(depth, t); mus.gain.linearRampToValueAtTime(1, t + G16 * 2.6); }   /* 킥마다 음악이 '훅훅' 숨쉬게 */
  function gKick(t, vol = 1){ const o = ctx.createOscillator(), g = ctx.createGain(), sh = ctx.createWaveShaper(); sh.curve = SAT; o.frequency.setValueAtTime(190, t); o.frequency.exponentialRampToValueAtTime(42, t + 0.12); o.frequency.exponentialRampToValueAtTime(34, t + 0.4); g.gain.setValueAtTime(1.15 * vol, t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.42); o.connect(sh); sh.connect(g); g.connect(gymG); o.start(t); o.stop(t + 0.45);
    gNoise(t, 0.012, 'highpass', 3000, 0.5 * vol); }                                                                  /* 클릭(어택) */
  function gSnare(t, vol = 1){ gNoise(t, 0.2, 'bandpass', 1900, 0.95 * vol, null, 0.8); gNoise(t, 0.12, 'highpass', 6000, 0.35 * vol); gNoise(t + 0.01, 0.3, 'bandpass', 1500, 0.25 * vol, echo, 1);
    [0, 0.011, 0.024].forEach(d => gNoise(t + d, 0.09, 'bandpass', 1200, 0.4 * vol, null, 2));                          /* 박수 겹치기 */
    const o = ctx.createOscillator(), g = ctx.createGain(); o.type = 'triangle'; o.frequency.setValueAtTime(240, t); o.frequency.exponentialRampToValueAtTime(150, t + 0.08); g.gain.setValueAtTime(0.6 * vol, t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.12); o.connect(g); g.connect(gymG); o.start(t); o.stop(t + 0.14); }
  function gCrash(t, vol = 1){ gNoise(t, 1.8, 'highpass', 4500, 0.42 * vol); gNoise(t, 1.1, 'bandpass', 8500, 0.25 * vol, echo, 0.6); }
  function gTom(t, f){ const o = ctx.createOscillator(), g = ctx.createGain(); o.frequency.setValueAtTime(f * 1.6, t); o.frequency.exponentialRampToValueAtTime(f, t + 0.08); g.gain.setValueAtTime(0.8, t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.3); o.connect(g); g.connect(gymG); o.start(t); o.stop(t + 0.32); gNoise(t, 0.05, 'bandpass', 900, 0.3); }
  function gImpact(t){ /* 💥 드롭 첫 박: 땅이 꺼지는 붐 + 파편 + 크래시 */
    const o = ctx.createOscillator(), g = ctx.createGain(), sh = ctx.createWaveShaper(); sh.curve = SAT; o.frequency.setValueAtTime(120, t); o.frequency.exponentialRampToValueAtTime(27, t + 1.4); g.gain.setValueAtTime(1.4, t); g.gain.exponentialRampToValueAtTime(0.001, t + 1.6); o.connect(sh); sh.connect(g); g.connect(gymG); o.start(t); o.stop(t + 1.65);
    gNoise(t, 0.7, 'lowpass', 1400, 0.9); gNoise(t, 1.2, 'bandpass', 400, 0.4, echo); gCrash(t, 1.3); }
  function gHey(t, vol = 1){ /* 떼창 '헤이!': 3명이 살짝 어긋나게 */ [0, 0.012, 0.025].forEach((dd, p) => { const tt = t + dd;
    [[700, 9], [1150, 8], [2500, 6]].forEach(([f, q], k) => { const s = ctx.createBufferSource(); s.buffer = hatB; const bp = ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = f * (1 + p * 0.04); bp.Q.value = q; const g = ctx.createGain(); env(g, tt, 0.015, [0.8, 0.6, 0.3][k] * vol, 0.26); s.connect(bp); bp.connect(g); g.connect(gymG); if (p === 0) g.connect(echo); s.start(tt, Math.random() * 2); s.stop(tt + 0.3); });
    const o = ctx.createOscillator(), g = ctx.createGain(), bp = ctx.createBiquadFilter(); o.type = 'sawtooth'; o.frequency.setValueAtTime(220 + p * 14, tt); o.frequency.linearRampToValueAtTime(180 + p * 10, tt + 0.22); bp.type = 'bandpass'; bp.frequency.value = 850; bp.Q.value = 3; env(g, tt, 0.015, 0.2 * vol, 0.24); o.connect(bp); bp.connect(g); g.connect(gymG); o.start(tt); o.stop(tt + 0.28); }); }
  function g808(t, f, dur){ const o = ctx.createOscillator(), g = ctx.createGain(), sh = ctx.createWaveShaper(); o.frequency.setValueAtTime(f * 1.8, t); o.frequency.exponentialRampToValueAtTime(f, t + 0.05); sh.curve = SAT; g.gain.setValueAtTime(0.85, t); g.gain.setValueAtTime(0.75, t + dur * 0.7); g.gain.exponentialRampToValueAtTime(0.001, t + dur); o.connect(sh); sh.connect(g); g.connect(mus); o.start(t); o.stop(t + dur + 0.02); }
  function gGrowl(t, root, dur){ /* 그로울 베이스: 톱니 두 대 + 필터가 '와앙' 열렸다 닫힘 */ const lp = ctx.createBiquadFilter(), g = ctx.createGain(), sh = ctx.createWaveShaper(); sh.curve = SAT; lp.type = 'lowpass'; lp.Q.value = 6; lp.frequency.setValueAtTime(220, t); lp.frequency.linearRampToValueAtTime(1300, t + dur * 0.35); lp.frequency.exponentialRampToValueAtTime(260, t + dur);
    env(g, t, 0.005, 0.3, dur); lp.connect(sh); sh.connect(g); g.connect(mus); osc('sawtooth', N(root), t, dur, lp, -12); osc('sawtooth', N(root), t, dur, lp, 12); osc('square', N(root - 12), t, dur, lp); }
  function gPower(t, root, dur, muted, vol = 1){ const g = ctx.createGain(); env(g, t, 0.005, (muted ? 0.38 : 0.55) * vol, muted ? 0.085 : dur); g.connect(gtr);
    (muted ? [0, 7] : [0, 7, 12]).forEach(iv => [-9, 9].forEach(dt => osc('sawtooth', N(root + iv), t, muted ? 0.1 : dur, g, dt))); }
  function gLead(t, m, dur){ /* 슈퍼소 리드: 톱니 5대 + 옥타브 위 반짝임 */ const lp = ctx.createBiquadFilter(), g = ctx.createGain(); lp.type = 'lowpass'; lp.frequency.setValueAtTime(5200, t); lp.frequency.exponentialRampToValueAtTime(2400, t + dur);
    g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(0.055, t + 0.01); g.gain.setValueAtTime(0.05, t + dur * 0.8); g.gain.exponentialRampToValueAtTime(0.001, t + dur + 0.08); lp.connect(g); g.connect(mus); g.connect(echo);
    [-24, -11, 0, 11, 24].forEach(dt => osc('sawtooth', N(m), t, dur + 0.1, lp, dt)); osc('square', N(m + 12), t, dur + 0.1, lp, 5); }
  function gBrass(t, root, dur){ const lp = ctx.createBiquadFilter(), g = ctx.createGain(); lp.type = 'lowpass'; lp.frequency.setValueAtTime(500, t); lp.frequency.linearRampToValueAtTime(3200, t + 0.08); lp.frequency.exponentialRampToValueAtTime(900, t + dur); env(g, t, 0.03, 0.11, dur); lp.connect(g); g.connect(mus); g.connect(echo);
    [0, 7, 12, 15, 19].forEach(iv => [-7, 7].forEach(dt => osc('sawtooth', N(root + 12 + iv), t, dur, lp, dt))); }
  function gRiser(t, len){ /* 빌드업 4마디 동안 '쉬이이익' 올라가는 바람 + 사이렌 */
    const s = ctx.createBufferSource(); s.buffer = hatB; s.loop = true; const bp = ctx.createBiquadFilter(), g = ctx.createGain(); bp.type = 'bandpass'; bp.Q.value = 1.4; bp.frequency.setValueAtTime(300, t); bp.frequency.exponentialRampToValueAtTime(9000, t + len);
    g.gain.setValueAtTime(0.01, t); g.gain.exponentialRampToValueAtTime(0.35, t + len - 0.02); g.gain.linearRampToValueAtTime(0, t + len); s.connect(bp); bp.connect(g); g.connect(gymG); s.start(t); s.stop(t + len + 0.02);
    const o = ctx.createOscillator(), og = ctx.createGain(); o.type = 'sawtooth'; o.frequency.setValueAtTime(N(50), t); o.frequency.exponentialRampToValueAtTime(N(86), t + len); og.gain.setValueAtTime(0.001, t); og.gain.exponentialRampToValueAtTime(0.06, t + len - 0.02); og.gain.linearRampToValueAtTime(0, t + len); const f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 3000; o.connect(f); f.connect(og); og.connect(gymG); og.connect(echo); o.start(t); o.stop(t + len + 0.02); }
  function gymSchedule(){
    if (!gymOn) return;
    const ahead = ctx.currentTime + 0.3;
    while (gymNext < ahead){
      const t = gymNext, i = gymStep16 % 16, bar = Math.floor(gymStep16 / 16) % 16;
      if (bar < 4){                                   /* ① 빌드업 */
        const b = bar, root = G_DROP[b];
        if (b === 0 && i === 0){ gRiser(t, G16 * 64 - 0.1); gCrash(t, 0.6); }
        if (i % 4 === 0) gKick(t, 0.7), pump(t, 0.55);
        if (i === 0) gPower(t, root, G16 * 15, false, 0.55), g808(t, N(root - 12), G16 * 14);
        if (b < 2 && i % 2 === 0) gPower(t, root, G16, true, 0.6);
        if (b >= 2) gPower(t, root, G16, true, 0.5 + b * 0.1);
        /* 스네어 롤 가속: 4분 → 8분 → 16분 → 16분(크레센도) */
        const every = [4, 2, 1, 1][b], v = 0.2 + (bar * 16 + i) / 64 * 0.6;
        if (i % every === 0 && !(b === 3 && i >= 15)) gSnare(t, v);
        if (b === 3 && i >= 8 && i < 15) gTom(t + G16 / 2, 70 + i * 8);
        if (b === 3 && i % 4 === 0) gHey(t, 0.7 + i * 0.03);    /* 마지막 마디: 헤이! 헤이! 헤이! 헤이! */
        if (b === 1 && (i === 4 || i === 12)) gHey(t, 0.7);
      } else if (bar < 12){                           /* ② 💥 드롭 */
        const d = bar - 4, root = G_DROP[d % 4];
        if (d === 0 && i === 0) gImpact(t); else if (i === 0 && d % 4 === 0) gCrash(t, 0.9); else if (i === 0) gCrash(t, 0.4);
        if (i % 4 === 0){ gKick(t); pump(t, 0.28); }
        if (i === 4 || i === 12) gSnare(t);
        if (i % 2 === 1) gNoise(t, 0.04, 'highpass', 8000, 0.13);
        if (i === 12 && d % 2 === 1) gHey(t);
        const c = G_GALLOP[i]; if (c === 1) gPower(t, root, G16, true); else if (c === 2) gPower(t, root, G16 * 2.4, false);
        if (i % 2 === 0) gGrowl(t, root, G16 * 1.8);
        if (i === 0) g808(t, N(root - 12), G16 * 7); if (i === 8) g808(t, N(root - 12), G16 * 6);
        if (i === 0) gBrass(t, root, G16 * (d % 2 ? 3 : 6));
        G_HOOK[d % 4].forEach(([s, m, len]) => { if (s === i) gLead(t, m, G16 * len); });
        if (d === 7 && i >= 8){ gSnare(t + G16 * 0.5, 0.6 + (i - 8) * 0.06); if (i >= 12) gTom(t, 160 - (i - 12) * 25); }
      } else {                                        /* ③ 하프타임 스톰프 (숨 고르기지만 무겁게) */
        const b = bar - 12, root = G_STOMP[b];
        if (b === 0 && i === 0) gCrash(t, 0.8);
        if (i === 0 || i === 6 || i === 10){ gKick(t, 1.05); gNoise(t, 0.09, 'lowpass', 400, 0.5); pump(t, 0.45); }
        if (i === 8) gSnare(t, 1.05);
        if (i === 8 && b % 2 === 1) gHey(t);
        if (i % 2 === 0) gNoise(t, 0.035, 'highpass', 7500, i % 4 === 2 ? 0.15 : 0.08);
        if (b === 3 && i >= 12){ gNoise(t + G16 / 2, 0.03, 'highpass', 8000, 0.12); }
        const c = G_GALLOP[i]; if (c === 1) gPower(t, root, G16, true, 0.8); else if (c === 2) gPower(t, root, G16 * 2.2, false, 0.9);
        if (i === 0) g808(t, N(root - 12), G16 * 6); if (i === 6) g808(t, N(root - 12), G16 * 4);
        if (i === 0 && b % 2 === 0) gBrass(t, root, G16 * 5);
      }
      gymStep16++; gymNext += G16;
    }
  }
  function gym(onNow){
    if (!built) return;
    const t = ctx.currentTime;
    if (onNow && !gymOn){ gymOn = true; gymStep16 = 0; mus.gain.cancelScheduledValues(t); mus.gain.setValueAtTime(1, t); gymNext = t + 0.5; gymG.gain.cancelScheduledValues(t); gymG.gain.setValueAtTime(gymG.gain.value, t); gymG.gain.linearRampToValueAtTime(0.46, t + 2.0); gymLoop = setInterval(gymSchedule, 80); }
    else if (!onNow && gymOn){ gymOn = false; gymG.gain.cancelScheduledValues(t); gymG.gain.setValueAtTime(gymG.gain.value, t); gymG.gain.linearRampToValueAtTime(0, t + 1.5); setTimeout(() => { if (!gymOn) clearInterval(gymLoop); }, 1600); }
  }
  function build(){
    const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return false;
    ctx = new AC();
    out = ctx.createGain(); out.gain.value = 0;
    { const comp = ctx.createDynamicsCompressor(); comp.threshold.value = -12; comp.knee.value = 8; comp.ratio.value = 4; comp.attack.value = 0.005; comp.release.value = 0.2; out.connect(comp); comp.connect(ctx.destination); }   /* 소리가 겹쳐도 찢어지지 않게 */
    filt = ctx.createBiquadFilter(); filt.type = 'lowpass'; filt.frequency.value = 6000; filt.Q.value = 0.3; filt.connect(out);
    sea = ctx.createGain(); sea.gain.value = 1; sea.connect(filt);
    tav = ctx.createGain(); tav.gain.value = 0; tav.connect(out);
    gymG = ctx.createGain(); gymG.gain.value = 0; gymG.connect(out); mus = ctx.createGain(); mus.gain.value = 1; mus.connect(gymG);
    { gtr = ctx.createGain(); gtr.gain.value = 0.6; const sh = ctx.createWaveShaper(); const n = 2048, c = new Float32Array(n); for (let k = 0; k < n; k++){ const x = k / (n - 1) * 2 - 1; c[k] = Math.tanh(x * 6) * 0.8; } sh.curve = c; sh.oversample = '2x';
      const hp = ctx.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = 90; const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 3200; const mid = ctx.createBiquadFilter(); mid.type = 'peaking'; mid.frequency.value = 900; mid.gain.value = -4;
      gtr.connect(sh); sh.connect(hp); hp.connect(mid); mid.connect(lp); const gv = ctx.createGain(); gv.gain.value = 0.32; lp.connect(gv); gv.connect(mus); }
    { echo = ctx.createGain(); echo.gain.value = 0.35; const d = ctx.createDelay(1); d.delayTime.value = 60 / 150 * 0.75; const fb = ctx.createGain(); fb.gain.value = 0.32; const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 2200; echo.connect(d); d.connect(lp); lp.connect(fb); fb.connect(d); lp.connect(gymG); }
    const pinkB = noise(6, true), whiteB = noise(4, false); hatB = whiteB;
    /* 파도: 두 겹이 서로 다른 속도로 밀려왔다 빠져요 */
    [[0.075, 750, 0.55], [0.11, 1300, 0.35]].forEach(([rate, cut, amp], i) => {
      const s = src(pinkB), lp = ctx.createBiquadFilter(), g = ctx.createGain(); lp.type = 'lowpass'; lp.frequency.value = cut;
      s.connect(lp); lp.connect(g); g.connect(sea); lfo(rate, amp*0.85, g.gain, amp); lfo(rate*0.5, cut*0.35, lp.frequency, cut);
      s.playbackRate.value = i ? 0.93 : 1;
    });
    { const s = src(whiteB), bp = ctx.createBiquadFilter(), g = ctx.createGain(); bp.type = 'bandpass'; bp.frequency.value = 2400; bp.Q.value = 0.6; s.connect(bp); bp.connect(g); g.connect(sea); lfo(0.075, 0.03, g.gain, 0.035); }
    { const s = src(pinkB), bp = ctx.createBiquadFilter(); windG = ctx.createGain(); windG.gain.value = 0.12; bp.type = 'bandpass'; bp.Q.value = 1.4; s.playbackRate.value = 0.8; s.connect(bp); bp.connect(windG); windG.connect(sea); lfo(0.05, 260, bp.frequency, 520); }
    /* 아주 작은 화음 — 8초마다 코드가 바뀌어요 */
    { padG = ctx.createGain(); padG.gain.value = 0.035; const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 900; padG.connect(lp); lp.connect(sea);
      const CH = [[146.83, 220, 293.66], [130.81, 196, 261.63], [110, 164.81, 220], [123.47, 185, 246.94]];
      const osc = CH[0].map(f => { const o = ctx.createOscillator(); o.type = 'triangle'; o.frequency.value = f; const g = ctx.createGain(); g.gain.value = 0.33; o.connect(g); g.connect(padG); o.start(); return o; });
      let k = 0; timers.push(setInterval(() => { k = (k + 1) % CH.length; osc.forEach((o, i) => o.frequency.setTargetAtTime(CH[k][i], ctx.currentTime, 1.6)); }, 8000)); }
    /* 주점 웅성거림 */
    { const s = src(pinkB), bp = ctx.createBiquadFilter(); crowd = ctx.createGain(); crowd.gain.value = 0; bp.type = 'bandpass'; bp.frequency.value = 450; bp.Q.value = 0.9; s.playbackRate.value = 1.3; s.connect(bp); bp.connect(crowd); crowd.connect(out); lfo(0.3, 120, bp.frequency, 450); }
    const creak = () => { if (on && ctx.state === 'running' && mode !== 'tavern'){ const t = ctx.currentTime, o = ctx.createOscillator(), bp = ctx.createBiquadFilter(), g = ctx.createGain();
        o.type = 'sawtooth'; o.frequency.setValueAtTime(70 + Math.random()*30, t); o.frequency.linearRampToValueAtTime(110 + Math.random()*40, t + 0.7);
        bp.type = 'bandpass'; bp.frequency.value = 420; bp.Q.value = 6; g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(mode === 'cabin' ? 0.05 : 0.025, t + 0.25); g.gain.linearRampToValueAtTime(0, t + 0.8);
        o.connect(bp); bp.connect(g); g.connect(sea); o.start(t); o.stop(t + 0.85); }
      timers.push(setTimeout(creak, 12000 + Math.random()*18000)); };
    timers.push(setTimeout(gulls, 1500)); timers.push(setTimeout(creak, 7000));
    built = true; applyMode(); return true;
  }
  let mode = 'deck';
  function applyMode(){
    if (!built) return; const t = ctx.currentTime;
    const cut = mode === 'cabin' ? 650 : mode === 'tavern' ? 450 : mode === 'nest' ? 9000 : 6000;   /* gym 은 아래에서 바다 소리를 0으로 */
    const wind = mode === 'nest' ? 0.42 : mode === 'cabin' || mode === 'tavern' ? 0.04 : 0.12;
    filt.frequency.setTargetAtTime(cut, t, 0.6); windG.gain.setTargetAtTime(wind, t, 0.8);
    sea.gain.setTargetAtTime(mode === 'gym' ? 0 : mode === 'tavern' ? 0.25 : 1, t, mode === 'gym' ? 0.7 : 0.6); padG.gain.setTargetAtTime(mode === 'tavern' || mode === 'gym' ? 0 : 0.035, t, 0.8);
    tavern(mode === 'tavern'); gym(mode === 'gym');
  }
  function setMode(m){ if (m === mode) return; mode = m; applyMode(); }
  function start(){
    if (!on) return;
    if (!built && !build()) return;
    if (ctx.state !== 'running') ctx.resume().catch(() => {});
    out.gain.setTargetAtTime(VOL, ctx.currentTime, 0.8);
    applyMode();
  }
  function stop(){ if (!built) return; out.gain.setTargetAtTime(0, ctx.currentTime, 0.25); tavern(false); gym(false); setTimeout(() => { if (!on && ctx.state === 'running') ctx.suspend().catch(() => {}); }, 900); }
  function set(v){ on = v; try { localStorage.setItem(SEA_PREF_KEY, v ? '1' : '0'); } catch(e){} if (v) start(); else stop(); }
  return { start, set, setMode, get on(){ return on; } };
})();
/* 위쪽 버튼 · 첫 클릭에 시작(브라우저는 사용자가 한 번 눌러야 소리를 낼 수 있어요) */
(() => {
  const pills = document.querySelector('.hud .pills'); if (!pills) return;
  const b = document.createElement('button'); b.className = 'pill lp-ico'; b.id = 'seaPill'; b.type = 'button';
  const paint = () => { b.innerHTML = SeaSnd.on ? '🔊' : '🔇'; b.title = `바다 소리 ${SeaSnd.on ? '켜짐' : '꺼짐'} (눌러서 ${SeaSnd.on ? '끄기' : '켜기'})`; b.setAttribute('aria-pressed', String(SeaSnd.on)); b.setAttribute('aria-label', `배경 바다 소리 ${SeaSnd.on ? '켜짐' : '꺼짐'}. 눌러서 ${SeaSnd.on ? '끄기' : '켜기'}`); };
  b.addEventListener('click', e => { e.stopPropagation(); SeaSnd.set(!SeaSnd.on); paint(); });
  pills.insertBefore(b, pills.firstChild); paint();
  const first = () => { SeaSnd.start(); window.removeEventListener('pointerdown', first, true); window.removeEventListener('keydown', first, true); };
  window.addEventListener('pointerdown', first, true); window.addEventListener('keydown', first, true);
  setInterval(() => { const inGame = MODE === 'cabin', m = (typeof nest !== 'undefined' && nest.open) ? 'nest' : inGame && AREA && AREA.id === 'cabin' ? 'cabin' : inGame && AREA && AREA.id === 'tavern' ? 'tavern' : inGame && AREA && AREA.id === 'isle' && typeof GYM !== 'undefined' && Math.hypot(player.x - GYM.x, player.z - GYM.z) < 12.5 ? 'gym' : 'deck'; SeaSnd.setMode(m); }, 400);
})();
/* 카메라 이동 연출: fn(t, e)를 매 프레임 불러요 (t: 0→1, e: 부드럽게 가감속) */
function camTween(dur, fn, done){
  const t0 = performance.now(); let stop = false;
  const step = now => { if (stop) return; const t = Math.min(1, (now - t0)/(dur*1000)), e = t < .5 ? 4*t*t*t : 1 - Math.pow(-2*t + 2, 3)/2; fn(t, e); if (t < 1) requestAnimationFrame(step); else if (done) done(); };
  requestAnimationFrame(step); return () => { stop = true; };
}
const lerpV = (out, a, b, t) => out.set(a.x + (b.x - a.x)*t, a.y + (b.y - a.y)*t, a.z + (b.z - a.z)*t);

/* ============================================================
   화질: 자동(기본) · 높음 · 낮음
   자동은 2초마다 화면이 몇 번 바뀌는지 재서, 버벅이면 해상도를 한 단계 낮추고 여유가 생기면 다시 올려요.
   ============================================================ */
const Q_KEY = 'logpose.quality';
const QUAL = (() => {
  const max = Math.min(2, window.devicePixelRatio || 1);
  const steps = [max, Math.min(max, 1.4), 1, 0.8, 0.67].filter((v, i, a) => a.indexOf(v) === i).sort((a, b) => b - a);
  let mode = (() => { try { const v = localStorage.getItem(Q_KEY); return v === 'high' || v === 'low' ? v : 'auto'; } catch(e){ return 'auto'; } })();
  let step = 0, frames = 0, last = performance.now(), good = 0;
  try { step = Math.min(steps.length - 2, +localStorage.getItem(Q_KEY + '.step') || 0); } catch(e){}
  function apply(){
    const i = mode === 'high' ? 0 : mode === 'low' ? steps.length - 1 : step;
    if (renderer.getPixelRatio() !== steps[i]){ renderer.setPixelRatio(steps[i]); window.dispatchEvent(new Event('resize')); }
    paint();
  }
  function setStep(i){ step = Math.max(0, Math.min(steps.length - 2, i)); try { localStorage.setItem(Q_KEY + '.step', String(step)); } catch(e){} apply(); }
  function tick(now){
    requestAnimationFrame(tick);
    if (mode !== 'auto' || document.hidden) { last = now; frames = 0; return; }
    frames++; const dt = now - last; if (dt < 2000) return;
    const fps = frames * 1000 / dt; frames = 0; last = now;
    if (uiOpen && MODE === 'cabin') return;   /* 창이 열려 있을 땐 재지 않아요 */
    if (fps < 38){ good = 0; if (step < steps.length - 2) setStep(step + 1); }
    else if (fps > 56){ if (++good >= 4 && step > 0){ good = 0; setStep(step - 1); } }
    else good = 0;
  }
  let pill = null;
  function paint(){ if (!pill) return; const lbl = mode === 'auto' ? (step ? '자동·절약' : '자동') : mode === 'high' ? '높음' : '낮음'; pill.innerHTML = `⚙ <b>${lbl}</b>`; pill.title = `화질 ${lbl} (자동 → 높음 → 낮음)`; pill.setAttribute('aria-label', `화질 ${lbl}. 눌러서 바꾸기 (자동 → 높음 → 낮음)`); }
  function set(m){ mode = m; try { localStorage.setItem(Q_KEY, m); } catch(e){} if (m === 'auto'){ step = 0; good = 0; } apply(); }
  function mount(p){ pill = p; paint(); }
  setTimeout(() => { apply(); requestAnimationFrame(tick); }, 0);
  return { set, mount, get mode(){ return mode; } };
})();

/* ============================================================
   도움말(?): 지금 있는 공간에 무엇이 있는지 + 조작법
   ============================================================ */
const HELP = {
  gate:{ t:'LOG POSE에 오신 걸 환영해요', d:'나만의 배를 꾸리고, 손목의 로그포스가 가리키는 다음 애니메이션으로 항해하는 서비스예요. 시작 버튼을 누르면 내 배의 선장실에서 출발해요.' },
  cabin:{ t:'선장실', d:'내 배의 방이에요. 취향 질문으로 추천을 받고, 저장한 작품을 모아 두는 곳이에요.',
    tips:['왼쪽 아래 <b>로그포스</b>: 취향 질문 · 추천 · 저장한 목적지', '<b>선장 책상</b>: 작품 정보(스포일러 없는 1화 시점 소개)', '<b>항해일지 책장</b>: 저장한 작품이 책으로 꽂혀요', '<b>옷장</b>: 상점에서 산 옷 · 모자 갈아입기', '<b>보물 상자</b>: 모아 둔 유리병 편지'] },
  deck:{ t:'갑판', d:'배 위예요. 지도 · 망원경 · 망루 · 낚시를 할 수 있어요.',
    tips:['<b>해도 탁자</b>: 저장한 작품이 장르 해역에 찍힌 항해 지도', '<b>망원경</b>: 멀리 있는 섬(라프텔 · 절영도) 자세히 보기', '<b>망루</b>: 줄사다리로 올라가 360도 바다 구경', '<b>고물 낚시터</b>: 물고기 낚기 · 도감 · 유리병 던지기', '<b>낮과 밤</b>에 잡히는 물고기가 달라요 (위쪽 창밖 버튼)'] },
  isle:{ t:'절영도', d:'모든 선장님이 모이는 공용 섬이에요. 이름은 부산 영도의 옛 이름에서 따왔어요. 어느 해적단의 것도 아닌 평화지대예요.',
    tips:['<b>공용 낚시터</b>: 긴 잔교 끝에서 낚시', '<b>시장 거리 · 상점</b>: 물고기를 은화로 팔고 모자 · 옷 · 해적기 사기', '<b>현상금 게시판</b>: 인기 캐릭터 응원 · 현상금 선장 순위', '<b>주점 럼통</b>: 바텐더 · 맥주 · 의자', '<b>쉼터</b>: 모닥불 · 평상 · 파라솔에서 쉬기', '<b>강자 ZONE</b>(게시판 뒤): 럼통 · 닻 · 밧줄 기구로 운동 · 앵무새와 원숭이가 응원해요'] },
  tavern:{ t:'주점 럼통', d:'커다란 럼통 안의 주점이에요.', tips:['<b>바텐더</b>에게 말 걸기 · 맥주 마시기', '의자에 앉아 쉬기', '출구로 나가면 절영도예요'] },
};
const helpEl = document.createElement('section'); helpEl.className = 'lp-help'; helpEl.hidden = true; helpEl.setAttribute('role', 'dialog'); helpEl.setAttribute('aria-modal', 'true'); helpEl.setAttribute('aria-labelledby', 'lpHelpT');
document.body.appendChild(helpEl);
let helpWasUi = false;
function openHelp(){
  if (!helpEl.hidden) return;
  const id = MODE === 'cabin' ? AREA.id : 'gate', H = HELP[id] || { t:AREA.name || '여기', d:'' };
  const spots = MODE === 'cabin' && AREA.spots ? [...new Set(Object.values(AREA.spots).map(s => s && typeof s.label === 'string' ? s.label : null).filter(Boolean))] : [];
  const touch = matchMedia('(pointer:coarse)').matches;
  helpEl.innerHTML = `<div class="lp-help-card">
    <header><div><p class="lp-help-k">도움말 · 지금 있는 곳</p><h2 id="lpHelpT">${H.t}</h2></div><button type="button" class="lp-help-x" data-x>닫기</button></header>
    ${H.d ? `<p class="lp-help-d">${H.d}</p>` : ''}
    ${id === 'isle' ? '<button type="button" class="lp-help-tour" data-tour>🗺 절영도 한눈에 보기 (장소 소개 다시 보기)</button>' : ''}
    ${H.tips ? `<h3>여기에 있는 것</h3><ul>${H.tips.map(t => `<li>${t}</li>`).join('')}</ul>` : ''}
    ${spots.length ? `<h3>가까이 가면 누를 수 있어요</h3><p class="lp-help-chips">${spots.map(s => `<span>${s.replace(/[<>&]/g, '')}</span>`).join('')}</p>` : ''}
    <h3>조작</h3><ul class="lp-help-keys">${touch ? '<li>왼쪽 아래 조이스틱으로 걷기 · 화면을 끌어서 둘러보기</li><li>살펴볼 곳에 가까이 가면 아래에 버튼이 떠요 · 점프 버튼</li>' : '<li><kbd>W A S D</kbd> 걷기 · 바닥 클릭으로 이동 · 끌어서 둘러보기</li><li><kbd>F</kbd> 가까운 곳 살펴보기 · <kbd>Space</kbd> 점프</li>'}<li>위쪽 버튼: <b>?</b> 도움말 · <b>⚙</b> 화질(자동 → 높음 → 낮음) · <b>🔊</b> 바다 소리 켜기/끄기 · <b>창밖</b> 낮/밤</li></ul>
  </div>`;
  helpWasUi = uiOpen; uiOpen = true; if (typeof keys !== 'undefined') keys.clear();
  helpEl.hidden = false; setTimeout(() => { const x = helpEl.querySelector('[data-x]'); if (x) x.focus({ preventScroll:true }); }, 30);
}
function closeHelp(){ if (helpEl.hidden) return; helpEl.hidden = true; uiOpen = helpWasUi; }
helpEl.addEventListener('click', e => { if (e.target.closest('[data-tour]')){ closeHelp(); startIsleTour(); return; } if (e.target === helpEl || e.target.closest('[data-x]')) closeHelp(); });   /* startIsleTour: isletour.js */
helpEl.addEventListener('keydown', e => { if (e.key === 'Escape'){ e.preventDefault(); closeHelp(); } e.stopPropagation(); });

/* 위쪽 버튼: [?] [화질] [바다 소리] [창밖] … */
(() => {
  const pills = document.querySelector('.hud .pills'); if (!pills) return;
  const q = document.createElement('button'); q.className = 'pill'; q.id = 'qPill'; q.type = 'button';
  q.addEventListener('click', e => { e.stopPropagation(); const nx = { auto:'high', high:'low', low:'auto' }[QUAL.mode]; QUAL.set(nx); if (typeof toast === 'function') toast(nx === 'auto' ? '화질 <strong>자동</strong>: 버벅이면 알아서 낮추고 여유 있으면 올려요.' : nx === 'high' ? '화질 <strong>높음</strong>으로 고정했어요.' : '화질 <strong>낮음</strong>으로 고정했어요. 렉이 줄어요.', 2400); });
  const h = document.createElement('button'); h.className = 'pill lp-help-pill'; h.id = 'helpPill'; h.type = 'button'; h.textContent = '?'; h.setAttribute('aria-label', '도움말: 지금 있는 곳에 무엇이 있는지 보기');
  h.addEventListener('click', e => { e.stopPropagation(); openHelp(); });
  pills.insertBefore(q, pills.firstChild); pills.insertBefore(h, pills.firstChild); QUAL.mount(q);
})();

/* ============================================================
   은화 보유액 (위쪽 '나가기' 아래) + 절영도 미니맵 (실시간 내 위치 · 클릭하면 그쪽으로 걸어가요)
   ============================================================ */
(() => {
  const pills = document.querySelector('.hud .pills'); if (!pills) return;
  const row = document.createElement('div'); row.className = 'lp-silver-row';
  row.innerHTML = '<div class="lp-silver" id="silverChip" role="status" aria-live="polite" title="지금 가진 은화"><i aria-hidden="true"></i><b>0</b><span>은화</span></div>';
  pills.appendChild(row);
  const chip = row.firstChild, num = chip.querySelector('b'); let last = -1;
  setInterval(() => { let v = 0; try { v = shopData().silver; } catch(e){ return; } if (v === last) return; const up = last >= 0 && v > last; last = v; num.textContent = Number(v).toLocaleString('ko-KR'); chip.classList.remove('up', 'down'); void chip.offsetWidth; if (last >= 0) chip.classList.add(up ? 'up' : 'down'); }, 600);
})();
const MM = { el:null, cv:null, g:null, open:true, t:0 };
(() => {
  const el = document.createElement('section'); el.className = 'lp-mm'; el.hidden = true; el.setAttribute('aria-label', '절영도 지도');
  el.innerHTML = '<header><b>🗺 절영도</b><span id="mmXY"></span><button type="button" class="lp-mm-x" aria-label="지도 접기/펴기">–</button></header><canvas aria-hidden="true"></canvas><p class="lp-mm-tip">누르면 그쪽으로 걸어가요</p>';
  document.body.appendChild(el); MM.el = el; MM.cv = el.querySelector('canvas'); MM.g = MM.cv.getContext('2d'); MM.xy = el.querySelector('#mmXY');
  try { MM.open = localStorage.getItem('logpose.minimap') !== '0'; } catch(e){}
  const btn = el.querySelector('.lp-mm-x'); const paintBtn = () => { el.classList.toggle('min', !MM.open); btn.textContent = MM.open ? '–' : '+'; };
  btn.addEventListener('click', e => { e.stopPropagation(); MM.open = !MM.open; try { localStorage.setItem('logpose.minimap', MM.open ? '1' : '0'); } catch(_){} paintBtn(); }); paintBtn();
  /* 지도 → 월드 좌표 (북쪽 = -z 가 위) */
  const B = { x0:-62, x1:33, z0:-33, z1:51 };
  const toMap = (x, z, W, H) => { const s = Math.min(W / (B.x1 - B.x0), H / (B.z1 - B.z0)), ox = (W - (B.x1 - B.x0) * s) / 2, oy = (H - (B.z1 - B.z0) * s) / 2; return [ox + (x - B.x0) * s, oy + (z - B.z0) * s, s]; };
  const toWorld = (mx, my, W, H) => { const s = Math.min(W / (B.x1 - B.x0), H / (B.z1 - B.z0)), ox = (W - (B.x1 - B.x0) * s) / 2, oy = (H - (B.z1 - B.z0) * s) / 2; return [B.x0 + (mx - ox) / s, B.z0 + (my - oy) / s]; };
  MM.cv.addEventListener('pointerdown', e => {
    if (MODE !== 'cabin' || !AREA || AREA.id !== 'isle' || uiOpen) return;
    const r = MM.cv.getBoundingClientRect(), [x, z] = toWorld(e.clientX - r.left, e.clientY - r.top, r.width, r.height);
    if (Math.hypot(x, z) > ISLE.R + 1 && !(Math.abs(x) < 1.6 && z > ISLE.pier.z0 - 1 && z < ISLE.pier.z1)) { if (typeof toast === 'function') toast('바다로는 걸어갈 수 없어요. 섬 안을 눌러 주세요.', 1800); return; }
    if (typeof goTo === 'function'){ goTo(x, z); if (typeof toast === 'function') toast('지도에 찍은 곳으로 걸어가요.', 1400); }
  });
  function drawBase(g, W, H){
    const sea = g.createLinearGradient(0, 0, 0, H); sea.addColorStop(0, '#0f3a48'); sea.addColorStop(1, '#0b2a36'); g.fillStyle = sea; g.fillRect(0, 0, W, H);
    g.strokeStyle = 'rgba(127,211,224,.12)'; g.lineWidth = 1; for (let y = 6; y < H; y += 9){ g.beginPath(); for (let x = 0; x <= W; x += 6) g.lineTo(x, y + Math.sin(x * 0.25 + y) * 1.2); g.stroke(); }
    const [cx, cy, s] = toMap(0, 0, W, H);
    g.fillStyle = '#e2cb92'; g.beginPath(); g.arc(cx, cy, (ISLE.R + 1.5) * s, 0, 7); g.fill();
    g.fillStyle = '#7fae5a'; g.beginPath(); g.arc(cx, cy, (ISLE.R - 3) * s, 0, 7); g.fill();
    g.fillStyle = '#d9c49a'; g.beginPath(); g.arc(cx, cy, ISLE.plaza * s, 0, 7); g.fill();
    const rect = (x0, z0, x1, z1, col) => { const [a, b] = toMap(x0, z0, W, H), [c, d] = toMap(x1, z1, W, H); g.fillStyle = col; g.fillRect(a, b, c - a, d - b); };
    rect(ISLE.pier.x0, ISLE.pier.z0 - 2, ISLE.pier.x1, ISLE.pier.z1, '#a07a50');
    if (typeof FP !== 'undefined') FP.vis.forEach(r => rect(r.x0, r.z0, r.x1, r.z1, '#a07a50'));
    rect(-ISLE.R - 1, PL.jettyZ - 1.2, -29, PL.jettyZ + 1.2, '#a07a50');
    rect(-7, -18.3, 7, -17.7, '#5a3a20');                                  /* 현상금 게시판 */
    if (typeof GYM !== 'undefined') rect(GYM.x - 9.2, GYM.z - 3.9, GYM.x + 9.2, GYM.z + 3.9, '#c9a274');   /* 강자 ZONE 데크 */
    const icon = (x, z, emoji, label, dy = 0) => { const [px, py] = toMap(x, z, W, H); g.font = `${Math.round(13 * W / 200)}px sans-serif`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(emoji, px, py);
      g.font = `600 ${Math.round(9.5 * W / 200)}px ${FB}`; g.lineWidth = 3; g.strokeStyle = 'rgba(10,20,26,.85)'; g.strokeText(label, px, py + 11 * W / 200 + dy); g.fillStyle = '#f3ead6'; g.fillText(label, px, py + 11 * W / 200 + dy); };
    icon(0, -16, '📜', '게시판'); icon(GYM.x, GYM.z - 0.5, '💪', '강자 ZONE'); icon(PL.market.x, PL.market.z, '🛒', '시장'); icon(PL.tavern.x, PL.tavern.z, '🍺', '주점');
    icon(-55, PL.jettyZ - 4, '🎣', '낚시터'); icon(0, ISLE.pier.z1 - 5, '⛵', '내 배', -22 * W / 200); icon(0, 0, '⛲', '광장');
    g.strokeStyle = 'rgba(217,179,108,.7)'; g.lineWidth = 1.5; g.strokeRect(0.75, 0.75, W - 1.5, H - 1.5);
    g.fillStyle = '#f0d49a'; g.font = `700 ${Math.round(10 * W / 200)}px ${FD}`; g.textAlign = 'right'; g.textBaseline = 'top'; g.fillText('N ↑', W - 5, 4);
  }
  function frameMM(){
    requestAnimationFrame(frameMM);
    const on = MODE === 'cabin' && AREA && AREA.id === 'isle' && !uiOpen;
    if (MM.el.hidden === on) { MM.el.hidden = !on; document.body.classList.toggle('mm-on', on); }
    if (!on || !MM.open) return;
    const now = performance.now(); if (now - MM.t < 66) return; MM.t = now;   /* 초당 15번이면 충분 */
    const cv = MM.cv, dpr = Math.min(2, window.devicePixelRatio || 1), W = cv.clientWidth, H = cv.clientHeight; if (!W) return;
    if (cv.width !== Math.round(W * dpr)){ cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr); MM.base = null; }
    const g = MM.g; g.setTransform(dpr, 0, 0, dpr, 0, 0);
    if (!MM.base){ const b = document.createElement('canvas'); b.width = cv.width; b.height = cv.height; const bg = b.getContext('2d'); bg.setTransform(dpr, 0, 0, dpr, 0, 0); drawBase(bg, W, H); MM.base = b; }
    g.setTransform(1, 0, 0, 1, 0, 0); g.drawImage(MM.base, 0, 0); g.setTransform(dpr, 0, 0, dpr, 0, 0);
    /* 다른 선장님들 (함께 쓰기 켜졌을 때) */
    if (typeof NETP !== 'undefined') NETP.peers.forEach(pe => { if (!pe || pe.isMe || pe.kind !== 'viewer') return; const p = typeof peerState === 'function' ? peerState(pe.presence) : null; if (!p || typeof p.x !== 'number' || p.a !== 'isle') return; const [px, py] = toMap(p.x, p.z, W, H); g.fillStyle = '#7fd3e0'; g.beginPath(); g.arc(px, py, 3, 0, 7); g.fill(); });
    /* 시야(카메라가 보는 쪽) 부채꼴 + 내 위치 화살표 */
    const [px, py] = toMap(player.x, player.z, W, H), vx = -Math.sin(cam.yaw), vz = -Math.cos(cam.yaw), va = Math.atan2(vz, vx);
    const fov = g.createRadialGradient(px, py, 2, px, py, 34); fov.addColorStop(0, 'rgba(255,240,200,.35)'); fov.addColorStop(1, 'rgba(255,240,200,0)');
    g.fillStyle = fov; g.beginPath(); g.moveTo(px, py); g.arc(px, py, 34, va - 0.55, va + 0.55); g.closePath(); g.fill();
    const a = Math.atan2(Math.cos(player.r), Math.sin(player.r)), pulse = 5 + Math.sin(now / 250) * 1.5;
    g.strokeStyle = 'rgba(240,212,154,.6)'; g.lineWidth = 1.5; g.beginPath(); g.arc(px, py, pulse + 4, 0, 7); g.stroke();
    g.save(); g.translate(px, py); g.rotate(a); g.fillStyle = '#ffffff'; g.strokeStyle = '#c9a15e'; g.lineWidth = 2; g.beginPath(); g.moveTo(8, 0); g.lineTo(-5, 5); g.lineTo(-2.5, 0); g.lineTo(-5, -5); g.closePath(); g.fill(); g.stroke(); g.restore();
    MM.xy.textContent = `${Math.round(player.x)}, ${Math.round(-player.z)}`;
  }
  requestAnimationFrame(frameMM);
})();
