/* ============================================================
   LOG POSE · 갑판 5단계: 고물 낚시터 (심심풀이)
   - 낚싯대 던지기 → 찌가 둥둥 → 입질! 때 당기기 → 물고기 (도감에 쌓여요)
   - 잡은 물고기는 어창(보관함)에 모여요. 절영도 시장(market.js)에서 은화로 팔아 모자 · 해적기를 사고, 주점에서 맥주를 마셔요.
   - 유리병은 내 배에서는 던지기만 해요: 작품 + 한줄평(60자)을 담아 던지면 '보낸 병'에 쌓여요.
     병 낚기는 절영도 낚시터에서 (같은 형식 그대로 공유 바다에 띄워요).
   유리병 규칙: 내 로그포스에 저장한 작품 수만큼만 쓸 수 있어요 · 강한 스포일러는 막고, 3번 걸리면 10분 동안 병을 못 써요
               · 병마다 보낸 사람(닉네임 · 선장 종류)을 꼭 적어요
   기록: LPProfile.fishing = { dex:{ 종류:{ n, best } }, hold:[{ sp, size, at }], sent:[{ id, work, text, at, from:{ name, kind } }], warn:{ n, until } }
   ============================================================ */
const FISH = [
  { id:'mackerel',  name:'고등어',    w:22, price:3, size:[25, 45],  color:'#3f7896', belly:'#dfe8ee', note:'푸른 등에 물결무늬. 바다에서 가장 흔한 단골이에요.' },
  { id:'jack',      name:'전갱이',    w:18, price:2, size:[15, 35],  color:'#8fa3ad', belly:'#eef2f4', note:'꼬리 쪽 단단한 비늘이 특징이에요.' },
  { id:'filefish',  name:'쥐치',      w:12, price:3, size:[15, 30],  color:'#a8935e', belly:'#efe3c4', note:'납작한 몸에 뾰족한 등지느러미.' },
  { id:'flyingfish',name:'날치',      w:10, price:4, size:[20, 35],  color:'#4f8fcf', belly:'#e6f0f8', note:'큰 가슴지느러미로 햇살 아래 수면 위를 날아요. 낮에만 보여요.', wings:true, day:true },
  { id:'puffer',    name:'복어',      w:8, price:6,  size:[12, 30],  color:'#c9a24e', belly:'#f6edd2', note:'놀라면 동그랗게 부풀어요.', round:true },
  { id:'seabream',  name:'참돔',      w:7, price:8,  size:[30, 60],  color:'#cf5f58', belly:'#f6dcd6', note:'붉은 빛이 도는 바다의 귀한 손님.' },
  { id:'squid',     name:'오징어',    w:12, price:5, size:[20, 40],  color:'#e6cdbd', belly:'#f6ece4', note:'밤이 되면 불빛을 따라 올라와요.', night:true, kind:'squid' },
  { id:'yellowtail', name:'방어',      w:7, price:7,  size:[50, 90],  color:'#5f86a8', belly:'#f1e6c0', note:'햇살 아래 떼 지어 다니는 힘센 물고기. 낮에 잘 물어요.', day:true },
  { id:'hairtail',  name:'갈치',      w:9, price:6,  size:[60, 110], color:'#c9d3dc', belly:'#eef3f7', note:'은빛 칼 같은 몸. 밤바다 불빛 아래서 반짝여요.', night:true },
  { id:'rockfish',  name:'볼락',      w:10, price:4, size:[15, 30],  color:'#6b5a4a', belly:'#cdbfae', note:'큰 눈으로 깜깜한 밤에 먹이를 찾아요.', night:true },
  { id:'octopus',   name:'문어',      w:5, price:7,  size:[30, 80],  color:'#a5503c', belly:'#d98a72', note:'여덟 다리로 낚싯줄을 꽉 붙잡아요.', kind:'octopus' },
  { id:'tuna',      name:'황금 참치', w:1.5, price:40,size:[90, 160], color:'#d9a63a', belly:'#f8e7b0', note:'전설로만 듣던 황금빛 참치! 정말 드물어요.', rare:true },
  /* 보물 물고기: 애니메이션 섬 바다에만 산다는 전설의 물고기 (오리지널) · 아주 드물어요 · 크기와 상관없이 20은화 */
  { id:'rainbowkoi',  name:'무지개 비늘 잉어', day:true, w:0.15, price:20, size:null, color:'#7f8fd8', belly:'#f4f0ff', note:'비늘마다 다른 색으로 반짝여요. 엔딩 크레딧이 올라갈 때만 수면에 나온대요.', treasure:true, kind:'treasure' },
  { id:'starjelly',   name:'별빛 해파리',     night:true, w:0.15, price:20, size:null, color:'#9d7fe0', belly:'#e9dcff', note:'몸속에 작은 별이 떠다녀요. 밤하늘 장면을 몰래 빠져나왔다는 소문이 있어요.', treasure:true, kind:'treasure' },
  { id:'crownpuffer', name:'왕관 복어',       day:true, w:0.15, price:20, size:null, color:'#e8d27a', belly:'#fbf3d2', note:'머리에 작은 금관을 쓴 복어. 바다의 주인공은 자기라고 믿어요.', treasure:true, kind:'treasure' },
  { id:'moonray',     name:'달빛 가오리',     night:true, w:0.15, price:20, size:null, color:'#2c3f6e', belly:'#c9d6f2', note:'등에 초승달 무늬가 있어요. 보름달 에피소드에만 나타난대요.', treasure:true, kind:'treasure' },
  { id:'lanternangler', name:'등불 아귀',     night:true, w:0.15, price:20, size:null, color:'#4a3b5e', belly:'#8a7aa0', note:'머리의 등불로 길 잃은 선장을 비춰 준다는 심해의 안내자예요.', treasure:true, kind:'treasure' },
  { id:'boot',      name:'낡은 장화', w:6, price:1,  size:null,      color:'#5a3e2a', belly:'#3a2616', note:'…누가 바다에 버렸을까요. 그래도 도감엔 올려 둘게요.', kind:'boot' }
];
const BOTTLE_TEXT_MAX = 60, SENT_MAX = 30, HOLD_MAX = 20, BOTTLE_CATCH = 0.03;   /* 공용 낚시터에서 유리병이 낚일 확률 3% */
const ISLE_BOTTLES = false;   /* 절영도 유리병(떠다니는 병 · 낚이는 병 · 병 띄우기) 끔. 다시 켜려면 true */
const FI = { kick:$('#fiKick'), root:$('#fishing'), body:$('#fiBody'), title:$('#fiTitle'), close:$('#fiClose'), hold:$('#fiHold') };
/* 어디서 낚시하나요: 'deck' 내 배 고물 · 'pier' 공용 낚시터 자리 (seat) */
const FCTX = { kind:'deck', seat:null, pool:[], share:null };
const fi = { open:false, state:'idle', t:0, wait:0, timer:null, pick:null, catchRes:null, formWork:null, back:'idle' };
const fishData = () => { const p = LPProfile.get() || {}; const f = p.fishing || {}; return { dex:f.dex || {}, hold:Array.isArray(f.hold) ? f.hold : [], sent:Array.isArray(f.sent) ? f.sent : [], warn:f.warn || { n:0, until:0 }, got:Array.isArray(f.got) ? f.got : [], letters:Array.isArray(f.letters) ? f.letters : [] }; };
const spOf = id => FISH.find(s => s.id === id);
/* 시장 예상 값: 종류 기본값 × 크기 (장화는 1은화) */
function fishValue(sp, size){ if (!sp) return 0; if (!sp.size || !size) return sp.price; const mid = (sp.size[0] + sp.size[1]) / 2; return Math.max(1, Math.round(sp.price * size / mid)); }
const saveFish = f => LPProfile.update({ fishing:f });

/* 잡은 것 그림 (코드로 그려요) */
const catchArt = {};
/* 보물 물고기 그림 (오리지널 디자인) */
function drawTreasure(g, sp){
  const spark = () => { g.fillStyle = 'rgba(255,246,200,.95)'; [[-92, -44], [88, -50], [96, 40], [-84, 46], [6, -64]].forEach(([x, y], i) => { const r = 5 + (i % 2) * 3; g.beginPath(); for (let k = 0; k < 8; k++){ const a = k * Math.PI / 4, rr = k % 2 ? r * 0.35 : r; g.lineTo(x + Math.cos(a) * rr, y + Math.sin(a) * rr); } g.closePath(); g.fill(); }); };
  const eye = (x, y, r = 6) => { g.fillStyle = '#fff'; g.beginPath(); g.arc(x, y, r, 0, 7); g.fill(); g.fillStyle = '#1a100a'; g.beginPath(); g.arc(x - 1, y, r * 0.5, 0, 7); g.fill(); };
  if (sp.id === 'rainbowkoi'){
    g.fillStyle = '#b9a6f0'; g.beginPath(); g.moveTo(48, 0); g.bezierCurveTo(80, -40, 104, -30, 96, -4); g.bezierCurveTo(108, 20, 84, 44, 48, 0); g.fill();   // 하늘하늘한 꼬리
    const gr = g.createLinearGradient(-70, 0, 60, 0); ['#ff8a8a', '#ffc46b', '#f6ec7a', '#8fe0a0', '#7fc6f0', '#b49af0'].forEach((c, i) => gr.addColorStop(i / 5, c));
    g.fillStyle = gr; g.beginPath(); g.ellipse(-6, 0, 64, 22, 0, 0, 7); g.fill();
    g.strokeStyle = 'rgba(255,255,255,.55)'; g.lineWidth = 1.6; for (let x = -50; x < 50; x += 12) for (const y of [-8, 6]){ g.beginPath(); g.arc(x, y, 6, -1.2, 1.2); g.stroke(); }
    g.strokeStyle = '#8f7ad8'; g.lineWidth = 2; g.beginPath(); g.moveTo(-64, 8); g.quadraticCurveTo(-84, 20, -78, 34); g.stroke();   // 수염 한 가닥
    eye(-46, -5);
  } else if (sp.id === 'starjelly'){
    g.fillStyle = 'rgba(157,127,224,.85)'; g.beginPath(); g.ellipse(0, -14, 56, 40, 0, Math.PI, 0); g.closePath(); g.fill();
    g.fillStyle = 'rgba(233,220,255,.6)'; g.beginPath(); g.ellipse(0, -14, 56, 10, 0, 0, Math.PI); g.fill();
    g.strokeStyle = 'rgba(190,170,240,.85)'; g.lineWidth = 3; g.lineCap = 'round'; for (let k = -4; k <= 4; k++){ g.beginPath(); g.moveTo(k * 11, -8); g.bezierCurveTo(k * 11 + 10, 14, k * 11 - 10, 30, k * 11 + 4, 54); g.stroke(); }
    g.fillStyle = '#fff6c8'; [[-22, -30], [6, -40], [26, -24], [-4, -22], [14, -10]].forEach(([x, y]) => { g.beginPath(); for (let k = 0; k < 10; k++){ const a = -Math.PI / 2 + k * Math.PI / 5, r = k % 2 ? 2.2 : 5; g.lineTo(x + Math.cos(a) * r, y + Math.sin(a) * r); } g.closePath(); g.fill(); });
  } else if (sp.id === 'crownpuffer'){
    g.fillStyle = sp.color; g.beginPath(); g.moveTo(44, 0); g.lineTo(70, -20); g.lineTo(70, 20); g.closePath(); g.fill();
    g.strokeStyle = '#b8a050'; g.lineWidth = 3; for (let k = 0; k < 14; k++){ const a = k / 14 * Math.PI * 2; g.beginPath(); g.moveTo(Math.cos(a) * 44, Math.sin(a) * 40); g.lineTo(Math.cos(a) * 54, Math.sin(a) * 50); g.stroke(); }
    const gr = g.createLinearGradient(0, -42, 0, 42); gr.addColorStop(0, sp.color); gr.addColorStop(.6, sp.belly); g.fillStyle = gr; g.beginPath(); g.ellipse(0, 0, 46, 42, 0, 0, 7); g.fill();
    g.fillStyle = 'rgba(120,100,40,.35)'; [[-10, -20], [12, -26], [20, -8], [-2, -6]].forEach(([x, y]) => { g.beginPath(); g.arc(x, y, 4, 0, 7); g.fill(); });
    g.fillStyle = '#f2c230'; g.beginPath(); g.moveTo(-26, -40); g.lineTo(-26, -60); g.lineTo(-16, -50); g.lineTo(-6, -66); g.lineTo(4, -50); g.lineTo(14, -60); g.lineTo(14, -40); g.closePath(); g.fill();   // 작은 금관
    g.fillStyle = '#d64545'; g.beginPath(); g.arc(-6, -46, 3.4, 0, 7); g.fill();
    eye(-24, -6, 7); g.strokeStyle = '#7a5a20'; g.lineWidth = 2; g.beginPath(); g.arc(-36, 12, 6, 0.2, 2.6); g.stroke();
  } else if (sp.id === 'moonray'){
    g.strokeStyle = sp.color; g.lineWidth = 3; g.beginPath(); g.moveTo(30, 0); g.quadraticCurveTo(70, 6, 100, -12); g.stroke();   // 긴 꼬리
    const gr = g.createLinearGradient(0, -50, 0, 50); gr.addColorStop(0, '#3a5490'); gr.addColorStop(1, sp.color); g.fillStyle = gr;
    g.beginPath(); g.moveTo(-60, 0); g.quadraticCurveTo(-20, -60, 10, -50); g.quadraticCurveTo(30, -10, 36, 0); g.quadraticCurveTo(30, 10, 10, 50); g.quadraticCurveTo(-20, 60, -60, 0); g.fill();
    g.fillStyle = '#f6e7a8'; g.beginPath(); g.arc(-8, 0, 16, 0, 7); g.fill(); g.fillStyle = '#34497e'; g.beginPath(); g.arc(-2, -5, 14, 0, 7); g.fill();   // 초승달
    g.fillStyle = 'rgba(246,231,168,.8)'; [[-30, -24], [12, 26], [18, -30], [-34, 22]].forEach(([x, y]) => { g.beginPath(); g.arc(x, y, 2, 0, 7); g.fill(); });
    eye(-46, -10, 4.5);
  } else {   /* 등불 아귀 */
    g.strokeStyle = '#6a5a80'; g.lineWidth = 3; g.beginPath(); g.moveTo(-20, -30); g.quadraticCurveTo(-30, -70, -66, -56); g.stroke();
    const lg = g.createRadialGradient(-68, -54, 2, -68, -54, 24); lg.addColorStop(0, 'rgba(255,240,170,1)'); lg.addColorStop(1, 'rgba(255,200,90,0)'); g.fillStyle = lg; g.beginPath(); g.arc(-68, -54, 24, 0, 7); g.fill();
    g.fillStyle = '#ffe9a0'; g.beginPath(); g.arc(-68, -54, 7, 0, 7); g.fill();
    g.fillStyle = sp.color; g.beginPath(); g.moveTo(48, 0); g.lineTo(80, -24); g.lineTo(76, 0); g.lineTo(80, 24); g.closePath(); g.fill();
    g.beginPath(); g.ellipse(0, 4, 56, 38, 0, 0, 7); g.fill();
    g.fillStyle = '#2a2036'; g.beginPath(); g.moveTo(-56, 6); g.quadraticCurveTo(-20, 30, -4, 14); g.quadraticCurveTo(-24, 20, -56, 6); g.fill();   // 큰 입
    g.fillStyle = '#f4f0e6'; for (let k = 0; k < 5; k++){ g.beginPath(); g.moveTo(-50 + k * 9, 9 + k * 1.5); g.lineTo(-46 + k * 9, 17 + k * 1.5); g.lineTo(-42 + k * 9, 9 + k * 1.5); g.fill(); }
    eye(-26, -12, 6);
  }
  spark();
}
function catchURL(sp){
  if (catchArt[sp.id]) return catchArt[sp.id];
  const c = document.createElement('canvas'); c.width = 240; c.height = 150; const g = c.getContext('2d'); if (!g) return '';
  g.translate(120, 78);
  if (sp.kind === 'treasure'){ drawTreasure(g, sp); }
  else if (sp.kind === 'boot'){
    g.fillStyle = sp.color; g.beginPath(); g.moveTo(-30, -55); g.lineTo(14, -55); g.lineTo(14, 12); g.quadraticCurveTo(70, 14, 72, 40); g.lineTo(-30, 40); g.closePath(); g.fill();
    g.fillStyle = sp.belly; g.fillRect(-34, 36, 108, 10); g.fillStyle = 'rgba(255,255,255,.15)'; g.fillRect(-22, -48, 8, 70);
  } else if (sp.kind === 'squid'){
    g.fillStyle = sp.color; g.beginPath(); g.moveTo(-70, 0); g.quadraticCurveTo(-20, -30, 30, -16); g.lineTo(30, 16); g.quadraticCurveTo(-20, 30, -70, 0); g.fill();
    g.beginPath(); g.moveTo(-80, 0); g.lineTo(-58, -22); g.lineTo(-58, 22); g.closePath(); g.fill();
    g.strokeStyle = sp.color; g.lineWidth = 4; g.lineCap = 'round'; for (let k = -3; k <= 3; k++){ g.beginPath(); g.moveTo(30, k * 4); g.quadraticCurveTo(60, k * 9, 86, k * 7 + Math.sin(k) * 6); g.stroke(); }
    g.fillStyle = '#1a100a'; g.beginPath(); g.arc(20, -6, 4, 0, 7); g.fill();
  } else if (sp.kind === 'octopus'){
    g.fillStyle = sp.color; g.beginPath(); g.ellipse(0, -22, 34, 30, 0, 0, 7); g.fill();
    g.strokeStyle = sp.color; g.lineWidth = 8; g.lineCap = 'round'; for (let k = 0; k < 8; k++){ const a = Math.PI * (0.1 + k * 0.115); g.beginPath(); g.moveTo(Math.cos(a) * 22, 0); g.quadraticCurveTo(Math.cos(a) * 48, 30, Math.cos(a) * 60 + (k % 2 ? 8 : -8), 48); g.stroke(); }
    g.fillStyle = '#fff'; [-12, 12].forEach(x => { g.beginPath(); g.arc(x, -18, 7, 0, 7); g.fill(); }); g.fillStyle = '#1a100a'; [-12, 12].forEach(x => { g.beginPath(); g.arc(x + 1, -17, 3.5, 0, 7); g.fill(); });
  } else {
    const L = sp.round ? 52 : 78, H = sp.round ? 44 : (sp.id === 'filefish' ? 36 : 26);
    g.fillStyle = sp.color; g.beginPath(); g.moveTo(L * .8, 0); g.lineTo(L + 26, -H * .9); g.lineTo(L + 18, 0); g.lineTo(L + 26, H * .9); g.closePath(); g.fill();
    if (sp.wings){ g.fillStyle = 'rgba(120,180,230,.75)'; g.beginPath(); g.moveTo(-6, 0); g.lineTo(46, -52); g.lineTo(30, 4); g.closePath(); g.fill(); }
    const gr = g.createLinearGradient(0, -H, 0, H); gr.addColorStop(0, sp.color); gr.addColorStop(.55, sp.color); gr.addColorStop(.62, sp.belly); gr.addColorStop(1, sp.belly);
    g.fillStyle = gr; g.beginPath(); g.ellipse(0, 0, L, H, 0, 0, 7); g.fill();
    g.fillStyle = sp.color; g.beginPath(); g.moveTo(-10, -H + 2); g.lineTo(22, -H - 16); g.lineTo(34, -H + 6); g.closePath(); g.fill();
    if (sp.id === 'mackerel'){ g.strokeStyle = 'rgba(20,40,60,.55)'; g.lineWidth = 2.5; for (let k = 0; k < 6; k++){ g.beginPath(); g.moveTo(-30 + k * 13, -H + 6); g.quadraticCurveTo(-24 + k * 13, -8, -32 + k * 13, -2); g.stroke(); } }
    if (sp.rare){ g.strokeStyle = 'rgba(255,240,180,.9)'; g.lineWidth = 2; for (let k = 0; k < 5; k++){ const a = k * 1.3; g.beginPath(); g.moveTo(Math.cos(a) * 92, Math.sin(a) * 52); g.lineTo(Math.cos(a) * 104, Math.sin(a) * 60); g.stroke(); } }
    g.fillStyle = '#fff'; g.beginPath(); g.arc(-L * .62, -H * .22, 7, 0, 7); g.fill(); g.fillStyle = '#1a100a'; g.beginPath(); g.arc(-L * .64, -H * .22, 3.6, 0, 7); g.fill();
    g.strokeStyle = 'rgba(0,0,0,.25)'; g.lineWidth = 2; g.beginPath(); g.arc(-L * .38, 0, H * .7, -0.9, 0.9); g.stroke();
  }
  try { catchArt[sp.id] = c.toDataURL('image/png'); } catch(e){ catchArt[sp.id] = ''; }
  return catchArt[sp.id];
}

/* ---------- 3D: 찌 · 낚싯줄 · 낚싯대 · 유리병 ---------- */
const F3 = { bob:null, line:null, rod:null, tip:new THREE.Vector3(), target:new THREE.Vector3(0, -2.3, -22), from:new THREE.Vector3(), bottles:[] };
function buildFishing(){
  const bob = new THREE.Group();
  const red = new THREE.MeshStandardMaterial({ color:'#d23a2a', roughness:.5 }), wht = new THREE.MeshStandardMaterial({ color:'#f4f0e6', roughness:.5 });
  const top = new THREE.Mesh(new THREE.SphereGeometry(0.16, 14, 8, 0, Math.PI * 2, 0, Math.PI / 2), red); bob.add(top);
  const bot = new THREE.Mesh(new THREE.SphereGeometry(0.16, 14, 8, 0, Math.PI * 2, Math.PI / 2, Math.PI / 2), wht); bob.add(bot);
  bob.visible = false; DK3.out.add(bob); F3.bob = bob;
  const lg = new THREE.BufferGeometry(); lg.setAttribute('position', new THREE.Float32BufferAttribute([0, 0, 0, 0, 0, 0], 3));
  F3.line = new THREE.Line(lg, new THREE.LineBasicMaterial({ color:'#f4f0e6', transparent:true, opacity:.7 })); F3.line.visible = false; F3.line.frustumCulled = false; deckScene.add(F3.line);
  const rod = new THREE.Group();
  const stick = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.03, 2.4, 6), M.woodDark); stick.position.y = 1.2; rod.add(stick);
  const tip = new THREE.Object3D(); tip.position.y = 2.4; rod.add(tip); rod.userData.tip = tip;
  rod.position.set(0, -0.3, 0.05); rod.rotation.x = 1.0; F3.rod = rod;
}
function bottleMesh(){
  const g = new THREE.Group();
  g.add(new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 0.36, 12), new THREE.MeshStandardMaterial({ color:'#bfe6d8', transparent:true, opacity:.6, roughness:.1 })));
  const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.1, 0.14, 10), new THREE.MeshStandardMaterial({ color:'#bfe6d8', transparent:true, opacity:.6, roughness:.1 })); neck.position.y = 0.25; g.add(neck);
  const cork = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 0.08, 8), new THREE.MeshStandardMaterial({ color:'#a07a52' })); cork.position.y = 0.35; g.add(cork);
  const note = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.24, 8), new THREE.MeshStandardMaterial({ color:'#efe4cc' })); g.add(note);
  g.rotation.z = Math.PI / 2.4; return g;
}
function throwBottle3D(){
  const b = bottleMesh(); DK3.out.add(b);
  const from = new THREE.Vector3(0.3, DECK.qH + 1.4, DECK.stern + 0.4), to = new THREE.Vector3(rand(-3, 3), -2.3, rand(-30, -26));
  F3.bottles.push({ m:b, t:0, from, to, x:to.x, z:to.z });
}
const _tipW = new THREE.Vector3();
function fishStep(dt, t){
  /* 던진 병: 포물선 → 둥둥 → 천천히 멀어져요 */
  for (let i = F3.bottles.length - 1; i >= 0; i--){
    const B = F3.bottles[i]; B.t += dt;
    if (B.t < 1.0){ const k = B.t; B.m.position.lerpVectors(B.from, B.to, k); B.m.position.y = B.from.y + (B.to.y - B.from.y) * k + Math.sin(k * Math.PI) * 2.2; B.m.rotation.x += dt * 6; }
    else { B.z -= dt * 1.2; B.m.position.set(B.x + Math.sin(t + i) * 0.2, -2.35 + waveH(B.x, B.z, t) * 0.8, B.z); B.m.rotation.x = Math.sin(t * 1.4 + i) * 0.3; }
    if (B.t > 9){ DK3.out.remove(B.m); F3.bottles.splice(i, 1); }
  }
  if (!F3.bob) return;
  if (!fi.open){ F3.bob.visible = false; F3.line.visible = false; return; }
  /* 낚싯대 끝 */
  if (F3.rod.parent) F3.rod.userData.tip.getWorldPosition(_tipW); else fiTipFallback(_tipW);
  const bobOn = ['cast', 'wait', 'bite'].includes(fi.state);
  F3.bob.visible = bobOn; F3.line.visible = bobOn;
  if (!bobOn) return;
  fi.t += dt;
  const T = F3.target, wt = reduceMotion ? 0 : t, base = FCTX.kind === 'pier' ? -1.68 + waveH(T.x, T.z, wt) * 0.55 : -2.33 + waveH(T.x, T.z, wt) * 0.8;
  if (fi.state === 'cast'){
    const k = Math.min(1, fi.t / 0.7);
    F3.bob.position.lerpVectors(F3.from, T, k); F3.bob.position.y = F3.from.y + (base - F3.from.y) * k + Math.sin(k * Math.PI) * 2.5;
    if (k >= 1) fiSet('wait');
  } else if (fi.state === 'wait'){
    F3.bob.position.set(T.x, base + Math.sin(t * 2.2) * 0.04, T.z);
    if (fi.t > fi.wait) fiSet('bite');
  } else if (fi.state === 'bite'){
    F3.bob.position.set(T.x, base - 0.18 - Math.abs(Math.sin(fi.t * 14)) * 0.12, T.z);
    if (fi.t > 1.4) fiResult('miss');
  }
  /* 줄 (DK3.out 이 살짝 기울어 있어서 찌 위치를 세상 좌표로) */
  const bw = F3.bob.getWorldPosition(new THREE.Vector3());
  const a = F3.line.geometry.attributes.position; a.setXYZ(0, _tipW.x, _tipW.y, _tipW.z); a.setXYZ(1, bw.x, bw.y, bw.z); a.needsUpdate = true;
}

function fiTipFallback(v){
  if (FCTX.kind === 'pier'){ const S = FCTX.seat; v.set(S.x + Math.sin(S.face) * 0.6, FP.H + 2.2, S.z + Math.cos(S.face) * 0.6); }
  else v.set(0, DECK.qH + 2.2, DECK.stern + 0.3);
}
/* ---------- 낚시 흐름 ---------- */
function fiSet(st){ fi.state = st; fi.t = 0; renderFishing(); }
function fiCast(){
  if (!['idle', 'result', 'miss', 'early'].includes(fi.state)) return;
  if (FCTX.kind === 'pier'){ const S = FCTX.seat, fx = Math.sin(S.face), fz = Math.cos(S.face), d = rand(5, 7.5), lat = rand(-1.3, 1.3); F3.target.set(S.x + fx * d + fz * lat, -1.7, S.z + fz * d - fx * lat); }
  else F3.target.set(rand(-1.6, 1.6), -2.3, rand(-24, -20));
  if (F3.rod.parent) F3.rod.userData.tip.getWorldPosition(F3.from); else fiTipFallback(F3.from);
  fi.wait = rand(2.0, 5.5); fiSet('cast');
}
function fiPull(){
  if (fi.state === 'bite') return fiResult('catch');
  if (fi.state === 'wait' || fi.state === 'cast') return fiResult('early');
}
/* 낚인 것 고르기 (밤에만 나오는 종류도 있어요) */
const TREASURE_CATCH = 0.005;   /* 보물 물고기(20은화) 5종을 합쳐 0.5% */
function rollFish(){
  const night = timeMode !== 'day';
  const okTime = s => (!s.night || night) && (!s.day || !night);   /* 낮 · 밤에 따라 나오는 물고기가 달라요 (창밖 버튼) */
  if (Math.random() < TREASURE_CATCH){ const T = FISH.filter(s => s.treasure && okTime(s)); return T[Math.floor(Math.random() * T.length)]; }
  const pool = FISH.filter(s => !s.treasure && okTime(s)), sum = pool.reduce((a, s) => a + s.w, 0);
  let r = Math.random() * sum; for (const s of pool){ r -= s.w; if (r <= 0) return s; } return pool[0];
}
function fiResult(kind){
  if (kind !== 'catch'){ fi.catchRes = null; fiSet(kind); return; }
  const f = fishData();
  /* 공용 낚시터: 가끔 다른 선장님의 유리병 (내 병 · 숨겨진 병 · 이미 낚은 병은 빼고) */
  const pool = FCTX.kind === 'pier' ? FCTX.pool.filter(b => !f.got.includes(b.id) && LPData.get(b.work) && checkSpoiler(b.text, b.work).ok) : [];
  if (ISLE_BOTTLES && pool.length && Math.random() < BOTTLE_CATCH){
    const b = pool[Math.floor(Math.random() * pool.length)];
    f.got.push(b.id);
    /* 낚은 편지는 선장실 보물 상자에 모아 둬요 */
    f.letters.unshift({ id:b.id, work:b.work, text:b.text, from:b.from || null, at:b.at || null, caughtAt:new Date().toISOString(), sample:!!b.sample });
    f.letters = f.letters.slice(0, 80); saveFish(f);
    fi.catchRes = { bottle:b }; pulseLogpose(); fiSet('result'); return;
  }
  const sp = rollFish(), size = sp.size ? Math.round(rand(sp.size[0], sp.size[1])) : null;
  const d = f.dex[sp.id] || { n:0, best:0 }, isNew = !d.n, isBest = size && size > (d.best || 0) && d.n > 0;
  d.n += 1; if (size && size > (d.best || 0)) d.best = size; f.dex[sp.id] = d;
  /* 어창에 자동으로 보관 (가득 차면 보관하지 않고 알려줘요) */
  const at = new Date().toISOString(), kept = f.hold.length < HOLD_MAX;
  if (kept) f.hold.push({ sp:sp.id, size, at });
  saveFish(f);
  fi.catchRes = { sp, size, isNew, isBest, kept, at };
  pulseLogpose(); fiSet('result');
}

/* ---------- 화면 ---------- */
const TITLES = { idle:'고물 낚시터', cast:'휙—', wait:'찌가 둥둥…', bite:'입질이에요!', result:'낚았어요!', miss:'놓쳤어요', early:'너무 일찍 당겼어요', bottle:'유리병 던지기', dex:'물고기 도감', thrown:'병을 띄워 보냈어요', hold:'어창 · 물고기 보관함' };
function renderFishing(){
  const st = fi.state, f = fishData(), caught = FISH.filter(s => f.dex[s.id]).length;
  const pier = FCTX.kind === 'pier';
  FI.title.textContent = st === 'result' && fi.catchRes && fi.catchRes.bottle ? '유리병이 낚였어요!' : (st === 'idle' && pier ? `공용 낚시터 · 자리 ${FCTX.seat.n}` : TITLES[st] || '고물 낚시터');
  FI.kick.textContent = pier ? '절영도 · 바다로 뻗은 잔교' : '고물 난간 · 심심풀이';
  FI.hold.innerHTML = `어창 <b>${f.hold.length}</b>/${HOLD_MAX}`; FI.hold.setAttribute('aria-pressed', String(st === 'hold'));
  FI.root.dataset.state = st;
  let h = '';
  if (st === 'idle'){
    h = `<p class="fi-hint">찌를 던지고, 찌가 쑥 잠기며 <b>입질</b>이 오면 바로 당겨요. 낚은 물고기는 위의 <b>어창</b>에 모여요.${timeMode !== 'day' ? ' 🌙 밤에는 <b>오징어 · 갈치 · 볼락</b>이 올라오고, 날치 · 방어는 숨어요.' : ' ☀ 낮에는 <b>날치 · 방어</b>가 잘 물어요. 밤엔 다른 물고기가 와요 (위쪽 창밖 버튼).'}</p>
      <div class="fi-btns"><button type="button" class="g-btn primary fi-main" data-act="cast">낚싯대 던지기 <kbd>Space</kbd></button></div>
      <div class="fi-btns sub">${pier ? '' : `<button type="button" class="g-btn" data-act="bottle">유리병 던지기 <small>남은 병 ${bottleQuota(f).left}</small></button>`}<button type="button" class="g-btn" data-act="dex">물고기 도감 <small>${caught} / ${FISH.length}</small></button></div>
      ${pier && ISLE_BOTTLES ? `<p class="fi-share">🍾 이 바다엔 다른 선장님의 유리병이 <b>${FCTX.pool.filter(b => !f.got.includes(b.id)).length}개</b> 떠다녀요. 물고기 사이로 가끔 낚여요.<small>${FCTX.share ? escHTML(FCTX.share.label) : ''} · 유리병 던지기는 내 배 갑판 고물 낚시터에서</small></p>` : ''}`;
  } else if (st === 'cast' || st === 'wait'){
    h = `<p class="fi-hint">찌가 쑥 잠길 때까지 기다려요…</p><div class="fi-btns"><button type="button" class="g-btn primary fi-main" data-act="pull">당기기 <kbd>Space</kbd></button></div>`;
  } else if (st === 'bite'){
    h = `<p class="fi-hint fi-now"><b>지금 당기세요!</b></p><div class="fi-btns"><button type="button" class="g-btn primary fi-main fi-pulse" data-act="pull">당기기! <kbd>Space</kbd></button></div>`;
  } else if (st === 'miss' || st === 'early'){
    h = `<p class="fi-hint">${st === 'miss' ? '물고기가 미끼만 먹고 달아났어요. 찌가 잠기면 바로 당겨 보세요.' : '아직 입질이 오기 전이었어요. 찌가 쑥 잠길 때까지 기다려요.'}</p>
      <div class="fi-btns"><button type="button" class="g-btn primary fi-main" data-act="cast">다시 던지기 <kbd>Space</kbd></button><button type="button" class="g-btn ghost" data-act="idle">잠깐 쉬기</button></div>`;
  } else if (st === 'result' && fi.catchRes && fi.catchRes.bottle){
    const b = fi.catchRes.bottle, w = LPData.get(b.work), rep = fi.catchRes.reported;
    h = `<article class="fi-letter">
        <p class="fi-from">다른 선장님이 보낸 유리병 <small>${b.sample ? '시연용 예시 병 · ' : ''}${fmtDay(b.at)}에 띄운 병이에요</small></p>
        <div class="fi-lw"><img src="${coverURL(w)}" alt=""><div><b>${escHTML(w.title)}</b><small>${escHTML(w.genre.name)}</small><p class="fi-quote">“${escHTML(b.text)}”</p></div></div>
        <p class="fi-sender">보낸 사람 · <b>${escHTML(senderText(b.from))}</b></p>
      </article>
      ${rep ? `<p class="fi-kept off" role="status">신고했어요. 이 병은 선장님께 다시 보이지 않아요${rep.hidden ? ' · 신고가 쌓여 모두에게서 숨겨졌어요' : ''}.</p>` : ''}
      <div class="fi-btns"><button type="button" class="g-btn primary" data-open="${w.id}">책상에서 열기</button><button type="button" class="g-btn" data-save="${w.id}" aria-pressed="${isSaved(w.id)}">${isSaved(w.id) ? '✓ 저장됨' : '내 로그포스에 저장'}</button></div>
      <p class="fi-hint">낚은 편지는 선장실 <b>보물 상자</b>에 모아 둬요.</p>
      <div class="fi-btns sub"><button type="button" class="g-btn ghost" data-act="cast">다시 던지기</button>${rep ? '' : '<button type="button" class="g-btn ghost fi-report" data-act="report">스포일러 신고 · 숨기기</button>'}</div>`;
  } else if (st === 'result' && fi.catchRes){
    const { sp, size, isNew, isBest, kept, released } = fi.catchRes;
    const keepMsg = released ? '바다로 놓아줬어요. 잘 가!' : kept ? `어창에 보관했어요 · 예상 <b>${fishValue(sp, size)}은화</b> <small>(${f.hold.length}/${HOLD_MAX})</small>` : `어창이 가득 찼어요(${HOLD_MAX}/${HOLD_MAX}). 어창에서 몇 마리를 놓아주면 다시 보관돼요.`;
    h = `<div class="fi-catch${sp.rare || sp.treasure ? ' rare' : ''}${sp.treasure ? ' treasure' : ''}">${sp.treasure ? '<p class="fi-trea">✦ 보물 물고기! ✦</p>' : ''}<img src="${catchURL(sp)}" alt="${escHTML(sp.name)} 그림"><div><b>${escHTML(sp.name)}</b>${size ? `<span class="fi-size">${size}cm</span>` : ''}${isNew ? '<span class="fi-tag">도감에 새로 올렸어요!</span>' : isBest ? '<span class="fi-tag">최고 기록!</span>' : ''}<p>${escHTML(sp.note)}</p></div></div>
      <p class="fi-kept${kept && !released ? '' : ' off'}" role="status">${keepMsg}</p>
      <div class="fi-btns"><button type="button" class="g-btn primary fi-main" data-act="cast">다시 던지기 <kbd>Space</kbd></button>${kept && !released ? '<button type="button" class="g-btn ghost" data-act="release">놓아주기</button>' : ''}<button type="button" class="g-btn" data-act="hold">어창 보기</button></div>`;
  } else if (st === 'hold'){
    const groups = FISH.map(sp => ({ sp, list:f.hold.map((x, i) => ({ ...x, i })).filter(x => x.sp === sp.id) })).filter(g => g.list.length);
    const total = f.hold.reduce((a, x) => a + fishValue(spOf(x.sp), x.size), 0);
    h = `<p class="fi-hint">${f.hold.length ? `${f.hold.length}마리 보관 중 · 모두 팔면 예상 <b>${total}은화</b>` : '아직 보관한 물고기가 없어요. 낚은 물고기는 여기에 자동으로 모여요.'}</p>
      ${groups.length ? `<ul class="fi-hold">${groups.map(({ sp, list }) => { const best = Math.max(0, ...list.map(x => x.size || 0)), val = list.reduce((a, x) => a + fishValue(sp, x.size), 0);
        return `<li><img src="${catchURL(sp)}" alt=""><div><b>${escHTML(sp.name)} <span>×${list.length}</span></b><small>${best ? `가장 큰 것 ${best}cm · ` : ''}예상 ${val}은화</small></div><button type="button" class="lm-b del" data-rel="${sp.id}" aria-label="${escHTML(sp.name)} 한 마리 놓아주기">한 마리 놓아주기</button></li>`; }).join('')}</ul>` : ''}
      <p class="fi-market">🏝 <b>절영도 시장</b>에서 은화로 팔아 <b>모자 · 해적기</b>를 사고, 주점 럼통에서 <b>맥주</b>를 마실 수 있어요. <small>지금 은화 ${shopData().silver}</small></p>
      <div class="fi-btns"><button type="button" class="g-btn primary" data-act="idle">낚시터로</button></div>`;
  } else if (st === 'dex'){
    h = `<p class="fi-hint">${caught} / ${FISH.length}종을 낚았어요.</p><ul class="fi-dex">${FISH.map(s => { const d = f.dex[s.id];
      const tm = s.night ? '<i class="fi-tm n">🌙 밤</i>' : s.day ? '<i class="fi-tm d">☀ 낮</i>' : '';
      return d ? `<li><img src="${catchURL(s)}" alt=""><b>${escHTML(s.name)}</b><small>${d.n}마리${d.best ? ` · 최고 ${d.best}cm` : ''}</small>${tm}</li>` : `<li class="unk"><span aria-hidden="true">?</span><b>???</b><small>${s.treasure ? '보물 물고기' : s.night ? '밤에 만날지도' : s.day ? '낮에 만날지도' : s.rare ? '전설의 물고기' : '아직 미발견'}</small>${tm}</li>`; }).join('')}</ul>
      <div class="fi-btns"><button type="button" class="g-btn primary" data-act="idle">낚시터로</button></div>`;
  } else if (st === 'bottle' || st === 'thrown'){
    const w = fi.formWork && LPData.get(fi.formWork), q = bottleQuota(f), lock = bottleLock(f), me = senderOf();
    const quotaLine = `<p class="fi-quota">남은 병 <b>${q.left}</b>개 <small>로그포스에 저장한 작품 ${q.saved}편만큼 쓸 수 있어요 · 보낸 병 ${q.used}개</small></p>`;
    let form;
    if (st === 'thrown') form = `<p class="fi-hint fi-ok">병이 파도를 타고 멀어져요. <b>절영도 낚시터</b>에서 다른 선장님이 낚을 수 있어요.</p>${quotaLine}`;
    else if (lock) form = `<p class="fi-hint fi-lock">스포일러 경고가 ${SPOIL_MAX}번 쌓여서 <b>${lock}분 뒤</b>에 다시 병을 쓸 수 있어요.<br><small>처음 보는 선장님이 재미를 잃지 않게, 결말 · 정체 · 반전은 병에 넣지 말아 주세요.</small></p>
      <div class="fi-btns"><button type="button" class="g-btn primary" data-act="idle">낚시터로</button></div>`;
    else if (!q.left) form = `<p class="fi-hint">${q.saved ? `저장한 작품 ${q.saved}편만큼 병을 모두 썼어요.` : '아직 로그포스에 저장한 작품이 없어요.'} <b>책상에서 작품을 저장</b>하면 병이 하나씩 늘어나요.</p>${quotaLine}
      <div class="fi-btns"><button type="button" class="g-btn primary" data-act="idle">낚시터로</button></div>`;
    else form = `
      <p class="fi-hint">추천하고 싶은 작품과 한줄평을 병에 담아 던져요. 병은 <b>절영도 낚시터</b>에서 다른 선장님이 낚게 될 거예요.</p>${quotaLine}
      <label class="fi-l" for="fiWorkQ">추천할 작품</label>
      ${w ? `<div class="fi-picked"><b>${escHTML(w.title)}</b><small>${escHTML(w.genre.name)}</small><button type="button" class="lm-b" data-act="unpick">바꾸기</button></div>`
          : `<input class="fi-in" id="fiWorkQ" type="search" placeholder="제목 · 초성 (예: 프리렌, ㅅㅍ)" autocomplete="off"><div class="fi-res" id="fiWorkR"></div>`}
      <label class="fi-l" for="fiText">한줄평 <small id="fiCount">0 / ${BOTTLE_TEXT_MAX}</small></label>
      <input class="fi-in" id="fiText" maxlength="${BOTTLE_TEXT_MAX}" placeholder="예: 첫 화부터 여운이 길어요" autocomplete="off">
      <p class="fi-rule">결말 · 누가 죽는지 · 숨겨진 정체 · 반전, 1화 뒤에 나오는 인물 이름은 넣을 수 없어요.${f.warn.n ? ` <b>스포일러 경고 ${f.warn.n}/${SPOIL_MAX}</b>` : ''}</p>
      <p class="fi-from2">보낸 사람 · <b>${escHTML(senderText(me))}</b></p>
      <p class="fi-err" id="fiErr" role="alert"></p>
      <div class="fi-btns"><button type="button" class="g-btn primary" data-act="throw">병에 담아 던지기</button><button type="button" class="g-btn ghost" data-act="idle">그만두기</button></div>`;
    h = form +
      (f.sent.length ? `<h3 class="fi-h">보낸 병 <small>${f.sent.length}개 · 절영도 낚시터에 가면 공용 바다에 띄워져요</small></h3><ul class="fi-sent">${f.sent.slice().reverse().map(b => { const sw = LPData.get(b.work); return sw ? `<li><b>${escHTML(sw.title)}</b><span>“${escHTML(b.text)}”</span><small class="fi-by">보낸 사람 · ${escHTML(senderText(b.from || me))} · ${fmtDay(b.at)} · ${b.shared ? '<em>공용 바다에 떠 있어요</em>' : '절영도에 가면 띄워져요'}</small></li>` : ''; }).join('')}</ul>` : '') +
      (st === 'thrown' ? `<div class="fi-btns"><button type="button" class="g-btn primary" data-act="idle">낚시터로</button>${q.left && !lock ? '<button type="button" class="g-btn" data-act="bottle">한 병 더 쓰기</button>' : ''}</div>` : '');
  }
  FI.body.innerHTML = h;
  FI.body.querySelectorAll('[data-act]').forEach(b => b.addEventListener('click', () => fiAct(b.dataset.act)));
  FI.body.querySelectorAll('[data-rel]').forEach(b => b.addEventListener('click', () => releaseOne(b.dataset.rel)));
  FI.body.querySelectorAll('[data-open]').forEach(b => b.addEventListener('click', () => { const id = b.dataset.open; closeFishing(true); openDeskInfo(id, {}); }));
  FI.body.querySelectorAll('[data-save]').forEach(b => b.addEventListener('click', () => { const on = toggleSave(b.dataset.save); b.textContent = on ? '✓ 저장됨' : '내 로그포스에 저장'; b.setAttribute('aria-pressed', String(on)); pulseLogpose(); }));
  if (st === 'bottle') wireBottleForm();
  const main = FI.body.querySelector('.fi-main') || FI.body.querySelector('#fiWorkQ') || FI.body.querySelector('#fiText') || FI.body.querySelector('button');
  if (main && !(st === 'bottle' && document.activeElement && FI.root.contains(document.activeElement) && document.activeElement.tagName === 'INPUT')) setTimeout(() => { try { main.focus({ preventScroll:true }); } catch(e){} }, 30);
}
function fiAct(a){
  if (a === 'cast') return fiCast();
  if (a === 'pull') return fiPull();
  if (a === 'idle') return fiSet('idle');
  if (a === 'dex') return fiSet('dex');
  if (a === 'hold') return fiSet('hold');
  if (a === 'release'){ const r = fi.catchRes; if (!r || !r.kept || r.released) return; const f = fishData(); const i = f.hold.findIndex(x => x.at === r.at && x.sp === r.sp.id); if (i >= 0){ f.hold.splice(i, 1); saveFish(f); } r.released = true; return renderFishing(); }
  if (a === 'bottle'){ fi.formWork = null; return fiSet('bottle'); }
  if (a === 'unpick'){ fi.formWork = null; const keep = ($('#fiText') || {}).value || ''; fiSet('bottle'); const t = $('#fiText'); if (t){ t.value = keep; t.dispatchEvent(new Event('input')); } return; }
  if (a === 'throw') return fiThrow();
  if (a === 'report'){ const r = fi.catchRes; if (!r || !r.bottle || r.reported) return; LPShare.report(r.bottle.id, captainId()).then(res => { r.reported = res || { hidden:false }; renderFishing(); }); return; }
}
/* 어창에서 한 마리 놓아주기 (그 종류 중 가장 작은 것부터) */
function releaseOne(spId){
  const f = fishData(); let idx = -1, small = Infinity;
  f.hold.forEach((x, i) => { if (x.sp === spId && (x.size || 0) < small){ small = x.size || 0; idx = i; } });
  if (idx < 0) return; f.hold.splice(idx, 1); saveFish(f); renderFishing();
  const next = FI.body.querySelector(`[data-rel="${spId}"]`) || FI.body.querySelector('[data-rel]') || FI.body.querySelector('[data-act="idle"]'); if (next) try { next.focus({ preventScroll:true }); } catch(e){}
}
/* 병 개수: 로그포스에 저장한 작품 수만큼 */
function bottleQuota(f){ const saved = savedList().filter(x => LPData.get(x.id)).length, used = f.sent.length; return { saved, used, left:Math.max(0, saved - used) }; }
/* 스포일러 거르기: 결말 · 죽음 · 정체 · 반전 같은 표현 + 1화 뒤에 처음 나오는 인물 · 용어 이름 */
const SPOIL_RULES = [
  [/죽(는다|어요|었|음|여요|여서|이고|인다|게 ?(돼|되|된)|고 ?말)|사망|목숨을 ?잃|살해|전사(해|했|한)/, '누가 죽는지'],
  [/범인(은|이|는|이었)|흑막|정체(는|가|가 ?밝)|진짜 ?정체|알고 ?보니|사실은 .{0,10}(였|이었|이다)/, '숨겨진 정체'],
  [/결말|엔딩(은|이|에서)|마지막(에|화|회)|최종화|최종 ?보스|끝(에|엔) .{0,8}(된다|돼요|됨)/, '결말'],
  [/반전(은|이|으로)|배신(자|해|했|한|당)|뒤통수/, '반전'],
  [/스포(일러)?/, '스포일러 예고']
];
const SPOIL_OK = new Set(['파워', '레몬', '하나']);
function checkSpoiler(text, workId){
  for (const [re, what] of SPOIL_RULES){ const m = text.match(re); if (m) return { ok:false, what, hit:m[0] }; }
  const w = LPData.get(workId);
  if (w) for (const n of (w.later || [])){ if (SPOIL_OK.has(n)) continue; if (text.includes(n)) return { ok:false, what:'1화 뒤에 나오는 이름', hit:n }; }
  return { ok:true };
}
const SPOIL_MAX = 3, SPOIL_LOCK = 10 * 60 * 1000;
function bottleLock(f){ return f.warn && f.warn.until > Date.now() ? Math.ceil((f.warn.until - Date.now()) / 60000) : 0; }
/* 시연용 예시 병: 공용 서버가 붙기 전엔 바다가 비어 있어서, 다른 선장님 병이 적으면 예시 병을 띄워 둬요 (sample 표시) */
const SAMPLE_LINES = [
  ['파도소리', 'laftel-demo', '1화 오프닝부터 분위기에 푹 빠져요. 밤에 보기 딱!'],
  ['고래잡이', 'guest', '주인공이 조금씩 자라는 게 보여서 계속 응원하게 돼요.'],
  ['별헤는밤', 'laftel-demo', '작화가 예뻐서 몇 번이나 멈추고 감상했어요.'],
  ['등대지기', 'guest', '가볍게 웃고 싶을 때 틀어요. 한 화가 금방 가요.'],
  ['바닷바람', 'laftel-demo', '음악이 좋아서 다 보고 나서도 계속 들었어요.'],
  ['모래성', 'guest', '세계관 설명이 친절해서 처음 보는 사람도 괜찮아요.']
];
function withSamples(list){
  if (list.length >= 4) return list;
  const all = LPData.all().filter(w => w && checkSpoiler('', w.id).ok), got = fishData().got;
  if (!all.length) return list;
  const day = 86400000, now = Date.now();
  const samples = SAMPLE_LINES.map(([name, kind, text], i) => { const w = all[(i * 7 + 3) % all.length];
    return { id:'sample-' + i, work:w.id, text, from:{ name, kind }, at:new Date(now - (i + 1) * day).toISOString(), sample:true }; })
    .filter(b => !got.includes(b.id) && checkSpoiler(b.text, b.work).ok);
  return list.concat(samples);
}
const senderOf = () => { const p = LPProfile.get(); return p ? { name:p.nickname, kind:p.kind } : { name:'이름 없는', kind:'guest' }; };
const senderText = from => `${from && from.name ? from.name : '이름 없는'} 선장 · ${LPProfile.kindLabel({ kind:from && from.kind })}`;
/* 병 쓰기: 작품은 63편 목록에서만, 한줄평은 60자 · 링크 금지 */
function wireBottleForm(){
  const q = $('#fiWorkQ'), r = $('#fiWorkR'), t = $('#fiText'), c = $('#fiCount');
  if (q){
    const draw = () => { const v = q.value.trim(); const list = v ? LPData.search(v).slice(0, 5) : [];
      r.innerHTML = list.map(w => `<button type="button" class="q-res" data-w="${w.id}"><b>${escHTML(w.title)}</b><small>${escHTML(w.genre.name)}</small></button>`).join('') || (v ? `<p class="fi-sub">"${escHTML(v)}"에 맞는 작품이 없어요.</p>` : '');
      r.querySelectorAll('[data-w]').forEach(b => b.addEventListener('click', () => { fi.formWork = b.dataset.w; const keep = t.value; fiSet('bottle'); const t2 = $('#fiText'); if (t2){ t2.value = keep; t2.dispatchEvent(new Event('input')); t2.focus(); } })); };
    q.addEventListener('input', draw);
  }
  if (t) t.addEventListener('input', () => { c.textContent = `${[...t.value].length} / ${BOTTLE_TEXT_MAX}`; });
}
function checkBottleText(raw){
  const s = String(raw || '').replace(/\s+/g, ' ').trim();
  if (!s) return { ok:false, msg:'한줄평을 적어 주세요.' };
  if ([...s].length < 4) return { ok:false, msg:'한줄평은 4자 이상 적어 주세요.' };
  if ([...s].length > BOTTLE_TEXT_MAX) return { ok:false, msg:`한줄평은 ${BOTTLE_TEXT_MAX}자까지예요.` };
  if (/https?:|www\.|[a-z0-9-]+\.(com|net|kr|io|me|co|org|ly|gg)\b/i.test(s)) return { ok:false, msg:'병에는 링크를 넣을 수 없어요.' };
  if (/[<>]/.test(s)) return { ok:false, msg:'꺾쇠(< >)는 쓸 수 없어요.' };
  return { ok:true, text:s };
}
function fiThrow(){
  const err = $('#fiErr'), t = $('#fiText'); if (!err || !t) return;
  const f = fishData();
  if (bottleLock(f) || !bottleQuota(f).left) return renderFishing();
  if (!fi.formWork){ err.textContent = '추천할 작품을 먼저 골라 주세요.'; const q = $('#fiWorkQ'); if (q) q.focus(); return; }
  const r = checkBottleText(t.value); if (!r.ok){ err.textContent = r.msg; t.focus(); return; }
  const sp = checkSpoiler(r.text, fi.formWork);
  if (!sp.ok){
    f.warn.n = (f.warn.n || 0) + 1;
    if (f.warn.n >= SPOIL_MAX){ f.warn = { n:0, until:Date.now() + SPOIL_LOCK }; saveFish(f); fi.formWork = null; return renderFishing(); }
    saveFish(f);
    const keepText = t.value; renderFishing(); const t2 = $('#fiText'), e2 = $('#fiErr');
    if (t2){ t2.value = keepText; t2.dispatchEvent(new Event('input')); t2.focus(); }
    if (e2) e2.textContent = `‘${sp.hit}’ — ${sp.what}${chJosa(sp.what, '은', '는')} 스포일러라 병에 넣을 수 없어요. (경고 ${f.warn.n}/${SPOIL_MAX} · ${SPOIL_MAX}번이면 10분 동안 못 써요)`;
    return;
  }
  f.sent.push({ id:'b' + Date.now().toString(36) + Math.floor(Math.random() * 1e4).toString(36), work:fi.formWork, text:r.text, at:new Date().toISOString(), from:senderOf() });
  if (f.sent.length > SENT_MAX) f.sent = f.sent.slice(-SENT_MAX);
  saveFish(f); fi.formWork = null;
  throwBottle3D(); pulseLogpose(); fiSet('thrown');
  /* 함께 쓰는 바다면 바로 띄워서, 다른 선장님이 절영도 낚시터에서 낚을 수 있게 해요 */
  LPShare.status().then(st => { if (st.mode !== 'server') return;
    const f2 = fishData(), mine = captainId(LPProfile.get()), pend = f2.sent.filter(b => !b.shared).map(b => ({ ...b, from:b.from || senderOf(), owner:mine }));
    return LPShare.putBottles(pend).then(n => { if (!n && !pend.length) return; const f3 = fishData(); f3.sent.forEach(b => { if (pend.some(x => x.id === b.id)) b.shared = true; }); saveFish(f3);
      if (fi.open && fi.state === 'thrown') renderFishing(); }); }).catch(() => {});
}

/* ---------- 열고 닫기 ---------- */
function openFishing(opts = {}){
  if (fi.open) return;
  const pier = AREA === ISLE_AREA && opts.seat;
  if (!pier && AREA !== DECK_AREA) return;
  fi.open = true; uiOpen = true; keys.clear(); auto = null; $('#toast').hidden = true;
  FCTX.kind = pier ? 'pier' : 'deck'; FCTX.seat = pier ? opts.seat : null;
  const ud = player.mesh.userData; if (ud && ud.rArm && F3.rod) ud.rArm.add(F3.rod);
  /* 찌 · 줄을 지금 있는 바다로 옮겨요 */
  if (pier){ isleScene.add(F3.bob); isleScene.add(F3.line); } else { DK3.out.add(F3.bob); deckScene.add(F3.line); }
  if (pier){
    const S = opts.seat, fx = Math.sin(S.face), fz = Math.cos(S.face);
    player.x = S.x; player.z = S.z; player.r = S.face;
    ISLE_AREA.view = { pos:new THREE.Vector3(S.x - fx * 3.0 + fz * 1.2, FP.H + 2.8, S.z - fz * 3.0 - fx * 1.2), look:new THREE.Vector3(S.x + fx * 7, -1.6, S.z + fz * 7) };
    /* 공용 바다: 내 보낸 병을 띄우고, 낚을 수 있는 병을 불러와요 */
    const f = fishData(), me = LPProfile.get(), mine = captainId(me);
    const pend = f.sent.filter(b => !b.shared).map(b => ({ ...b, from:b.from || senderOf(), owner:mine }));
    LPShare.status().then(st => { FCTX.share = st; });
    if (ISLE_BOTTLES) LPShare.putBottles(pend).then(n => {
      if (pend.length){ const f2 = fishData(); f2.sent.forEach(b => { if (pend.some(x => x.id === b.id)) b.shared = true; }); saveFish(f2); }
      if (n) toast(`갑판에서 써 둔 유리병 <strong>${n}개</strong>를 공용 바다에 띄웠어요!`, 3200);
      return LPShare.listBottles({ notOwner:mine, exclude:fishData().got });
    }).then(list => { FCTX.pool = withSamples(list || []); if (fi.open && fi.state === 'idle') renderFishing(); }).catch(() => { FCTX.pool = withSamples([]); });
  } else DECK_AREA.view = { pos:new THREE.Vector3(1.1, DECK.qH + 3.0, DECK.stern + 3.6), look:new THREE.Vector3(0, -2.0, -21) };
  document.body.classList.add('fishing-open'); FI.root.hidden = false;
  fiSet('idle');
}
function closeFishing(instant){
  if (!fi.open) return;
  fi.open = false; FI.root.hidden = true; document.body.classList.remove('fishing-open');
  if (F3.rod && F3.rod.parent) F3.rod.parent.remove(F3.rod);
  DECK_AREA.view = null; ISLE_AREA.view = null; uiOpen = false; fi.state = 'idle';
  if (!instant) try { renderer.domElement.focus({ preventScroll:true }); } catch(e){}
}
FI.close.addEventListener('click', () => closeFishing());
FI.hold.addEventListener('click', () => { if (['cast', 'wait', 'bite'].includes(fi.state)) return; fiSet(fi.state === 'hold' ? 'idle' : 'hold'); });
window.addEventListener('keydown', e => {
  if (!fi.open) return;
  const inInput = document.activeElement && ['INPUT', 'TEXTAREA'].includes(document.activeElement.tagName);
  if (e.key === 'Escape'){ e.preventDefault(); if (['bottle', 'dex', 'thrown', 'hold'].includes(fi.state)) fiSet('idle'); else closeFishing(); return; }
  /* Space: 버튼에 커서가 있으면 그 버튼이 눌려요. 아니면 던지기 · 당기기 */
  const onBtn = document.activeElement && document.activeElement.tagName === 'BUTTON' && FI.root.contains(document.activeElement);
  if ((e.key === ' ' || e.code === 'Space') && !inInput && !onBtn){
    if (['cast', 'wait', 'bite'].includes(fi.state)){ e.preventDefault(); fiPull(); }
    else if (['idle', 'result', 'miss', 'early'].includes(fi.state)){ e.preventDefault(); fiCast(); }
    return;
  }
  if (e.key === 'Enter' && inInput && document.activeElement.id === 'fiText'){ e.preventDefault(); fiThrow(); return; }
  if (e.key === 'Tab'){
    const f = [...FI.root.querySelectorAll('button:not([disabled]), input')].filter(b => b.offsetParent !== null);
    if (!f.length) return; const first = f[0], last = f[f.length - 1];
    if (e.shiftKey && document.activeElement === first){ e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && document.activeElement === last){ e.preventDefault(); first.focus(); }
  }
});
DECK_SPOTS.fish.use = () => openFishing();
