/* ============================================================
   LOG POSE · 함께 쓰는 기능의 연결 고리 (lpUse)
   share.js(유리병 · 게시판)와 net.js(절영도에서 서로 보이기)는 lpUse('db' | 'user' | 'room') 만 불러요.
   어디서 열었느냐에 따라 뒤에서 이어 주는 곳이 달라요.
     ① claude.ai 공유 링크  → 페이지의 공유 저장소 · 실시간 방 (window.claude)
     ② 우리 웹사이트       → Supabase (config.json 의 주소 · 공개 키, 방문자는 익명 선장으로 자동 로그인)
     ③ 파일로 열기          → 없음(null) → 각자 브라우저 안의 연습용으로 동작
   Supabase 쪽 표: supabase/schema.sql · 설정 방법: DEPLOY.md
   ============================================================ */
/* ★ 함께 쓰기 스위치: 지금은 꺼 둔 상태(혼자 쓰기). 켜는 방법은 SERVER_NOTES.md
     - claude.ai 공유 링크에서 켜기: 아래 LP_SHARED 를 true 로 (+ 링크에 db · user · room 권한 선언)
     - 우리 웹사이트(Supabase)에서 켜기: config.json 에 "shared": true 와 주소 · 공개 키 */
const LP_SHARED = false;
const lpUse = (() => {
  const cfg = (typeof window !== 'undefined' && window.LP_CONFIG) || {};
  const ON = LP_SHARED || cfg.shared === true;
  const hasClaude = () => typeof window !== 'undefined' && window.claude && typeof window.claude.use === 'function';
  const hasSupa = () => !!(cfg.supabaseUrl && cfg.supabaseAnonKey && typeof window !== 'undefined' && window.supabase && typeof window.supabase.createClient === 'function');

  /* ---------- ② Supabase ---------- */
  let SB = null;
  const supa = () => SB || (SB = (async () => {
    const sb = window.supabase.createClient(cfg.supabaseUrl, cfg.supabaseAnonKey, { auth:{ persistSession:true, autoRefreshToken:true } });
    let { data } = await sb.auth.getSession();
    let user = data && data.session && data.session.user;
    if (!user){ const r = await sb.auth.signInAnonymously(); if (r.error) throw r.error; user = r.data && r.data.user; }
    if (!user) throw new Error('no user');
    return { sb, uid:user.id };
  })().catch(e => { console.warn('[LOG POSE] Supabase 연결 실패 — 연습용으로 동작해요', e); return null; }));

  /* 공유 저장소 흉내: 'docs' 표 한 장에 (col, owner) 마다 문서 하나. 경로는 'col/owner' 꼴만 써요 */
  const snap = (id, data) => ({ id, exists:data != null, data:() => data == null ? undefined : data });
  function supaDb(S){
    const { sb, uid } = S;
    const doc = path => { const [col, owner] = path.split('/');
      return {
        async get(){ const { data, error } = await sb.from('docs').select('data').eq('col', col).eq('owner', owner).maybeSingle(); if (error) throw error; return snap(owner, data ? data.data : null); },
        async set(body){ if (owner !== uid) throw { code:'invalid_argument', message:'own document only' };
          const { error } = await sb.from('docs').upsert({ col, owner:uid, data:body, updated_at:new Date().toISOString() }); if (error) throw error; }
      }; };
    const collection = col => { let n = 400; const q = {
        limit(k){ n = Math.max(1, Math.min(1000, k | 0)); return q; },
        async get(){ const { data, error } = await sb.from('docs').select('owner,data').eq('col', col).order('updated_at', { ascending:false }).limit(n); if (error) throw error;
          const docs = (data || []).map(r => snap(r.owner, r.data)); return { docs, size:docs.length, empty:!docs.length }; },
        doc:id => doc(col + '/' + id) };
      return q; };
    return { doc, collection };
  }
  /* 실시간 방 흉내: Supabase Realtime Presence 채널 하나('logpose-isle') */
  function supaRoom(S){
    const { sb, uid } = S, key = uid + '-' + Math.random().toString(36).slice(2, 8);
    const ch = sb.channel('logpose-isle', { config:{ presence:{ key } } });
    let mine = {}, peers = [], subscribed = false, dirty = false, timer = 0, lastSent = 0;
    const listeners = new Set();
    const rebuild = () => {
      const st = ch.presenceState(); peers = Object.keys(st).map(k => { const metas = st[k] || [], m = metas[metas.length - 1] || {};
        const { presence_ref, ...presence } = m; void presence_ref;
        return { peer:k, by:null, isMe:k === key, sameTab:k === key, kind:'viewer', guest:false, presence, updatedAt:Date.now() }; });
      listeners.forEach(fn => { try { fn({ peers, joined:[], left:[], updated:[] }); } catch(e){} });
    };
    const flush = () => { timer = 0; if (!subscribed || !dirty) return; dirty = false; lastSent = Date.now();
      (mine.a ? ch.track(mine) : ch.untrack()).catch(() => {}); };
    ch.on('presence', { event:'sync' }, rebuild);
    ch.subscribe(status => { if (status === 'SUBSCRIBED'){ subscribed = true; dirty = true; flush(); } });
    window.addEventListener('pagehide', () => { try { ch.untrack(); sb.removeChannel(ch); } catch(e){} });
    return {
      presence(patch){ Object.keys(patch || {}).forEach(k => { if (patch[k] === null) delete mine[k]; else mine[k] = patch[k]; });
        dirty = true; if (!timer){ const wait = Math.max(0, 150 - (Date.now() - lastSent)); timer = setTimeout(flush, wait); } return Promise.resolve(); },
      onPeers(fn){ listeners.add(fn); setTimeout(() => fn({ peers, joined:[], left:[], updated:[] }), 0); return () => listeners.delete(fn); },
      peers:() => peers, connected:() => subscribed
    };
  }

  const cache = {};
  return name => cache[name] || (cache[name] = (async () => {
    if (!ON) return null;   /* 꺼져 있으면 모두 혼자 쓰기(각자 브라우저) */
    if (hasClaude()){ try { return await window.claude.use(name); } catch(e){ return null; } }
    if (!hasSupa()) return null;
    const S = await supa(); if (!S) return null;
    if (name === 'db') return supaDb(S);
    if (name === 'user') return { id:async () => S.uid, can:async () => true };
    if (name === 'room') return supaRoom(S);
    return null;
  })());
})();
/* 지금 함께 쓰는 곳 이름 (화면 표시용) */
const lpBackendLabel = () => (typeof window !== 'undefined' && window.claude && typeof window.claude.use === 'function') ? '이 링크로 들어온 선장님들과 함께 쓰는 바다' : '공용 바다 · 모든 선장님과 함께';
