/* ============================================================
   LOG POSE · 절영도: 해적 주점 '럼통' (바깥 + 안)
   바깥: 삐뚤빼뚤한 목조 건물 · 비뚤어진 지붕 · 연기 나는 굴뚝 · 매달린 간판 · 테라스 술통 테이블
   안:  꺾인 모양의 홀 · 바 카운터와 술병 선반 · 바텐더 · 벽난로 · 타륜 샹들리에 · 수배서 · 그물
   앉기: 바 의자 · 테이블 의자 · 테라스 의자 (움직이면 일어나요)
   ============================================================ */
const TV = { r:2.29 };   /* 주점이 광장 쪽을 보도록 돈 각도 */
/* 주점 기준 좌표 → 섬 좌표 (앞 = 주점 쪽 +z) */
function tvW(lx, lz){ const c = Math.cos(TV.r), s = Math.sin(TV.r); return { x:PL.tavern.x + lx * c + lz * s, z:PL.tavern.z - lx * s + lz * c }; }
const tvFace = a => TV.r + a;   /* 주점 기준 방향 → 섬 기준 방향 */
const tvSmoke = [];

/* 술통 · 의자 · 테이블 (안팎에서 같이 써요) */
function barrel(parent, x, y, z, s = 1, onSide = false){
  const g = new THREE.Group(); g.position.set(x, y, z); parent.add(g);
  const b = new THREE.Mesh(new THREE.CylinderGeometry(0.36 * s, 0.36 * s, 0.95 * s, 14), flat('#7a5230')); g.add(b);
  const mid = new THREE.Mesh(new THREE.CylinderGeometry(0.4 * s, 0.4 * s, 0.5 * s, 14), flat('#86603a')); g.add(mid);
  [-0.36, 0, 0.36].forEach(yy => { const r = new THREE.Mesh(new THREE.CylinderGeometry(0.405 * s, 0.405 * s, 0.05 * s, 14, 1, true), M.iron); r.position.y = yy * s; g.add(r); });
  if (onSide){ g.rotation.z = Math.PI / 2; g.position.y = y + 0.4 * s - 0.48 * s; }
  else g.position.y = y + 0.48 * s;
  return g;
}
function stool(parent, x, z, h = 0.5){
  const g = new THREE.Group(); g.position.set(x, 0, z); parent.add(g);
  const seat = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.22, 0.08, 10), flat('#8a6440')); seat.position.y = h; g.add(seat);
  for (let k = 0; k < 3; k++){ const a = k / 3 * Math.PI * 2; const l = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.035, h, 5), flat('#4a2e18')); l.position.set(Math.cos(a) * 0.14, h / 2, Math.sin(a) * 0.14); l.rotation.set(Math.sin(a) * 0.12, 0, -Math.cos(a) * 0.12); g.add(l); }
  return g;
}
function barrelTable(parent, x, z, mugs = 2){
  const g = new THREE.Group(); g.position.set(x, 0, z); parent.add(g);
  barrel(g, 0, 0, 0, 1.05);
  const top = new THREE.Mesh(new THREE.CylinderGeometry(0.75, 0.75, 0.08, 16), flat('#9a7048')); top.position.y = 1.04; g.add(top);
  for (let k = 0; k < mugs; k++){ const a = k * 2.4 + 0.5; const m = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.08, 0.18, 10), flat('#e8b84a')); m.position.set(Math.cos(a) * 0.35, 1.17, Math.sin(a) * 0.35); g.add(m);
    const foam = new THREE.Mesh(new THREE.CylinderGeometry(0.095, 0.095, 0.04, 10), flat('#fff6e0')); foam.position.set(m.position.x, 1.28, m.position.z); g.add(foam); }
  return g;
}
function bench(parent, x, z, len, ry){
  const g = new THREE.Group(); g.position.set(x, 0, z); g.rotation.y = ry; parent.add(g);
  const s = new THREE.Mesh(new THREE.BoxGeometry(len, 0.1, 0.42), flat('#8a6440')); s.position.y = 0.46; g.add(s);
  [-len / 2 + 0.2, len / 2 - 0.2].forEach(xx => { const l = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.46, 0.36), flat('#4a2e18')); l.position.set(xx, 0.23, 0); g.add(l); });
  return g;
}
function hangLantern(parent, x, y, z, glowList){
  const box = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.32, 0.22), new THREE.MeshStandardMaterial({ color:'#ffe0a8', emissive:'#ffb050', emissiveIntensity:1.2 })); box.position.set(x, y, z); parent.add(box);
  const cap = new THREE.Mesh(new THREE.ConeGeometry(0.18, 0.14, 4), M.iron); cap.position.set(x, y + 0.23, z); cap.rotation.y = Math.PI / 4; parent.add(cap);
  const glow = new THREE.Sprite(new THREE.SpriteMaterial({ map:glowTex, color:'#ffc070', transparent:true, opacity:.6, blending:THREE.AdditiveBlending, depthWrite:false })); glow.scale.set(1.5, 1.5, 1); glow.position.set(x, y, z); parent.add(glow);
  if (glowList) glowList.push({ box, glow });
}
/* 해골 없는 뱃사람 표식: 엇갈린 노 + 닻 (흔한 해적 소품) */
function oarsMark(parent, x, y, z, ry, s = 1){
  const g = new THREE.Group(); g.position.set(x, y, z); g.rotation.y = ry; g.scale.setScalar(s); parent.add(g);
  [-0.6, 0.6].forEach(a => { const o = new THREE.Group(); o.rotation.z = a; g.add(o);
    const sh = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 2.0, 6), flat('#8a6440')); o.add(sh);
    const bl = new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.6, 0.04), flat('#8a6440')); bl.position.y = -1.1; o.add(bl); });
  return g;
}
function tavernSignTex(){ return canvasTex(512, 320, (g, w, h) => {
  g.fillStyle = '#5a3a20'; g.beginPath(); g.moveTo(30, 20); g.lineTo(w - 30, 20); g.quadraticCurveTo(w - 8, h / 2, w - 30, h - 20); g.lineTo(30, h - 20); g.quadraticCurveTo(8, h / 2, 30, 20); g.fill();
  speckle(g, w, h, 900, '#2a180c', .25);
  g.strokeStyle = '#c9a15e'; g.lineWidth = 8; g.beginPath(); g.moveTo(44, 34); g.lineTo(w - 44, 34); g.quadraticCurveTo(w - 24, h / 2, w - 44, h - 34); g.lineTo(44, h - 34); g.quadraticCurveTo(24, h / 2, 44, 34); g.stroke();
  /* 맥주잔 그림 */
  g.fillStyle = '#e8b84a'; g.fillRect(70, 120, 70, 100); g.strokeStyle = '#e8b84a'; g.lineWidth = 12; g.beginPath(); g.arc(150, 170, 26, -1.2, 1.2); g.stroke();
  g.fillStyle = '#fff6e0'; [[80, 118], [105, 108], [130, 118]].forEach(([x, y]) => { g.beginPath(); g.arc(x, y, 18, 0, 7); g.fill(); });
  g.fillStyle = '#f6ecd2'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.font = `700 96px ${FD}`; g.fillText('럼통', 320, 140);
  g.font = `700 34px ${FB}`; g.fillStyle = '#f0d49a'; g.fillText('해적들의 주점', 320, 222);
}); }

/* ---------- 바깥 ---------- */
const TV_FOOT = [[-3.6, -3.0], [3.1, -3.4], [4.2, 0.4], [2.8, 2.6], [-2.9, 2.5], [-4.3, -0.4]];   /* 삐뚤빼뚤한 육각형 */
function buildTavernOutside(){
  const G = new THREE.Group(); G.position.set(PL.tavern.x, 0, PL.tavern.z); G.rotation.y = TV.r; isleScene.add(G); TV.out = G;
  const wallM = new THREE.MeshStandardMaterial({ map:M.wall.map, color:'#b88a5a', roughness:.85, side:THREE.DoubleSide });
  const beamM = flat('#3a2414'), H = 3.1;
  /* 벽: 바닥 모양대로 세운 판자벽 + 모서리마다 검은 기둥 */
  const sh = new THREE.Shape(); TV_FOOT.forEach(([x, z], i) => i ? sh.lineTo(x, -z) : sh.moveTo(x, -z)); sh.closePath();
  const wg = new THREE.ExtrudeGeometry(sh, { depth:H, bevelEnabled:false }); wg.rotateX(-Math.PI / 2);
  const walls = new THREE.Mesh(wg, wallM); G.add(walls);
  TV_FOOT.forEach(([x, z]) => { const b = new THREE.Mesh(new THREE.BoxGeometry(0.28, H + 0.2, 0.28), beamM); b.position.set(x, (H + 0.2) / 2, z); G.add(b); });
  for (let i = 0; i < TV_FOOT.length; i++){ const [ax, az] = TV_FOOT[i], [bx, bz] = TV_FOOT[(i + 1) % TV_FOOT.length];
    const len = Math.hypot(bx - ax, bz - az), mid = [(ax + bx) / 2, (az + bz) / 2];
    [0.35, H - 0.1].forEach(y => { const t = new THREE.Mesh(new THREE.BoxGeometry(len, 0.18, 0.2), beamM); t.position.set(mid[0], y, mid[1]); t.rotation.y = -Math.atan2(bz - az, bx - ax); G.add(t); });
    const x1 = new THREE.Mesh(new THREE.BoxGeometry(Math.hypot(len, H) * 0.7, 0.12, 0.16), beamM); x1.position.set(mid[0], H * 0.55, mid[1]); x1.rotation.y = -Math.atan2(bz - az, bx - ax); x1.rotateZ(Math.atan2(H, len) * (i % 2 ? 1 : -1) * 0.8); if (i !== 3) G.add(x1);
  }
  /* 지붕: 처마가 넓고 살짝 비뚤어진 여섯모 지붕 */
  const roof = new THREE.Mesh(new THREE.ConeGeometry(5.6, 2.6, 6, 1), flat('#5a2e1e')); roof.position.set(0, H + 1.2, -0.3); roof.scale.set(1.08, 1, 0.92); roof.rotation.set(0.05, 0.3, -0.06); G.add(roof);
  const ridge = new THREE.Mesh(new THREE.ConeGeometry(0.5, 1.0, 6), flat('#3a2414')); ridge.position.set(0.15, H + 2.6, -0.4); G.add(ridge);
  /* 굴뚝 + 연기 */
  const ch = new THREE.Mesh(new THREE.BoxGeometry(0.8, 2.6, 0.8), flat('#8a7a68')); ch.position.set(-2.2, H + 1.6, -1.6); ch.rotation.z = 0.05; G.add(ch);
  const chTop = new THREE.Mesh(new THREE.BoxGeometry(1.0, 0.25, 1.0), flat('#6a5848')); chTop.position.set(-2.27, H + 2.95, -1.6); G.add(chTop);
  for (let k = 0; k < 6; k++){ const p = new THREE.Sprite(new THREE.SpriteMaterial({ map:glowTex, color:'#d8d4cc', transparent:true, opacity:.5, depthWrite:false })); G.add(p); tvSmoke.push({ p, ph:k / 6, base:new THREE.Vector3(-2.27, H + 3.1, -1.6) }); }
  /* 지붕 위 깃대 */
  const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.06, 2.6, 6), beamM); pole.position.set(1.8, H + 2.4, 0.4); G.add(pole);
  const fl = new THREE.Mesh(new THREE.PlaneGeometry(1.2, 0.75), new THREE.MeshStandardMaterial({ map:canvasTex(256, 160, (g, w, h) => { g.fillStyle = '#1d1a14'; g.fillRect(0, 0, w, h); g.fillStyle = '#f2e8d2'; g.font = `700 92px ${FD}`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('⚓', w / 2, h / 2 + 6); }), side:THREE.DoubleSide })); fl.position.set(2.4, H + 3.3, 0.4); G.add(fl); TV.flag = fl;
  /* 앞문 (둥근 아치) · 선창 창문 */
  const doorM = flat('#4a2a16');
  const door = new THREE.Mesh(new THREE.BoxGeometry(1.3, 1.9, 0.12), doorM); door.position.set(0, 0.95, 2.6); G.add(door);
  const arch = new THREE.Mesh(new THREE.CircleGeometry(0.65, 18, 0, Math.PI), doorM); arch.position.set(0, 1.9, 2.63); G.add(arch);
  const frame = new THREE.Mesh(new THREE.TorusGeometry(0.72, 0.08, 6, 18, Math.PI), beamM); frame.position.set(0, 1.9, 2.66); G.add(frame);
  [-0.72, 0.72].forEach(x => { const j = new THREE.Mesh(new THREE.BoxGeometry(0.16, 1.9, 0.16), beamM); j.position.set(x, 0.95, 2.66); G.add(j); });
  [[-0.3, 1.0], [0.3, 1.0]].forEach(([x, y]) => { const h = new THREE.Mesh(new THREE.TorusGeometry(0.08, 0.02, 6, 12), M.iron); h.position.set(x, y, 2.64); G.add(h); });
  const winM = new THREE.MeshStandardMaterial({ color:'#ffd58a', emissive:'#ffb050', emissiveIntensity:.9 });
  /* 창은 삐뚤빼뚤한 벽면 위에 정확히 붙여요: 변(i)의 t 지점 + 바깥쪽 법선 */
  const onWall = (i, t) => { const [ax, az] = TV_FOOT[i], [bx, bz] = TV_FOOT[(i + 1) % TV_FOOT.length];
    const x = ax + (bx - ax) * t, z = az + (bz - az) * t; let nx = bz - az, nz = -(bx - ax); const l = Math.hypot(nx, nz) || 1; nx /= l; nz /= l;
    if (nx * x + nz * z < 0){ nx = -nx; nz = -nz; } return { x, z, nx, nz, ry:Math.atan2(nx, nz) }; };
  [[3, 0.175, 1.7], [3, 0.825, 1.7], [2, 0.5, 1.6], [4, 0.5, 1.6]].forEach(([i, t, y]) => { const P = onWall(i, t);
    const w = new THREE.Mesh(new THREE.CircleGeometry(0.36, 16), winM); w.position.set(P.x + P.nx * 0.03, y, P.z + P.nz * 0.03); w.rotation.y = P.ry; G.add(w);
    const f = new THREE.Mesh(new THREE.TorusGeometry(0.4, 0.07, 6, 18), M.brass); f.position.set(P.x + P.nx * 0.05, y, P.z + P.nz * 0.05); f.rotation.y = P.ry; G.add(f); });
  TV.win = winM;
  /* 테라스: 앞쪽 나무 바닥 · 난간 · 술통 테이블 · 의자 · 긴 의자 · 등불 */
  const deck = new THREE.Mesh(new THREE.BoxGeometry(9.2, 0.14, 4.4), flat('#8a6440')); deck.position.set(0, 0.07, 4.9); G.add(deck);
  for (let x = -4.4; x <= 4.4; x += 0.55){ const pl = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.02, 4.3), flat('#5a3e26')); pl.position.set(x, 0.15, 4.9); G.add(pl); }
  [[-4.55, 3.0, -4.55, 7.0], [4.55, 3.0, 4.55, 7.0]].forEach(([x0, z0, x1, z1]) => { const r = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.1, z1 - z0), beamM); r.position.set(x0, 0.9, (z0 + z1) / 2); G.add(r);
    for (let z = z0; z <= z1; z += 1.0){ const p = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 0.9, 6), beamM); p.position.set(x0, 0.45, z); G.add(p); } });
  TV.seatsOut = [];
  [[-2.3, 5.2], [2.4, 4.8]].forEach(([x, z], i) => {
    barrelTable(G, x, z, 2 + i);
    [[0.95, 0.2], [-0.95, -0.1], [0.1, 1.0]].forEach(([dx, dz]) => { stool(G, x + dx, z + dz, 0.5); TV.seatsOut.push({ lx:x + dx, lz:z + dz, face:Math.atan2(-dx, -dz) }); });
  });
  bench(G, -2.2, 2.95, 1.6, 0); TV.seatsOut.push({ lx:-2.6, lz:2.9, face:0 }, { lx:-1.8, lz:2.9, face:0 });   /* 벽(안쪽)을 등지고 바깥을 보며 앉아요 */   /* 문 옆 벽에 붙인 긴 의자 (문은 비워 둬요) */
  barrel(G, -4.0, 0, 2.95, 0.9); barrel(G, -3.4, 0, 3.4, 0.8); barrel(G, -3.7, 0.86, 3.15, 0.75, true);
  const crate = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.8, 0.8), M.wood); crate.position.set(3.9, 0.4, 3.0); crate.rotation.y = 0.4; G.add(crate);
  TV.lamps = [];
  [[-4.55, 7.0], [4.55, 7.0]].forEach(([x, z]) => { const p = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.07, 2.4, 6), beamM); p.position.set(x, 1.2, z); G.add(p); hangLantern(G, x, 2.35, z, TV.lamps); });
  /* 매달린 간판: 기둥 + 쇠 팔 + 사슬 두 줄 */
  const sp = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.12, 3.8, 8), beamM); sp.position.set(-3.6, 1.9, 7.3); G.add(sp);
  const armM = new THREE.Mesh(new THREE.BoxGeometry(2.6, 0.08, 0.08), M.iron); armM.position.set(-2.35, 3.6, 7.3); G.add(armM);
  const brace = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.06, 0.06), M.iron); brace.position.set(-3.15, 3.25, 7.3); brace.rotation.z = 0.6; G.add(brace);
  const hang = new THREE.Group(); hang.position.set(-2.1, 3.6, 7.3); G.add(hang); TV.sign = hang;
  [-0.7, 0.7].forEach(x => { const c = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.015, 0.45, 4), M.iron); c.position.set(x, -0.22, 0); hang.add(c); });
  const sw = 1.9, shh = sw * 320 / 512, face = new THREE.MeshStandardMaterial({ map:tavernSignTex(), roughness:.8, transparent:true, alphaTest:.5 });
  const board = new THREE.Mesh(new THREE.PlaneGeometry(sw, shh), face); board.position.set(0, -0.45 - shh / 2, 0.03); hang.add(board);
  const back = new THREE.Mesh(new THREE.PlaneGeometry(sw * 0.94, shh * 0.84), flat('#5a3a20')); back.position.set(0, -0.45 - shh / 2, -0.01); back.rotation.y = Math.PI; hang.add(back);
  /* 벽 장식: 엇갈린 노 · 구명 튜브 · 닻 */
  oarsMark(G, 2.75, 2.2, 2.75, -0.1, 0.7);
  const ring = new THREE.Mesh(new THREE.TorusGeometry(0.36, 0.11, 8, 18), flat('#e8e2d6')); ring.position.set(-1.9, 2.75, 2.5); G.add(ring);
  [0, 1, 2, 3].forEach(k => { const st = new THREE.Mesh(new THREE.TorusGeometry(0.36, 0.115, 8, 3, 0.4), flat('#c0392b')); st.position.copy(ring.position); st.rotation.z = k * Math.PI / 2; G.add(st); });
  /* 부딪힘: 건물 몸체 + 테이블 + 술통 (섬 좌표로) */
  /* 건물은 기울어 있어서 작은 상자 여러 개로 채워요 (문 앞은 비워 둬요) */
  const inFoot = (x, z) => { let ins = false; for (let i = 0, j = TV_FOOT.length - 1; i < TV_FOOT.length; j = i++){ const [xi, zi] = TV_FOOT[i], [xj, zj] = TV_FOOT[j]; if ((zi > z) !== (zj > z) && x < (xj - xi) * (z - zi) / (zj - zi) + xi) ins = !ins; } return ins; };
  for (let lx = -3.2; lx <= 3.3; lx += 1.6) for (let lz = -2.4; lz <= 1.3; lz += 1.2){ if (!inFoot(lx, lz)) continue; const w = tvW(lx, lz); iBox(w.x, w.z, 0.95, 0.95); }
  /* 테라스 난간도 길 찾기가 알도록 작은 상자로 */
  TV_RAILS.forEach(([[ax, az], [bx, bz]]) => { for (let t = 0; t <= 1.001; t += 1 / 6){ const w = tvW(ax + (bx - ax) * t, az + (bz - az) * t); iBox(w.x, w.z, 0.25, 0.25); } });
  [[-2.3, 5.2, 0.6], [2.4, 4.8, 0.6], [-3.7, 3.2, 0.7], [3.9, 3.0, 0.5], [-3.6, 7.3, 0.2]].forEach(([lx, lz, r]) => { const w = tvW(lx, lz); iBox(w.x, w.z, r, r); });
  G.userData.kind = 'tavern'; IS.clickables.push(G);
  { const d = tvW(0, 3.5); ISLE_SPOTS.tavern = { x:d.x, z:d.z, face:tvFace(Math.PI), label:'주점 럼통에 들어가기', use:() => goArea('tavern') }; }
  /* 테라스 의자에 앉기 */
  TV.seatsOut.forEach((st, i) => { const w = tvW(st.lx, st.lz); ISLE_SPOTS['tvOut' + i] = { x:w.x, z:w.z, face:tvFace(st.face), label:'의자에 앉기', near:0.9, use:() => sitDown(0.5, { x:w.x, z:w.z, face:tvFace(st.face) }) }; });
}
/* 섬 좌표 → 주점 기준 좌표 (테라스 바닥 높이용) */
function tvLocal(x, z){ const dx = x - PL.tavern.x, dz = z - PL.tavern.z, c = Math.cos(TV.r), s = Math.sin(TV.r); return { x:dx * c - dz * s, z:dx * s + dz * c }; }
const onPorch = (x, z) => { const l = tvLocal(x, z); return Math.abs(l.x) < 4.6 && l.z > 2.6 && l.z < 7.1; };
/* 주점 벽 · 테라스 난간: 캐릭터와 카메라가 파고들지 않게 정확한 모양으로 밀어내요 */
const TV_RAILS = [[[-4.55, 3.0], [-4.55, 7.0]], [[4.55, 3.0], [4.55, 7.0]]];
function tvPushLocal(l, m){
  /* 건물 안쪽이면 가장 가까운 벽 바깥으로 */
  let ins = false; for (let i = 0, j = TV_FOOT.length - 1; i < TV_FOOT.length; j = i++){ const [xi, zi] = TV_FOOT[i], [xj, zj] = TV_FOOT[j]; if ((zi > l.z) !== (zj > l.z) && l.x < (xj - xi) * (l.z - zi) / (zj - zi) + xi) ins = !ins; }
  const segs = TV_FOOT.map((a, i) => [a, TV_FOOT[(i + 1) % TV_FOOT.length]]).concat(TV_RAILS);
  let moved = false;
  segs.forEach(([a, b]) => {
    const ex = b[0] - a[0], ez = b[1] - a[1], L2 = ex * ex + ez * ez;
    const t = Math.max(0, Math.min(1, ((l.x - a[0]) * ex + (l.z - a[1]) * ez) / L2)), qx = a[0] + ex * t, qz = a[1] + ez * t;
    let dx = l.x - qx, dz = l.z - qz, d = Math.hypot(dx, dz);
    if (!ins && d < m){ if (d < 1e-6){ dx = ez; dz = -ex; d = Math.hypot(dx, dz); } l.x = qx + dx / d * m; l.z = qz + dz / d * m; moved = true; }
  });
  if (ins){
    let best = null, bd = Infinity;
    segs.slice(0, TV_FOOT.length).forEach(([a, b]) => { const ex = b[0] - a[0], ez = b[1] - a[1], L2 = ex * ex + ez * ez, t = Math.max(0, Math.min(1, ((l.x - a[0]) * ex + (l.z - a[1]) * ez) / L2)), qx = a[0] + ex * t, qz = a[1] + ez * t, d = Math.hypot(l.x - qx, l.z - qz); if (d < bd){ bd = d; best = { qx, qz, ex, ez }; } });
    /* 바닥 모양이 시계 반대 방향이라 (ez, -ex) 가 바깥쪽이에요 */
    const nl = Math.hypot(best.ez, best.ex); l.x = best.qx + best.ez / nl * m; l.z = best.qz - best.ex / nl * m; moved = true;
  }
  return moved;
}
function tvPush(p, m){
  const l = tvLocal(p.x, p.z); if (Math.abs(l.x) > 9 || Math.abs(l.z) > 11) return;
  if (tvPushLocal(l, m)){ const w = tvW(l.x, l.z); p.x = w.x; p.z = w.z; }
}
let sitTold = false;
/* 앉기: 의자 한가운데로 옮겨 앉고(엉덩이가 방석에 닿게), 정해진 쪽을 바라봐요 */
function sitDown(h, seat){
  if (seat){ player.standAt = { x:player.x, z:player.z }; player.x = seat.x; player.z = seat.z; if (seat.face != null) player.r = seat.face; }
  auto = null; player.moving = false;
  player.pose = 'sit'; player.sitY = h - 0.25;   /* 몸통 아래(엉덩이)가 바닥에서 0.25 위 */
  player.lie = !!(seat && seat.lie);   /* 파라솔 의자: 앉지 않고 누워요 (cabin.js 자세) */
  if (player.lie) toast('파라솔 아래 누웠어요. 움직이면 일어나요.', 2200);
  else if (!sitTold){ sitTold = true; toast('앉았어요. 움직이면 일어나요.', 2200); }
}

/* ---------- 안 ---------- */
const tavernScene = new THREE.Scene();
const TI = { colliders:[], clickables:[], floors:[], lamps:[], fire:null, chand:null };
/* 꺾인 모양의 홀: 앞 홀(넓게) + 안쪽 바 공간(좁게) + 오른쪽 벽난로 자리 */
const TVIS = [{ x0:-7, x1:7, z0:-4, z1:4.5 }, { x0:-4.5, x1:4.5, z0:-8.5, z1:-4 }, { x0:7, x1:9, z0:-2.5, z1:2.5 }];   /* 바닥 · 천장 */
const TROOMS = [{ x0:-7, x1:7, z0:-4, z1:4.5 }, { x0:-4.5, x1:4.5, z0:-8.5, z1:-3.0 }, { x0:6.0, x1:9, z0:-2.5, z1:2.5 }];   /* 걷기용 (방끼리 넉넉히 겹쳐요) */
const T_H = 3.6;
const tBox = (cx, cz, hx, hz) => TI.colliders.push({ minX:cx - hx, maxX:cx + hx, minZ:cz - hz, maxZ:cz + hz });
const tInside = (x, z, m = 0) => TROOMS.some(r => x > r.x0 + m && x < r.x1 - m && z > r.z0 + m && z < r.z1 - m);
function buildTavernInside(){
  const S = tavernScene;
  S.background = new THREE.Color('#120a05');
  S.add(new THREE.HemisphereLight('#ffd9a8', '#2a160a', .55));
  const warm = new THREE.PointLight('#ffb060', 1.2, 16, 1.6); warm.position.set(0, 3.0, 0); S.add(warm);
  const barL = new THREE.PointLight('#ffc080', 0.9, 12, 1.8); barL.position.set(0, 2.8, -6.5); S.add(barL);
  const fireL = new THREE.PointLight('#ff7a30', 1.1, 9, 2); fireL.position.set(8.2, 1.0, 0); S.add(fireL); TI.fireL = fireL;
  const floorM = M.floor.clone(); floorM.map = M.floor.map.clone(); floorM.map.needsUpdate = true; floorM.map.wrapS = floorM.map.wrapT = THREE.RepeatWrapping; floorM.map.repeat.set(3, 3);
  const wallM = new THREE.MeshStandardMaterial({ map:M.wall.map, color:'#a07850', roughness:.85, side:THREE.DoubleSide });
  const beamM = flat('#3a2414');
  /* 바닥 · 천장 · 벽 (방마다) */
  TVIS.forEach(r => {
    const w = r.x1 - r.x0, d = r.z1 - r.z0, cx = (r.x0 + r.x1) / 2, cz = (r.z0 + r.z1) / 2;
    const f = new THREE.Mesh(new THREE.PlaneGeometry(w, d), floorM); f.rotation.x = -Math.PI / 2; f.position.set(cx, 0, cz); f.name = 'floor'; S.add(f); TI.floors.push(f);
    const c = new THREE.Mesh(new THREE.PlaneGeometry(w, d), flat('#2a1a0e')); c.rotation.x = Math.PI / 2; c.position.set(cx, T_H, cz); S.add(c);
  });
  /* 벽: 방 둘레 중 다른 방과 맞닿지 않는 부분만 */
  const edge = (x0, z0, x1, z1) => {
    const len = Math.hypot(x1 - x0, z1 - z0); if (len < 0.05) return;
    const m = new THREE.Mesh(new THREE.PlaneGeometry(len, T_H), wallM); m.position.set((x0 + x1) / 2, T_H / 2, (z0 + z1) / 2); m.rotation.y = -Math.atan2(z1 - z0, x1 - x0); S.add(m);
    const b = new THREE.Mesh(new THREE.BoxGeometry(len, 0.2, 0.2), beamM); b.position.set((x0 + x1) / 2, T_H - 0.1, (z0 + z1) / 2); b.rotation.y = m.rotation.y; S.add(b);
  };
  edge(-7, 4.5, 7, 4.5); edge(-7, -4, -7, 4.5); edge(7, 2.5, 7, 4.5); edge(7, -4, 7, -2.5); edge(-7, -4, -4.5, -4); edge(4.5, -4, 7, -4);
  edge(-4.5, -8.5, -4.5, -3.8); edge(4.5, -8.5, 4.5, -3.8); edge(-4.5, -8.5, 4.5, -8.5);
  edge(6.8, -2.5, 9, -2.5); edge(6.8, 2.5, 9, 2.5); edge(9, -2.5, 9, 2.5);
  /* 기둥 · 천장 들보 */
  [[-4.5, -4], [4.5, -4], [-7, 4.5], [7, 4.5], [-7, -4], [7, -4], [-2.4, 0.6], [2.4, 0.6]].forEach(([x, z]) => { const p = new THREE.Mesh(new THREE.BoxGeometry(0.3, T_H, 0.3), beamM); p.position.set(x, T_H / 2, z); S.add(p); });
  tBox(-2.4, 0.6, 0.2, 0.2); tBox(2.4, 0.6, 0.2, 0.2);
  for (let x = -6; x <= 6; x += 2){ const b = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.24, 12.6), beamM); b.position.set(x, T_H - 0.14, -2.0); S.add(b); }
  /* 입구 (안쪽에서 본 문) */
  const door = new THREE.Mesh(new THREE.BoxGeometry(1.4, 2.1, 0.1), flat('#4a2a16')); door.position.set(0, 1.05, 4.44); S.add(door);
  door.userData.kind = 'exit'; TI.clickables.push(door);
  /* 바 카운터 (안쪽 방) · 의자 · 술병 선반 · 럼 술통 · 바텐더 */
  const counter = new THREE.Group(); counter.position.set(0, 0, -6.0); S.add(counter);
  /* 양쪽은 높은 카운터, 가운데는 바텐더와 마주 보는 낮은 주문대 */
  [-2.25, 2.25].forEach(x => { const ct = new THREE.Mesh(new THREE.BoxGeometry(1.9, 1.1, 0.9), flat('#6b4528')); ct.position.set(x, 0.55, 0); counter.add(ct);
    const tp = new THREE.Mesh(new THREE.BoxGeometry(2.05, 0.1, 1.15), flat('#9a7048')); tp.position.set(x, 1.13, 0); counter.add(tp); });
  const low = new THREE.Mesh(new THREE.BoxGeometry(2.6, 0.78, 0.9), flat('#7a5230')); low.position.set(0, 0.39, 0); counter.add(low);
  const lowTop = new THREE.Mesh(new THREE.BoxGeometry(2.7, 0.1, 1.2), flat('#b08458')); lowTop.position.set(0, 0.83, 0); counter.add(lowTop);
  const bell = new THREE.Mesh(new THREE.SphereGeometry(0.1, 12, 8, 0, Math.PI * 2, 0, Math.PI / 2), M.brass); bell.position.set(0.7, 0.88, 0.25); counter.add(bell);
  for (let x = -3; x <= 3; x += 0.6){ const pl = new THREE.Mesh(new THREE.BoxGeometry(0.04, 1.0, 0.02), beamM); pl.position.set(x, 0.55, 0.46); counter.add(pl); }
  [[-1.9, 1.22, 0.1], [-0.4, 0.92, 0.2], [2.3, 1.22, 0.15]].forEach(([x, y, z]) => { const m = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.08, 0.18, 10), flat('#e8b84a')); m.position.set(x, y, z); counter.add(m); });
  counter.userData.kind = 'bar'; TI.clickables.push(counter); tBox(0, -6.0, 3.4, 0.6);
  TI.seats = [];
  [-2.7, -1.8, 1.8, 2.7].forEach(x => { stool(S, x, -4.95, 0.7); TI.seats.push({ x, z:-4.95, face:Math.PI, h:0.7 }); });   /* 가운데 주문대 앞은 비워 둬요 */
  const shelfBack = new THREE.Mesh(new THREE.BoxGeometry(7.6, 2.4, 0.3), flat('#4a2e18')); shelfBack.position.set(0, 1.9, -8.35); S.add(shelfBack);
  const bottleCols = ['#3f6f3a', '#7a3a24', '#c9a24e', '#2f5f8a', '#5a2a4a', '#bfe6d8'];
  [1.2, 1.95, 2.7].forEach((y, row) => {
    const sh = new THREE.Mesh(new THREE.BoxGeometry(6.9, 0.08, 0.45), flat('#7a5230')); sh.position.set(0, y - 0.05, -8.1); S.add(sh);   /* 폭 6.9: 양 끝 럼 술통(x ±3.5부터)을 뚫고 들어가지 않게 (예전 7.4) */
    for (let k = 0; k < 14; k++){ const x = -3.3 + k * 0.5 + Math.sin(k * row + row) * 0.08; const hgt = 0.3 + ((k * 7 + row * 3) % 4) * 0.06;
      const b = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.08, hgt, 8), new THREE.MeshStandardMaterial({ color:bottleCols[(k + row) % bottleCols.length], roughness:.2, transparent:true, opacity:.85 })); b.position.set(x, y + hgt / 2, -8.05); S.add(b);
      const nk = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.03, 0.12, 6), b.material); nk.position.set(x, y + hgt + 0.06, -8.05); S.add(nk); }
  });
  [[-3.9, -7.6], [3.9, -7.6]].forEach(([x, z]) => { barrel(S, x, 0, z, 1.0); barrel(S, x, 0.98, z, 0.9);
    const tap = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 0.3, 6), M.brass); tap.rotation.x = Math.PI / 2; tap.position.set(x, 0.6, z + 0.5); S.add(tap); tBox(x, z, 0.45, 0.45); });
  tBox(0, -8.2, 3.9, 0.35);
  const step = new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.3, 1.2), flat('#5a3a20')); step.position.set(0, 0.15, -6.95); S.add(step);   /* 바텐더 발판: 낮은 주문대 너머로 상반신이 보여요 */
  const keeper = makeAvatar('#6b2a1c'); keeper.position.set(0, 0.3, -6.95); keeper.rotation.y = 0; S.add(keeper); TI.keeper = keeper;
  const apron = new THREE.Mesh(new THREE.CylinderGeometry(0.255, 0.27, 0.5, 14, 1, true, -1.2, 2.4), flat('#e8dcc2')); apron.position.y = 0.55; keeper.add(apron);
  tBox(0, -6.95, 1.2, 0.6);
  /* 둥근 테이블 셋 (술통 받침) + 의자 */
  [[-4.3, 1.4], [4.2, 1.9], [-4.6, -2.3]].forEach(([x, z], i) => {
    barrelTable(S, x, z, 2 + (i % 2)); tBox(x, z, 0.6, 0.6);
    [[1.1, 0], [-1.1, 0.1], [0, 1.1], [0.1, -1.1]].slice(0, i === 2 ? 3 : 4).forEach(([dx, dz]) => { stool(S, x + dx, z + dz, 0.5); TI.seats.push({ x:x + dx, z:z + dz, face:Math.atan2(-dx, -dz), h:0.5 }); });
  });
  /* 긴 의자 (양쪽 창가) */
  [-3.4, 3.4].forEach(x => { bench(S, x, 3.95, 2.2, 0); TI.seats.push({ x:x - 0.5, z:3.95, face:Math.PI, h:0.5 }, { x:x + 0.5, z:3.95, face:Math.PI, h:0.5 }); tBox(x, 3.95, 1.1, 0.2); });
  /* 벽난로 (오른쪽 자리) + 불꽃 */
  const fp = new THREE.Mesh(new THREE.BoxGeometry(0.8, 2.6, 2.6), flat('#6a5848')); fp.position.set(8.6, 1.3, 0); S.add(fp);
  const hole = new THREE.Mesh(new THREE.BoxGeometry(0.4, 1.1, 1.5), flat('#1a0e06')); hole.position.set(8.25, 0.6, 0); S.add(hole);
  const fire = new THREE.Sprite(new THREE.SpriteMaterial({ map:glowTex, color:'#ff8a30', transparent:true, opacity:.9, blending:THREE.AdditiveBlending, depthWrite:false })); fire.scale.set(1.4, 1.4, 1); fire.position.set(8.1, 0.5, 0); S.add(fire); TI.fire = fire;
  const logs = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.1, 1.0, 6), flat('#4a2a16')); logs.rotation.x = Math.PI / 2; logs.position.set(8.15, 0.15, 0); S.add(logs);
  tBox(8.5, 0, 0.6, 1.4);
  /* 불멍 의자: 벽난로 정면에 두고 불 쪽(+x)을 보며 앉아요 */
  bench(S, 6.75, 0, 1.0, Math.PI / 2); tBox(6.75, 0, 0.2, 0.5); TI.seats.push({ x:6.7, z:0, face:Math.PI / 2, h:0.5 });
  /* 타륜 샹들리에 + 촛불 */
  const chand = new THREE.Group(); chand.position.set(0, T_H - 0.9, 0.2); S.add(chand); TI.chand = chand;
  const rim = new THREE.Mesh(new THREE.TorusGeometry(1.0, 0.07, 8, 28), flat('#5a3820')); rim.rotation.x = Math.PI / 2; chand.add(rim);
  for (let k = 0; k < 8; k++){ const a = k / 8 * Math.PI * 2; const sp = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 2.0, 5), flat('#5a3820')); sp.rotation.set(Math.PI / 2, 0, a); chand.add(sp);
    const cd = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 0.18, 6), flat('#f6ecd2')); cd.position.set(Math.cos(a) * 1.0, 0.12, Math.sin(a) * 1.0); chand.add(cd);
    const fl = new THREE.Sprite(new THREE.SpriteMaterial({ map:glowTex, color:'#ffcf7a', transparent:true, opacity:.8, blending:THREE.AdditiveBlending, depthWrite:false })); fl.scale.set(0.35, 0.35, 1); fl.position.set(Math.cos(a) * 1.0, 0.27, Math.sin(a) * 1.0); chand.add(fl); }
  [[-1, 1], [1, 1], [-1, -1], [1, -1]].forEach(([sx, sz]) => { const c = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.012, 0.95, 4), M.iron); c.position.set(sx * 0.5, 0.46, sz * 0.5); c.rotation.set(sz * 0.5, 0, -sx * 0.5); chand.add(c); });
  hangLantern(S, -5.5, 2.7, -1, TI.lamps); hangLantern(S, 5.5, 2.7, 3.2, TI.lamps); hangLantern(S, -2.5, 2.8, -6.6, TI.lamps); hangLantern(S, 2.5, 2.8, -6.6, TI.lamps);
  /* 벽 장식: 수배서 · 그물 · 엇갈린 노 · 닻 · 선창 창 */
  /* 왼쪽 벽: 현상금 선장 (board.js 의 buildCaptainWall) */
  const netM = new THREE.LineBasicMaterial({ color:'#c9b08a', transparent:true, opacity:.7 }), net = [];
  for (let i = 0; i <= 8; i++){ net.push(new THREE.Vector3(6.95, 3.3 - i * 0.25, -3.8 + i * 0.05), new THREE.Vector3(6.95, 3.3 - i * 0.22 - Math.sin(i) * 0.1, 3.8)); }
  for (let i = 0; i <= 12; i++){ const z = -3.8 + i * 0.63; net.push(new THREE.Vector3(6.95, 3.3, z), new THREE.Vector3(6.95, 1.3 + Math.sin(i * 0.8) * 0.15, z + 0.2)); }
  S.add(new THREE.LineSegments(new THREE.BufferGeometry().setFromPoints(net), netM));
  oarsMark(S, 0, 2.7, -8.18, 0, 0.6);
  const anchor = new THREE.Group(); anchor.position.set(-4.42, 2.0, -6.2); anchor.rotation.y = Math.PI / 2; S.add(anchor);
  const ash = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 1.4, 6), M.iron); anchor.add(ash);
  const acr = new THREE.Mesh(new THREE.TorusGeometry(0.5, 0.06, 6, 16, Math.PI), M.iron); acr.rotation.z = Math.PI; acr.position.y = -0.45; anchor.add(acr);
  const winM = new THREE.MeshBasicMaterial({ color:'#7fc4e0' });
  [[-3, 4.48, 0], [3, 4.48, 0], [-6.98, 1.8, Math.PI / 2], [6.98, -3.2, -Math.PI / 2]].forEach(([x, z, ry], i) => { if (i > 1) return;
    const w = new THREE.Mesh(new THREE.CircleGeometry(0.42, 16), winM); w.position.set(x, 1.9, z - 0.02); w.rotation.y = Math.PI + ry; S.add(w);
    const f = new THREE.Mesh(new THREE.TorusGeometry(0.46, 0.07, 6, 18), M.brass); f.position.set(x, 1.9, z - 0.04); f.rotation.y = ry; S.add(f); });
  barrel(S, -6.3, 0, 3.8, 0.9); barrel(S, -5.6, 0, 4.0, 0.8); tBox(-6.0, 3.9, 0.8, 0.45);
  barrel(S, 6.3, 0, -3.4, 0.9); tBox(6.3, -3.4, 0.45, 0.45);
  /* 앉기 자리 */
  TI.seats.forEach((st, i) => { TAVERN_SPOTS['seat' + i] = { x:st.x, z:st.z, face:st.face, label:i < 4 ? '바 의자에 앉기' : '의자에 앉기', near:0.9, use:() => sitDown(st.h, st) }; });
}

const TAVERN_SPOTS = {
  exit:{ x:0, z:3.4, face:0, label:'주점에서 나가기', use:() => goArea('isle', { from:'tavern', quiet:true }) },
  bar:{ x:0, z:-4.75, face:Math.PI, label:'바텐더에게 말 걸기', use:() => toast('바텐더: “어서 와요, 선장님! 시원한 맥주는 <strong>시장 단계</strong>가 열리면 은화로 팔게요. 앉아서 쉬다 가요.”', 4200) }
};
const TAVERN_AREA = {
  id:'tavern', name:'주점 럼통', scene:tavernScene, colliders:TI.colliders, clickables:TI.clickables, spots:TAVERN_SPOTS, floors:TI.floors, exposure:1.05,
  clamp(p, m){
    if (tInside(p.x, p.z, m)) return;
    let best = null, bd = Infinity;
    TROOMS.forEach(r => { const x = Math.min(r.x1 - m, Math.max(r.x0 + m, p.x)), z = Math.min(r.z1 - m, Math.max(r.z0 + m, p.z)), d = Math.hypot(x - p.x, z - p.z); if (d < bd){ bd = d; best = { x, z }; } });
    if (best){ p.x = best.x; p.z = best.z; }
  },
  sideOk:(x, z) => tInside(x, z, 0.4),
  heightAt:() => 0,
  route:(tx, tz) => graphPlan(player.x, player.z, tx, tz, TI.colliders, (x, z) => tInside(x, z, PLAYER_R + 0.04), [{ x:0, z:-3.0 }, { x:0, z:-4.3 }, { x:6.6, z:0 }]),
  camClamp(v, gy){
    if (!tInside(v.x, v.z, 0.25)){ /* 벽 밖으로 나가지 않게: 가장 가까운 방 안으로 */
      let best = null, bd = Infinity; TROOMS.forEach(r => { const x = Math.min(r.x1 - 0.25, Math.max(r.x0 + 0.25, v.x)), z = Math.min(r.z1 - 0.25, Math.max(r.z0 + 0.25, v.z)), d = Math.hypot(x - v.x, z - v.z); if (d < bd){ bd = d; best = { x, z }; } });
      v.x = best.x; v.z = best.z; }
    v.y = Math.min(T_H - 0.25, Math.max(v.y, gy + 0.5));
  },
  ambient(dt, time){
    const t = reduceMotion ? 0 : time;
    if (TI.fire){ TI.fire.scale.setScalar(1.3 + Math.sin(t * 9) * 0.12 + Math.sin(t * 13) * 0.08); TI.fireL.intensity = 1.0 + Math.sin(t * 11) * 0.15; }
    if (TI.chand) TI.chand.rotation.y = Math.sin(t * 0.4) * 0.08;
    if (TI.keeper) TI.keeper.rotation.y = Math.sin(t * 0.5) * 0.4;
  },
  arrive(){ player.x = 0; player.z = 2.6; player.r = Math.PI; cam.yaw = 0; cam.pitch = 0.28; },
  welcome(){ toast('<strong>주점 럼통</strong>에 들어왔어요. 의자에 앉거나 바텐더에게 말을 걸어 보세요.', 3600); }
};
AREAS.tavern = TAVERN_AREA;
/* 절영도 바깥 움직임: 굴뚝 연기 · 간판 흔들림 · 깃발 */
function tavernOutStep(dt, t){
  tvSmoke.forEach(S => { const k = ((t * 0.18 + S.ph) % 1); S.p.position.set(S.base.x + Math.sin(k * 6 + S.ph * 9) * 0.3 + k * 0.8, S.base.y + k * 3.2, S.base.z - k * 0.4); S.p.scale.setScalar(0.6 + k * 1.8); S.p.material.opacity = 0.45 * (1 - k); });
  if (TV.sign) TV.sign.rotation.x = Math.sin(t * 1.4) * 0.08 * (reduceMotion ? 0 : 1);
  if (TV.flag) TV.flag.rotation.y = Math.sin(t * 2.2) * 0.25 * (reduceMotion ? 0 : 1);
}
function tavernTime(mode){
  const day = mode === 'day';
  if (TV.win) TV.win.emissiveIntensity = day ? .7 : 1.6;
  (TV.lamps || []).forEach(L => { L.box.material.emissiveIntensity = day ? .5 : 1.8; L.glow.material.opacity = day ? .25 : .85; });
}
function buildTavern(){ buildTavernOutside(); buildTavernInside(); buildCaptainWall(); timeHooks.push(tavernTime); tavernTime(timeMode); }
