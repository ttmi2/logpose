/* ---------- 선장실 보물 상자: 절영도 낚시터에서 낚은 유리병 편지 모음 ----------
   편지는 fish.js 가 낚을 때 LPProfile.fishing.letters 에 모아 둬요. */
const LT = { root:$('#letters'), body:$('#ltBody'), count:$('#ltCount'), close:$('#ltClose') };
const letters = { open:false };

function lettersRender(){
  const f = fishData(), list = f.letters.filter(l => LPData.get(l.work));
  LT.count.textContent = list.length ? `편지 ${list.length}통` : '';
  if (!list.length){
    LT.body.innerHTML = `<p class="sh-empty"><b>아직 낚은 유리병이 없어요</b>절영도 <em>낚시터</em>에서 물고기 사이로 다른 선장님의 유리병이 가끔 낚여요. 낚은 편지는 여기 모여요.</p>`;
    return;
  }
  LT.body.innerHTML = `<ul class="lt-list">${list.map(l => { const w = LPData.get(l.work), saved = isSaved(w.id);
    return `<li class="lt-item">
      <img src="${coverURL(w)}" alt="">
      <div class="lt-main">
        <p class="lt-top"><b>${escHTML(w.title)}</b><span>${escHTML(w.genre.name)}</span>${l.sample ? '<em>예시 병</em>' : ''}</p>
        <p class="lt-quote">“${escHTML(l.text)}”</p>
        <p class="lt-from">보낸 사람 · <b class="${l.from && l.from.kind === 'laftel-demo' ? 'lf' : 'gs'}">${escHTML((l.from && l.from.name) || '이름 없는')} 선장</b><small>${fmtDay(l.caughtAt) ? ` · ${fmtDay(l.caughtAt)}에 낚음` : ''}</small></p>
        <div class="lt-btns"><button type="button" class="lm-b go" data-open="${w.id}">책상에서 열기</button><button type="button" class="lm-b" data-save="${w.id}" aria-pressed="${saved}">${saved ? '✓ 저장됨' : '내 로그포스에 저장'}</button></div>
      </div></li>`; }).join('')}</ul>`;
  LT.body.querySelectorAll('[data-open]').forEach(b => b.addEventListener('click', () => { const id = b.dataset.open; closeLetters(); openDeskInfo(id); }));
  LT.body.querySelectorAll('[data-save]').forEach(b => b.addEventListener('click', () => { toggleSave(b.dataset.save); pulseLogpose(); lettersRender(); }));
}
function openLetters(){
  if (letters.open) return;
  letters.open = true; uiOpen = true; keys.clear(); auto = null; $('#toast').hidden = true;
  chestRef.want = 1;
  LT.root.hidden = false; document.body.classList.add('letters-open'); lettersRender();
  setTimeout(() => { try { (LT.body.querySelector('button') || LT.close).focus({ preventScroll:true }); } catch(e){} }, 40);
}
function closeLetters(){
  if (!letters.open) return;
  letters.open = false; LT.root.hidden = true; document.body.classList.remove('letters-open'); uiOpen = false; chestRef.want = 0;
  try { renderer.domElement.focus({ preventScroll:true }); } catch(e){}
}
LT.close.addEventListener('click', () => closeLetters());
window.addEventListener('keydown', e => { if (letters.open && e.key === 'Escape'){ e.preventDefault(); closeLetters(); } });
/* 뚜껑 여닫기 (선장실 ambient 에서 불러요) */
function chestStep(dt){ if (!chestRef.hinge) return; chestRef.open += (chestRef.want - chestRef.open) * Math.min(1, dt * 5); chestRef.hinge.rotation.x = -1.15 * chestRef.open; }
SPOTS.chest = { x:ROOM.maxX - 1.75, z:1.6, face:Math.PI / 2, label:'보물 상자 열기 · 모은 유리병', near:1.0, use:() => openLetters() };
