/* ============================================================
   LOG POSE · 절영도 1단계: 섬 공간 + 타륜으로 오가기
   망원경 '절영도로 가기' 또는 선장실 타륜 → 선장실 타륜을 잡고 키를 돌리는 항해 장면 → 절영도 선착장
   섬: 야자수 광장 · 시장 · 수배서 게시판 · 공용 낚시터 · 주점 (2~4단계에서 차례로 열려요) · 선착장에 내 배
   좌표: 섬 가운데 (0, 0), 선착장은 +z 쪽으로 뻗어 있어요.
   ============================================================ */
const isleScene = new THREE.Scene();
const IS = { colliders:[], clickables:[], floors:[], sea:null, seaBase:null, far:null, sky:null, sun:null, hemi:null, light:null, palms:[], flags:[], lamps:[], out:null };
/* 섬 크기: R(땅 반지름)을 바꾸면 선착장 · 낚시 잔교가 함께 따라가요. 건물 자리는 PL 에서 */
const ISLE = { R:30, plaza:8, pier:{ x0:-1.6, x1:1.6, z0:28, z1:50 } };
const PL = { market:{ x:18, z:-3 }, board:{ x:0, z:-18 }, tavern:{ x:-15, z:13 }, jettyZ:-5 };
const iBox = (cx, cz, hx, hz) => IS.colliders.push({ minX:cx - hx, maxX:cx + hx, minZ:cz - hz, maxZ:cz + hz });
const iMesh = (geo, mat, x, y, z, parent = isleScene) => { const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); parent.add(m); return m; };
const onPier = (x, z) => x > ISLE.pier.x0 && x < ISLE.pier.x1 && z > ISLE.pier.z0 - 1 && z < ISLE.pier.z1;

/* 간판: 앞면에만 글씨가 있는 나무판 (뒤에서 보면 그냥 나무예요). posts=true 면 양옆 기둥이 땅까지 */
function signTex(text, sub){ return canvasTex(512, 224, (g, w, h) => {
  g.fillStyle = '#7a5230'; g.fillRect(0, 0, w, h); speckle(g, w, h, 900, '#3a2616', .25);
  for (let y = 44; y < h; y += 46){ g.fillStyle = 'rgba(40,24,12,.25)'; g.fillRect(0, y, w, 2); }
  g.strokeStyle = '#3a2616'; g.lineWidth = 12; g.strokeRect(6, 6, w - 12, h - 12);
  g.fillStyle = '#f6ecd2'; g.textAlign = 'center'; g.textBaseline = 'middle';
  const fit = (t, size, max) => { let s = size; do { g.font = `700 ${s}px ${FD}`; s -= 4; } while (g.measureText(t).width > max && s > 30); };
  fit(text, sub ? 84 : 96, w - 60); g.fillText(text, w / 2, sub ? 86 : h / 2 + 4);
  if (sub){ g.font = `700 40px ${FB}`; g.fillStyle = '#f0d49a'; let s2 = 40; while (g.measureText(sub).width > w - 70 && s2 > 24){ s2 -= 2; g.font = `700 ${s2}px ${FB}`; } g.fillText(sub, w / 2, 164); }
}); }
const SIGN_WOOD = () => flat('#6b4528');
function signBoard(text, sub, x, y, z, ry, wdt = 2.6, posts = false){
  const hgt = wdt * 224 / 512, wood = SIGN_WOOD();
  const face = new THREE.MeshStandardMaterial({ map:signTex(text, sub), roughness:.8 });
  const G = new THREE.Group(); G.position.set(x, y, z); G.rotation.y = ry; isleScene.add(G);
  G.add(new THREE.Mesh(new THREE.BoxGeometry(wdt, hgt, 0.12), [wood, wood, wood, wood, face, wood]));
  const cap = new THREE.Mesh(new THREE.BoxGeometry(wdt + 0.2, 0.1, 0.24), flat('#4a2e18')); cap.position.y = hgt / 2 + 0.05; G.add(cap);
  if (posts){
    const len = y + hgt / 2;
    [-1, 1].forEach(s => { const p = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.1, len, 6), flat('#4a2e18')); p.position.set(s * (wdt / 2 - 0.12), (hgt / 2 - y) / 2, -0.12); G.add(p); });
  }
  return G;
}

function buildIsleLand(){
  const sand = flat('#ecdcae'), grass = flat('#62a94e'), grassD = flat('#4f8f40'), wood = flat('#8a6440'), woodD = flat('#5a3e26'), stone = flat('#b8ab94');
  /* 땅: 모래톱 · 풀밭 · 가운데 돌 광장 */
  iMesh(new THREE.CylinderGeometry(ISLE.R + 2.5, ISLE.R + 5.5, 3, 48), sand, 0, -1.5, 0);
  const top = iMesh(new THREE.CircleGeometry(ISLE.R + 2.5, 48), sand, 0, 0.001, 0); top.rotation.x = -Math.PI / 2; top.name = 'floor'; IS.floors.push(top);
  const lawn = iMesh(new THREE.CircleGeometry(ISLE.R - 2, 36), grass, 0, 0.02, -1); lawn.rotation.x = -Math.PI / 2; lawn.name = 'floor'; IS.floors.push(lawn);
  const plaza = iMesh(new THREE.CircleGeometry(ISLE.plaza, 32), stone, 0, 0.035, 0); plaza.rotation.x = -Math.PI / 2; plaza.name = 'floor'; IS.floors.push(plaza);
  for (let k = 0; k < 34; k++){ const a = k / 34 * Math.PI * 2; iMesh(new THREE.BoxGeometry(0.5, 0.06, 0.25), flat('#9a8e78'), Math.cos(a) * ISLE.plaza, 0.05, Math.sin(a) * ISLE.plaza).rotation.y = -a; }
  /* 광장에서 네 곳으로 가는 돌길 */
  [[PL.market.x - 3.4, PL.market.z], [PL.board.x, PL.board.z + 1.8], [PL.tavern.x + 5.8, PL.tavern.z - 5.1], [-ISLE.R + 0.5, PL.jettyZ], [0, ISLE.R]].forEach(([tx, tz]) => {
    const d = Math.hypot(tx, tz), n = Math.floor((d - ISLE.plaza) / 1.3);
    for (let i = 1; i <= n; i++){ const k = (ISLE.plaza + i * 1.3) / d; const st = iMesh(new THREE.CylinderGeometry(0.42, 0.46, 0.06, 7), flat('#b8ab94'), tx * k + Math.sin(i * 1.7) * 0.25, 0.04, tz * k + Math.cos(i * 1.3) * 0.25); st.rotation.y = i; }
  });
  /* 가운데: 나침반 분수 */
  iMesh(new THREE.CylinderGeometry(1.7, 1.9, 0.6, 20), stone, 0, 0.3, 0);
  iMesh(new THREE.CylinderGeometry(1.45, 1.45, 0.05, 20), new THREE.MeshStandardMaterial({ color:'#5fb8d6', roughness:.2, metalness:.2 }), 0, 0.58, 0);
  iMesh(new THREE.CylinderGeometry(0.2, 0.3, 1.6, 10), stone, 0, 1.2, 0);
  const comp = iMesh(new THREE.TorusGeometry(0.45, 0.06, 8, 24), M.brass, 0, 2.15, 0); IS.compass = comp;
  const nd = iMesh(new THREE.ConeGeometry(0.1, 0.8, 4), new THREE.MeshStandardMaterial({ color:'#8a2a1c' }), 0, 2.15, 0); nd.rotation.z = Math.PI / 2; IS.needle = nd;
  iBox(0, 0, 1.9, 1.9);
  /* 선착장 */
  const P = ISLE.pier, pz = (P.z0 + P.z1) / 2, pl = P.z1 - P.z0 + 2;
  const deck = iMesh(new THREE.BoxGeometry(P.x1 - P.x0 + 0.4, 0.25, pl), wood, 0, 0.0, pz); deck.name = 'floor'; IS.floors.push(deck);
  for (let z = P.z0; z <= P.z1; z += 1.1) iMesh(new THREE.BoxGeometry(P.x1 - P.x0 + 0.4, 0.02, 0.06), woodD, 0, 0.13, z);
  for (let z = P.z0 + 1; z <= P.z1; z += 3.2) [-1, 1].forEach(s => iMesh(new THREE.CylinderGeometry(0.16, 0.18, 3.2, 8), woodD, s * (P.x1 + 0.1), -0.8, z));
  [-1, 1].forEach(s => { const m = iMesh(new THREE.BoxGeometry(0.08, 0.08, pl - 2), woodD, s * (P.x1 + 0.1), 0.85, pz + 1); void m; for (let z = P.z0 + 1; z <= P.z1; z += 3.2) iMesh(new THREE.CylinderGeometry(0.06, 0.06, 0.9, 6), woodD, s * (P.x1 + 0.1), 0.45, z); });
  signBoard('절영도', '선장님들이 모이는 곳', 3.4, 1.9, P.z0 + 0.5, -0.35, 3.0, true);   /* 배에서 내려 걸어오는 쪽을 봐요 */
  /* 선착장 옆에 대 놓은 내 배 (첫 화면 배와 같은 모델) */
  if (IN.ship){
    const ship = IN.ship.clone(true);
    ship.children.slice().forEach(c => { if (c.material === IN.wake.material || c.material === IN.foam.material) ship.remove(c); });
    ship.scale.setScalar(2.1); ship.rotation.set(0, -Math.PI / 2, 0); const sz = ISLE.pier.z1 - 4; ship.position.set(-8.6, -2.4, sz);   /* 모래톱에 닿지 않게 선착장 끝쪽에 */ isleScene.add(ship); IS.ship = ship;
    iBox(-8.6, sz, 4.6, 14);
  }
}

/* 광장 둘레의 네 곳 (지금은 자리만, 2~4단계에서 열려요) */
function buildIslePlaces(){
  const wood = flat('#8a6440'), woodD = flat('#5a3e26'), cloth1 = flat('#c0392b'), cloth2 = flat('#f2e8d2'), roof = flat('#7a3a24');
  /* 시장: marketplace.js 의 허름한 해적 장터 */
  buildMarketStreet();
  /* 현상금 게시판: board.js */
  buildBountyBoard();
  /* 공용 낚시터: fishpier.js (바다로 뻗은 긴 잔교 + T자 낚시 마루) */
  if (ISLE_BOTTLES) for (let k = 0; k < 3; k++){ const b = bottleMesh(); isleScene.add(b); IS.flags.push({ bottle:b, ph:k }); }
  buildFishPier(); fishPierSpots();
  buildIsleRest();   /* rest.js: 모닥불 · 평상 · 해변 파라솔 */
  buildPirateGym();  /* gym.js: 게시판 뒤 근육 해적단 훈련장 */
  /* 주점: tavern.js 의 buildTavern() 이 지어요 */
  /* 야자수 · 바위 · 등불 */
  [[-22, -10, .25], [-19, -20, -.2], [22, -14, .2], [24, 8, -.15], [10, 21, .2], [-6, 22, -.25], [-24, 3, .1], [14, -23, -.2],
   [-11, -25, .15], [12, -26, -.2], [26, -3, .1], [17, 15, -.2], [-26, 13, .2], [-17, 22, -.15], [7, 12, .1], [-12, -8, -.1], [12, -12, .15]].forEach(([x, z, lean]) => {
    const P = makePalm(6.5 + Math.abs(Math.sin(x * z)) * 2, lean * 1.6, 8); P.root.position.set(x, 0, z); P.root.rotation.y = (x * 7 + z * 3) % 6.28; isleScene.add(P.root);
    IS.palms.push({ crown:P.crown, ph:x + z }); iBox(x, z, 0.5, 0.5);
  });
  [[19, 16, 1.6], [-25, -14, 1.2], [25, -8, 1.0], [-13, -22, 1.3], [21, -20, 0.9]].forEach(([x, z, r]) => { iMesh(rough(new THREE.IcosahedronGeometry(r, 0), 0.2), flat('#9a8e78'), x, r * .5, z); iBox(x, z, r * .8, r * .8); });
  [[6.5, 6.5], [-6.5, 6.5], [6.5, -6.5], [-6.5, -6.5]].forEach(([x, z]) => {
    iMesh(new THREE.CylinderGeometry(0.07, 0.07, 2.4, 6), M.iron, x, 1.2, z);
    const box = iMesh(new THREE.BoxGeometry(0.34, 0.44, 0.34), new THREE.MeshStandardMaterial({ color:'#ffe0a8', emissive:'#ffb050', emissiveIntensity:.5 }), x, 2.6, z);
    const glow = new THREE.Sprite(new THREE.SpriteMaterial({ map:glowTex, color:'#ffcf8a', transparent:true, opacity:.3, blending:THREE.AdditiveBlending, depthWrite:false })); glow.scale.set(1.8, 1.8, 1); glow.position.set(x, 2.6, z); isleScene.add(glow);
    IS.lamps.push({ box, glow }); iBox(x, z, 0.2, 0.2);
  });
  /* 깃발줄: 광장 위 삼각 깃발 */
  const fl = [];
  for (let k = 0; k < 16; k++){ const a = k / 16 * Math.PI * 2; fl.push(new THREE.Vector3(Math.cos(a) * (ISLE.plaza - 0.4), 4.2 - Math.abs(Math.sin(k * 0.8)) * 0.4, Math.sin(a) * (ISLE.plaza - 0.4))); }
  fl.forEach((p, k) => { const tri = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(-0.3, 0, 0), new THREE.Vector3(0.3, 0, 0), new THREE.Vector3(0, -0.6, 0)]); tri.computeVertexNormals();
    const m = new THREE.Mesh(tri, new THREE.MeshBasicMaterial({ color:['#c0392b', '#f2c230', '#2f9fbf', '#f2e8d2'][k % 4], side:THREE.DoubleSide })); m.position.copy(p); m.lookAt(0, p.y, 0); isleScene.add(m); });
}

function buildIsleWorld(){
  IS.hemi = new THREE.HemisphereLight('#dff0ff', '#3a5a2a', .85); isleScene.add(IS.hemi);
  IS.light = new THREE.DirectionalLight('#fff1d6', 1.15); IS.light.position.set(-30, 50, 25); isleScene.add(IS.light);
  isleScene.fog = new THREE.Fog('#bfe0f0', 90, 420);
  IS.sky = new THREE.Mesh(new THREE.SphereGeometry(450, 32, 16), new THREE.MeshBasicMaterial({ side:THREE.BackSide, fog:false })); isleScene.add(IS.sky);
  IS.sun = new THREE.Sprite(new THREE.SpriteMaterial({ map:glowTex, color:'#fff4d6', transparent:true, fog:false, depthWrite:false, blending:THREE.AdditiveBlending })); IS.sun.scale.set(120, 120, 1); IS.sun.position.set(-240, 160, -300); isleScene.add(IS.sun);
  IS.out = new THREE.Group(); isleScene.add(IS.out);
  const g = new THREE.PlaneGeometry(280, 280, 70, 70); g.rotateX(-Math.PI / 2);
  IS.seaBase = Float32Array.from(g.attributes.position.array);
  IS.sea = new THREE.Mesh(g, new THREE.MeshStandardMaterial({ color:'#ffffff', roughness:.5, flatShading:true })); IS.sea.position.y = -1.7; IS.out.add(IS.sea);
  IS.far = new THREE.Mesh(new THREE.PlaneGeometry(2000, 2000), new THREE.MeshStandardMaterial({ color:'#1583bf', roughness:.5 })); IS.far.rotation.x = -Math.PI / 2; IS.far.position.y = -2.4; IS.out.add(IS.far);
  /* 멀리 라프텔 섬이 보여요 (갑판에서 보던 그 섬) */
  const L = ISLES.find(x => x.id === 'laftel');
  if (L){ const far = L.group.clone(true); far.position.set(-140, -3, -230); far.scale.setScalar(0.9); isleScene.add(far); }
}

function isleTime(mode){
  if (!IS.sky) return;
  const day = mode === 'day';
  IS.sky.material.map = domeTex[mode] || (domeTex[mode] = skyDomeTex(mode)); IS.sky.material.needsUpdate = true;
  IS.sea.material.map = seaTexs[mode] || (seaTexs[mode] = seaTex(mode)); IS.sea.material.needsUpdate = true;
  IS.far.material.color.set(day ? '#1583bf' : '#0b2a48');
  isleScene.fog.color.set(day ? '#bfe0f0' : '#0f2444'); isleScene.background = new THREE.Color(day ? '#9fd0ec' : '#0b1a32');
  IS.hemi.intensity = day ? .85 : .35; IS.hemi.color.set(day ? '#dff0ff' : '#5a7aa8');
  IS.light.intensity = day ? 1.15 : .25; IS.light.color.set(day ? '#fff1d6' : '#9fb6e0');
  IS.sun.material.color.set(day ? '#fff4d6' : '#dfe8f8'); IS.sun.scale.setScalar(day ? 120 : 55);
  IS.lamps.forEach(L => { L.box.material.emissiveIntensity = day ? .4 : 1.8; L.glow.material.opacity = day ? .2 : .85; });
}

/* 다음 단계 자리 안내 */
const isleSoon = (what, step) => () => toast(`<strong>${what}</strong>${josaEun(what)} 절영도 ${step}단계에서 열려요. 조금만 기다려 주세요!`);
const ISLE_SPOTS = {
  pier:{ x:0, z:ISLE.pier.z1 - 1.2, face:0, label:'내 배로 돌아가기', use:() => sailTo('ship') },
};
/* 걸을 수 있는 곳: 섬(둥근 땅) + 선착장 + 서쪽 낚시 잔교 */
const onJetty = (x, z) => onFishPier(x, z);   /* 공용 낚시터 마루 */
function isleInside(x, z){
  const m = PLAYER_R + 0.04;
  if (x > ISLE.pier.x0 + m && x < ISLE.pier.x1 - m && z > ISLE.pier.z0 - 1 && z < ISLE.pier.z1 - 0.4) return true;
  if (fpInside(x, z, m)) return true;
  return Math.hypot(x, z) < ISLE.R + 2.5 - m;
}
const ISLE_GATES = [{ x:0, z:ISLE.pier.z0 + 1 }, { x:0, z:ISLE.R - 1 }, { x:-ISLE.R + 1, z:PL.jettyZ }, { x:-ISLE.R - 3.5, z:PL.jettyZ }, { x:-51.5, z:PL.jettyZ }, { x:-55, z:PL.jettyZ }];
const ISLE_AREA = {
  id:'isle', name:'절영도', walk:1.5, scene:isleScene, colliders:IS.colliders, clickables:IS.clickables, spots:ISLE_SPOTS, floors:IS.floors, exposure:.95,
  clamp(p, m){
    if (onPier(p.x, p.z)){ p.x = Math.min(ISLE.pier.x1 - m, Math.max(ISLE.pier.x0 + m, p.x)); p.z = Math.min(ISLE.pier.z1 - 0.4, p.z); return; }
    if (Math.hypot(p.x, p.z) > ISLE.R + 2.5 - m && FP.rects.some(r => p.x > r.x0 - 3 && p.x < r.x1 + 3 && p.z > r.z0 - 3 && p.z < r.z1 + 3)){ fpClamp(p, m); return; }   /* 낚시터 마루 위 · 근처 */
    const r = Math.hypot(p.x, p.z), max = ISLE.R + 2.5 - m;
    if (r > max){ p.x *= max / r; p.z *= max / r; }
  },
  sideOk:(x, z) => Math.hypot(x, z) < ISLE.R + 2 || onPier(x, z),
  route:(tx, tz) => graphPlan(player.x, player.z, tx, tz, IS.colliders, isleInside, ISLE_GATES),
  push:(p, m) => tvPush(p, m),
  heightAt:(x, z) => (onPier(x, z) ? 0.13 : onJetty(x, z) && Math.hypot(x, z) > ISLE.R + 1.8 ? FP.H : onJetty(x, z) ? 0.2 : onPorch(x, z) ? 0.14 : 0.03),
  camClamp(v, gy){ v.y = Math.max(v.y, gy + 0.6); if (v.y < 6) tvPush(v, 0.35); },   /* 카메라도 주점 벽 안으로 안 들어가요 */
  ambient(dt, time, sway){
    gymStep(dt, time);
    const t = reduceMotion ? 0 : time;
    const p = IS.sea.geometry.attributes.position, b = IS.seaBase;
    for (let i = 0; i < p.count; i++) p.array[i * 3 + 1] = waveH(b[i * 3], b[i * 3 + 2], t) * 0.55;
    p.needsUpdate = true; IS.sea.geometry.computeVertexNormals();
    if (IS.sea.material.map){ IS.sea.material.map.offset.x = (t * 0.008) % 1; IS.sea.material.map.offset.y = (t * 0.006) % 1; }
    IS.palms.forEach(P => { P.crown.rotation.z = Math.sin(t * 0.9 + P.ph) * 0.06 * sway; }); restStep(t);
    IS.flags.forEach(F => { if (F.bottle){ F.bottle.position.y = -1.75 + waveH(F.bottle.position.x, F.bottle.position.z, t) * 0.55; F.bottle.rotation.x = Math.sin(t + F.ph) * 0.3; } });
    if (IS.ship){ IS.ship.position.y = -2.4 + Math.sin(t * 0.7) * 0.15 * sway; IS.ship.rotation.z = Math.sin(t * 0.5) * 0.015 * sway; }
    tavernOutStep(dt, t); fishPierStep(dt, t); marketStep(dt, t); boardStep(dt, t); fishStep(dt, time);
    if (IS.needle) IS.needle.rotation.y = Math.sin(t * 0.6) * 0.5 * sway + 0.4;
  },
  arrive(opts = {}){
    if (opts.from === 'tavern'){ const d = tvW(0, 4.2); player.x = d.x; player.z = d.z; player.r = TV.r; cam.yaw = TV.r + Math.PI; cam.pitch = 0.3; return; }   /* 주점 문 앞으로 나와요 */
    player.x = 0; player.z = ISLE.pier.z1 - 3.4; player.r = Math.PI; cam.yaw = 0; cam.pitch = 0.3;
  },
  welcome(){ toast('<strong>절영도</strong>에 도착했어요!<br>시장 · 수배서 게시판 · 공용 낚시터 · 주점이 광장 둘레에 있어요.', 4600); }
};
AREAS.isle = ISLE_AREA;
function buildIsle(){ buildIsleWorld(); buildIsleLand(); buildIslePlaces(); buildTavern(); timeHooks.push(isleTime); isleTime(timeMode); }

/* ---------- 타륜: 어디로 항해할까요? ---------- */
const HM = { root:$('#helm'), go:$('#hmIsle'), stay:$('#hmStay') };
function openHelm(){
  if (AREA !== CABIN_AREA) return;
  uiOpen = true; keys.clear(); auto = null; HM.root.hidden = false; document.body.classList.add('helm-open');
  wheelRef.spin = 1.2; setTimeout(() => { try { HM.go.focus({ preventScroll:true }); } catch(e){} }, 40);
}
function closeHelm(keepUi){ if (HM.root.hidden) return; HM.root.hidden = true; document.body.classList.remove('helm-open'); if (!keepUi) uiOpen = false; }
HM.go.addEventListener('click', () => { closeHelm(true); uiOpen = false; sailTo('isle', { atWheel:true }); });
HM.stay.addEventListener('click', () => { closeHelm(); wheelRef.spin = 2.2; toast('타륜을 돌렸어요. 배는 <strong>순항 중</strong>이에요.'); });
window.addEventListener('keydown', e => { if (!HM.root.hidden && e.key === 'Escape'){ e.preventDefault(); closeHelm(); } });

/* ---------- 항해 장면: 선장실 타륜에서 키를 돌려요 ---------- */
const SL = { root:$('#sail'), text:$('#slText'), bar:$('#slBar'), skip:$('#slSkip') };
const sail = { on:false, dest:null, timers:[], t0:0, dur:0 };
function sailClear(){ sail.timers.forEach(clearTimeout); sail.timers = []; }
const sailLater = (fn, ms) => sail.timers.push(setTimeout(fn, ms));
function fadeSwap(mid, then){
  if (reduceMotion){ mid(); if (then) then(); return; }
  $('#fade').classList.add('on');
  sailLater(() => { mid(); sailLater(() => { $('#fade').classList.remove('on'); if (then) then(); }, 140); }, 420);
}
/* dest: 'isle' (절영도로) | 'ship' (내 배로 돌아오기) */
function sailTo(dest, opts = {}){
  if (sail.on || areaBusy) return;
  sail.on = true; cutscene = true; uiOpen = true; keys.clear(); auto = null; $('#toast').hidden = true;
  closeScope(); closeHelm(true);
  const toIsle = dest === 'isle';
  const steer = () => {
    /* 타륜 앞: 두 손으로 키를 잡고 크게 돌려요 · 카메라는 어깨 너머로 타륜과 고물 창을 */
    player.x = WHEEL.x; player.z = SPOTS.wheel.z; player.r = Math.PI; player.pose = 'steer';
    CABIN_AREA.view = { pos:new THREE.Vector3(1.5, 2.35, WHEEL.z + 3.3), look:new THREE.Vector3(-0.2, 1.45, WHEEL.z - 1.2) };
    wheelRef.spin = toIsle ? 6 : 4; sailFx.want = 1;
    SL.root.hidden = false; document.body.classList.add('sail-open');
    SL.text.innerHTML = toIsle ? '키를 돌려요! <b>절영도</b>로 항해 중…' : '닻을 올렸어요. <b>순항</b>으로 돌아가요…';
    const dur = reduceMotion ? 1200 : (toIsle ? 4600 : 3200); sail.t0 = performance.now(); sail.dur = dur;
    SL.bar.style.transition = 'none'; SL.bar.style.width = '0%'; void SL.bar.offsetWidth; SL.bar.style.transition = `width ${dur}ms linear`; SL.bar.style.width = '100%';
    try { SL.skip.focus({ preventScroll:true }); } catch(e){}
    sailLater(() => finish(), dur);
  };
  const finish = () => {
    sailClear();
    if (toIsle) fadeSwap(() => { endSteer(); setArea('isle'); }, () => { sailDone(); ISLE_AREA.welcome(); });
    else { endSteer(); sailDone(); toast('내 배로 돌아왔어요. 다시 <strong>순항</strong> 중이에요.', 3200); }
  };
  sail.finish = finish;
  if (toIsle && opts.atWheel && AREA === CABIN_AREA){ steer(); return; }
  if (toIsle){
    /* 망원경 등 다른 곳에서: 선장실 문 앞 → 타륜까지 걸어가서 */
    fadeSwap(() => { setArea('cabin'); player.x = 0; player.z = ROOM.maxZ - 2.0; player.r = Math.PI; cam.yaw = 0; cam.pitch = 0.32; },
      () => { toast('선장실 <strong>타륜</strong>으로 가요.', 1800); goTo(SPOTS.wheel.x, SPOTS.wheel.z, { face:Math.PI, then:() => steer() }); sailLater(() => { if (sail.on && player.pose !== 'steer') steer(); }, 7000); });
  } else {
    /* 절영도 선착장에서: 배에 올라 바로 타륜을 잡아요 */
    fadeSwap(() => { setArea('cabin'); steer(); });
  }
}
function endSteer(){ player.pose = null; CABIN_AREA.view = null; sailFx.want = 0; SL.root.hidden = true; document.body.classList.remove('sail-open'); }
function sailDone(){ sail.on = false; cutscene = false; uiOpen = false; auto = null; sail.finish = null; try { renderer.domElement.focus({ preventScroll:true }); } catch(e){} }
function cancelSail(){ if (!sail.on) return; sailClear(); endSteer(); sailDone(); $('#fade').classList.remove('on'); }
SL.skip.addEventListener('click', () => { if (sail.finish) sail.finish(); });
window.addEventListener('keydown', e => { if (sail.on && e.key === 'Escape' && player.pose === 'steer'){ e.preventDefault(); if (sail.finish) sail.finish(); } });
