/* ============================================================
   LOG POSE · 선장실 3D (단계 1)
   항해 중인 해적선의 선장실: 타륜 · 선장 책상 · 고물 창(바다·하늘) · 랜턴 · 손목 로그포스
   작품 데이터는 LPData(app/works.js)로만 읽어요. 이 파일은 공간과 조작만 담당해요.
   ============================================================ */
const $ = s => document.querySelector(s);
const reduceMotion = (() => { try { return matchMedia('(prefers-reduced-motion: reduce)').matches; } catch(e){ return false; } })();
const isTouch = (() => { try { return matchMedia('(pointer: coarse)').matches; } catch(e){ return false; } })();
if (isTouch) document.body.classList.add('touch');
const FD = "'Gowun Batang', serif", FB = "'IBM Plex Sans KR', sans-serif";
const rand = (a, b) => a + Math.random() * (b - a);

/* ---------- 알림 ---------- */
let toastT = 0;
function toast(html, ms = 3600){ const t = $('#toast'); t.innerHTML = html; t.hidden = false; clearTimeout(toastT); toastT = setTimeout(() => { t.hidden = true; }, ms); }

/* ---------- 렌더러 · 장면 ---------- */
const renderer = new THREE.WebGLRenderer({ canvas:$('#scene'), antialias:true });
renderer.setPixelRatio(Math.min(2, window.devicePixelRatio || 1));
renderer.outputEncoding = THREE.sRGBEncoding;
renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.05;
const scene = new THREE.Scene();
scene.fog = new THREE.Fog('#9fc6e2', 30, 220);
const camera = new THREE.PerspectiveCamera(58, 1, 0.05, 600);
function resize(){ const w = window.innerWidth, h = window.innerHeight; renderer.setSize(w, h, false); camera.aspect = w / h; camera.updateProjectionMatrix(); }
window.addEventListener('resize', resize); resize();

/* ---------- 텍스처 도구 ---------- */
function canvasTex(w, h, draw, repeat){
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  const g = c.getContext('2d'); draw(g, w, h);
  const t = new THREE.CanvasTexture(c); t.encoding = THREE.sRGBEncoding; t.anisotropy = 4;
  if (repeat){ t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(repeat[0], repeat[1]); }
  return t;
}
function speckle(g, w, h, n, color, alpha){ g.fillStyle = color; for (let i = 0; i < n; i++){ g.globalAlpha = Math.random() * alpha; g.fillRect(Math.random() * w, Math.random() * h, 1 + Math.random() * 2, 1 + Math.random() * 2); } g.globalAlpha = 1; }
const glowTex = canvasTex(128, 128, (g, w, h) => { const r = g.createRadialGradient(w/2, h/2, 0, w/2, h/2, w/2); r.addColorStop(0, 'rgba(255,255,255,1)'); r.addColorStop(.35, 'rgba(255,255,255,.45)'); r.addColorStop(1, 'rgba(255,255,255,0)'); g.fillStyle = r; g.fillRect(0, 0, w, h); });
const shadowTex = canvasTex(128, 128, (g, w, h) => { const r = g.createRadialGradient(w/2, h/2, 0, w/2, h/2, w/2); r.addColorStop(0, 'rgba(0,0,0,.45)'); r.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = r; g.fillRect(0, 0, w, h); });

function plankTex(tones, planks, caulk){ return canvasTex(1024, 1024, (g, w, h) => {
  const pw = w / planks;
  for (let i = 0; i < planks; i++){
    let y = -Math.random() * h;
    while (y < h){
      const len = rand(380, 760); g.fillStyle = tones[Math.floor(Math.random() * tones.length)]; g.fillRect(i * pw, y, pw, len);
      g.strokeStyle = 'rgba(30,18,8,.28)'; g.lineWidth = 1;
      for (let k = 0; k < 5; k++){ const x = i * pw + rand(6, pw - 6); g.globalAlpha = rand(.15, .4); g.beginPath(); g.moveTo(x, y); g.bezierCurveTo(x + rand(-5, 5), y + len * .3, x + rand(-5, 5), y + len * .7, x + rand(-4, 4), y + len); g.stroke(); }
      g.globalAlpha = 1; g.fillStyle = caulk; g.fillRect(i * pw, y + len - 3, pw, 3);
      g.fillStyle = 'rgba(25,16,8,.7)'; [[.25, 9], [.75, 9]].forEach(([fx, fy]) => { g.beginPath(); g.arc(i * pw + pw * fx, y + fy, 2.4, 0, Math.PI * 2); g.fill(); });
      y += len;
    }
    g.fillStyle = caulk; g.fillRect(i * pw, 0, 3, h);
  }
  speckle(g, w, h, 4000, '#1e1208', .2);
}); }

/* ---------- 재질 ---------- */
const M = {
  floor: new THREE.MeshStandardMaterial({ map:plankTex(['#8a6a48','#7f603f','#93734f','#76583a'], 10, 'rgba(20,12,6,.85)'), roughness:.85 }),
  wall: new THREE.MeshStandardMaterial({ roughness:.9 }),
  beam: new THREE.MeshStandardMaterial({ color:'#3b2616', roughness:.8 }),
  wood: new THREE.MeshStandardMaterial({ color:'#6b4528', roughness:.6 }),
  woodDark: new THREE.MeshStandardMaterial({ color:'#3e2617', roughness:.65 }),
  woodRed: new THREE.MeshStandardMaterial({ color:'#5a2a1c', roughness:.55 }),
  brass: new THREE.MeshStandardMaterial({ color:'#c9a15e', roughness:.3, metalness:.75 }),
  iron: new THREE.MeshStandardMaterial({ color:'#3a3836', roughness:.5, metalness:.6 }),
  bulb: new THREE.MeshBasicMaterial({ color:'#ffe2a8' }),
  shadow: new THREE.MeshBasicMaterial({ map:shadowTex, transparent:true, depthWrite:false })
};
M.wall.map = plankTex(['#6a4a30','#714f33','#634529','#6e4c2f'], 14, 'rgba(25,15,7,.75)');
M.wall.map.wrapS = M.wall.map.wrapT = THREE.RepeatWrapping;
M.wall.map.rotation = Math.PI / 2;   // 판재를 가로로 눕혀요

/* ---------- 선장실 크기 ---------- */
const ROOM = { minX:-6, maxX:6, minZ:-5, maxZ:5, H:3.4 };
const colliders = [];
const addBox = (cx, cz, hx, hz) => colliders.push({ minX:cx - hx, maxX:cx + hx, minZ:cz - hz, maxZ:cz + hz });
const mesh = (geo, mat, x, y, z, parent = scene) => { const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); parent.add(m); return m; };

/* ---------- 창밖: 하늘 · 바다 (작은 흔들림으로 항해 느낌) ---------- */
const OUT = new THREE.Group(); scene.add(OUT);
function skyTex(mode){ return canvasTex(1024, 512, (g, w, h) => {
  const day = mode === 'day', gr = g.createLinearGradient(0, 0, 0, h);
  if (day){ gr.addColorStop(0, '#5f9fd6'); gr.addColorStop(.62, '#a9d1ec'); gr.addColorStop(1, '#e8f1f4'); }
  else { gr.addColorStop(0, '#060d1a'); gr.addColorStop(.62, '#13284a'); gr.addColorStop(1, '#27406a'); }
  g.fillStyle = gr; g.fillRect(0, 0, w, h);
  if (day){
    g.fillStyle = 'rgba(255,255,255,.75)';
    for (let i = 0; i < 9; i++){ const x = rand(0, w), y = rand(h * .15, h * .6), s = rand(40, 110); for (let k = 0; k < 5; k++){ g.beginPath(); g.ellipse(x + k * s * .35, y + rand(-8, 8), s * .5, s * .22, 0, 0, Math.PI * 2); g.fill(); } }
    const sun = g.createRadialGradient(w * .72, h * .3, 0, w * .72, h * .3, 90); sun.addColorStop(0, 'rgba(255,250,225,1)'); sun.addColorStop(.25, 'rgba(255,240,200,.8)'); sun.addColorStop(1, 'rgba(255,240,200,0)'); g.fillStyle = sun; g.fillRect(0, 0, w, h);
  } else {
    for (let i = 0; i < 380; i++){ g.fillStyle = `rgba(230,238,250,${rand(.3, .95)})`; g.fillRect(rand(0, w), rand(0, h * .78), rand(1, 2.4), rand(1, 2.4)); }
    const moon = g.createRadialGradient(w * .3, h * .26, 0, w * .3, h * .26, 70); moon.addColorStop(0, 'rgba(240,244,252,1)'); moon.addColorStop(.3, 'rgba(220,230,248,.6)'); moon.addColorStop(1, 'rgba(220,230,248,0)'); g.fillStyle = moon; g.fillRect(0, 0, w, h);
  }
}); }
const SKY = { day:null, night:null };
const skyMat = new THREE.MeshBasicMaterial({ fog:false });
const sky = mesh(new THREE.PlaneGeometry(900, 300), skyMat, 0, 120, -260, OUT);
const skySideL = mesh(new THREE.PlaneGeometry(600, 300), skyMat, -300, 120, 0, OUT); skySideL.rotation.y = Math.PI / 2;
const skySideR = mesh(new THREE.PlaneGeometry(600, 300), skyMat, 300, 120, 0, OUT); skySideR.rotation.y = -Math.PI / 2;
const waterTex = canvasTex(512, 512, (g, w, h) => {
  g.fillStyle = '#ffffff'; g.fillRect(0, 0, w, h);
  g.strokeStyle = 'rgba(40,80,110,.22)'; g.lineWidth = 2;
  for (let i = 0; i < 90; i++){ const y = rand(0, h), x = rand(0, w), l = rand(30, 90); g.beginPath(); g.moveTo(x, y); g.quadraticCurveTo(x + l / 2, y - 4, x + l, y); g.stroke(); }
}, [70, 70]);
const sea = mesh(new THREE.PlaneGeometry(700, 700), new THREE.MeshStandardMaterial({ map:waterTex, color:'#3f7fa6', roughness:.3, metalness:.4 }), 0, -2.4, -200, OUT);
sea.rotation.x = -Math.PI / 2;
/* 배 뒤로 남는 물결 자국 */
const wake = mesh(new THREE.PlaneGeometry(6, 60), new THREE.MeshBasicMaterial({ map:glowTex, color:'#ffffff', transparent:true, opacity:.22, depthWrite:false }), 0, -2.35, -36, OUT);
wake.rotation.x = -Math.PI / 2;

/* ---------- 방: 바닥 · 벽 · 천장 들보 ---------- */
function buildRoom(){
  const W = ROOM.maxX - ROOM.minX, D = ROOM.maxZ - ROOM.minZ, H = ROOM.H;
  M.floor.map.wrapS = M.floor.map.wrapT = THREE.RepeatWrapping; M.floor.map.repeat.set(W / 4, D / 4);
  const floor = mesh(new THREE.PlaneGeometry(W, D), M.floor, 0, 0, 0); floor.rotation.x = -Math.PI / 2; floor.name = 'floor'; CABIN_AREA.floors.push(floor);
  const ceil = mesh(new THREE.PlaneGeometry(W, D), new THREE.MeshStandardMaterial({ color:'#2a1a0f', roughness:.95 }), 0, H, 0); ceil.rotation.x = Math.PI / 2;
  for (let x = ROOM.minX + 1; x < ROOM.maxX; x += 1.5) mesh(new THREE.BoxGeometry(0.22, 0.24, D), M.beam, x, H - 0.12, 0);
  mesh(new THREE.BoxGeometry(W, 0.28, 0.3), M.beam, 0, H - 0.14, ROOM.minZ + 0.15);
  /* 벽 조각: 텍스처 반복을 길이에 맞춰요 */
  const wallPiece = (w, h, x, y, z, ry) => { const mat = M.wall.clone(); mat.map = M.wall.map.clone(); mat.map.needsUpdate = true; mat.map.repeat.set(h / 3, w / 3); const m = mesh(new THREE.PlaneGeometry(w, h), mat, x, y, z); m.rotation.y = ry; return m; };
  wallPiece(D, H, ROOM.minX, H / 2, 0, Math.PI / 2);     // 왼쪽 벽
  wallPiece(D, H, ROOM.maxX, H / 2, 0, -Math.PI / 2);    // 오른쪽 벽
  wallPiece(W, H, 0, H / 2, ROOM.maxZ, Math.PI);         // 앞(문) 벽
  /* 뒤쪽 = 고물 창 벽: 창 다섯 개 사이 기둥 */
  const WIN = { y0:0.95, y1:2.75 }, open = [[-4.3, -2.9], [-2.5, -1.1], [-0.7, 0.7], [1.1, 2.5], [2.9, 4.3]];
  const z = ROOM.minZ;
  wallPiece(W, WIN.y0, 0, WIN.y0 / 2, z, 0);
  wallPiece(W, H - WIN.y1, 0, (WIN.y1 + H) / 2, z, 0);
  let cur = ROOM.minX;
  for (const [a, b] of open){ if (a > cur) wallPiece(a - cur, WIN.y1 - WIN.y0, (cur + a) / 2, (WIN.y0 + WIN.y1) / 2, z, 0); cur = b; }
  wallPiece(ROOM.maxX - cur, WIN.y1 - WIN.y0, (cur + ROOM.maxX) / 2, (WIN.y0 + WIN.y1) / 2, z, 0);
  /* 창틀 · 살 · 유리 */
  const glass = new THREE.MeshBasicMaterial({ color:'#cfe6f2', transparent:true, opacity:.06, depthWrite:false });
  for (const [a, b] of open){
    const cx = (a + b) / 2, w = b - a, cy = (WIN.y0 + WIN.y1) / 2, h = WIN.y1 - WIN.y0;
    mesh(new THREE.BoxGeometry(w + 0.16, 0.1, 0.22), M.woodDark, cx, WIN.y0, z + 0.06);
    mesh(new THREE.BoxGeometry(w + 0.16, 0.1, 0.22), M.woodDark, cx, WIN.y1, z + 0.06);
    [a, b].forEach(x => mesh(new THREE.BoxGeometry(0.1, h, 0.22), M.woodDark, x, cy, z + 0.06));
    mesh(new THREE.BoxGeometry(0.05, h, 0.08), M.brass, cx, cy, z + 0.04);
    mesh(new THREE.BoxGeometry(w, 0.05, 0.08), M.brass, cx, cy + 0.2, z + 0.04);
    mesh(new THREE.PlaneGeometry(w, h), glass, cx, cy, z + 0.02);
    /* 아치 장식 */
    const arch = mesh(new THREE.TorusGeometry(w / 2, 0.05, 6, 24, Math.PI), M.woodDark, cx, WIN.y1, z + 0.08);
    arch.scale.y = 0.35;
  }
  mesh(new THREE.BoxGeometry(W, 0.12, 0.36), M.wood, 0, WIN.y0 - 0.04, z + 0.18);   // 창턱
  /* 양옆 벽의 둥근 현창 */
  [[ROOM.maxX, -1]].forEach(([x, s]) => [-1.6, 2.2].forEach(zz => {   /* 왼쪽 벽은 해도 · 옷장 · 지도 꽂이로 가득해서 현창은 오른쪽만 */
    const ring = mesh(new THREE.TorusGeometry(0.34, 0.06, 10, 28), M.brass, x + s * 0.03, 1.8, zz); ring.rotation.y = Math.PI / 2;
    const disc = mesh(new THREE.CircleGeometry(0.33, 28), new THREE.MeshBasicMaterial({ color:'#8fc0dc', fog:false }), x + s * 0.02, 1.8, zz); disc.rotation.y = s * Math.PI / 2;
    portholes.push(disc);
  }));
  /* 문 (앞 벽) — 다른 공간은 나중에 열려요 */
  const door = mesh(new THREE.BoxGeometry(1.3, 2.2, 0.1), M.woodRed, 0, 1.1, ROOM.maxZ - 0.06);
  mesh(new THREE.SphereGeometry(0.05, 10, 8), M.brass, 0.48, 1.05, ROOM.maxZ - 0.13);
  mesh(new THREE.BoxGeometry(1.5, 0.12, 0.16), M.woodDark, 0, 2.26, ROOM.maxZ - 0.08);
  door.userData.kind = 'door'; clickables.push(door);
}
const portholes = [];
const flagShows = [];   /* 내 해적기를 보여 주는 천들 (market.js applyLooks 가 그림을 바꿔요) */
const clickables = [];

/* ---------- 선장 책상 ---------- */
const DESK = { x:0, z:0.7 };          // 방 한가운데(러그 위). 앞뒤 구분 없는 해도 탁자
function mapTex(){ return canvasTex(512, 384, (g, w, h) => {
  g.fillStyle = '#e8dcbc'; g.fillRect(0, 0, w, h); speckle(g, w, h, 1800, '#8a6a48', .18);
  g.strokeStyle = 'rgba(90,64,40,.35)'; g.lineWidth = 1; for (let x = 0; x < w; x += 48){ g.beginPath(); g.moveTo(x, 0); g.lineTo(x, h); g.stroke(); } for (let y = 0; y < h; y += 48){ g.beginPath(); g.moveTo(0, y); g.lineTo(w, y); g.stroke(); }
  g.fillStyle = 'rgba(110,86,52,.55)';
  [[120, 120, 60], [330, 220, 80], [400, 90, 34], [210, 290, 40]].forEach(([x, y, r]) => { g.beginPath(); for (let a = 0; a < Math.PI * 2; a += 0.4){ const rr = r * rand(.7, 1.15); g.lineTo(x + Math.cos(a) * rr, y + Math.sin(a) * rr * .7); } g.closePath(); g.fill(); });
  g.setLineDash([8, 6]); g.strokeStyle = '#8a2a1c'; g.lineWidth = 3; g.beginPath(); g.moveTo(60, 330); g.bezierCurveTo(180, 260, 260, 160, 400, 96); g.stroke(); g.setLineDash([]);
  g.fillStyle = '#8a2a1c'; g.font = `700 30px ${FD}`; g.fillText('✕', 388, 106);
  g.save(); g.translate(70, 70); g.strokeStyle = '#5a4030'; g.lineWidth = 2; g.beginPath(); g.arc(0, 0, 34, 0, Math.PI * 2); g.stroke();
  for (let k = 0; k < 4; k++){ g.rotate(Math.PI / 2); g.beginPath(); g.moveTo(0, -40); g.lineTo(6, 0); g.lineTo(-6, 0); g.closePath(); g.fillStyle = '#5a4030'; g.fill(); } g.restore();
  g.strokeStyle = '#6a5440'; g.lineWidth = 6; g.strokeRect(4, 4, w - 8, h - 8);
}); }
function buildDesk(){
  const D = new THREE.Group(); D.position.set(DESK.x, 0, DESK.z); scene.add(D);
  /* 앞뒤 구분 없는 해도 탁자: 네 귀퉁이 다리 · 사방 같은 서랍 · 아래 선반 */
  mesh(new THREE.BoxGeometry(2.4, 0.1, 1.2), M.woodRed, 0, 0.82, 0, D);                // 상판
  mesh(new THREE.BoxGeometry(2.46, 0.04, 1.26), M.brass, 0, 0.765, 0, D);
  mesh(new THREE.BoxGeometry(2.2, 0.16, 1.0), M.wood, 0, 0.67, 0, D);                    // 앞치마(사방)
  [-1, 1].forEach(sz => [-0.6, 0, 0.6].forEach(x => {                                    // 앞·뒤 똑같은 서랍
    mesh(new THREE.BoxGeometry(0.5, 0.11, 0.02), M.woodRed, x, 0.67, sz * 0.505, D);
    mesh(new THREE.SphereGeometry(0.022, 8, 6), M.brass, x, 0.67, sz * 0.52, D); }));
  [-1, 1].forEach(sx => mesh(new THREE.BoxGeometry(0.02, 0.11, 0.6), M.woodRed, sx * 1.105, 0.67, 0, D));   // 양 옆 서랍
  [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(([sx, sz]) => {                           // 다리
    mesh(new THREE.CylinderGeometry(0.07, 0.055, 0.6, 12), M.woodDark, sx * 1.02, 0.3, sz * 0.46, D);
    mesh(new THREE.SphereGeometry(0.085, 12, 8), M.woodDark, sx * 1.02, 0.42, sz * 0.46, D);
    mesh(new THREE.CylinderGeometry(0.08, 0.08, 0.04, 12), M.brass, sx * 1.02, 0.02, sz * 0.46, D); });
  mesh(new THREE.BoxGeometry(2.0, 0.05, 0.86), M.wood, 0, 0.16, 0, D);                   // 아래 선반
  [[-0.6, 0.1, '#8a2a1c'], [0.15, -0.15, '#1d3346'], [0.7, 0.2, '#6a4628']].forEach(([x, z, c], i) => {   // 선반 위 말린 해도·상자
    const r = mesh(i === 2 ? new THREE.BoxGeometry(0.4, 0.18, 0.3) : new THREE.CylinderGeometry(0.06, 0.06, 0.6, 10), new THREE.MeshStandardMaterial({ color:i === 2 ? c : '#e8dcbc', roughness:.9 }), x, i === 2 ? 0.28 : 0.25, z, D);
    if (i !== 2) r.rotation.z = Math.PI / 2; });
  const map = mesh(new THREE.PlaneGeometry(1.2, 0.9), new THREE.MeshStandardMaterial({ map:mapTex(), roughness:.9 }), -0.15, 0.876, 0.05, D); map.rotation.x = -Math.PI / 2; map.rotation.z = 0.06;
  /* 펼친 항해일지 */
  const book = new THREE.Group(); book.position.set(0.72, 0.88, 0.12); book.rotation.y = -0.25; D.add(book);
  const pageMat = new THREE.MeshStandardMaterial({ color:'#efe4cc', roughness:.9 });
  [-1, 1].forEach(s => { const p = mesh(new THREE.BoxGeometry(0.3, 0.03, 0.4), pageMat, s * 0.155, 0, 0, book); p.rotation.z = -s * 0.06; });
  mesh(new THREE.BoxGeometry(0.64, 0.015, 0.43), M.woodRed, 0, -0.02, 0, book);
  /* 놋쇠 나침반 · 촛불 · 깃펜 */
  mesh(new THREE.CylinderGeometry(0.11, 0.12, 0.05, 24), M.brass, -0.9, 0.9, -0.3, D);
  const face = mesh(new THREE.CircleGeometry(0.09, 24), new THREE.MeshStandardMaterial({ color:'#efe4cc' }), -0.9, 0.926, -0.3, D); face.rotation.x = -Math.PI / 2;
  const nd = mesh(new THREE.BoxGeometry(0.012, 0.006, 0.15), new THREE.MeshBasicMaterial({ color:'#8a2a1c' }), -0.9, 0.93, -0.3, D); deskNeedle.ref = nd;
  mesh(new THREE.CylinderGeometry(0.035, 0.035, 0.18, 12), new THREE.MeshStandardMaterial({ color:'#efe4cc' }), 1.0, 0.96, -0.38, D);
  mesh(new THREE.CylinderGeometry(0.07, 0.08, 0.03, 16), M.brass, 1.0, 0.885, -0.38, D);
  const flame = new THREE.Sprite(new THREE.SpriteMaterial({ map:glowTex, color:'#ffc66b', transparent:true, blending:THREE.AdditiveBlending, depthWrite:false })); flame.scale.set(0.22, 0.32, 1); flame.position.set(1.0, 1.1, -0.38); D.add(flame); candle.flame = flame;
  const cl = new THREE.PointLight('#ffb35c', 0.9, 4.5, 2); cl.position.set(1.0, 1.25, -0.38); D.add(cl); candle.light = cl;
  const quill = mesh(new THREE.ConeGeometry(0.02, 0.32, 6), new THREE.MeshStandardMaterial({ color:'#f3ead6' }), 0.38, 0.92, -0.32, D); quill.rotation.z = 1.1; quill.rotation.y = 0.5;
  addBox(DESK.x, DESK.z, 1.25, 0.65);
  D.userData.kind = 'desk'; clickables.push(D);
}
const candle = { flame:null, light:null };
const deskNeedle = { ref:null };

/* ---------- 타륜 ---------- */
const WHEEL = { x:0, z:-3.55 };        // 가운데 창 앞
const wheelRef = { g:null, spin:0 };
function buildWheel(){
  const base = new THREE.Group(); base.position.set(WHEEL.x, 0, WHEEL.z); scene.add(base);
  mesh(new THREE.CylinderGeometry(0.9, 0.95, 0.14, 24), M.woodDark, 0, 0.07, 0, base);           // 단
  mesh(new THREE.BoxGeometry(0.3, 1.25, 0.34), M.wood, 0, 0.74, 0, base);                          // 받침
  mesh(new THREE.BoxGeometry(0.36, 0.08, 0.4), M.brass, 0, 1.36, 0, base);
  const wheel = new THREE.Group(); wheel.position.set(0, 1.5, 0.24); base.add(wheel);
  const rimMat = new THREE.MeshStandardMaterial({ color:'#7a4a28', roughness:.5 });
  wheel.add(new THREE.Mesh(new THREE.TorusGeometry(0.62, 0.05, 10, 40), rimMat));
  wheel.add(new THREE.Mesh(new THREE.TorusGeometry(0.4, 0.025, 8, 32), rimMat));
  wheel.add(new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 0.14, 16).rotateX(Math.PI / 2), M.brass));
  for (let k = 0; k < 8; k++){
    const a = k * Math.PI / 4, sp = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.035, 1.6, 8), rimMat);
    sp.rotation.z = a; wheel.add(sp);
    const knob = new THREE.Mesh(new THREE.SphereGeometry(0.05, 10, 8), M.brass); knob.position.set(Math.sin(-a) * 0.8, Math.cos(a) * 0.8, 0); wheel.add(knob);
  }
  wheelRef.g = wheel;
  addBox(WHEEL.x, WHEEL.z, 0.55, 0.5);
  base.userData.kind = 'wheel'; clickables.push(base);
}

/* ---------- 소품: 랜턴 · 지도 · 궤짝 · 지구본 · 책장 · 러그 ---------- */
const lanterns = [];
function buildProps(){
  [[-2.6, 0.6], [2.6, 0.6]].forEach(([x, z]) => {
    const g = new THREE.Group(); g.position.set(x, ROOM.H - 0.24, z); scene.add(g);
    mesh(new THREE.CylinderGeometry(0.008, 0.008, 0.5, 6), M.iron, 0, -0.25, 0, g);
    mesh(new THREE.ConeGeometry(0.2, 0.16, 6), M.brass, 0, -0.55, 0, g);
    mesh(new THREE.CylinderGeometry(0.16, 0.16, 0.34, 6, 1, true), new THREE.MeshStandardMaterial({ color:'#ffe0a8', emissive:'#ffb860', emissiveIntensity:.8, transparent:true, opacity:.7, side:THREE.DoubleSide }), 0, -0.8, 0, g);
    mesh(new THREE.CylinderGeometry(0.18, 0.14, 0.05, 6), M.brass, 0, -0.99, 0, g);
    const glow = new THREE.Sprite(new THREE.SpriteMaterial({ map:glowTex, color:'#ffcf8a', transparent:true, opacity:.6, blending:THREE.AdditiveBlending, depthWrite:false })); glow.scale.set(1.3, 1.3, 1); glow.position.y = -0.8; g.add(glow);
    const l = new THREE.PointLight('#ffc27a', 1.3, 9, 1.8); l.position.y = -0.8; g.add(l);
    lanterns.push({ g, l, ph:Math.random() * 6 });
  });
  /* 러그: 나침반 장미 */
  const rug = mesh(new THREE.PlaneGeometry(4.6, 3.6), new THREE.MeshStandardMaterial({ map:canvasTex(512, 384, (g, w, h) => {
    g.fillStyle = '#5a2a1c'; g.fillRect(0, 0, w, h); g.strokeStyle = '#c9a15e'; g.lineWidth = 6; g.strokeRect(16, 16, w - 32, h - 32);
    g.save(); g.translate(w / 2, h / 2); g.scale(1, 0.72);
    for (let k = 0; k < 8; k++){ g.save(); g.rotate(k * Math.PI / 4 + Math.PI / 8); g.beginPath(); g.moveTo(0, -95); g.lineTo(14, 0); g.lineTo(-14, 0); g.closePath(); g.fillStyle = 'rgba(239,228,204,.5)'; g.fill(); g.restore(); }
    for (let k = 0; k < 4; k++){ g.save(); g.rotate(k * Math.PI / 2); g.beginPath(); g.moveTo(0, -150); g.lineTo(22, 0); g.lineTo(-22, 0); g.closePath(); g.fillStyle = k ? '#c9a15e' : '#e8c27a'; g.fill(); g.restore(); }
    g.strokeStyle = 'rgba(201,161,94,.7)'; g.lineWidth = 3; g.beginPath(); g.arc(0, 0, 120, 0, Math.PI * 2); g.stroke(); g.restore();
    speckle(g, w, h, 2500, '#000', .2);
  }), roughness:.95 }), 0, 0.012, 0.6); rug.rotation.x = -Math.PI / 2;
  /* 왼쪽 벽: 큰 해도 + 지도 꽂이 */
  mesh(new THREE.PlaneGeometry(2.6, 1.6), new THREE.MeshStandardMaterial({ map:mapTex(), roughness:.9 }), ROOM.minX + 0.02, 1.9, -1.0).rotation.y = Math.PI / 2;
  const rack = new THREE.Group(); rack.position.set(ROOM.minX + 0.35, 0, 2.6); scene.add(rack);
  mesh(new THREE.BoxGeometry(0.6, 1.8, 1.6), M.wood, 0, 0.9, 0, rack);
  for (let r = 0; r < 4; r++) for (let c = 0; c < 5; c++){ const s = mesh(new THREE.CylinderGeometry(0.07, 0.07, 0.5, 10), new THREE.MeshStandardMaterial({ color:['#e8dcbc','#d9cdb0','#efe4cc'][c % 3], roughness:.9 }), 0.12, 0.3 + r * 0.4, -0.6 + c * 0.3, rack); s.rotation.z = Math.PI / 2; }
  addBox(ROOM.minX + 0.35, 2.6, 0.32, 0.82);
  /* 오른쪽: 궤짝 · 지구본 · 통 */
  const chest = new THREE.Group(); chest.position.set(ROOM.maxX - 0.7, 0, 1.6); chest.rotation.y = -Math.PI / 2; scene.add(chest);
  mesh(new THREE.BoxGeometry(1.1, 0.55, 0.65), M.woodRed, 0, 0.28, 0, chest);
  /* 뚜껑: 뒤쪽 모서리를 경첩 삼아 열려요 (보물 상자 · letters.js) */
  const lidHinge = new THREE.Group(); lidHinge.position.set(0, 0.55, -0.325); chest.add(lidHinge); chestRef.hinge = lidHinge; chestRef.g = chest;
  const lid = mesh(new THREE.CylinderGeometry(0.33, 0.33, 1.1, 16, 1, false, 0, Math.PI), M.woodRed, 0, 0, 0.325, lidHinge); lid.rotation.z = Math.PI / 2;
  [-0.38, 0.38].forEach(x => { const b = mesh(new THREE.CylinderGeometry(0.34, 0.34, 0.06, 16, 1, false, 0, Math.PI), M.brass, x, 0, 0.325, lidHinge); b.rotation.z = Math.PI / 2; });
  mesh(new THREE.BoxGeometry(0.14, 0.16, 0.04), M.brass, 0, 0.47, 0.335, chest);   // 자물쇠
  chest.userData.kind = 'chest'; clickables.push(chest);
  [-0.38, 0.38].forEach(x => mesh(new THREE.BoxGeometry(0.06, 0.58, 0.67), M.brass, x, 0.29, 0, chest));
  addBox(ROOM.maxX - 0.7, 1.6, 0.36, 0.58);
  const globe = new THREE.Group(); globe.position.set(-3.6, 0, -3.4); scene.add(globe);
  mesh(new THREE.CylinderGeometry(0.22, 0.3, 0.7, 12), M.wood, 0, 0.35, 0, globe);
  const ball = mesh(new THREE.SphereGeometry(0.34, 24, 18), new THREE.MeshStandardMaterial({ map:mapTex(), roughness:.7 }), 0, 1.08, 0, globe); globeRef.ball = ball;
  const meridian = mesh(new THREE.TorusGeometry(0.38, 0.015, 6, 32), M.brass, 0, 1.08, 0, globe); meridian.rotation.y = Math.PI / 2;
  addBox(-3.6, -3.4, 0.36, 0.36);
  [[ROOM.maxX - 0.5, 3.9], [ROOM.maxX - 1.2, 4.3], [ROOM.minX + 0.5, 4.2]].forEach(([x, z]) => {
    mesh(new THREE.CylinderGeometry(0.3, 0.3, 0.8, 16), new THREE.MeshStandardMaterial({ color:'#6a4628', roughness:.7 }), x, 0.4, z);
    [0.15, 0.65].forEach(y => mesh(new THREE.CylinderGeometry(0.315, 0.315, 0.05, 16, 1, true), M.iron, x, y, z));
    addBox(x, z, 0.32, 0.32);
  });
  /* 앞 벽 양옆 깃발 */
  [-2.2, 2.2].forEach((x, i) => { const f = mesh(new THREE.PlaneGeometry(0.9, 0.6), new THREE.MeshStandardMaterial({ map:canvasTex(256, 170, (g, w, h) => {
    g.fillStyle = i ? '#1d3346' : '#5a2a1c'; g.fillRect(0, 0, w, h); g.fillStyle = '#efe4cc'; g.font = `700 70px ${FD}`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(i ? '☸' : '⚓', w / 2, h / 2 + 4);
  }), side:THREE.DoubleSide, roughness:.9 }), x, 2.5, ROOM.maxZ - 0.03); f.rotation.y = Math.PI; if (!i){ f.scale.set(1.35, 1.35, 1); flagShows.push(f.material); } });   /* 문 왼쪽 = 내 해적기 */
}
const globeRef = { ball:null };
const chestRef = { g:null, hinge:null, open:0, want:0 };

/* ---------- 조명 ---------- */
const hemi = new THREE.HemisphereLight('#ffe2b8', '#3a2414', .55); scene.add(hemi);
const windowLight = new THREE.DirectionalLight('#dcecff', .8); windowLight.position.set(1, 4, -12); scene.add(windowLight);

/* ---------- 캐릭터 + 손목 로그포스 ---------- */
/* 하얗고 통통한 꼬마 선장: 큰 머리 · 짧은 팔다리 · 해진 셔츠와 반바지는 몸에 '그려서' 꼭 맞게 입혀요
   (color: 바지 색, 셔츠는 그 색이 살짝 섞인 바랜 리넨) */
function mixHex(a, b, t){ const p = h => [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16)); const A = p(a), B = p(b); return '#' + A.map((v, i) => Math.round(v + (B[i] - v) * t).toString(16).padStart(2, '0')).join(''); }
const SKIN = '#f4f2f7';
/* 찢어진 밑단: 위는 반듯, 아래는 들쭉날쭉 (가로로 이어 붙여도 끊기지 않게) */
function jagBand(g, w, y0, base, color, seed, amp){
  g.beginPath(); g.moveTo(0, y0); g.lineTo(w, y0);
  const n = 32; for (let i = n; i >= 0; i--){ const x = i / n * w, k = (i % n), r = ((k * 37 + seed * 11) % 7) / 7;
    g.lineTo(x, base + (k % 2 ? amp * (0.5 + r) : -amp * 0.25 * r)); }
  g.closePath(); g.fillStyle = color; g.fill();
}
function wornSpots(g, w, y0, y1, color, n, seed){
  for (let i = 0; i < n; i++){ const x = ((i * 97 + seed * 31) % 1000) / 1000 * w, y = y0 + ((i * 53 + seed * 17) % 1000) / 1000 * (y1 - y0);
    g.fillStyle = color; g.globalAlpha = 0.08 + (i % 3) * 0.04; g.beginPath(); g.ellipse(x, y, 6 + (i % 4) * 4, 3 + (i % 3) * 2, 0, 0, 7); g.fill(); }
  g.globalAlpha = 1;
}
function patch(g, x, y, pw, ph, color, rot){
  g.save(); g.translate(x, y); g.rotate(rot); g.fillStyle = color; g.fillRect(-pw / 2, -ph / 2, pw, ph);
  g.strokeStyle = 'rgba(40,28,18,.75)'; g.lineWidth = 1.6; g.setLineDash([3, 3]); g.strokeRect(-pw / 2 + 2, -ph / 2 + 2, pw - 4, ph - 4); g.setLineDash([]); g.restore();
}
/* 몸 윤곽 (반지름, 높이): 둥근 배 → 살짝 잘록한 목 → 머리 속으로. 옷 그림은 이 점 순서(아래→위)를 따라 입혀요 */
const BODY_PROFILE = [[0,0.24],[0.16,0.245],[0.235,0.265],[0.27,0.3],[0.288,0.35],[0.293,0.4],[0.29,0.46],[0.283,0.52],[0.274,0.58],[0.262,0.64],[0.245,0.7],[0.222,0.75],[0.192,0.795],[0.165,0.835],[0.15,0.87],[0.135,0.91],[0,0.95]];   /* 통통한 콩 모양: 어깨부터 엉덩이까지 거의 고르게 둥글고, 목은 짧게 */
const BODY_TALL = 1.0;   /* 몸 키 늘림 배율 */
const bodyV = y => { let j = 0; BODY_PROFILE.forEach((q, i) => { if (Math.abs(q[1] - y) < Math.abs(BODY_PROFILE[j][1] - y)) j = i; }); return (1 - j / (BODY_PROFILE.length - 1)) * 256; };   /* 높이 → 그림 세로 위치 */
/* ---------- 옷: 몸에 직접 그려 입혀요 (시장 모자·옷 가게에서 사고, 선장실 옷장에서 갈아입어요) ---------- */
const OUTFITS = [
  { id:'rags',     name:'해진 옷',       price:0,  note:'처음 선장의 낡은 셔츠와 반바지', torn:true },
  { id:'stripe',   name:'줄무늬 선원복', price:30, note:'파란 줄무늬 셔츠 · 남색 반바지', shirt:'#f4f1ea', pants:'#24365a', belt:'#2a2a2a', pattern:'stripe', acc:'#c0392b' },
  { id:'tropical', name:'꽃무늬 셔츠',   price:40, note:'남쪽 섬 바람 같은 주황 꽃무늬', shirt:'#e8873a', pants:'#d9c9a0', belt:'#7a5a34', pattern:'flower' },
  { id:'vest',     name:'해적 조끼',     price:50, note:'흰 셔츠 위에 빨간 조끼 · 금 버클', shirt:'#f2ece0', pants:'#5a3c26', belt:'#1d1612', pattern:'vest', acc:'#a82a22' },
  { id:'coat',     name:'선장 코트',     price:90, note:'금단추 두 줄 남색 코트 · 흰 바지', shirt:'#1f2d4a', pants:'#ece6d8', belt:'#c9a15e', pattern:'coat', acc:'#c9a15e', long:true },
  /* 장르 감성 오리지널 세트 (특정 작품·캐릭터 의상이 아니에요) */
  { id:'scout',    name:'정찰대 야전복',   price:60, note:'짙은 올리브 야전 코트 · 나침반 휘장 · 성벽 너머로!', shirt:'#4a5a3a', pants:'#d9d2bf', belt:'#5a3c26', pattern:'scout', acc:'#c9a15e', long:true, set:true },
  { id:'haori',    name:'떠돌이 검객 하오리', price:60, note:'쪽빛 물결 무늬 하오리 · 짙은 하카마', shirt:'#2e4f7a', pants:'#33333d', belt:'#1d1d24', pattern:'haori', acc:'#f2efe6', long:true, set:true },
  { id:'jersey',   name:'섬 배구부 유니폼', price:45, note:'청록 어깨선 · 등번호 7 · 날아오르자!', shirt:'#eef6f7', pants:'#2a9fa8', belt:'#2a9fa8', pattern:'jersey', acc:'#2a9fa8', set:true },
  { id:'explorer', name:'바다 탐험가 재킷', price:55, note:'금테 두른 청록 재킷 · 갈색 바지 (탐험가 챙모자와 한 벌)', shirt:'#2f6f73', pants:'#6b5338', belt:'#3a2616', pattern:'explorer', acc:'#e0b85a', set:true },
  { id:'school',   name:'섬 학교 교복',     price:40, note:'남색 블레이저 · 빨간 리본 · 회색 바지', shirt:'#253048', pants:'#55565e', belt:'#2a2a2a', pattern:'school', acc:'#c0392b', set:true }
];
const outfitOf = id => OUTFITS.find(o => o.id === id) || OUTFITS[0];
function outfitColors(o, color){
  return o.torn ? { shirt:mixHex('#e0d2ae', color, 0.18), pants:mixHex(color, '#5a5a5a', 0.2), belt:'#8a6a42' } : { shirt:o.shirt, pants:o.pants, belt:o.belt };
}
function bodyClothTex(o, color, seed){
  const c = outfitColors(o, color), belt = bodyV(0.42), chest = bodyV(0.58), hip = bodyV(0.31), hem = o.long ? bodyV(0.33) : belt;
  return canvasTex(512, 256, (g, w, h) => {
    g.fillStyle = SKIN; g.fillRect(0, 0, w, h);
    g.fillStyle = c.pants; g.fillRect(0, belt - 4, w, h - belt + 4);                  // 바지 (허리 아래 전부)
    if (o.torn){ wornSpots(g, w, belt, h - 10, '#000', 12, seed); jagBand(g, w, 0, belt + 3, c.shirt, seed, 10); wornSpots(g, w, 14, belt - 6, '#5a4030', 16, seed + 5); }
    else { g.fillStyle = c.shirt; g.fillRect(0, 0, w, hem + 2); }
    /* 무늬 (앞면 = 가로 가운데 256) */
    if (o.pattern === 'stripe'){ g.fillStyle = '#2f5a9a'; for (let y = 18; y < belt - 6; y += 18) g.fillRect(0, y, w, 7);
      g.fillStyle = o.acc; g.beginPath(); g.moveTo(232, 0); g.lineTo(280, 0); g.lineTo(256, 34); g.closePath(); g.fill(); }   // 빨간 스카프 매듭
    if (o.pattern === 'flower'){ for (let i = 0; i < 46; i++){ const x = (i * 83 + 17) % w, y = 10 + (i * 37) % Math.max(20, belt - 22);
        g.fillStyle = i % 3 ? '#fff3d6' : '#c0392b'; for (let k = 0; k < 5; k++){ const a = k / 5 * Math.PI * 2; g.beginPath(); g.arc(x + Math.cos(a) * 5, y + Math.sin(a) * 5, 3.6, 0, 7); g.fill(); }
        g.fillStyle = '#f2c230'; g.beginPath(); g.arc(x, y, 2.6, 0, 7); g.fill(); } }
    if (o.pattern === 'vest'){ g.fillStyle = o.acc; g.fillRect(0, 10, 214, belt - 10); g.fillRect(298, 10, w - 298, belt - 10);   // 앞이 트인 조끼
      g.strokeStyle = '#c9a15e'; g.lineWidth = 3; [214, 298].forEach(x => { g.beginPath(); g.moveTo(x, 10); g.lineTo(x, belt); g.stroke(); }); }
    if (o.pattern === 'scout'){ g.fillStyle = 'rgba(0,0,0,.18)'; [[214, 60], [266, 60]].forEach(([x, y]) => g.fillRect(x, y, 34, 26));   // 가슴 주머니
      g.strokeStyle = 'rgba(0,0,0,.35)'; g.lineWidth = 2; g.beginPath(); g.moveTo(256, 0); g.lineTo(256, hem); g.stroke();
      g.fillStyle = o.acc; g.beginPath(); g.arc(231, 40, 9, 0, 7); g.fill(); g.fillStyle = '#4a5a3a'; g.beginPath(); g.moveTo(231, 33); g.lineTo(234, 40); g.lineTo(231, 47); g.lineTo(228, 40); g.closePath(); g.fill();   // 나침반 휘장
      g.fillStyle = o.belt; g.fillRect(0, belt - 6, w, 7); g.fillStyle = '#c9a15e'; g.fillRect(250, belt - 7, 12, 9); }
    if (o.pattern === 'haori'){ g.strokeStyle = 'rgba(242,239,230,.75)'; g.lineWidth = 2;                                   // 물결(청해파) 무늬
      for (let y = 18; y < hem; y += 18) for (let x = (y / 18 % 2) * 14; x < w + 28; x += 28){ for (const r of [12, 8, 4]){ g.beginPath(); g.arc(x, y, r, Math.PI, 0); g.stroke(); } }
      g.fillStyle = '#1d1d24'; g.fillRect(236, 0, 40, hem);                                                                // 앞섶 (안쪽 기모노)
      g.fillStyle = o.acc; g.fillRect(232, 0, 4, hem); g.fillRect(276, 0, 4, hem); }
    if (o.pattern === 'jersey'){ g.fillStyle = o.acc; g.fillRect(0, 0, w, 16); [[150, 30], [330, 30]].forEach(([x, wd]) => g.fillRect(x, 16, wd, belt - 16));   // 어깨 · 옆선
      g.font = `800 56px ${FB}`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillStyle = o.acc; g.fillText('7', 470, 80); g.fillText('7', 40, 80);   // 등번호 (등 = 가장자리)
      g.font = `800 20px ${FB}`; g.fillText('LP', 256, 62); }
    if (o.pattern === 'explorer'){ g.fillStyle = '#f2ece0'; g.fillRect(238, 0, 36, belt); g.fillStyle = o.acc; g.fillRect(232, 0, 6, belt); g.fillRect(274, 0, 6, belt); g.fillRect(0, belt - 12, w, 4);
      g.fillStyle = 'rgba(0,0,0,.16)'; g.fillRect(200, 92, 28, 22); g.fillRect(284, 92, 28, 22); }
    if (o.pattern === 'school'){ g.fillStyle = '#f4f2ee'; g.beginPath(); g.moveTo(230, 0); g.lineTo(282, 0); g.lineTo(256, 70); g.closePath(); g.fill();   // 흰 셔츠 V
      g.fillStyle = o.acc; g.beginPath(); g.moveTo(256, 14); g.lineTo(240, 6); g.lineTo(240, 24); g.closePath(); g.fill(); g.beginPath(); g.moveTo(256, 14); g.lineTo(272, 6); g.lineTo(272, 24); g.closePath(); g.fill();   // 리본
      g.fillStyle = '#c9a15e'; [88, 112].forEach(y => { g.beginPath(); g.arc(256, y, 4, 0, 7); g.fill(); }); g.fillStyle = 'rgba(0,0,0,.18)'; g.fillRect(196, 118, 30, 4); g.fillRect(286, 118, 30, 4); }
    if (o.pattern === 'coat'){ g.fillStyle = '#c9a15e'; [238, 274].forEach(x => { for (let y = 26; y < hem - 6; y += 22){ g.beginPath(); g.arc(x, y, 4.6, 0, 7); g.fill(); } });
      g.fillRect(0, hem - 4, w, 5); g.fillStyle = 'rgba(255,255,255,.12)'; g.fillRect(250, 0, 12, hem); }       // 금단추 두 줄 · 금테
    /* 허리띠 */
    if (!o.long){ g.fillStyle = c.belt; g.fillRect(0, belt - 4, w, 6);
      if (o.torn){ g.fillStyle = 'rgba(60,40,20,.45)'; for (let x = 0; x < w; x += 8) g.fillRect(x, belt - 4, 3, 6); }
      else { g.fillStyle = '#e0b85a'; g.fillRect(248, belt - 6, 16, 10); } }                                   // 금 버클
    if (o.torn){
      patch(g, 290, chest, 30, 22, mixHex('#a8543a', color, 0.2), 0.2); patch(g, 470, chest - 18, 26, 20, '#c9a15e', -0.25); patch(g, 220, hip, 22, 16, '#c9a15e', -0.15);
      g.strokeStyle = 'rgba(60,40,20,.5)'; g.lineWidth = 1.4;
      [[60, belt + 8], [200, belt + 10], [330, belt + 6], [450, belt + 9]].forEach(([x, y]) => { g.beginPath(); g.moveTo(x, y); g.lineTo(x + 3, y + 9); g.stroke(); });
    }
  });
}
function armClothTex(o, color, seed){
  const c = outfitColors(o, color);
  return canvasTex(128, 128, (g, w, h) => { g.fillStyle = SKIN; g.fillRect(0, 0, w, h);
    if (o.torn){ jagBand(g, w, 0, 88, c.shirt, seed, 6); wornSpots(g, w, 4, 80, '#5a4030', 5, seed); return; }
    const len = o.long ? 104 : 86; g.fillStyle = c.shirt; g.fillRect(0, 0, w, len);
    if (o.pattern === 'stripe'){ g.fillStyle = '#2f5a9a'; for (let y = 10; y < len; y += 16) g.fillRect(0, y, w, 6); }
    if (o.pattern === 'flower'){ g.fillStyle = '#fff3d6'; for (let i = 0; i < 6; i++){ g.beginPath(); g.arc((i * 41) % w, 12 + (i * 23) % (len - 20), 4, 0, 7); g.fill(); } }
    if (o.pattern === 'vest'){ g.fillStyle = 'rgba(0,0,0,.06)'; g.fillRect(0, len - 8, w, 8); }
    if (o.pattern === 'coat'){ g.fillStyle = '#c9a15e'; g.fillRect(0, len - 9, w, 6); }
    if (o.pattern === 'haori'){ g.strokeStyle = 'rgba(242,239,230,.7)'; g.lineWidth = 2; for (let y = 14; y < len; y += 18) for (let x = 0; x < w + 20; x += 24){ g.beginPath(); g.arc(x, y, 9, Math.PI, 0); g.stroke(); } }
    if (o.pattern === 'jersey'){ g.fillStyle = o.acc; g.fillRect(0, 0, w, 22); g.fillRect(0, len - 10, w, 6); }
    if (o.pattern === 'explorer' || o.pattern === 'scout'){ g.fillStyle = 'rgba(0,0,0,.14)'; g.fillRect(0, len - 10, w, 6); }
    if (o.pattern === 'school'){ g.fillStyle = '#f4f2ee'; g.fillRect(0, len - 8, w, 8); }
  });
}
function legClothTex(o, color, seed){
  const c = outfitColors(o, color);
  return canvasTex(128, 128, (g, w, h) => { g.fillStyle = SKIN; g.fillRect(0, 0, w, h);
    if (o.torn){ jagBand(g, w, 0, 58, c.pants, seed + 2, 7); return; }
    g.fillStyle = c.pants; g.fillRect(0, 0, w, o.long ? 78 : 56); g.fillStyle = 'rgba(0,0,0,.12)'; g.fillRect(0, (o.long ? 78 : 56) - 5, w, 5); });
}
/* 옷 갈아입히기: 그림만 바꿔요 */
function dressAvatar(av, id){
  const ud = av && av.userData; if (!ud || !ud.mats) return;
  const o = outfitOf(id), set = (m, t) => { if (!m) return; if (m.map && m.map.dispose) m.map.dispose(); m.map = t; m.needsUpdate = true; };
  set(ud.mats.body, bodyClothTex(o, ud.color, ud.seed)); set(ud.mats.arm, armClothTex(o, ud.color, ud.seed)); set(ud.mats.leg, legClothTex(o, ud.color, ud.seed));
  ud.outfit = o.id;
}
function makeAvatar(color){
  const g = new THREE.Group();
  const skin = new THREE.MeshStandardMaterial({ color:SKIN, roughness:.88 });
  const seed = parseInt(color.slice(1, 3), 16) % 13;
  const bodyMat = new THREE.MeshStandardMaterial({ map:bodyClothTex(outfitOf('rags'), color, seed), roughness:.9 });
  /* 몸: 한 덩어리로 매끈하게 (둥근 배 · 잘록한 목) */
  const prof = BODY_PROFILE.map(([r, y]) => new THREE.Vector2(r, y));
  /* 옆에서 보면 등은 살짝 납작, 배는 배꼽 높이에서만 동그랗게 볼록 (뒤쪽 절반 조금 얇게 · 빛 받는 방향도 같이 맞춰요) */
  const bodyGeo = new THREE.LatheGeometry(prof, 40, Math.PI), bp = bodyGeo.attributes && bodyGeo.attributes.position, bn = bodyGeo.attributes && bodyGeo.attributes.normal;
  if (bp && bn && bp.count > 0){ for (let i = 0; i < bp.count; i++){ const z = bp.getZ(i), y = bp.getY(i), belly = Math.exp(-Math.pow((y - 0.42) / 0.12, 2)), sz = z < 0 ? 0.9 : 1 + 0.06 * belly; bp.setZ(i, z * sz);
      const nx = bn.getX(i), ny = bn.getY(i), nz = bn.getZ(i) / sz, l = Math.hypot(nx, ny, nz) || 1; bn.setXYZ(i, nx / l, ny / l, nz / l); }
    bp.needsUpdate = true; bn.needsUpdate = true; }
  const bodyM = mesh(bodyGeo, bodyMat, 0, -0.2 * (BODY_TALL - 1), 0, g);
  bodyM.scale.set(1.0, BODY_TALL, 0.9);   /* 키를 살짝 늘려요 (바닥 높이는 그대로) */
  /* 짧고 통통한 다리: 엉덩이에서 앞뒤로 흔들려요 */
  const legMat = new THREE.MeshStandardMaterial({ map:legClothTex(outfitOf('rags'), color, seed), roughness:.9 });
  /* 다리: 엉덩이 속에서 굵게 시작해 아래로 살짝 좁아지는 두 갈래 (조금 벌어져 서요) */
  const legProf = [[0,-0.34],[0.07,-0.335],[0.1,-0.315],[0.112,-0.28],[0.118,-0.22],[0.128,-0.14],[0.142,-0.06],[0.15,0],[0.13,0.06],[0,0.08]].map(([r, y]) => new THREE.Vector2(r, y));
  const legs = [-1, 1].map(s => { const L = new THREE.Group(); L.position.set(s * 0.13, 0.34, 0.01); g.add(L);
    const m = mesh(new THREE.LatheGeometry(legProf, 20, Math.PI), legMat, 0, 0, 0, L); m.rotation.z = s * 0.12; m.scale.set(1, 1, 0.92); return L; });
  /* 머리: 몸과 비슷한 너비로 크고 동그랗게 (안쪽 0.2 크기를 1.5배로 — 모자도 같이 커져요) */
  const head = new THREE.Group(); head.position.set(0, 1.09, 0); head.scale.setScalar(1.35); g.add(head);
  const face = mesh(new THREE.SphereGeometry(0.2, 32, 24), new THREE.MeshStandardMaterial({ color:SKIN, roughness:.88 }), 0, 0, 0, head); face.scale.set(1.05, 0.96, 1);
  head.userData.face = face;
  /* 눈: 쏙 들어간 듯한 짙은 타원 두 개 */
  const eyeM = new THREE.MeshBasicMaterial({ color:'#2e2b34' });
  [-0.07, 0.07].forEach(x => { const e = mesh(new THREE.SphereGeometry(0.023, 14, 10), eyeM, x, -0.01, 0.184, head); e.scale.set(1, 1.08, 0.32); e.rotation.y = x * 2.4; });
  const hat = mesh(new THREE.CylinderGeometry(0.26, 0.3, 0.1, 20), new THREE.MeshStandardMaterial({ color:'#1d1612', roughness:.7 }), 0, 0.16, 0, head);
  const hatTop = mesh(new THREE.CylinderGeometry(0.16, 0.2, 0.14, 20), new THREE.MeshStandardMaterial({ color:'#1d1612', roughness:.7 }), 0, 0.27, 0, head);
  const hatBand = mesh(new THREE.TorusGeometry(0.19, 0.012, 6, 24), M.brass, 0, 0.2, 0, head); hatBand.rotation.x = Math.PI / 2;
  head.userData.hatParts = [hat, hatTop, hatBand];   /* 선장 모자 (market.js 에서 사서 써요 · NPC 는 기본으로 써요) */
  /* 말랑한 팔: 목 바로 아래 어깨에서 몸에 녹아들듯 이어져 비스듬히 흘러내려요 (뿌리는 굵고 끝은 둥글게) + 해진 반소매 · 왼손목 로그포스 */
  const armMat = new THREE.MeshStandardMaterial({ map:armClothTex(outfitOf('rags'), color, seed), roughness:.9 });
  /* 뿌리를 몸 속 깊이(목 옆)에 두고 어깨 경사를 따라 얕게 빠져나오게 → 이음매 없이 몸에서 흘러나온 것처럼 */
  const armProf = [[0,-0.37],[0.05,-0.365],[0.072,-0.34],[0.08,-0.3],[0.086,-0.25],[0.095,-0.19],[0.108,-0.12],[0.118,-0.06],[0.115,-0.01],[0.09,0.03],[0,0.045]].map(([r, y]) => new THREE.Vector2(r, y));
  const limb = (x, z0) => { const a = new THREE.Group(); a.position.set(x, 0.81, 0);   /* 뿌리를 목 밑동에 → 목에서 어깨를 타고 팔로 이어져요 */ a.rotation.z = z0; g.add(a);
    mesh(new THREE.LatheGeometry(armProf, 20, Math.PI), armMat, 0, 0, 0, a).scale.set(0.95, 0.98, 0.9); return a; };
  const arm = limb(-0.07, -1.12), rArm = limb(0.07, 1.12);
  /* 손목 로그포스: 손목을 감싼 가죽·놋쇠 띠 + 바깥쪽에 얹힌 유리 돔 (손목시계처럼 차고 있어요) */
  const lp = new THREE.Group(); lp.position.set(0, -0.255, 0); arm.add(lp);
  const strap = mesh(new THREE.TorusGeometry(0.083, 0.02, 8, 24), new THREE.MeshStandardMaterial({ color:'#6a4628', roughness:.8 }), 0, 0, 0, lp); strap.rotation.x = Math.PI / 2; strap.scale.set(1, 0.95, 1.3);
  [-0.022, 0.022].forEach(y => { const r = mesh(new THREE.TorusGeometry(0.085, 0.006, 6, 24), M.brass, 0, y, 0, lp); r.rotation.x = Math.PI / 2; });
  const lpFace = new THREE.Group(); lpFace.position.set(0, 0, 0.086); lp.add(lpFace);
  mesh(new THREE.CylinderGeometry(0.05, 0.054, 0.024, 20).rotateX(Math.PI / 2), M.brass, 0, 0, 0, lpFace);                // 놋쇠 받침
  const dome = mesh(new THREE.SphereGeometry(0.043, 16, 10, 0, Math.PI * 2, 0, Math.PI / 2), new THREE.MeshStandardMaterial({ color:'#bfeaf2', emissive:'#7fd3e0', emissiveIntensity:.6, transparent:true, opacity:.8, roughness:.1 }), 0, 0, 0.012, lpFace); dome.rotation.x = Math.PI / 2;
  const glow = new THREE.Sprite(new THREE.SpriteMaterial({ map:glowTex, color:'#7fd3e0', transparent:true, opacity:.55, blending:THREE.AdditiveBlending, depthWrite:false })); glow.scale.set(0.26, 0.26, 1); glow.position.z = 0.05; lpFace.add(glow);
  const sh = mesh(new THREE.PlaneGeometry(1.0, 1.0), M.shadow, 0, 0.012, 0, g); sh.rotation.x = -Math.PI / 2;
  g.userData = { head, arm, rArm, legs, mats:{ body:bodyMat, arm:armMat, leg:legMat }, color, seed, outfit:'rags', armZ:-1.12, logpose:{ group:lp, dome, glow } };
  scene.add(g); return g;
}

/* ---------- 이동 · 카메라 ---------- */
const PLAYER_R = 0.32;
const player = { x:0, z:3.6, r:Math.PI, moving:false, mesh:null, bob:0 };
const cam = { yaw:0, pitch:0.32, dist:isTouch ? 4.0 : 3.6, distT:isTouch ? 4.0 : 3.6 };
const keys = new Set(); const joy = { x:0, y:0, id:null };
let uiOpen = false, auto = null, deskView = null, cutscene = false;   /* cutscene: 항해 장면 (입력은 막고 자동 걷기만) */   /* deskView: 책상 정보창용 카메라 (desk.js) */
/* 일어나기: 앉기 전에 서 있던 자리로 한 발 물러나요 (의자 상자 안에서 출발하지 않게) */
function standUp(){
  player.pose = null; player.lie = false;
  if (player.standAt){ player.x = player.standAt.x; player.z = player.standAt.z; player.standAt = null; }
}
function collide(p){
  if (p === player && player.pose === 'sit') return;   /* 앉아 있을 땐 의자 위 그대로 */
  AREA.clamp(p, PLAYER_R + 0.05);
  if (AREA.push) AREA.push(p, PLAYER_R + 0.04);   /* 기울어진 건물 벽 같은 정확한 모양 */
  for (let it = 0; it < 2; it++) for (const c of AREA.colliders){
    const qx = Math.max(c.minX, Math.min(p.x, c.maxX)), qz = Math.max(c.minZ, Math.min(p.z, c.maxZ));
    const dx = p.x - qx, dz = p.z - qz, d2 = dx * dx + dz * dz;
    if (d2 < PLAYER_R * PLAYER_R){
      if (d2 < 1e-8){ const o = [[p.x - c.minX, -1, 0], [c.maxX - p.x, 1, 0], [p.z - c.minZ, 0, -1], [c.maxZ - p.z, 0, 1]].sort((a, b) => a[0] - b[0])[0]; p.x += o[1] * (o[0] + PLAYER_R); p.z += o[2] * (o[0] + PLAYER_R); }
      else { const d = Math.sqrt(d2), push = PLAYER_R - d; p.x += dx / d * push; p.z += dz / d * push; }
    }
  }
}
const inBox = (x, z) => AREA.colliders.some(c => x > c.minX && x < c.maxX && z > c.minZ && z < c.maxZ);
/* 클릭 이동 경로: 곧장 가다 가구에 막히면 그 가구 옆으로 돌아가요 */
function blockedBy(ax, az, bx, bz){
  const n = Math.max(1, Math.ceil(Math.hypot(bx - ax, bz - az) / 0.1)), m = PLAYER_R + 0.02;
  for (let i = 1; i <= n; i++){ const x = ax + (bx - ax) * i / n, z = az + (bz - az) * i / n;
    for (const c of AREA.colliders) if (x > c.minX - m && x < c.maxX + m && z > c.minZ - m && z < c.maxZ + m) return c; }
  return null;
}
function planPath(tx, tz){ return AREA.route ? AREA.route(tx, tz) : planFrom(player.x, player.z, tx, tz); }
function planFrom(ax, az, tx, tz){
  let c = blockedBy(ax, az, tx, tz);
  if (!c) return [{ x:tx, z:tz }];
  /* 막는 가구들을 하나로 묶어(책상+의자처럼) 그 바깥으로 */
  const box = { minX:c.minX, maxX:c.maxX, minZ:c.minZ, maxZ:c.maxZ };
  for (let k = 0; k < 3; k++) for (const o of AREA.colliders) if (o.maxX > box.minX - 0.8 && o.minX < box.maxX + 0.8 && o.maxZ > box.minZ - 0.8 && o.minZ < box.maxZ + 0.8){ box.minX = Math.min(box.minX, o.minX); box.maxX = Math.max(box.maxX, o.maxX); box.minZ = Math.min(box.minZ, o.minZ); box.maxZ = Math.max(box.maxZ, o.maxZ); }
  const m = PLAYER_R + 0.3;
  const sides = [box.minX - m, box.maxX + m].filter(x => AREA.sideOk(x, az) && AREA.sideOk(x, tz));
  if (!sides.length) return [{ x:tx, z:tz }];
  const side = sides.sort((a, b) => (Math.abs(ax - a) + Math.abs(a - tx)) - (Math.abs(ax - b) + Math.abs(b - tx)))[0];
  return [{ x:side, z:az }, { x:side, z:tz }, { x:tx, z:tz }];
}
const goTo = (x, z, extra = {}) => { if (player.pose === 'sit') standUp(); auto = Object.assign({ pts:planPath(x, z), t:0 }, extra); };

window.addEventListener('keydown', e => {
  if (uiOpen) return;
  const k = e.key.toLowerCase();
  if (['w','a','s','d','arrowup','arrowdown','arrowleft','arrowright','shift','q','e'].includes(k)){ keys.add(k); if (k !== 'shift') e.preventDefault(); auto = null; }
  if ((k === 'f' || (k === 'enter' && document.activeElement === document.body)) && !$('#actBtn').hidden){ e.preventDefault(); $('#actBtn').click(); }
});
window.addEventListener('keyup', e => keys.delete(e.key.toLowerCase()));
window.addEventListener('blur', () => keys.clear());

const cvs = renderer.domElement, drag = { id:null, x:0, y:0, t:0, moved:0 };
cvs.addEventListener('pointerdown', e => { if (drag.id !== null) return; drag.id = e.pointerId; drag.x = e.clientX; drag.y = e.clientY; drag.t = performance.now(); drag.moved = 0; try { cvs.setPointerCapture(e.pointerId); } catch(_){} });
cvs.addEventListener('pointermove', e => {
  if (e.pointerId !== drag.id) return;
  const dx = e.clientX - drag.x, dy = e.clientY - drag.y; drag.x = e.clientX; drag.y = e.clientY; drag.moved += Math.abs(dx) + Math.abs(dy);
  if (drag.moved > 6){ cam.yaw -= dx * 0.0062; cam.pitch = Math.min(0.95, Math.max(0.05, cam.pitch + dy * 0.0045)); }
});
const endDrag = e => { if (e.pointerId !== drag.id) return; if (drag.moved < 8 && performance.now() - drag.t < 450 && e.type === 'pointerup') handleTap(e.clientX, e.clientY); drag.id = null; };
cvs.addEventListener('pointerup', endDrag); cvs.addEventListener('pointercancel', endDrag);
cvs.addEventListener('wheel', e => { cam.distT = Math.min(5.5, Math.max(2.2, cam.distT + e.deltaY * 0.004)); }, { passive:true });
const joyEl = $('#joy'), knob = $('#knob');
joyEl.addEventListener('pointerdown', e => { joy.id = e.pointerId; try { joyEl.setPointerCapture(e.pointerId); } catch(_){} updJoy(e); auto = null; });
joyEl.addEventListener('pointermove', e => { if (e.pointerId === joy.id) updJoy(e); });
const joyEnd = e => { if (e.pointerId !== joy.id) return; joy.id = null; joy.x = joy.y = 0; knob.style.transform = ''; };
joyEl.addEventListener('pointerup', joyEnd); joyEl.addEventListener('pointercancel', joyEnd);
function updJoy(e){
  const r = joyEl.getBoundingClientRect(), cx = r.left + r.width / 2, cy = r.top + r.height / 2;
  let dx = e.clientX - cx, dy = e.clientY - cy; const max = r.width / 2 - 14, len = Math.hypot(dx, dy);
  if (len > max){ dx = dx / len * max; dy = dy / len * max; }
  joy.x = dx / max; joy.y = dy / max; knob.style.transform = `translate(${dx}px, ${dy}px)`;
}

/* 클릭: 가구면 그 앞으로 걸어가 살펴보기, 바닥이면 그 자리로 */
const raycaster = new THREE.Raycaster(), ndc = new THREE.Vector2();
const SPOTS = {
  desk:{ x:DESK.x, z:DESK.z + 1.25, face:Math.PI, label:'선장 책상 살펴보기', use:() => useDesk() },
  wheel:{ x:WHEEL.x, z:WHEEL.z + 1.2, face:Math.PI, label:'타륜 잡기', use:() => useWheel() },
  door:{ x:0, z:ROOM.maxZ - 0.9, face:0, label:'갑판으로 나가기', use:() => goArea('deck') }
};
function handleTap(x, y){
  if (uiOpen) return;
  ndc.set(x / window.innerWidth * 2 - 1, -(y / window.innerHeight) * 2 + 1);
  raycaster.setFromCamera(ndc, camera);
  const hits = raycaster.intersectObjects(AREA.clickables.concat(AREA.floors), true);
  for (const h of hits){
    let o = h.object; while (o && !o.userData.kind && o.name !== 'floor') o = o.parent;
    if (!o) continue;
    if (o.userData.kind){ const s = AREA.spots[o.userData.kind]; if (!s) continue; goTo(s.x, s.z, { then:s.use, face:s.face }); return; }
    if (o.name === 'floor'){ const p = h.point; if (!inBox(p.x, p.z)) goTo(p.x, p.z); return; }
  }
}

/* ---------- 살펴보기 (단계 1: 자리만. 책상 정보창은 단계 5, 로그포스 메뉴는 단계 6) ---------- */
function useDesk(){ useDeskSpot(); }   /* desk.js */
function useWheel(){ openHelm(); }   /* sail.js: 어디로 항해할지 고르기 */
$('#logposeBtn').addEventListener('click', () => onLogposeButton());   /* taste.js */
$('#actBtn').addEventListener('click', () => { const s = nearSpot(); if (s) s.use(); });
let lpPulse = 0; function pulseLogpose(){ lpPulse = 1.2; }
/* 손목 들어 로그포스 보기: 팔을 들어 얼굴 앞으로 → 잠깐 들여다본 뒤 창이 열려요 */
const wrist = { t:0, k:0, busy:false, keep:false };   /* keep: 로그포스 창이 떠 있는 동안 손을 계속 들고 있어요 */
function lookWrist(then, hold = 0.3){
  const go = () => { if (then) then(); };
  if (wrist.busy) return;
  if (uiOpen || player.pose === 'steer' || reduceMotion || !player.mesh){ go(); return; }
  if (player.pose === 'sit') standUp();
  uiOpen = true; keys.clear(); auto = null; wrist.busy = true; wrist.keep = true;
  wrist.t = hold + 0.7; lpPulse = 1.4; $('#actBtn').hidden = true;
  setTimeout(() => { wrist.busy = false; uiOpen = false; go(); }, hold * 1000 + 200);
}
function nearSpot(){
  /* 가장 가까운 자리 (의자처럼 촘촘한 곳은 near 로 좁게) */
  let best = null, bd = Infinity;
  for (const k in AREA.spots){ const s = AREA.spots[k], d = Math.hypot(player.x - s.x, player.z - s.z); if (d < (s.near || 1.1) && d < bd){ bd = d; best = s; } }
  return best;
}

/* ---------- 낮 / 밤 ---------- */
let timeMode = (() => { try { const v = localStorage.getItem('logpose.window'); if (v === 'day' || v === 'night') return v; } catch(e){} const h = new Date().getHours(); return h >= 6 && h < 19 ? 'day' : 'night'; })();
function applyTime(){
  const day = timeMode === 'day';
  skyMat.map = SKY[timeMode] || (SKY[timeMode] = skyTex(timeMode)); skyMat.needsUpdate = true;
  scene.fog.color.set(day ? '#cfe3ee' : '#1b3152'); scene.background = new THREE.Color(day ? '#a9d1ec' : '#0d1a30');
  sea.material.color.set(day ? '#3f7fa6' : '#16314c');
  windowLight.color.set(day ? '#dcecff' : '#8fa8d6'); windowLight.intensity = day ? .9 : .3;
  hemi.intensity = day ? .7 : .42;
  portholes.forEach(p => p.material.color.set(day ? '#8fc0dc' : '#1d3a5c'));
  const b = $('#timePill b'); if (b) b.textContent = day ? '낮' : '밤';
  $('#timePill').setAttribute('aria-pressed', String(!day));
  timeHooks.forEach(f => f(timeMode));
}
const timeHooks = [];
$('#timePill').addEventListener('click', () => { timeMode = timeMode === 'day' ? 'night' : 'day'; try { localStorage.setItem('logpose.window', timeMode); } catch(e){} applyTime(); });

/* ---------- 매 프레임 ---------- */
const clock = new THREE.Clock();
const sailFx = { k:0, want:0, flow:0 };
const camPos = new THREE.Vector3(), camTarget = new THREE.Vector3(), _camWant = new THREE.Vector3();
const lerpAngle = (a, b, t) => { let d = ((b - a + Math.PI) % (Math.PI * 2)) - Math.PI; if (d < -Math.PI) d += Math.PI * 2; return a + d * t; };
let lastSpot = null;
/* 선장실 한 프레임 (그리기는 main 루프가 해요) */
function cabinStep(dt, time){
  /* 입력 → 이동 (카메라 기준) */
  let ix = 0, iz = 0;
  if (!uiOpen){
    if (keys.has('w') || keys.has('arrowup')) iz -= 1; if (keys.has('s') || keys.has('arrowdown')) iz += 1;
    if (keys.has('a') || keys.has('arrowleft')) ix -= 1; if (keys.has('d') || keys.has('arrowright')) ix += 1;
    if (keys.has('q')) cam.yaw += dt * 1.6; if (keys.has('e')) cam.yaw -= dt * 1.6;
    ix += joy.x; iz += joy.y;
  }
  let mx = 0, mz = 0;
  const len = Math.hypot(ix, iz);
  if (len > 0.08){
    const s = Math.sin(cam.yaw), c = Math.cos(cam.yaw);
    mx = (ix * c + iz * s) / Math.max(1, len); mz = (-ix * s + iz * c) / Math.max(1, len);
  } else if (auto && (!uiOpen || cutscene)){
    const pt = auto.pts[0], dx = pt.x - player.x, dz = pt.z - player.z, d = Math.hypot(dx, dz);
    /* 막힘 감지: 1초 동안 거의 못 움직였으면 멈춰요 (먼 길도 끝까지 걸어가요) */
    auto.t += dt; if (!auto.chk || auto.t - auto.chk.t > 1){ const moved = auto.chk ? Math.hypot(player.x - auto.chk.x, player.z - auto.chk.z) : 1; auto.chk = { t:auto.t, x:player.x, z:player.z }; if (moved < 0.15) auto.stuck = true; }
    if (d < 0.12 && auto.pts.length > 1){ auto.pts.shift(); }
    else if (d < 0.12 || auto.stuck || auto.t > 60){ const a = auto; auto = null; if (d < 0.6){ if (a.face !== undefined) player.r = a.face; if (a.then) a.then(); } }
    else { mx = dx / d; mz = dz / d; }
  }
  const speed = (keys.has('shift') ? 4.2 : 2.6) * (AREA.walk || 1) * dt;   /* 넓은 절영도는 조금 빠르게 */
  player.moving = Math.hypot(mx, mz) > 0.01;
  if (player.moving && (player.pose === 'sit' || (player.pose || '').startsWith('gym'))) standUp();   /* 움직이면 일어나요 · 운동도 멈춰요 */
  if (player.moving){
    player.x += mx * speed; player.z += mz * speed;
    player.r = lerpAngle(player.r, Math.atan2(mx, mz), Math.min(1, dt * 12));
  }
  collide(player);
  const pm = player.mesh;
  player.bob += player.moving ? dt * 10 : 0;
  const gy = AREA.heightAt(player.x, player.z);
  /* 점프: 위로 튀었다가 중력으로 내려와요 */
  if (player.vy || player.jy){ player.jy = (player.jy || 0) + (player.vy || 0) * dt; player.vy = (player.vy || 0) - 13 * dt; if (player.jy <= 0){ player.jy = 0; player.vy = 0; } }
  const gp = player.pose, gw = (Math.sin(time * 3) * 0.5 + 0.5);
  const gymY = gp === 'gymClimb' ? 0.2 + (1 - Math.cos(Math.min(1, (player.gymT = (player.gymT || 0) + dt) / 5.8) * Math.PI * 2)) * 2.2 : gp === 'gymPull' ? 0.55 + Math.max(0, Math.sin(time * 2.6)) * 0.42 : gp === 'gymSquat' ? -gw * 0.18 : gp === 'gymLift' ? -Math.abs(Math.sin(time * 2.2)) * 0.03 : 0;
  pm.position.set(player.x, gy + (player.jy || 0) + gymY + (player.pose === 'sit' ? (player.sitY || 0.4) : player.moving ? Math.abs(Math.sin(player.bob)) * 0.05 : 0), player.z);
  pm.rotation.y = player.r;
  /* 눕기(파라솔 의자): 엉덩이(다리 뿌리 높이 0.34)를 축으로 몸을 뒤로 젖혀 등받이에 기대요 */
  { pm.rotation.order = 'YXZ'; const want = player.pose === 'sit' && player.lie ? 1 : 0, ud = pm.userData;
    ud.lieK = (ud.lieK || 0) + (want - (ud.lieK || 0)) * Math.min(1, dt * 7); const th = 0.72 * ud.lieK, hip = 0.34;
    pm.rotation.x = -th;
    if (th > 0.001){ const back = hip * Math.sin(th); pm.position.y += hip - hip * Math.cos(th); pm.position.x += Math.sin(player.r) * back; pm.position.z += Math.cos(player.r) * back; } }
  const swing = player.moving ? Math.sin(player.bob) * 0.5 : 0;
  if (player.pose === 'steer'){ pm.userData.arm.rotation.x = -1.35 + Math.sin(time * 3) * 0.08; pm.userData.rArm.rotation.x = -1.35 - Math.sin(time * 3) * 0.08; }
  else if (player.pose === 'drink'){ pm.userData.arm.rotation.x = 0; pm.userData.rArm.rotation.x = -2.25 + Math.sin(time * 6) * 0.05; }
  else if (player.pose === 'sit' && player.lie){ pm.userData.arm.rotation.x = -0.12; pm.userData.rArm.rotation.x = -0.12 + Math.sin(time * 0.9) * 0.03; }   /* 누우면 팔은 몸 옆에 편하게 */
  else if (player.pose === 'sit'){ pm.userData.arm.rotation.x = -0.55; pm.userData.rArm.rotation.x = -0.55 + Math.sin(time * 1.3) * 0.05; }
  else if (gp === 'gymLift'){ pm.userData.arm.rotation.x = -0.2 - (Math.sin(time * 2.4) * 0.5 + 0.5) * 1.35; pm.userData.rArm.rotation.x = -0.2 - (Math.sin(time * 2.4 + Math.PI) * 0.5 + 0.5) * 1.35; }
  else if (gp === 'gymRope'){ pm.userData.arm.rotation.x = -1.0 + Math.sin(time * 12) * 0.55; pm.userData.rArm.rotation.x = -1.0 - Math.sin(time * 12) * 0.55; }
  else if (gp === 'gymClimb'){ pm.userData.arm.rotation.x = -2.7 + Math.sin(time * 5) * 0.35; pm.userData.rArm.rotation.x = -2.7 - Math.sin(time * 5) * 0.35; }
  else if (gp === 'gymPull'){ pm.userData.arm.rotation.x = -2.9 + Math.max(0, Math.sin(time * 2.6)) * 0.5; pm.userData.rArm.rotation.x = pm.userData.arm.rotation.x; }
  else if (gp === 'gymSquat'){ pm.userData.arm.rotation.x = 0.45; pm.userData.rArm.rotation.x = 0.45; }
  else if (gp === 'gymPush'){ pm.userData.arm.rotation.x = -1.5; pm.userData.rArm.rotation.x = -1.5; }
  else if (gp === 'gymWheel'){ pm.userData.arm.rotation.x = -1.35 + Math.sin(time * 9) * 0.3; pm.userData.rArm.rotation.x = -1.35 - Math.sin(time * 9) * 0.3; }
  else { pm.userData.arm.rotation.x = swing; pm.userData.rArm.rotation.x = -swing; }
  if (wrist.keep){ const lpOpen = wrist.busy || menuOpen() || !$('#quiz').hidden || !$('#recs').hidden || !RC.fx.hidden; if (lpOpen){ wrist.t = Math.max(wrist.t, 0.15); wrist.gap = 0; } else if ((wrist.gap = (wrist.gap || 0) + dt) > 0.5) wrist.keep = false; else wrist.t = Math.max(wrist.t, 0.15); }
  /* 다리: 걸을 때 번갈아 앞뒤로 · 앉으면 앞으로 뻗고 · 공중에선 살짝 오므려요 */
  if (Array.isArray(pm.userData.legs)){ const [L, R] = pm.userData.legs, air = (player.jy || 0) > 0.02;
    const gl = gp === 'gymSquat' ? -gw * 1.1 : gp === 'gymClimb' || gp === 'gymPull' ? -0.5 + Math.sin(time * 5) * 0.25 : gp === 'gymPush' ? Math.sin(time * 6) * 0.5 : null;
    const sitLeg = player.lie ? -0.87 : -1.25;   /* 누우면 몸이 젖힌 만큼 다리를 펴서 의자 위에 쭉 뻗어요 */
    const lx = gl !== null ? gl : player.pose === 'sit' ? sitLeg : air ? -0.35 : swing * 1.1, rx = gl !== null ? (gp === 'gymPush' || gp === 'gymClimb' ? -gl : gl) : player.pose === 'sit' ? sitLeg : air ? 0.2 : -swing * 1.1;
    L.rotation.x += (lx - L.rotation.x) * Math.min(1, dt * 14); R.rotation.x += (rx - R.rotation.x) * Math.min(1, dt * 14); }
  wrist.t = Math.max(0, wrist.t - dt); wrist.k += ((wrist.t > 0 ? 1 : 0) - wrist.k) * Math.min(1, dt * 14);
  { const k = wrist.k, ud = pm.userData;
    ud.arm.rotation.x += (-1.5 - ud.arm.rotation.x) * k;   /* 손목을 가슴 앞 높이까지만 (예전 -1.85는 얼굴에 너무 붙었어요) */ const wob = reduceMotion ? 0 : Math.sin(time * 2.1) * 0.06 + (player.moving ? Math.sin(player.bob * 2) * 0.08 : 0);   /* 흐물흐물 */
    ud.arm.rotation.z = ud.armZ + 1.25 * k + wob * (1 - k);   /* 몸 안쪽으로 덜 꺾어서 얼굴에서 조금 떨어지게 (예전 1.6) */ ud.rArm.rotation.z = -ud.armZ - wob;
    ud.head.rotation.x = 0.4 * k + 0.38 * (ud.lieK || 0) * (1 - k);   /* 누워 있을 땐 고개를 살짝 들어 바다를 봐요 */ ud.head.rotation.y = -0.12 * k;   /* 손이 낮아진 만큼 고개를 조금 더 숙여 들여다봐요 */
    if (k > 0.5) lpPulse = Math.max(lpPulse, 0.6); }
  /* 손목 로그포스: 은은하게 숨쉬고, 버튼을 누르면 반짝 */
  lpPulse = Math.max(0, lpPulse - dt);
  const lp = pm.userData.logpose, breathe = reduceMotion ? .6 : .55 + Math.sin(time * 2.2) * .15;
  lp.glow.material.opacity = Math.min(1, breathe + lpPulse * .5); lp.glow.scale.setScalar(0.32 + lpPulse * 0.5);
  lp.dome.material.emissiveIntensity = .6 + lpPulse;

  const sway = reduceMotion ? 0 : 1;
  AREA.ambient(dt, time, sway);

  /* 가까운 살펴보기 자리 → 하단 버튼 */
  const sp = uiOpen ? null : nearSpot();
  if (sp !== lastSpot){ const b = $('#actBtn'); if (sp){ b.querySelector('span').textContent = sp.label; b.hidden = false; } else b.hidden = true; lastSpot = sp; }

  /* 카메라: 캐릭터 뒤 위, 방 안에 머물게 */
  cam.dist += (cam.distT - cam.dist) * Math.min(1, dt * 6);
  const camUp = gp === 'gymClimb' || gp === 'gymPull' ? gymY : 0;   /* 밧줄 · 턱걸이: 시야도 캐릭터와 같이 올라가요 */
  camTarget.set(player.x, gy + 1.25 + camUp, player.z);
  const cp = Math.cos(cam.pitch);
  _camWant.set(player.x + Math.sin(cam.yaw) * cam.dist * cp, gy + 1.25 + camUp + Math.sin(cam.pitch) * cam.dist, player.z + Math.cos(cam.yaw) * cam.dist * cp);
  AREA.camClamp(_camWant, gy);
  if (deskView){ camPos.lerp(deskView.pos, Math.min(1, dt * 6)); camTarget.copy(deskView.look); }
  else if (AREA.view){ camPos.lerp(AREA.view.pos, Math.min(1, dt * 4)); camTarget.copy(AREA.view.look); }
  else camPos.lerp(_camWant, Math.min(1, dt * 9));
  camera.position.copy(camPos); camera.lookAt(camTarget);
  camera.rotation.z += Math.sin(time * 0.45) * 0.004 * sway;
}

/* ---------- 공간(선장실 · 갑판) ----------
   이동 · 충돌 · 클릭 · 카메라는 지금 있는 공간(AREA)의 규칙을 따라요. 갑판은 deck.js */
const CABIN_AREA = {
  id:'cabin', name:'선장실', scene, colliders, clickables, spots:SPOTS, floors:[], exposure:1.05,
  clamp(p, m){ p.x = Math.min(ROOM.maxX - m, Math.max(ROOM.minX + m, p.x)); p.z = Math.min(ROOM.maxZ - m, Math.max(ROOM.minZ + m, p.z)); },
  sideOk:(x) => x > ROOM.minX + 0.4 && x < ROOM.maxX - 0.4,
  heightAt:() => 0,
  camClamp(v){ v.x = Math.min(ROOM.maxX - 0.3, Math.max(ROOM.minX + 0.3, v.x)); v.z = Math.min(ROOM.maxZ - 0.3, Math.max(ROOM.minZ + 0.3, v.z)); v.y = Math.min(ROOM.H - 0.25, v.y); },
  ambient(dt, time, sway){
  sailFx.k += (sailFx.want - sailFx.k) * Math.min(1, dt * 1.5);
  const boost = sailFx.k;   /* 항해 장면: 창밖 바다가 빨리 흘러가고 더 출렁여요 */
  OUT.rotation.z = Math.sin(time * 0.45) * (0.018 + boost * 0.03) * sway; OUT.position.y = Math.sin(time * 0.6) * (0.25 + boost * 0.3) * sway;
  sailFx.flow += dt * (0.02 + boost * 0.5); waterTex.offset.y = sailFx.flow % 1; wake.material.opacity = 0.22 + boost * 0.4;
  wardrobeStep(dt); chestStep(dt);
  lanterns.forEach(L => { L.g.rotation.z = Math.sin(time * 0.9 + L.ph) * 0.06 * sway; L.l.intensity = 1.3 + Math.sin(time * 7 + L.ph) * 0.05; });
  if (candle.flame){ candle.flame.scale.y = 0.32 + Math.sin(time * 11) * 0.03 * sway; candle.light.intensity = 0.9 + Math.sin(time * 13) * 0.08 * sway; }
  if (deskNeedle.ref) deskNeedle.ref.rotation.y = Math.sin(time * 0.7) * 0.4 * sway;
  if (globeRef.ball) globeRef.ball.rotation.y += dt * 0.15 * sway;
  if (wheelRef.g){ wheelRef.spin = Math.max(0, wheelRef.spin - dt * 1.4); wheelRef.g.rotation.z += dt * wheelRef.spin * 2 + Math.sin(time * 0.5) * 0.002 * sway; }

  },
  arrive(){ player.x = 0; player.z = ROOM.maxZ - 2.0; player.r = Math.PI; cam.yaw = 0; cam.pitch = 0.32; }
};
const AREAS = { cabin:CABIN_AREA };
let AREA = CABIN_AREA;
/* 공간 바꾸기: 캐릭터를 옮기고 카메라를 바로 그 자리로 */
function setArea(id, opts = {}){
  const A = AREAS[id] || CABIN_AREA;
  AREA = A; auto = null; keys.clear(); A.view = null; player.pose = null; if (player.mesh && player.mesh.userData.gymBells) player.mesh.userData.gymBells.forEach(b => { b.visible = false; });
  camera.fov = 58; camera.updateProjectionMatrix();
  A.scene.add(player.mesh); player.mesh.visible = true;
  if (A.arrive) A.arrive(opts);
  const cp = Math.cos(cam.pitch), gy = A.heightAt(player.x, player.z);
  camPos.set(player.x + Math.sin(cam.yaw) * cam.dist * cp, gy + 1.25 + Math.sin(cam.pitch) * cam.dist, player.z + Math.cos(cam.yaw) * cam.dist * cp);
  A.camClamp(camPos, gy);
  lastSpot = undefined; $('#who').dataset.area = A.name;
  document.body.dataset.area = A.id;
  if (MODE === 'cabin') setWho();
}
/* 문으로 오가기: 잠깐 어두워졌다가 */
let areaBusy = false;
function goArea(id, opts = {}){
  if (areaBusy || uiOpen) return;
  areaBusy = true; uiOpen = true;
  const done = () => { uiOpen = false; areaBusy = false; const A = AREAS[id]; if (A && A.welcome && !opts.quiet) A.welcome(opts); };
  if (reduceMotion){ setArea(id, opts); done(); return; }
  $('#fade').classList.add('on');
  setTimeout(() => { setArea(id, opts); setTimeout(() => { $('#fade').classList.remove('on'); done(); }, 120); }, 420);
}

/* ---------- 선장실 짓기 (시작은 gate.js 가 해요) ---------- */
function buildCabin(){
  buildRoom(); buildDesk(); buildWheel(); buildProps(); buildShelf(); buildWardrobe();
  player.mesh = makeAvatar('#2f5f8a');
  applyTime();
  camPos.set(player.x, 2.4, player.z + 3.6);
}
