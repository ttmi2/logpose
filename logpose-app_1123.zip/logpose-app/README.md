# LOG POSE · 그뭔SHIP

> 그게 뭔데? 쉽게 알려줄게! — 나만의 배를 꾸리고, 손목의 **로그포스**가 가리키는 다음 애니메이션으로 항해하는 3D 탐색 서비스.
> 입덕 서재의 애니메이션 데이터(63편 · 가이드북)를 그대로 써요. 라프텔 제안용 시연 버전이에요.

**지금은 혼자 쓰기 모드예요.** 모든 기록은 각자 브라우저에만 저장되고, 다른 사람과 연결되지 않아요.
함께 쓰기(유리병 주고받기 · 게시판 공유 · 공용 섬에서 서로 보이기) 코드는 만들어 두고 꺼 뒀어요 → **나중에 서버 연동할 땐 `SERVER_NOTES.md` 부터** 읽어 주세요.

참고용 공유 링크(만든 사람 계정): https://claude.ai/artifact/UKnxJPgW9DS1do6EFDE3dr

> **처음이면 `CUSTOMIZE.md` 부터** 읽어 주세요 (Claude에게 맡기는 법 · 쉬운 수정 위치 · 주의사항).

## 빠른 시작 (팀원용)

필요한 것: **Python 3.9+**, **Node.js 18+** (빌드 전에 데이터 점검을 돌려요). 다른 설치는 없어요.

```
python3 build.py          # → dist/logpose.html 한 장으로 만들어요
```

`dist/logpose.html` 을 브라우저로 열면 끝이에요. 3D 엔진(three.js r150)은 인터넷(CDN)에서 받아요.
기록(선장 · 저장 목록 · 은화 등)은 각자 브라우저의 localStorage 에만 저장돼요. 처음부터 다시 보려면 첫 화면에서 '나가기' 후 새 선장으로 시작하거나 사이트 데이터를 지우세요.

**고치는 순서**: `app/` · `web/` · `data/extra/` 파일을 고침 → `python3 build.py` → `dist/logpose.html` 새로고침.
`dist/` 는 빌드 결과물이라 직접 고치지 마세요(다음 빌드 때 덮어써져요).

점검용: 주소 끝에 `?lpdebug` 를 붙이면 개발자 콘솔에서 `__lp.p`(위치·구역·자세), `__lp.go(x, z)`(걸어가기), `__lp.spot()`(가까운 상호작용), `__lp.ticker()`(안내 자막 바로 보기)를 쓸 수 있어요.

## 폴더 · 파일 지도

| 경로 | 내용 | 수정 |
| --- | --- | --- |
| `data/original/` | 입덕 서재 데이터 18개 (작품 63편, 가이드북) | **금지** · `data/ORIGINAL.sha256` 로 원본과 같은지 확인 |
| `data/extra/extra.js` | 팀이 채우는 추가 정보: 라프텔 주소(`LP_EXTRA.laftelHome` 등), 작품별 강점 | 팀 |
| `app/works.js` · `profile.js` · `recommend.js` · `share.js` | 작품 연결 · 선장 정보(닉네임 · 배 이름) · 추천 · 공유 저장소(LPShare) | 개발 |
| `app/backend.js` · `app/net.js` | 함께 쓰기 연결 고리(`lpUse`: 공유 링크 · Supabase · 없음) · 공용 섬에서 서로 보이기 | 개발 |
| `config.json` · `supabase/schema.sql` · `.github/workflows/deploy.yml` | 우리 사이트 Supabase 주소 · 키 / Supabase 표 · 권한 / 자동 배포 | 대표 (`DEPLOY.md`) |
| `app/vendor/guide.js` · `web/guide.html` · `web/guide.css` | **라프텔 항해일지** (시청 화면 옆 AI 길잡이 체험 화면) | 개발 |
| `web/head.html` · `web/body.html` | 모든 화면의 HTML · CSS | 개발 |
| `app/gate.js` | 첫 화면(로그인 · 배 이름) · 위쪽 빠른 이동 · 이름표 · 점프 · 안내 자막 · 시작 | 개발 |
| `app/cabin.js` | 선장실 3D · 캐릭터(몸 · 옷 그리기 `OUTFITS`) · 이동 · 카메라 · 공간 전환 | 개발 |
| `app/taste.js` · `recs.js` · `desk.js` · `menu.js` | 취향 질문 · 추천 · 작품 정보창(책상) · 로그포스 메뉴 | 개발 |
| `app/shelf.js` · `wardrobe.js` · `letters.js` | 선장실 항해일지 책장 · 옷장 · 보물 상자(유리병 편지) | 개발 |
| `app/intro.js` · `deck.js` · `scope.js` · `chart.js` · `nest.js` | 첫 화면 배 · 갑판 · 망원경(섬 보기) · 항해 지도 · 망루 | 개발 |
| `app/fish.js` | 낚시 · 물고기 도감(보물 물고기 포함) · 어창 · 유리병 던지기/낚기 | 개발 |
| `app/isle.js` · `fishpier.js` · `tavern.js` · `market.js` · `marketplace.js` · `board.js` · `rest.js` | 공용 섬 · 공용 낚시터 · 주점 · 상점(모자 · 옷 · 해적기) · 시장 거리 · 현상금 게시판 · 쉼터(의자 · 모닥불 · 평상 · 파라솔) | 개발 |
| `app/gym.js` | 공용 섬 해적 헬스장 **강자 ZONE** (기구 · 운동 · 앵무새/원숭이 응원) | 개발 |
| `app/ambience.js` | 배경 소리(바다 · 갈매기 · 주점 노래 · 강자 ZONE 노래) · 🔊 · '?' 도움말 · 화질 · 은화 표시 · 공용 섬 미니맵 | 개발 |
| `app/isletour.js` | 절영도 첫 방문 안내 **'절영도 한눈에 보기'** (카메라가 장소를 비추며 기능 소개 · '?' 도움말에서 다시 보기) | 개발 |
| `build.py` | 위 파일을 순서대로 합쳐 `dist/logpose.html` 로 | — |
| `tools/` | 데이터 점검 스크립트 | — |

새 3D 파일을 만들면 `build.py` 의 `scene_js` 목록에 넣어 주세요(순서 중요: 앞 파일의 `const` 를 뒤 파일이 써요).

## 자주 바꾸는 값

| 무엇 | 어디 | 지금 |
| --- | --- | --- |
| 모자 · 옷 · 해적기 가격 | `app/market.js` `HATS` · `FLAGS`, `app/cabin.js` `OUTFITS` | 20~90은화 |
| 시험용 전부 무료 | `app/market.js` `TEST_FREE` | false |
| 내 사진 해적기 가격 | `app/market.js` `CUSTOM_FLAG_PRICE` | 50은화 |
| 맥주 가격 | `app/market.js` `BEER_PRICE` | 5은화 |
| 유리병 낚일 확률 (공용 낚시터) | `app/fish.js` `BOTTLE_CATCH` | 0.03 (3%) |
| 보물 물고기 확률 (5종 합) | `app/fish.js` `TREASURE_CATCH` | 0.005 (0.5%) |
| 물고기 종류 · 값 · 흔한 정도 | `app/fish.js` `FISH` | 15종 |
| 어창 칸 수 | `app/fish.js` `HOLD_MAX` | 20 |
| 현상금 응원 한 번 · 하루 한도 | `app/board.js` `CHEER_STEP` · `CHEER_DAY` | 10 · 100은화 |
| 안내 자막 간격 (초) | `app/gate.js` `TICK_FIRST` · `TICK_EVERY` | 1800 · 1800 (30분) |
| 예시 유리병 문구 | `app/fish.js` `SAMPLE_LINES` | 6개 (서버에 병이 4개 이상이면 안 나와요) |

## 점검

```
node tools/check_data.js        # 원본 데이터 체크섬 + 63편 (build.py 가 먼저 돌려요)
node tools/validate_original.js # 원본 가이드 데이터 검사
```

## 원칙 (꼭 지켜 주세요)

- 데이터 파일은 읽기만 해요. 새 정보는 `data/extra` 에 따로 둬요. 없는 정보는 비워 두고 지어내지 않아요.
- 라프텔 주소는 지어내지 않아요. 연결 전까지 버튼은 '준비 중'으로 두고, 주소가 생기면 `data/extra/extra.js` 에 넣어요.
- **공식 이미지 · 캐릭터 · 작품 의상은 그리지 않아요.** 표지는 그린 표지, 의상 · 물고기는 장르 감성 오리지널이에요. 실제 작품 컬래버는 판권 계약 뒤에.
- 스포일러 방지: 정보창의 인물 · 용어는 1화에 처음 나오는 것의 1화 시점 설명만. 유리병 한줄평도 `checkSpoiler` 로 걸러요.
- 대표작이 아닌 57편의 `book.points` 는 1~2화 줄거리라서 '주요 특징'으로 쓰지 않아요.
- 라프텔 회원 전용 기능(라프텔 항해일지 · 현상금 응원 · 현상금 선장 순위)은 `isLaftelCaptain()` 으로 막아요.

## 함께 쓰기 (지금은 꺼짐)

켜는 법 · 주의사항은 `SERVER_NOTES.md`, 웹사이트 배포 단계는 `DEPLOY.md` 를 보세요.

## 공유 저장소 바꾸기 (웹사이트로 옮길 때)

여러 선장이 함께 쓰는 데이터(유리병 · 스포일러 신고)는 **`app/share.js` 의 `LPShare` 하나만** 거쳐요.
지금은 `localStorage['logpose.sea']` 에 저장하는 **"이 브라우저 안의 연습용 바다"** 예요. 같은 브라우저에서 다른 선장으로 들어오면 앞 선장의 병을 낚을 수 있어요.

서버로 옮길 때는 아래 함수들만 같은 이름 · 같은 값으로 다시 만들면 돼요. **모두 Promise 를 돌려줘요.**

| 함수 | 받는 값 | 돌려주는 값 | 서버에서 할 일 |
|---|---|---|---|
| `status()` | – | `{ ok, mode:'server', label }` | 연결 상태 (label 은 낚시 화면에 보여요) |
| `putBottles(list)` | 병 배열 | 새로 저장한 개수 | 같은 `id` 는 건너뛰기 · 글자 수(60) · 링크 금지 다시 검사 |
| `listBottles({ notOwner, exclude })` | 내 선장 id · 이미 낚은 병 id 들 | 병 배열 | 내 병 · 신고 2회 이상 · exclude 빼고 돌려주기 (무작위 몇십 개면 충분) |
| `report(id, by)` | 병 id · 신고한 선장 id | `{ count, hidden }` | 같은 사람 중복 신고 막기 · 2회 이상이면 숨김 |
| `removeBottle(id)` | 병 id | true/false | **관리자만** (페이지 주인 · 운영자) |

병 하나의 모양: `{ id, work, text, at, from:{ name, kind }, owner }`
- `work` 는 63편 작품 id 중 하나 · `text` 는 60자 이하 한줄평 · `from` 은 보낸 사람 표시용 닉네임과 선장 종류 · `owner` 는 선장 id
- 선장 id 는 지금 `captainId()` (닉네임 + 만든 시각으로 만든 짧은 값). **서버에서는 로그인 계정 id 로 바꿔 주세요.**

웹사이트로 열 때 꼭 함께 챙길 것
- 로그인 (지금 기록은 각자 브라우저에만 있어요 · 라프텔 연동도 이때 실제로)
- 신고 처리 · 병 지우기 관리자 화면, 스포일러 거르기(`checkSpoiler`)를 서버에서도 한 번 더
- 이용 약관 · 개인정보 처리방침 (닉네임 · 한줄평을 저장해요)

### 내 사진 해적기 (서버 붙일 때 주의)
- 지금은 사진을 320×200 JPEG로 줄여 **이 기기(localStorage)에만** 저장하고, 내 배(갑판·선장실·공용 섬 부두)에만 보여요. 다른 선장에게는 보이지 않아요.
- 나중에 공용 서버에서 다른 선장에게도 보이게 하려면: 업로드 크기 제한, 신고·숨김, 부적절한 이미지 검수(자동 + 사람)를 먼저 붙여 주세요.
- 시험용 무료 스위치: `app/market.js` 의 `TEST_FREE` (true 면 모자·옷·해적기가 무료, 지금은 false). 내 사진 해적기는 새 사진마다 `CUSTOM_FLAG_PRICE`(50은화).
