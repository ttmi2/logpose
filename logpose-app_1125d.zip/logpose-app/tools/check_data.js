// LOG POSE 단계 0 점검: node tools/check_data.js
// 1) data/original 이 원본과 같은지(체크섬)  2) 데이터를 읽어 63편이 한 모양으로 나오는지
const fs = require('fs'), path = require('path'), crypto = require('crypto');
const ROOT = path.join(__dirname, '..');
const ORIG = path.join(ROOT, 'data', 'original');
let bad = 0; const fail = m => { bad++; console.log('✗ ' + m); };

// 1) 체크섬
for (const line of fs.readFileSync(path.join(ROOT, 'data', 'ORIGINAL.sha256'), 'utf8').trim().split('\n')){
  const [hash, name] = line.split(/\s+\*?/);
  const now = crypto.createHash('sha256').update(fs.readFileSync(path.join(ORIG, name))).digest('hex');
  if (now !== hash) fail(`데이터 파일이 바뀌었어요: ${name}`);
}
console.log('체크섬 확인 끝');

// 2) 원본 빌드와 같은 순서로 읽기 → 추가 정보 → 연결부
const guides = fs.readdirSync(ORIG).filter(f => /^guides_[a-z]+\.js$/.test(f) && f !== 'guides_post.js').sort();
const order = ['data.js', 'data_fix.js', 'data_ep3.js', 'data_ep45.js', 'catalog.js', ...guides, 'guides_post.js'];
const src = order.map(f => fs.readFileSync(path.join(ORIG, f), 'utf8')).join('\n')
  + '\n' + fs.readFileSync(path.join(ROOT, 'data', 'extra', 'extra.js'), 'utf8')
  + '\n' + fs.readFileSync(path.join(ROOT, 'app', 'works.js'), 'utf8');
let D; eval(src + '\nD = LPData;');

const all = D.all();
if (all.length !== 63) fail(`작품 수 ${all.length} (63이어야 해요)`);
const cnt = k => all.filter(w => Array.isArray(w[k]) ? w[k].length : w[k]).length;
for (const w of all){
  if (!w.title) fail(`${w.id}: 제목 없음`);
  if (!w.genre || !w.genre.name) fail(`${w.id}: 장르 없음`);
  if (!w.summary) fail(`${w.id}: 줄거리 없음`);
  if (!w.cast.length) fail(`${w.id}: 1화 인물 정보 없음`);
}
console.log(`작품 ${all.length}편 · 장르 ${D.genres().length}개 · 대표작 ${all.filter(w => w.isRep).length}편`);
console.log(`정보창 항목 채움: 제목 ${cnt('title')} · 장르 ${all.filter(w => w.genre).length} · 줄거리 ${cnt('summary')} · 주요 특징 ${cnt('features')} · 1화 인물 ${cnt('cast')} · 1화 용어 ${cnt('terms')} · 1화 미리보기 ${cnt('ep1')} · 라프텔 주소 ${cnt('laftelUrl')} · 이미지 ${cnt('image')}`);
const s = q => D.search(q).slice(0, 3).map(w => w.title).join(', ') || '(없음)';
console.log(`검색 "진격" → ${s('진격')} | "ㄱㅁ" → ${s('ㄱㅁ')} | "카프카" → ${s('카프카')}`);
const k = D.get('kaiju');
console.log(`예시 괴수 8호: ${k.summary} / 인물 ${k.cast.map(c => c.name).join(', ')} / 용어 ${k.terms.map(t => t.name).join(', ')}`);
console.log(bad ? `문제 ${bad}개` : '단계 0 점검 통과');
process.exit(bad ? 1 : 0);
