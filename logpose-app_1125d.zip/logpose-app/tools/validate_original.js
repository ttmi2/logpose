// 가이드 데이터 검증: node validate.js [workId...]
const fs = require('fs'), path = require('path');
const B = path.join(__dirname, '..', 'data', 'original');
const files = ['data','data_fix','data_ep3','data_ep45','catalog', ...fs.readdirSync(B).filter(f => /^guides_[a-z]+\.js$/.test(f)).map(f => f.replace('.js','')).sort(), 'guides_post'].filter(f => fs.existsSync(path.join(B, f + '.js')));
const src = files.map(f => fs.readFileSync(path.join(B, f + '.js'), 'utf8')).join('\n');
const ARTS = 'title field hill town home alley wallsteam fire boat camp party night wall training city battle meteor grave forest flowers gym tv street classroom office darkroom void'.split(' ');
const RELS = ['family','friend','rival','peer','other'];
let out;
eval(src + '\nout = { WORKS, COMMON_BANNED, CATALOG };');
const { WORKS, COMMON_BANNED } = out;
const only = process.argv.slice(2);
const T = (a) => a[0] * 10000 + a[1];
let errors = 0, warns = 0, checked = 0;
const err = (id, m) => { errors++; console.log(`✗ ${id}: ${m}`); };
const warn = (id, m) => { warns++; console.log(`△ ${id}: ${m}`); };
const strip = s => String(s).replace(/\*\*/g, '');
for (const [id, W] of Object.entries(WORKS)){
  if (only.length && !only.includes(id)) continue;
  const G = W.guide;
  if (!G){ if (!only.length) warn(id, '가이드 없음'); continue; }
  checked++;
  for (const k of ['season','eps','startAt','core','episodes','scenes','chars','rels','terms']) if (G[k] === undefined) err(id, `필드 없음: ${k}`);
  if (!G.chars) continue;
  const epN = G.eps;
  if (Object.keys(G.episodes).length !== epN) err(id, `episodes 개수 ${Object.keys(G.episodes).length} ≠ eps ${epN}`);
  for (let e = 1; e <= epN; e++){
    if (!G.episodes[e] || !G.episodes[e].title || !G.episodes[e].summary) err(id, `${e}화 제목/요약 없음`);
    const sc = G.scenes[e]; if (!sc || !sc.length){ err(id, `${e}화 장면 없음`); continue; }
    if (sc[0].s !== 0) err(id, `${e}화 첫 장면이 0초가 아님`);
    sc.forEach((x, i) => {
      const end = i + 1 < sc.length ? sc[i+1].s : 1440;
      if (i && x.s <= sc[i-1].s) err(id, `${e}화 장면 시간 순서 오류 @${x.s}`);
      if (x.s < 0 || x.s >= 1440) err(id, `${e}화 장면 시간 범위 오류 @${x.s}`);
      if (!ARTS.includes(x.art)) err(id, `${e}화 @${x.s} art '${x.art}' 없음`);
      for (const c of x.chars){ const C = G.chars[c]; if (!C) err(id, `${e}화 @${x.s} 인물 ${c} 없음`); else if (T(C.at) >= T([e, end])) err(id, `${e}화 @${x.s} 인물 ${c} 공개 전 등장 (at ${C.at})`); }
      for (const t of x.terms){ const D = G.terms[t]; if (!D) err(id, `${e}화 @${x.s} 용어 ${t} 없음`); else if (T(D.at) >= T([e, end])) err(id, `${e}화 @${x.s} 용어 ${t} 공개 전 사용 (at ${D.at})`); }
      // 장면 요약에 아직 공개 안 된 인물 이름이 나오면 안 됨
      for (const [cid, C] of Object.entries(G.chars)) if (T(C.at) >= T([e, end])) for (const nm of [C.short, C.name]) if (nm && nm.length >= 2 && x.sum.includes(nm) && !Object.values(G.terms).some(D => T(D.at) < T([e, end]) && (D.name === nm || D.alias.includes(nm)))) err(id, `${e}화 @${x.s} 요약에 공개 전 이름 '${nm}'`);
    });
    if (sc[sc.length-1].s > 1440) err(id, `${e}화 마지막 장면 범위 초과`);
  }
  const inRange = a => Array.isArray(a) && a[0] >= 1 && a[0] <= epN && a[1] >= 0 && a[1] < 1440;
  if (!inRange(G.startAt)) err(id, 'startAt 범위 오류');
  for (const c of G.core) if (!G.terms[c]) err(id, `core 용어 ${c} 없음`);
  const names = [];
  for (const [cid, C] of Object.entries(G.chars)){
    if (!C.name || !C.short || !Array.isArray(C.alias) || !inRange(C.at)) err(id, `인물 ${cid} 필드 오류`);
    if (!Array.isArray(C.pos) || C.pos[0] < 30 || C.pos[0] > 575 || C.pos[1] < 30 || C.pos[1] > 440) err(id, `인물 ${cid} pos 범위 오류 ${C.pos}`);
    if (!C.facts || !C.facts.length) err(id, `인물 ${cid} facts 없음`);
    (C.facts || []).forEach(([a, t]) => { if (!inRange(a)) err(id, `인물 ${cid} fact 시간 오류`); if (T(a) < T(C.at)) err(id, `인물 ${cid} fact가 등장 전 ${a}`); });
    // 첫 등장 장면 확인
    const appears = Object.entries(G.scenes).some(([e, sc]) => sc.some(x => x.chars.includes(cid)));
    if (!appears) warn(id, `인물 ${cid} 어느 장면에도 없음`);
    names.push(C.short, ...(C.alias || []));
  }
  const pos = Object.values(G.chars).map(c => c.pos.join(','));
  if (new Set(pos).size !== pos.length) err(id, '인물 pos 겹침');
  for (const r of G.rels){
    if (!G.chars[r[0]] || !G.chars[r[1]]) err(id, `관계 ${r[0]}-${r[1]} 인물 없음`);
    else { if (!RELS.includes(r[2])) err(id, `관계 종류 ${r[2]}`); if (!inRange(r[4])) err(id, `관계 시간 오류`); if (T(r[4]) < Math.max(T(G.chars[r[0]].at), T(G.chars[r[1]].at))) err(id, `관계 ${r[0]}-${r[1]}가 인물 공개 전`); }
  }
  for (const [tid, D] of Object.entries(G.terms)){
    if (!D.name || !Array.isArray(D.alias) || !inRange(D.at)) err(id, `용어 ${tid} 필드 오류`);
    if (!D.facts || !D.facts.length) err(id, `용어 ${tid} facts 없음`);
    (D.facts || []).forEach(([a]) => { if (!inRange(a)) err(id, `용어 ${tid} fact 시간 오류`); if (T(a) < T(D.at)) err(id, `용어 ${tid} fact가 공개 전`); });
  }
  // 금지어가 공개 텍스트에 들어가면 안 됨
  const banned = COMMON_BANNED.concat(G.banned || []);
  const texts = [];
  for (let e = 1; e <= epN; e++){ texts.push(G.episodes[e].summary, G.episodes[e].title); G.scenes[e].forEach(x => texts.push(x.sum, x.title)); }
  Object.values(G.chars).forEach(C => { texts.push(C.name, C.easy || ''); C.facts.forEach(f => texts.push(f[1])); });
  Object.values(G.terms).forEach(D => { texts.push(D.name, D.easy || ''); D.facts.forEach(f => texts.push(f[1])); });
  for (const b of banned) for (const t of texts) if (strip(t).includes(b)){ err(id, `금지어 '${b}'가 공개 텍스트에: ${strip(t).slice(0, 40)}`); break; }
  for (const b of (G.banned || [])) if (names.includes(b)) err(id, `금지어 '${b}'가 공개 인물 이름과 같음`);
  // 다른 작품 이름이 섞이지 않았는지(복붙 사고)
}
console.log(`\n검사 ${checked}편 · 오류 ${errors} · 경고 ${warns}`);
process.exit(errors ? 1 : 0);
