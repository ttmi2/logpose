// 작품별 강점(세계관·작화·캐릭터) 초안: 한 줄 소개 + 대표작 소개글의 단어로만 찾아요.
// node tools/draft_strengths.js  → data/extra/strengths_draft.js 와 표(JSON) 출력
const fs = require('fs'), path = require('path');
const ROOT = path.join(__dirname, '..'), O = path.join(ROOT, 'data', 'original');
const g = fs.readdirSync(O).filter(f => /^guides_[a-z]+\.js$/.test(f) && f !== 'guides_post.js').sort();
let D; eval(['data.js','data_fix.js','data_ep3.js','data_ep45.js','catalog.js',...g,'guides_post.js'].map(f => fs.readFileSync(path.join(O, f), 'utf8')).join('\n')
  + fs.readFileSync(path.join(ROOT, 'data/extra/extra.js'), 'utf8') + fs.readFileSync(path.join(ROOT, 'app/works.js'), 'utf8') + '\nD = LPData;');
const RULES = {
  world:     /세계관|설정|세계|이세계/,
  art:       /작화|연출|영상미|화려|그림|비주얼|아름다운 영상|액션 연출/,
  character: /캐릭터|인물/
};
const rows = D.all().map(w => {
  const text = w.isRep ? `${w.line} ${w.summary}` : w.line;
  const out = { id:w.id, title:w.title, genre:w.genre.name, line:w.line, picks:[], why:{} };
  for (const [k, re] of Object.entries(RULES)){ const m = text.match(re); if (m){ out.picks.push(k); out.why[k] = m[0]; } }
  return out;
});
const map = Object.fromEntries(rows.filter(r => r.picks.length).map(r => [r.id, r.picks]));
fs.writeFileSync(path.join(ROOT, 'data/extra/strengths_draft.js'),
  '/* 작품별 강점 초안 (tools/draft_strengths.js 가 한 줄 소개의 단어로 자동 생성). 팀 검토 전이에요.\n   검토가 끝나면 extra.js 의 strengths 로 옮기거나 이 파일을 고쳐 주세요. */\n' +
  'const LP_STRENGTHS_DRAFT = ' + JSON.stringify(map, null, 1) + ';\n');
fs.writeFileSync('/tmp/strength_rows.json', JSON.stringify(rows));
const c = k => rows.filter(r => r.picks.includes(k)).length;
console.log(`63편 중 강점이 잡힌 작품 ${Object.keys(map).length}편 · 세계관 ${c('world')} · 작화 ${c('art')} · 캐릭터 ${c('character')}`);
rows.filter(r => r.picks.length).forEach(r => console.log(' ', r.title, r.picks.join(','), JSON.stringify(r.why)));
