// 추천 점검: 예시 답변 10가지 → 결과 표, 규칙 확인. node tools/check_recommend.js
const fs = require('fs'), path = require('path');
const ROOT = path.join(__dirname, '..'), O = path.join(ROOT, 'data', 'original');
const g = fs.readdirSync(O).filter(f => /^guides_[a-z]+\.js$/.test(f) && f !== 'guides_post.js').sort();
let D, RC; eval(['data.js','data_fix.js','data_ep3.js','data_ep45.js','catalog.js',...g,'guides_post.js'].map(f => fs.readFileSync(path.join(O, f), 'utf8')).join('\n')
  + ['data/extra/extra.js','data/extra/strengths_draft.js','app/works.js','app/recommend.js'].map(f => fs.readFileSync(path.join(ROOT, f), 'utf8')).join('\n') + '\nD = LPData; RC = LPRecommend;');
const CASES = [
  ['입문 · 아무것도 안 봄 · 캐릭터 · 코미디', { none:true, seen:[], values:['character'], genres:['comedy'] }],
  ['입문 · 아무것도 안 봄 · 작화 · 판타지+로맨스', { none:true, seen:[], values:['art'], genres:['fantasy','romance'] }],
  ['귀멸 본 사람 · 작화 · 액션', { seen:['kimetsu'], values:['art'], genres:['action'] }],
  ['진격·데스노트 · 세계관 · 미스터리', { seen:['aot','deathnote'], values:['world'], genres:['mystery'] }],
  ['하이큐 · 캐릭터 · 모험·스포츠', { seen:['haikyu'], values:['character'], genres:['adventure'] }],
  ['프리렌·바이올렛 · 세계관+작화 · 판타지+로맨스', { seen:['frieren','violet'], values:['world','art'], genres:['fantasy','romance'] }],
  ['스파이패밀리 · 캐릭터 · 코미디+로맨스', { seen:['spy'], values:['character'], genres:['comedy','romance'] }],
  ['안 봄 · 세계관 · SF·미스터리', { none:true, seen:[], values:['world'], genres:['mystery'] }],
  ['주술·체인소·귀멸 · 작화+캐릭터 · 액션', { seen:['jujutsu','chainsaw','kimetsu'], values:['art','character'], genres:['action'] }],
  ['원피스 · 세계관 · 모험+판타지', { seen:['onepiece'], values:['world'], genres:['adventure','fantasy'] }]
];
let bad = 0; const rows = [];
for (const [name, t] of CASES){
  const r = RC.recommend(t, { seed:'테스트' });
  if (r.length !== 4) { bad++; console.log('✗ 4편이 아님', name); }
  if (r.some(x => t.seen.includes(x.id))) { bad++; console.log('✗ 본 작품이 추천됨', name); }
  const per = {}; r.forEach(x => per[x.work.genre.id] = (per[x.work.genre.id] || 0) + 1);
  if (Object.values(per).some(v => v > (t.genres.length <= 1 ? 3 : 2))) { bad++; console.log('✗ 한 장르 3편 이상', name); }
  if (r.some(x => !x.reasons.length)) console.log('△ 이유 없는 추천', name, r.filter(x => !x.reasons.length).map(x => x.work.title));
  // 다시 추천: 겹치지 않음
  const r2 = RC.recommend(t, { seed:'테스트', exclude:r.map(x => x.id) });
  if (r2.some(x => r.find(y => y.id === x.id))) { bad++; console.log('✗ 다른 목적지에 같은 작품', name); }
  rows.push({ name, picks:r.map(x => ({ t:x.work.title, s:x.score, why:x.reasons })), again:r2.map(x => x.work.title) });
}
fs.writeFileSync('/tmp/rec_rows.json', JSON.stringify(rows));
rows.forEach(r => console.log(`${r.name}\n   → ${r.picks.map(p => `${p.t}(${p.s})`).join(' · ')}\n   다른 목적지 → ${r.again.join(' · ')}`));
console.log(bad ? `문제 ${bad}개` : '추천 점검 통과');
process.exit(bad ? 1 : 0);
