# LOG POSE 웹사이트로 열기 (GitHub Pages + Supabase)

## ★ 지금 우리 팀이 쓰는 방식 (11/23 기준 · 가장 쉬움)

- 사이트: https://ttmi2.github.io/logpose/ · 저장소: github.com/ttmi2/logpose
- 저장소 맨 위에는 **zip 파일 하나 + `.github/workflows/deploy.yml` + `config.json`** 만 있어요.
  `deploy.yml` 이 zip 을 풀어서 `python3 build.py` 로 사이트를 만들어요. (웹 업로드는 폴더 구조가 잘 풀려 버려서 이렇게 바꿨어요)
- **고친 버전 올리기**: 저장소에서 옛 zip 을 지우고 새 zip 을 올리면 1~2분 뒤 사이트가 바뀌어요. zip 은 **딱 하나만** 있어야 해요.
- **`config.json`** (저장소 맨 위, 새 파일로 만들기):
  ```json
  {
    "shared": true,
    "supabaseUrl": "https://zheewbwpbyxjphsflhcz.supabase.co",
    "supabaseAnonKey": "sb_publishable_로 시작하는 공개 키",
    "gaMeasurementId": "G-로 시작하는 측정 ID"
  }
  ```
  - `supabaseUrl` · `supabaseAnonKey` 가 있으면: 유리병 · 게시판 함께 쓰기 + **방문 기록**(`visits` 표)이 켜져요.
  - `gaMeasurementId` 가 있으면: **구글 애널리틱스 4** 가 켜져요. 비워 두면 꺼져요.
  - ⚠️ `sb_secret_…` / `service_role` 키는 절대 넣지 마세요.
- **Supabase 표**: `supabase/schema.sql` 을 SQL Editor 에서 실행 (브라우저 자동 번역은 끄고). 익명 로그인 허용 켜기.
- **숫자 보기**: Supabase SQL Editor 에 `supabase/visits_queries.sql` 의 질문을 하나씩 실행 (날짜별 · 시간대별 · 공간별 · 가이드북 많이 연 작품 등).
  GA4 는 analytics.google.com → 보고서 → 실시간 (일반 보고서는 하루쯤 뒤에 채워져요). 이벤트 이름은 `lp_area` · `lp_tour_done` · `lp_tour_skip` · `lp_guide`.
- 보내는 정보: 무작위 방문 번호 · 시각 · 이동한 공간 · PC/모바일 · 들어온 사이트 도메인. 이름 · 이메일 · 닉네임은 보내지 않아요 (`app/track.js`).

---

아래는 처음 설계할 때의 안내(폴더째 올리는 방식)예요. 위 방식으로 이미 열려 있으니 참고만 하세요.

목표: 누구나 주소로 들어와서 같이 놀 수 있고(유리병 · 게시판 · 공용 섬에서 서로 보이기), 팀원이 코드를 고쳐 올리면 **1~2분 안에 사이트에 자동 반영**돼요.

```
팀원이 코드 고침 → GitHub 에 올림(커밋) → GitHub Actions 가 python3 build.py → GitHub Pages 에 새 사이트
                                                         ↘ 사이트는 Supabase 에 유리병 · 게시판 저장, 실시간 위치 공유
```

처음 한 번만 30분쯤 걸려요. 아래 순서대로 하면 돼요. (먼저 `SERVER_NOTES.md` 의 주의사항을 읽어 주세요.)

---

## 1. GitHub 계정 · 저장소 만들기 (대표 한 명)

1. https://github.com 에서 **Sign up** 으로 계정을 만들어요 (팀원도 각자 계정을 만들어 두세요).
2. 오른쪽 위 **+ → New repository**
   - Repository name: 예) `logpose`
   - **Public** 선택 (무료 GitHub Pages 는 공개 저장소에서 돼요)
   - Create repository
3. 만든 저장소 화면에서 **uploading an existing file** 링크(또는 Add file → Upload files)를 눌러,
   이 zip 을 푼 `logpose-app` 폴더 **안의 내용물 전부**(`app`, `data`, `web`, `tools`, `supabase`, `.github`, `build.py`, `README.md` …)를 끌어다 놓고 **Commit changes**.
   - `.github` 처럼 점으로 시작하는 폴더가 안 보이면: 컴퓨터에서 숨김 파일 보기를 켜고 다시 끌어다 놓아요. 이 폴더가 있어야 자동 배포가 돼요.
4. 팀원 초대: 저장소 **Settings → Collaborators → Add people** 에서 팀원 GitHub 아이디를 넣어요.

## 2. 자동 배포 켜기 (GitHub Pages)

1. 저장소 **Settings → Pages**
2. **Build and deployment → Source** 를 **GitHub Actions** 로 바꿔요.
3. 저장소 위쪽 **Actions** 탭에서 '사이트 배포'가 초록 체크가 되면 끝. 사이트 주소는 `https://<아이디>.github.io/logpose/` 예요 (Settings → Pages 에도 나와요).

이 단계까지만 해도 사이트는 열려요. 다만 아직은 **각자 브라우저 안의 연습용**이라 유리병이 남에게 가지 않아요. 3~4단계로 함께 쓰기를 켜요.

## 3. Supabase 만들기 (함께 쓰는 데이터 · 실시간)

1. https://supabase.com 에서 **Start your project** → GitHub 계정으로 가입하면 편해요.
2. **New project**
   - Name: `logpose` · Database Password: 아무거나 길게(따로 적어 두기) · Region: **Northeast Asia (Seoul)**
3. 왼쪽 **SQL Editor** → New query → 저장소의 `supabase/schema.sql` 내용을 **통째로 붙여 넣고 Run**. 'Success' 가 나오면 돼요.
4. 왼쪽 **Authentication → Sign In / Providers** (또는 Auth 설정)에서 **Allow anonymous sign-ins(익명 로그인 허용)** 를 켜고 저장해요.
   - 방문자는 가입 없이 자동으로 '익명 선장'이 되고, 자기 유리병 · 응원 기록만 쓸 수 있어요.
5. 왼쪽 **Project Settings → API**(또는 Data API / API Keys)에서 두 값을 복사해요.
   - **Project URL** — `https://xxxx.supabase.co`
   - **anon public** 키 (또는 `sb_publishable_…` 로 시작하는 Publishable key)
   - ⚠️ `service_role` / `secret` 키는 **절대** 쓰지 마세요. 사이트에 넣으면 누구나 모든 데이터를 고칠 수 있어요.

## 4. 사이트에 Supabase 연결

1. GitHub 저장소에서 **Add file → Create new file**, 파일 이름 `config.json`, 내용:
   ```json
   {
     "shared": true,
     "supabaseUrl": "https://xxxx.supabase.co",
     "supabaseAnonKey": "여기에 anon public 키"
   }
   ```
   (`config.example.json` 과 같은 모양이에요.) **Commit changes**.
2. 1~2분 뒤 Actions 가 끝나면 사이트를 새로고침. 낚시터에 **'공용 바다 · 모든 선장님과 함께'** 라고 나오면 연결된 거예요.
   - anon 키는 원래 공개해도 되는 키예요. 데이터는 `schema.sql` 의 규칙(자기 것만 쓰기)으로 지켜요.

## 5. 팀원이 코드 고치는 법 (설치 없이)

- 저장소 화면에서 키보드 **`.`(마침표)** 를 누르면 브라우저 안에서 VS Code 같은 편집기(github.dev)가 열려요.
- 파일을 고치고 → 왼쪽 **Source Control** → 메시지 쓰고 **Commit & Push**.
- 1~2분 뒤 사이트에 반영돼요. 진행 상황은 **Actions** 탭에서 봐요 (빨간 X 면 눌러서 어디서 막혔는지 확인).
- 자주 고치는 값(가격 · 확률 · 자막 간격 등)이 어디 있는지는 `README.md` 의 '자주 바꾸는 값' 표를 보세요.
- 여럿이 같은 파일을 동시에 고치면 충돌이 날 수 있어요. 고치기 전에 팀 채팅에 "market.js 고쳐요" 정도 알리면 좋아요.

자기 컴퓨터에서 미리 보고 싶으면: Python 3 · Node.js 18 설치 → `python3 build.py` → `dist/logpose.html` 열기.

## 6. 운영할 때

- **이상한 유리병 · 기록 지우기**: Supabase → **Table Editor → docs** 에서 그 줄을 지워요. (`col` = bottles 인 줄의 `data.list` 에 병들이 있어요.)
- **익명 로그인 한도**: Supabase 는 같은 IP 에서 익명 로그인 횟수에 한도가 있어요(Authentication → Rate Limits). 행사장처럼 한 와이파이에서 여럿이 들어오면 한도를 올려 주세요.
- **무료 등급 한도**: Supabase · GitHub Pages 모두 무료 등급이 있어요. 동시 접속 · 저장 용량 한도는 각 서비스 요금 페이지에서 확인해 주세요.
- **아직 없는 것** (정식 서비스 전에 필요): 라프텔 실제 로그인 연동, 신고 처리 관리자 화면, 이용 약관 · 개인정보 처리방침, 내 사진 해적기 공유 시 이미지 검수 (README '공유 저장소 바꾸기' 참고).

## 연결 구조 (개발자용)

- `app/backend.js` 의 `lpUse('db' | 'user' | 'room')` 가 열린 곳에 따라 연결을 골라요.
  ① claude.ai 공유 링크 → 페이지 공유 저장소 · 실시간 방 ② 우리 사이트 → Supabase ③ 파일 → 없음(연습용)
- Supabase 표는 `docs` 한 장: `(col, owner)` 마다 JSON 문서 하나. `share.js` 는 `col/owner` 경로로 읽고 써요.
- 서로 보이기는 Realtime Presence 채널 `logpose-isle` (표 없음). 한 사람당 초당 최대 약 6번 위치를 보내요.
