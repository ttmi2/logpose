/* ============================================================
   LOG POSE · 갑판 3단계: 장르 6해역 (A~F)
   항해 지도(해도 탁자)에 있던 여섯 해역을 진짜 바다 위에도 나눠 놓았어요.
   - 배를 둘러싼 바다를 여섯 조각으로 나누고, 해역마다 작은 섬 하나 + 이정표 하나
   - 해역 사이 경계에는 두 해역 색이 번갈아 칠해진 부표가 줄지어 떠요
   - 망루에 올라가 둘러보면 바라보는 쪽 해역 이름이 떠요 (nest.js 의 nestUI)
   섬 모양은 장르 분위기만 담은 오리지널이에요. 특정 작품 속 장소를 따라 그리지 않았어요.
   고치기: 위치는 SEA_ANGLES(뱃머리 = 0°, 왼쪽이 +) · SEA_R(거리), 모양은 seaProp 의 장르별 부분
   ============================================================ */
const SEA_ZONES = [];
/* 뱃머리 앞(라프텔 · 다모였섬이 보이는 쪽)은 비워 두고 나머지를 여섯으로 나눠요 */
const SEA_ANGLES = { A:40, B:95, C:150, D:210, E:265, F:320 };
const SEA_R = 92;
/* 이정표: 판자 3.5 × 2.05 (예전 5.6 × 3.3 를 1.7배로 키웠던 것에서 크게 줄였어요) */
const seaDeg = d => d * Math.PI / 180;
const seaPos = (deg, r) => ({ x:Math.sin(seaDeg(deg)) * r, z:Math.cos(seaDeg(deg)) * r });   /* 뱃머리 = +z, 왼쪽 = +x (nestDirName 과 같은 방향) */

/* 이정표 판자 그림: 큰 해역 글자 + 장르 이름 + 한 줄 소개 */
function seaSignTex(g0){
  return canvasTex(512, 300, (g, w, h) => {
    g.fillStyle = '#e9d9b2'; g.fillRect(0, 0, w, h);
    for (let y = 0; y < h; y += 60){ g.fillStyle = 'rgba(120,84,50,.12)'; g.fillRect(0, y, w, 3); }
    g.fillStyle = `hsl(${g0.hue}, 55%, 38%)`; g.fillRect(0, 0, w, 74);
    g.fillStyle = '#fff7e6'; g.textAlign = 'center'; g.textBaseline = 'middle';
    g.font = `700 46px ${FD}`; g.fillText(`${g0.zone} 해역`, w / 2, 40);
    g.fillStyle = '#2a1a0e'; g.font = `700 50px ${FD}`; g.fillText(g0.name, w / 2, 140);
    g.fillStyle = '#5a3e26'; g.font = `600 24px ${FB}`;
    const t = g0.tag.replace(/분께$/, '분을 위한 바다'); g.fillText(t.length > 22 ? t.slice(0, 22) + '…' : t, w / 2, 210);
    g.strokeStyle = 'rgba(58,38,22,.6)'; g.lineWidth = 10; g.strokeRect(5, 5, w - 10, h - 10);
  });
}
/* 해역마다 섬 위에 올리는 것 (장르 분위기만) */
function seaProp(id, G, hue){
  const m = (geo, mat, x, y, z, p = G) => { const o = new THREE.Mesh(geo, mat); o.position.set(x, y, z); p.add(o); return o; };
  const col = `hsl(${hue}, 55%, 45%)`;
  if (id === 'action'){   /* 뾰족한 바위 봉우리 셋 + 꽂힌 두 칼 */
    [[-1.6, 5.5, 0], [1.2, 4.2, 0.8], [0.2, 6.8, -1.2]].forEach(([x, h, z]) => m(rough(new THREE.ConeGeometry(1.3, h, 6), 0.15), flat('#7a6a62'), x, 2 + h / 2, z));
    [-1, 1].forEach(s => { const b = m(new THREE.BoxGeometry(0.18, 3.2, 0.05), new THREE.MeshStandardMaterial({ color:'#d6dde2', metalness:.6, roughness:.3 }), 2.6 + s * 0.4, 3.6, 1.6); b.rotation.z = s * 0.35;
      m(new THREE.BoxGeometry(0.7, 0.12, 0.12), flat('#5a3e26'), 2.6 + s * 0.4 - s * 0.55, 5.0, 1.6).rotation.z = s * 0.35; });
  } else if (id === 'adventure'){   /* 깃발 꽂힌 언덕 + 뜀틀 같은 나무 계단 */
    m(rough(new THREE.SphereGeometry(2.6, 10, 6, 0, Math.PI * 2, 0, Math.PI / 2), 0.2), flat('#6f9a4a'), 0, 2, 0);
    m(new THREE.CylinderGeometry(0.08, 0.08, 4.5, 6), flat('#5a3e26'), 0.4, 6.2, 0);
    const f = m(new THREE.PlaneGeometry(2.2, 1.3), new THREE.MeshStandardMaterial({ color:col, side:THREE.DoubleSide, roughness:.9 }), 1.5, 7.6, 0); f.userData.wave = true; SEA_ZONES.wave.push(f);
    [0, 1, 2].forEach(k => m(new THREE.BoxGeometry(1.4, 0.5 + k * 0.5, 1.0), flat('#a8825a'), -2.4 + k * 1.2, 2 + (0.5 + k * 0.5) / 2, 1.8));
  } else if (id === 'fantasy'){   /* 빛나는 수정 + 공중에 뜬 작은 바위 */
    [[0, 3.2, 0, 0], [-1.1, 2.2, 0.6, 0.4], [1.0, 2.0, -0.5, -0.5]].forEach(([x, s, z, r]) => { const c = m(new THREE.OctahedronGeometry(s * 0.45, 0), new THREE.MeshStandardMaterial({ color:'#9fd8ff', emissive:'#4fa8e8', emissiveIntensity:.7, roughness:.2, flatShading:true }), x, 2 + s * 0.45, z); c.scale.y = 2.0; c.rotation.z = r; });
    const fl = m(rough(new THREE.ConeGeometry(1.4, 1.8, 7), 0.2), flat('#8a7a6e'), 0.5, 9.0, 0.3); fl.rotation.x = Math.PI; SEA_ZONES.float.push(fl);
    m(new THREE.SphereGeometry(0.9, 8, 6, 0, Math.PI * 2, 0, Math.PI / 2), flat('#6f9a4a'), 0.5, 9.9, 0.3);
  } else if (id === 'mystery'){   /* 불 꺼진 듯 깜빡이는 작은 등대 + 물음표 바위 */
    m(new THREE.CylinderGeometry(0.7, 1.0, 5, 10), flat('#3c3a4a'), 0, 4.5, 0);
    [0, 1].forEach(k => m(new THREE.CylinderGeometry(0.72 - k * 0.1, 0.86 - k * 0.1, 0.5, 10), flat('#7a3b8a'), 0, 3.2 + k * 1.9, 0));
    const lamp = m(new THREE.SphereGeometry(0.55, 10, 8), new THREE.MeshStandardMaterial({ color:'#f0e0ff', emissive:'#b48cff', emissiveIntensity:1, roughness:.3 }), 0, 7.4, 0); SEA_ZONES.blink.push(lamp);
    m(new THREE.ConeGeometry(0.9, 0.9, 10), flat('#2a2836'), 0, 8.2, 0);
    m(rough(new THREE.DodecahedronGeometry(1.0, 0), 0.15), flat('#5a566a'), 2.2, 2.6, 1.2);
  } else if (id === 'romance'){   /* 분홍 꽃나무 + 하트 모양 바위 */
    m(new THREE.CylinderGeometry(0.25, 0.4, 3.2, 7), flat('#6b4528'), 0, 3.6, 0);
    [[0, 6.0, 0, 2.0], [-1.3, 5.4, 0.5, 1.4], [1.3, 5.5, -0.4, 1.5], [0.2, 5.2, 1.3, 1.2]].forEach(([x, y, z, r]) => m(new THREE.IcosahedronGeometry(r, 0), new THREE.MeshStandardMaterial({ color:'#f7a8c4', roughness:.8, flatShading:true }), x, y, z));
    const hs = new THREE.Shape(); hs.moveTo(0, -1); hs.bezierCurveTo(-1.3, -0.1, -1.2, 1.0, -0.6, 1.0); hs.bezierCurveTo(-0.25, 1.0, 0, 0.75, 0, 0.55); hs.bezierCurveTo(0, 0.75, 0.25, 1.0, 0.6, 1.0); hs.bezierCurveTo(1.2, 1.0, 1.3, -0.1, 0, -1);
    m(new THREE.ExtrudeGeometry(hs, { depth:0.5, bevelEnabled:false }), flat('#e0607e'), 2.4, 3.1, 1.4);
  } else {   /* comedy: 야자수 + 해먹 + 커다란 비치볼 */
    const p1 = makePalm(5, 0.25, 7).root; p1.position.set(-1.6, 2, 0); G.add(p1);
    const p2 = makePalm(4.6, -0.2, 7).root; p2.position.set(1.7, 2, 0.3); G.add(p2);
    const hm = m(new THREE.CylinderGeometry(0.5, 0.5, 3.0, 10, 1, true, 0, Math.PI), new THREE.MeshStandardMaterial({ color:'#f2c94c', side:THREE.DoubleSide, roughness:.9 }), 0.05, 4.0, 0.15); hm.rotation.set(0, 0, Math.PI / 2); hm.rotation.x = Math.PI;
    const ball = new THREE.Group(); ball.position.set(1.8, 2.7, 2.0); G.add(ball);
    ['#e85a4f', '#f2c94c', '#4fa3e8', '#ffffff'].forEach((c, k) => { const q = new THREE.Mesh(new THREE.SphereGeometry(0.7, 12, 8, k * Math.PI / 2, Math.PI / 2), flat(c)); ball.add(q); });
  }
}
function buildSeas(){
  SEA_ZONES.length = 0; SEA_ZONES.wave = []; SEA_ZONES.float = []; SEA_ZONES.blink = []; SEA_ZONES.buoys = [];
  const genres = LPData.genres();
  genres.forEach(g0 => {
    const deg = SEA_ANGLES[g0.zone]; if (deg == null) return;
    const p = seaPos(deg, SEA_R), G = new THREE.Group(); G.position.set(p.x, -2.6, p.z); DK3.out.add(G);
    G.rotation.y = Math.atan2(-p.x, -p.z);   /* 이정표 · 섬 앞면이 배를 바라보게 */
    /* 얕은 물 (연한 색 고리) · 모래 · 풀 */
    const shallow = new THREE.Mesh(new THREE.CircleGeometry(11, 28), new THREE.MeshBasicMaterial({ color:`hsl(${g0.hue}, 60%, 70%)`, transparent:true, opacity:.35, depthWrite:false }));
    shallow.rotation.x = -Math.PI / 2; shallow.position.y = 0.25; G.add(shallow);
    const sand = new THREE.Mesh(rough(new THREE.CylinderGeometry(5.6, 7.2, 2.4, 14), 0.35, -1.1), flat('#e8d6a6')); sand.position.set(0, 0.9, 0); G.add(sand);
    const grass = new THREE.Mesh(rough(new THREE.CylinderGeometry(4.2, 5.0, 0.6, 12), 0.25), flat(`hsl(${g0.hue}, 30%, 52%)`)); grass.position.set(0, 2.25, -0.4); G.add(grass);
    seaProp(g0.id, G, g0.hue);
    /* 이정표: 판자 뒤에 기둥 둘 (기둥이 판자 앞으로 튀어나오지 않게, 판자 위로도 안 나오게) */
    const sign = new THREE.Group(); sign.position.set(-3.4, 2.0, 4.0); sign.rotation.y = 0.2; G.add(sign);
    const backB = new THREE.Mesh(new THREE.BoxGeometry(3.7, 2.2, 0.14), flat('#6b4528')); backB.position.set(0, 3.0, -0.08); sign.add(backB);
    const board = new THREE.Mesh(new THREE.PlaneGeometry(3.5, 2.05), new THREE.MeshStandardMaterial({ map:seaSignTex(g0), roughness:.9, emissive:'#ffffff', emissiveIntensity:0 }));
    board.position.set(0, 3.0, 0.0); sign.add(board);
    [-1.25, 1.25].forEach(x => { const po = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.13, 4.0, 6), flat('#5a3e26')); po.position.set(x, 2.0, -0.26); sign.add(po); });
    /* 해역 깃발 (멀리서도 색으로 구분) */
    const fp = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.11, 6.5, 6), flat('#3a2414')); fp.position.set(3.6, 5.2, -1.5); G.add(fp);
    const flg = new THREE.Mesh(new THREE.PlaneGeometry(2.0, 1.2, 6, 1), new THREE.MeshStandardMaterial({ color:`hsl(${g0.hue}, 60%, 48%)`, side:THREE.DoubleSide, roughness:.9 }));
    flg.position.set(4.6, 7.8, -1.5); G.add(flg); SEA_ZONES.wave.push(flg);
    /* 밤에 보이는 등불 */
    const lamp = new THREE.Sprite(new THREE.SpriteMaterial({ map:glowTex, color:`hsl(${g0.hue}, 80%, 70%)`, transparent:true, opacity:0, depthWrite:false, blending:THREE.AdditiveBlending }));
    lamp.scale.set(4, 4, 1); lamp.position.set(-3.4, 6.6, 4.0); G.add(lamp);
    SEA_ZONES.push({ id:g0.id, zone:g0.zone, name:g0.name, tag:g0.tag, hue:g0.hue, deg, ax:p.x, az:p.z, group:G, lamp, board });
  });
  /* 해역 경계: 이웃한 두 해역 사이 각도에 부표 줄 */
  const order = [...SEA_ZONES].sort((a, b) => a.deg - b.deg);
  order.forEach((Z, i) => {
    const N = order[(i + 1) % order.length]; let d1 = Z.deg, d2 = N.deg; if (d2 < d1) d2 += 360;
    if (d2 - d1 > 100) return;   /* 뱃머리 앞 빈 바다(라프텔 · 다모였섬 쪽)는 경계를 긋지 않아요 */
    const mid = (d1 + d2) / 2;
    for (let r = 40, k = 0; r <= 114; r += 12, k++){   /* 출렁이는 바다(반지름 120) 안에서만 */
      const p = seaPos(mid, r), b = new THREE.Group(); b.position.set(p.x, -2.3, p.z); DK3.out.add(b);
      const c = `hsl(${(k % 2 ? N : Z).hue}, 65%, 52%)`;
      const body = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.7, 1.4, 8), flat(c)); body.position.y = 0.5; b.add(body);
      const ring = new THREE.Mesh(new THREE.CylinderGeometry(0.72, 0.72, 0.25, 8), flat('#f4efe2')); ring.position.y = 0.05; b.add(ring);
      const top = new THREE.Mesh(new THREE.SphereGeometry(0.22, 8, 6), new THREE.MeshStandardMaterial({ color:'#fff6d0', emissive:'#ffcf6a', emissiveIntensity:.0 })); top.position.y = 1.35; b.add(top);
      SEA_ZONES.buoys.push({ b, top, ph:k * 0.7 + i });
    }
  });
  timeHooks.push(seasTime); seasTime(timeMode);
}
function seasTime(mode){
  const night = mode !== 'day';
  SEA_ZONES.forEach(Z => { Z.lamp.material.opacity = night ? .85 : 0; Z.board.material.emissiveIntensity = night ? .25 : 0; Z.board.material.emissiveMap = Z.board.material.map; Z.board.material.needsUpdate = true; });
  (SEA_ZONES.buoys || []).forEach(o => { o.top.material.emissiveIntensity = night ? 1.2 : 0; });
}
function seasStep(dt, t){
  if (!SEA_ZONES.length) return;
  const T = reduceMotion ? 0 : t;
  (SEA_ZONES.buoys || []).forEach(o => { o.b.position.y = -2.3 + Math.sin(T * 1.4 + o.ph) * 0.18; o.b.rotation.z = Math.sin(T * 1.1 + o.ph) * 0.08; });
  (SEA_ZONES.wave || []).forEach((f, i) => { f.rotation.y = Math.sin(T * 2.2 + i) * 0.25; });
  (SEA_ZONES.float || []).forEach(f => { f.position.y = 9.0 + Math.sin(T * 0.8) * 0.4; f.rotation.y = T * 0.15; });
  (SEA_ZONES.blink || []).forEach(l => { l.material.emissiveIntensity = 0.5 + Math.max(0, Math.sin(T * 1.6)) * 1.2; });
}
/* 망루: 바라보는 쪽 해역 (섬이 시야 가운데에 없을 때) */
function seaSeen(yaw){
  let best = null, bestD = seaDeg(30);
  SEA_ZONES.forEach(Z => { const a = Math.atan2(Z.ax - NEST_POS.x, Z.az - NEST_POS.z); const d = Math.abs(((yaw - a + Math.PI) % (Math.PI * 2) + Math.PI * 2) % (Math.PI * 2) - Math.PI); if (d < bestD){ bestD = d; best = Z; } });
  return best;
}
