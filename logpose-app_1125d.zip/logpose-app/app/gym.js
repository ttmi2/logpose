/* ============================================================
   LOG POSE · 다모였섬: 강자 ZONE (현상금 게시판 뒤 바닷가 · 다모였섬은 어느 해적단 것도 아닌 평화지대예요)
   양양 서퍼 비치 감성 — 나무 데크 · 모래 · 줄전구 · 서핑보드 · 해먹 — 을 해적 배 물건으로.
   기구는 전부 럼통 · 판자 · 닻 · 밧줄 · 선박 부품으로 만들었어요 (무기류 없음).
   가까이 가서 F → 그 기구로 한 세트 운동해요. 움직이면 그만둬요.
   ============================================================ */
const GYM = { x:0, z:-24.6, lights:[], board:null, boardTex:null };
const GYM_KEY = 'logpose.gym';
const gymLog = { get(){ try { const v = JSON.parse(localStorage.getItem(GYM_KEY) || '{}'); return v && typeof v === 'object' ? v : {}; } catch(e){ return {}; } },
  add(id){ const v = this.get(), today = new Date().toDateString(); if (v.day !== today){ v.day = today; v.today = 0; } v.today = (v.today | 0) + 1; v.total = (v.total | 0) + 1; v.by = v.by || {}; v.by[id] = (v.by[id] | 0) + 1; try { localStorage.setItem(GYM_KEY, JSON.stringify(v)); } catch(e){} return v; } };

function buildPirateGym(){
  const G = new THREE.Group(); isleScene.add(G);
  const wood = flat('#a07a50'), woodL = flat('#c9a274'), woodD = flat('#5a3e26'), drift = flat('#8f7a62'), ropeM = flat('#cdb48a'), ironM = M.iron, sail = flat('#efe4cc');
  const m = (geo, mat, x, y, z, parent = G) => { const o = new THREE.Mesh(geo, mat); o.position.set(x, y, z); parent.add(o); return o; };
  const cx = GYM.x, cz = GYM.z;
  /* 바닥: 바랜 판자 데크 (모래 위에 살짝) */
  const deckT = canvasTex(512, 256, (g, w, h) => { const tones = ['#c9a274', '#b8915f', '#d4af80', '#bf9866']; for (let i = 0; i < 16; i++){ g.fillStyle = tones[i % 4]; g.fillRect(i * 32, 0, 32, h); g.fillStyle = 'rgba(60,40,20,.35)'; g.fillRect(i * 32 + 30, 0, 2, h); }
    speckle(g, w, h, 1800, '#6b4a2e', .18); for (let k = 0; k < 40; k++){ g.fillStyle = 'rgba(40,24,10,.5)'; g.fillRect(Math.random() * w, Math.random() * h, 3, 3); } }, [3, 1]);
  m(new THREE.BoxGeometry(18.4, 0.06, 7.8), new THREE.MeshStandardMaterial({ map:deckT, roughness:.95 }), cx, 0.0, cz);
  /* 데크 가장자리 통나무 + 모서리 기둥 (줄전구 걸이) */
  [[-9.2, 0], [9.2, 0]].forEach(([dx]) => m(new THREE.CylinderGeometry(0.12, 0.12, 7.8, 8).rotateX(Math.PI / 2), drift, cx + dx, 0.08, cz));
  const posts = [[-9.1, -3.8], [-3, -3.8], [3, -3.8], [9.1, -3.8], [9.1, 3.7], [-9.1, 3.7]];
  posts.forEach(([dx, dz]) => { m(new THREE.CylinderGeometry(0.09, 0.12, 3.4, 7), drift, cx + dx, 1.7, cz + dz); iBox(cx + dx, cz + dz, 0.18, 0.18); });
  /* 줄전구: 기둥 사이를 늘어지게 잇는 따뜻한 전구들 (양양 바닷가 감성) */
  const bulbM = new THREE.MeshStandardMaterial({ color:'#ffe6b0', emissive:'#ffb860', emissiveIntensity:1.3 });
  const string = (a, b) => { const n = 9; for (let k = 0; k <= n; k++){ const t = k / n, x = a[0] + (b[0] - a[0]) * t, z = a[1] + (b[1] - a[1]) * t, y = 3.2 - Math.sin(t * Math.PI) * 0.55;
      if (k < n){ const t2 = (k + 1) / n, x2 = a[0] + (b[0] - a[0]) * t2, z2 = a[1] + (b[1] - a[1]) * t2, y2 = 3.2 - Math.sin(t2 * Math.PI) * 0.55; const d = new THREE.Vector3(x2 - x, y2 - y, z2 - z), L = d.length(); const w = m(new THREE.CylinderGeometry(0.008, 0.008, L, 3), woodD, (x + x2) / 2, (y + y2) / 2, (z + z2) / 2); w.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), d.normalize()); }
      if (k && k < n){ m(new THREE.SphereGeometry(0.06, 8, 6), bulbM, x, y - 0.08, z); const gl = new THREE.Sprite(new THREE.SpriteMaterial({ map:glowTex, color:'#ffc070', transparent:true, opacity:.45, blending:THREE.AdditiveBlending, depthWrite:false })); gl.scale.set(0.5, 0.5, 1); gl.position.set(x, y - 0.08, z); G.add(gl); GYM.lights.push(gl); } } };
  [[0, 1], [1, 2], [2, 3], [3, 4], [5, 0]].forEach(([i, j]) => string([cx + posts[i][0], cz + posts[i][1]], [cx + posts[j][0], cz + posts[j][1]]));
  const anchor = (s, x, y, z, ry = 0, rz = 0, parent = G) => {
    const A = new THREE.Group(); A.position.set(x, y, z); A.rotation.set(0, ry, rz); parent.add(A);
    m(new THREE.CylinderGeometry(0.045 * s, 0.055 * s, 1.0 * s, 8), ironM, 0, 0.5 * s, 0, A);
    const ring = m(new THREE.TorusGeometry(0.11 * s, 0.025 * s, 6, 14), ironM, 0, 1.08 * s, 0, A); void ring;
    m(new THREE.CylinderGeometry(0.035 * s, 0.035 * s, 0.6 * s, 6).rotateZ(Math.PI / 2), woodD, 0, 0.86 * s, 0, A);
    const arm = m(new THREE.TorusGeometry(0.36 * s, 0.045 * s, 6, 18, Math.PI), ironM, 0, 0.36 * s, 0, A); arm.rotation.z = Math.PI;
    [-1, 1].forEach(sd => { const f = m(new THREE.ConeGeometry(0.09 * s, 0.2 * s, 4), ironM, sd * 0.36 * s, 0.42 * s, 0, A); f.rotation.z = -sd * 0.5; });
    return A;
  };
  const rope = (a, b, r = 0.035, mat = ropeM) => { const d = new THREE.Vector3(b[0] - a[0], b[1] - a[1], b[2] - a[2]), L = d.length(); const o = m(new THREE.CylinderGeometry(r, r, L, 6), mat, (a[0] + b[0]) / 2, (a[1] + b[1]) / 2, (a[2] + b[2]) / 2); o.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), d.normalize()); return o; };
  const coil = (x, y, z, r = 0.3, n = 3) => { for (let k = 0; k < n; k++){ const c = m(new THREE.TorusGeometry(r - k * 0.04, 0.045, 6, 18), ropeM, x, y + k * 0.06, z); c.rotation.x = Math.PI / 2; } };

  /* ① 돛대 밧줄 오르기: 큰 돛대 + 망루 고리 + 매듭 진 굵은 밧줄 */
  const mx0 = cx - 7, mz0 = cz - 2.2;
  m(new THREE.CylinderGeometry(0.14, 0.2, 7, 10), woodD, mx0, 3.5, mz0); iBox(mx0, mz0, 0.3, 0.3);
  m(new THREE.CylinderGeometry(0.55, 0.45, 0.35, 12, 1, true), wood, mx0, 6.6, mz0);
  m(new THREE.CylinderGeometry(0.06, 0.06, 2.0, 6).rotateZ(Math.PI / 2), woodD, mx0, 6.2, mz0 + 0.0);
  rope([mx0 + 0.75, 6.2, mz0], [mx0 + 0.75, 0.3, mz0 + 0.55], 0.05);
  for (let k = 0; k < 6; k++){ const t = k / 6; m(new THREE.SphereGeometry(0.085, 8, 6), ropeM, mx0 + 0.75, 5.7 - t * 5.2, mz0 + t * 0.48); }
  coil(mx0 + 0.75, 0.05, mz0 + 0.75, 0.3, 2);
  /* 깃발: 돛천 배너 (강자 ZONE) */
  const flagT = canvasTex(256, 128, (g, w, h) => { g.fillStyle = '#1f2d4a'; g.fillRect(0, 0, w, h); g.fillStyle = '#f0d49a'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.font = `700 30px ${FD}`; g.font = `700 40px ${FD}`; g.fillText('강자 ZONE', w / 2, h / 2 - 8); g.font = `600 16px ${FB}`; g.fillText('평화의 섬 · 누구나 단련', w / 2, h / 2 + 30); });
  const flag = m(new THREE.PlaneGeometry(1.4, 0.7), new THREE.MeshStandardMaterial({ map:flagT, side:THREE.DoubleSide, roughness:.9 }), mx0 + 0.72, 6.95, mz0); GYM.flag = flag;

  /* ② 활대 턱걸이: 기둥 두 개 + 밧줄 감긴 활대(가로 돛대) */
  const px0 = cx - 3.2, pz0 = cz - 2.9;
  [-1.1, 1.1].forEach(dx => { m(new THREE.CylinderGeometry(0.12, 0.14, 2.7, 8), woodD, px0 + dx, 1.35, pz0); iBox(px0 + dx, pz0, 0.2, 0.2); });
  m(new THREE.CylinderGeometry(0.06, 0.06, 2.6, 8).rotateZ(Math.PI / 2), wood, px0, 2.5, pz0);
  [-0.5, 0.5].forEach(dx => { for (let k = 0; k < 5; k++){ const w = m(new THREE.TorusGeometry(0.07, 0.018, 4, 10), ropeM, px0 + dx + (k - 2) * 0.04, 2.5, pz0); w.rotation.y = Math.PI / 2; } });
  barrel(G, px0 + 1.75, 0, pz0 + 0.2, 0.7); iBox(px0 + 1.75, pz0 + 0.2, 0.32, 0.32);

  /* ③ 닻 덤벨 랙: 럼통 두 개 위에 판자 두 단 + 크기별 작은 닻 · 앞에는 데드리프트용 대왕 닻 */
  const rx0 = cx + 0.6, rz0 = cz - 3.1;
  [-1.1, 1.1].forEach(dx => barrel(G, rx0 + dx, 0, rz0, 0.85));
  m(new THREE.BoxGeometry(3.0, 0.08, 0.6), woodL, rx0, 0.86, rz0); m(new THREE.BoxGeometry(3.0, 0.08, 0.5), woodL, rx0, 1.42, rz0 - 0.05);
  [-0.85, 0.85].forEach(dx => m(new THREE.BoxGeometry(0.08, 0.6, 0.08), woodD, rx0 + dx, 1.13, rz0 - 0.2));
  [[-1.1, 0.9, 0.42], [-0.45, 0.9, 0.5], [0.3, 0.9, 0.58], [1.05, 0.9, 0.66], [-0.8, 1.46, 0.34], [0.2, 1.46, 0.38], [1.0, 1.46, 0.42]].forEach(([dx, y, s], k) => anchor(s, rx0 + dx, y, rz0, k * 0.4));
  iBox(rx0, rz0, 1.55, 0.4);
  const big = anchor(1.3, rx0, 0.06, rz0 + 1.25, 0, Math.PI / 2); void big;
  for (let k = 0; k < 9; k++){ const c = m(new THREE.TorusGeometry(0.07, 0.022, 4, 10), ironM, rx0 + 1.4 + k * 0.12, 0.06, rz0 + 1.25 + Math.sin(k) * 0.08); c.rotation.set(Math.PI / 2, k % 2 ? Math.PI / 2 : 0, 0); }
  iBox(rx0 + 0.2, rz0 + 1.25, 0.9, 0.35);

  /* ④ 계류 기둥 배틀 로프: 쇠 기둥(볼라드)에 걸린 굵은 밧줄 두 가닥이 물결처럼 */
  const bx0 = cx + 4.3, bz0 = cz - 3.2;
  m(new THREE.BoxGeometry(1.0, 0.12, 0.5), ironM, bx0, 0.06, bz0);
  [-0.25, 0.25].forEach(dx => { m(new THREE.CylinderGeometry(0.13, 0.15, 0.6, 10), ironM, bx0 + dx, 0.4, bz0); m(new THREE.CylinderGeometry(0.17, 0.17, 0.07, 10), ironM, bx0 + dx, 0.72, bz0); });
  iBox(bx0, bz0, 0.55, 0.3);
  GYM.ropes = [];
  [-0.35, 0.35].forEach((dx, i) => { const pts = []; for (let k = 0; k <= 10; k++){ const t = k / 10; pts.push([bx0 + dx * (0.4 + t * 0.6), 0.1 + Math.sin(t * Math.PI * 3 + i) * 0.04, bz0 + 0.2 + t * 2.6]); }
    const segs = []; for (let k = 0; k < 10; k++) segs.push(rope(pts[k], pts[k + 1], 0.055)); GYM.ropes.push({ pts, segs, dx, i }); });

  /* ⑤ 캡스턴(닻 감는 기계) 돌리기: 둥근 드럼 + 나무 손잡이 6개 · 빙빙 돌며 밀어요 */
  const kx0 = cx + 7.2, kz0 = cz + 0.2;
  m(new THREE.CylinderGeometry(0.42, 0.5, 0.9, 14), woodD, kx0, 0.45, kz0); m(new THREE.CylinderGeometry(0.5, 0.5, 0.14, 14), wood, kx0, 0.97, kz0);
  for (let k = 0; k < 4; k++){ const r = m(new THREE.TorusGeometry(0.47, 0.025, 4, 18), ironM, kx0, 0.15 + k * 0.22, kz0); r.rotation.x = Math.PI / 2; }
  const bars = new THREE.Group(); bars.position.set(kx0, 0.98, kz0); G.add(bars); GYM.capstan = bars;
  for (let k = 0; k < 6; k++){ const b = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.07, 0.07), woodL); b.position.x = 0.75 + 0.4; const h = new THREE.Group(); h.rotation.y = k / 6 * Math.PI * 2; h.add(b); bars.add(h); }
  iBox(kx0, kz0, 0.55, 0.55);
  rope([kx0, 0.6, kz0 + 0.45], [kx0 - 1.2, 0.06, kz0 + 2.6], 0.04); coil(kx0 - 1.3, 0.05, kz0 + 2.8, 0.32, 3);

  /* ⑥ 럼통 바벨 스쿼트: 노 두 개를 X자로 묶은 거치대 + 노(오어) 바벨 양끝에 작은 럼통 */
  const sx0 = cx - 5.2, sz0 = cz + 2.2;
  [-0.95, 0.95].forEach(dx => { [-1, 1].forEach(sd => { const o = m(new THREE.CylinderGeometry(0.04, 0.05, 1.9, 6), woodL, sx0 + dx, 0.85, sz0); o.rotation.x = sd * 0.35; });
    m(new THREE.BoxGeometry(0.08, 0.28, 0.08), woodD, sx0 + dx, 1.62, sz0 + 0.08); });
  const bar = new THREE.Group(); bar.position.set(sx0, 1.72, sz0); G.add(bar); GYM.squatBar = bar;
  const oar = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, 2.9, 8).rotateZ(Math.PI / 2), woodL); bar.add(oar);
  [-1.32, 1.32].forEach(dx => { const kb = barrel(bar, dx, -0.3, 0, 0.5, true); kb.rotation.set(0, 0, Math.PI / 2); kb.position.set(dx, 0, 0); });
  iBox(sx0, sz0, 1.35, 0.4);
  /* 판자 벤치 (럼통 다리) */
  const bnx = cx - 1.6, bnz = cz + 2.7;
  [-0.85, 0.85].forEach(dx => barrel(G, bnx + dx, 0, bnz, 0.55));
  m(new THREE.BoxGeometry(2.4, 0.08, 0.5), woodL, bnx, 0.58, bnz); iBox(bnx, bnz, 1.25, 0.32);

  /* 벤치 옆 작은 술병 두 개 */
  [[bnx + 1.45, bnz + 0.1, '#3f6f3a'], [bnx + 1.62, bnz - 0.12, '#7a3a24']].forEach(([x, z, c]) => {
    const bm = new THREE.MeshStandardMaterial({ color:c, roughness:.15, metalness:.1, transparent:true, opacity:.85 });
    m(new THREE.CylinderGeometry(0.075, 0.08, 0.26, 10), bm, x, 0.16, z); m(new THREE.CylinderGeometry(0.03, 0.06, 0.1, 10), bm, x, 0.33, z);
    m(new THREE.CylinderGeometry(0.022, 0.022, 0.07, 8), flat('#c9a274'), x, 0.41, z);
    m(new THREE.PlaneGeometry(0.12, 0.08), new THREE.MeshStandardMaterial({ color:'#efe2bf', side:THREE.DoubleSide }), x, 0.17, z + 0.081);
  });
  /* 응원 마스코트 ① 앵무새: 턱걸이 활대 끝에 앉아 있어요 (빨강 · 파랑 · 노랑 깃털) */
  const PR = new THREE.Group(); PR.position.set(px0 + 1.05, 2.56, pz0); PR.rotation.y = 0.4; G.add(PR); GYM.parrot = PR;
  const red = flat('#d23a2e'), blue = flat('#2f6fb8'), yel = flat('#f2c23a');
  const pBody = new THREE.Mesh(new THREE.SphereGeometry(0.13, 12, 10), red); pBody.scale.set(0.85, 1.25, 0.9); pBody.position.y = 0.17; PR.add(pBody);
  const pHead = new THREE.Group(); pHead.position.set(0, 0.36, 0.03); PR.add(pHead); GYM.parrotHead = pHead;
  pHead.add(new THREE.Mesh(new THREE.SphereGeometry(0.095, 12, 10), red));
  const face = new THREE.Mesh(new THREE.SphereGeometry(0.06, 10, 8), flat('#f6efe4')); face.position.set(0, -0.005, 0.06); face.scale.set(1.1, 0.9, 0.5); pHead.add(face);
  [-1, 1].forEach(s => { const e = new THREE.Mesh(new THREE.SphereGeometry(0.016, 6, 5), flat('#15100c')); e.position.set(s * 0.045, 0.02, 0.075); pHead.add(e); });
  const beak = new THREE.Mesh(new THREE.ConeGeometry(0.035, 0.09, 6), flat('#2a2420')); beak.position.set(0, -0.03, 0.105); beak.rotation.x = 2.1; pHead.add(beak);
  GYM.wings = [-1, 1].map(s => { const w = new THREE.Group(); w.position.set(s * 0.1, 0.24, -0.01); PR.add(w); const wm = new THREE.Mesh(new THREE.SphereGeometry(0.1, 10, 8), blue); wm.scale.set(0.35, 1.15, 0.8); wm.position.y = -0.08; w.add(wm); const tip = new THREE.Mesh(new THREE.SphereGeometry(0.06, 8, 6), yel); tip.scale.set(0.35, 1, 0.7); tip.position.y = -0.17; w.add(tip); return w; });
  [-0.03, 0.03].forEach((dx, k) => { const t = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.3, 0.02), k ? blue : red); t.position.set(dx, -0.08, -0.07); t.rotation.x = 0.35; PR.add(t); });
  [-1, 1].forEach(s => { const f = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.012, 0.07, 5), flat('#4a3a30')); f.position.set(s * 0.04, 0.0, 0.02); PR.add(f); });
  /* 응원 마스코트 ② 원숭이: 코코넛 럼통 위에 앉아 박수쳐요 (작은 두건 · 코코넛) */
  const MK = new THREE.Group(); MK.position.set(cx + 5.4, 0.8, cz + 3.0); MK.rotation.y = Math.PI + 0.5; G.add(MK); GYM.monkey = MK;
  const fur = flat('#7a4e2e'), skinM = flat('#e8c49a');
  const mBody = new THREE.Mesh(new THREE.SphereGeometry(0.17, 12, 10), fur); mBody.scale.set(1, 1.15, 0.9); mBody.position.y = 0.2; MK.add(mBody);
  const belly = new THREE.Mesh(new THREE.SphereGeometry(0.12, 10, 8), skinM); belly.position.set(0, 0.18, 0.08); belly.scale.set(0.9, 1, 0.6); MK.add(belly);
  const mHead = new THREE.Group(); mHead.position.set(0, 0.48, 0.02); MK.add(mHead); GYM.monkeyHead = mHead;
  mHead.add(new THREE.Mesh(new THREE.SphereGeometry(0.14, 14, 12), fur));
  const mFace = new THREE.Mesh(new THREE.SphereGeometry(0.1, 12, 10), skinM); mFace.position.set(0, -0.02, 0.07); mFace.scale.set(1.1, 0.9, 0.6); mHead.add(mFace);
  [-1, 1].forEach(s => { const ear = new THREE.Mesh(new THREE.SphereGeometry(0.055, 8, 6), skinM); ear.position.set(s * 0.15, 0.01, 0); ear.scale.set(0.5, 1, 1); mHead.add(ear);
    const e = new THREE.Mesh(new THREE.SphereGeometry(0.02, 6, 5), flat('#15100c')); e.position.set(s * 0.04, 0.02, 0.13); mHead.add(e); });
  const band = new THREE.Mesh(new THREE.TorusGeometry(0.13, 0.025, 6, 18), flat('#c0392b')); band.position.y = 0.06; band.rotation.x = Math.PI / 2 - 0.15; mHead.add(band);
  GYM.mArms = [-1, 1].map(s => { const a = new THREE.Group(); a.position.set(s * 0.13, 0.3, 0.02); MK.add(a); const am = new THREE.Mesh(new THREE.CapsuleGeometry(0.04, 0.2, 4, 8), fur); am.position.y = -0.12; a.add(am); const hand = new THREE.Mesh(new THREE.SphereGeometry(0.045, 8, 6), skinM); hand.position.y = -0.25; a.add(hand); a.rotation.z = s * 0.4; return a; });
  const tail = new THREE.Mesh(new THREE.TorusGeometry(0.16, 0.025, 6, 16, Math.PI * 1.3), fur); tail.position.set(0, 0.12, -0.2); tail.rotation.y = Math.PI / 2; MK.add(tail);
  /* 말풍선 (운동할 때 번갈아 응원해요) */
  const bubble = () => { const c = document.createElement('canvas'); c.width = 384; c.height = 128; const t = new THREE.CanvasTexture(c); if (THREE.sRGBEncoding) t.encoding = THREE.sRGBEncoding; const s = new THREE.Sprite(new THREE.SpriteMaterial({ map:t, transparent:true, depthWrite:false })); s.scale.set(1.5, 0.5, 1); s.visible = false; s.userData = { c, t, text:'' }; G.add(s); return s; };
  GYM.pBubble = bubble(); GYM.mBubble = bubble();
  /* 벤치에 앉기: 두 자리 */
  [-0.55, 0.55].forEach((dx, i) => { ISLE_SPOTS['gymBench' + i] = { x:bnx + dx, z:bnz - 0.05, face:Math.PI, label:'판자 벤치에 앉아 쉬기', near:0.9, use:() => sitDown(0.66, { x:bnx + dx, z:bnz - 0.05, face:Math.PI }) }; });
  /* ⑦ 타륜 유산소: 기둥에 단 커다란 배 키 (빙글빙글) */
  const hx0 = cx + 2.6, hz0 = cz + 2.6;
  m(new THREE.BoxGeometry(0.3, 1.1, 0.3), woodD, hx0, 0.55, hz0); iBox(hx0, hz0, 0.25, 0.25);
  const wheel = new THREE.Group(); wheel.position.set(hx0, 1.25, hz0 - 0.22); G.add(wheel); GYM.wheel = wheel;
  const rim = new THREE.Mesh(new THREE.TorusGeometry(0.5, 0.045, 6, 24), wood); wheel.add(rim);
  wheel.add(new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.1, 0.12, 10).rotateX(Math.PI / 2), M.brass || wood));
  for (let k = 0; k < 8; k++){ const sp = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.03, 1.36, 6), woodL); sp.rotation.z = k / 8 * Math.PI; wheel.add(sp); }

  /* ⑧ 화물 그물 오르기 벽: 판자 틀 + 밧줄 그물 */
  const nx0 = cx + 7.6, nz0 = cz - 2.6;
  [-1, 1].forEach(sd => { m(new THREE.CylinderGeometry(0.1, 0.12, 3.2, 7), drift, nx0 + sd * 0.0, 1.6, nz0 + sd * 0.95); });
  m(new THREE.BoxGeometry(0.16, 0.16, 2.1), woodD, nx0, 3.1, nz0);
  for (let k = 0; k < 7; k++){ rope([nx0, 0.25 + k * 0.45, nz0 - 0.9], [nx0, 0.25 + k * 0.45, nz0 + 0.9], 0.018); }
  for (let k = 0; k < 6; k++){ rope([nx0, 0.15, nz0 - 0.8 + k * 0.32], [nx0, 3.0, nz0 - 0.8 + k * 0.32], 0.018); }
  iBox(nx0, nz0, 0.25, 1.05);

  /* 서퍼 비치 소품: 판자 서핑보드 거치대 · 해먹 · 돛천 그늘 · 코코넛 럼통 · 칠판 */
  const sbx = cx - 8.3, sbz = cz + 0.6;
  m(new THREE.BoxGeometry(0.1, 1.2, 2.0), woodD, sbx - 0.35, 0.6, sbz);
  ['#2f8fb0', '#e8873a', '#efe4cc', '#c0392b'].forEach((c, k) => { const b = m(new THREE.CapsuleGeometry(0.2, 1.5, 4, 10), flat(c), sbx, 1.05, sbz - 0.7 + k * 0.47); b.scale.set(1, 1, 0.22); b.rotation.set(0, Math.PI / 2, 0.22); b.rotation.order = 'YXZ';
    const st = m(new THREE.BoxGeometry(0.03, 1.6, 0.012), flat('#f6efe0'), sbx + 0.01, 1.05, sbz - 0.7 + k * 0.47); st.rotation.z = 0.22; });
  iBox(sbx, sbz, 0.45, 1.05);
  /* 돛천 그늘막 (데크 가운데 위) */
  const shade = m(new THREE.PlaneGeometry(5.4, 3.0, 8, 4), new THREE.MeshStandardMaterial({ color:'#efe4cc', side:THREE.DoubleSide, roughness:.95, transparent:true, opacity:.92 }), cx, 3.15, cz - 1.0);
  shade.rotation.x = -Math.PI / 2 + 0.12; { const pa = shade.geometry.attributes.position; for (let i = 0; i < pa.count; i++){ const u = pa.getX(i) / 2.7, v = pa.getY(i) / 1.5; pa.setZ(i, -0.35 * (1 - u * u) * (1 - v * v)); } shade.geometry.computeVertexNormals(); }
  [[-3, -3.8], [3, -3.8]].forEach(([dx, dz]) => rope([cx + dx, 3.3, cz + dz], [cx + dx * 0.9, 3.2, cz - 2.4], 0.015));
  /* 해먹: 기둥과 야자수 사이 */
  const hm = m(new THREE.PlaneGeometry(2.2, 0.8, 10, 2), new THREE.MeshStandardMaterial({ color:'#d96a4a', side:THREE.DoubleSide, roughness:.9 }), cx - 10.2, 1.0, cz + 2.3);
  hm.rotation.set(-Math.PI / 2, 0, 0.5); { const pa = hm.geometry.attributes.position; for (let i = 0; i < pa.count; i++){ const u = pa.getX(i) / 1.1; pa.setZ(i, -0.35 * (1 - u * u)); } hm.geometry.computeVertexNormals(); }
  /* 코코넛 럼통 (단백질 보충소) */
  barrel(G, cx + 5.4, 0, cz + 3.0, 0.8); iBox(cx + 5.4, cz + 3.0, 0.36, 0.36);
  for (let k = 0; k < 4; k++){ m(new THREE.SphereGeometry(0.12, 8, 6), flat('#6b4a2e'), cx + 5.25 + (k % 2) * 0.28, 0.86, cz + 2.88 + Math.floor(k / 2) * 0.24); }
  /* 칠판: 오늘의 루틴 + 내 기록 (세트 끝날 때마다 다시 써요) */
  GYM.boardCanvas = document.createElement('canvas'); GYM.boardCanvas.width = 512; GYM.boardCanvas.height = 384;
  GYM.boardTex = new THREE.CanvasTexture(GYM.boardCanvas); if (THREE.sRGBEncoding) GYM.boardTex.encoding = THREE.sRGBEncoding;
  const easel = new THREE.Group(); easel.position.set(cx + 8.4, 0, cz + 2.4); easel.rotation.y = -Math.PI / 2 - 0.5; G.add(easel);
  [-0.55, 0.55].forEach(dx => { const l = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.04, 2.0, 5), woodD); l.position.set(dx, 1.0, -0.1); l.rotation.x = -0.1; easel.add(l); });
  const bd = new THREE.Mesh(new THREE.PlaneGeometry(1.3, 0.98), new THREE.MeshStandardMaterial({ map:GYM.boardTex, roughness:.95 })); bd.position.set(0, 1.35, 0); easel.add(bd);
  const frame = new THREE.Mesh(new THREE.BoxGeometry(1.4, 1.08, 0.04), woodD); frame.position.set(0, 1.35, -0.03); easel.add(frame);
  iBox(cx + 8.4, cz + 2.4, 0.5, 0.5); gymBoard();
  /* 입구 간판 */
  signBoard('강자 ZONE', '평화의 섬 · 럼통 · 판자 · 닻 · 밧줄로 단련해요', cx + 9.9, 1.9, cz + 4.6, Math.PI / 4, 2.8, true); iBox(cx + 9.9, cz + 4.6, 1.1, 0.3);
  gymSpots();
}
function gymBoard(){
  const c = GYM.boardCanvas, g = c && c.getContext('2d'); if (!g) return;
  const W = c.width, H = c.height, L = gymLog.get(), today = L.day === new Date().toDateString() ? (L.today | 0) : 0;
  g.fillStyle = '#23302a'; g.fillRect(0, 0, W, H); speckle(g, W, H, 1200, '#e8f0ea', .05);
  g.fillStyle = '#f2efe4'; g.textAlign = 'left'; g.textBaseline = 'top';
  g.font = `700 40px ${FD}`; g.fillText('강자 ZONE 루틴', 28, 22);
  g.font = `500 24px ${FB}`; ['① 돛대 밧줄 오르기', '② 활대 턱걸이', '③ 닻 덤벨 컬', '④ 볼라드 배틀 로프', '⑤ 캡스턴 밀기', '⑥ 럼통 바벨 스쿼트', '⑦ 타륜 돌리기'].forEach((t, i) => g.fillText(t, 34, 86 + i * 34));
  g.fillStyle = '#f0d49a'; g.font = `700 28px ${FD}`; g.textAlign = 'right'; g.fillText(`오늘 ${today}세트`, W - 28, 300); g.font = `500 20px ${FB}`; g.fillStyle = '#cfd8d0'; g.fillText(`누적 ${L.total | 0}세트`, W - 28, 338);
  if (GYM.boardTex) GYM.boardTex.needsUpdate = true;
}
/* ---------- 운동하기 ---------- */
const GYM_MOVES = {
  climb:{ name:'돛대 밧줄 오르기', pose:'gymClimb', tip:'팔로 끌어 올리고 다리로 감아요. 꼭대기 망루까지!' },
  pull:{ name:'활대 턱걸이', pose:'gymPull', tip:'턱이 활대를 넘을 때까지. 반동 없이!' },
  curl:{ name:'닻 덤벨 컬', pose:'gymLift', tip:'팔꿈치는 옆구리에 붙이고, 천천히 내려요.' },
  rope:{ name:'볼라드 배틀 로프', pose:'gymRope', tip:'양팔 번갈아 파도를 만들어요. 숨 고르기 잊지 말고!' },
  capstan:{ name:'캡스턴 밀기', pose:'gymPush', tip:'손잡이를 밀며 빙글빙글. 닻을 끌어 올리는 기분으로.' },
  squat:{ name:'럼통 바벨 스쿼트', pose:'gymSquat', tip:'허리는 곧게, 엉덩이는 뒤로. 럼통이 출렁여도 침착하게.' },
  wheel:{ name:'타륜 돌리기', pose:'gymWheel', tip:'폭풍 속 항해처럼 힘차게 돌려요. 유산소!' },
};
let gymRun = null;
function startGym(id, at){
  const M2 = GYM_MOVES[id]; if (!M2 || uiOpen) return;
  if (player.pose === 'sit') standUp();
  player.x = at.x; player.z = at.z; player.r = at.face; player.pose = M2.pose; player.gymT = 0; player.gymAt = at;
  const run = gymRun = { id, t0:performance.now() };
  toast(`<strong>${M2.name}</strong> 시작! ${M2.tip}`, 2600);
  setTimeout(() => {
    if (gymRun !== run || player.pose !== M2.pose) return;
    player.pose = null; gymRun = null; const L = gymLog.add(id); gymBoard();
    toast(`💪 <strong>${M2.name}</strong> 1세트 끝! 오늘 ${L.today}세트 · 누적 ${L.total}세트`, 2800);
  }, 6000);
}
function gymSpots(){
  const c = (dx, dz) => ({ x:GYM.x + dx, z:GYM.z + dz });
  const S = {
    gymClimb:{ ...c(-6.25, -1.65), face:Math.PI, label:'돛대 밧줄 오르기', near:1.1, move:'climb' },
    gymPull:{ ...c(-3.2, -2.35), face:Math.PI, label:'활대 턱걸이', near:1.1, move:'pull' },
    gymCurl:{ ...c(0.6, -1.15), face:Math.PI, label:'닻 덤벨 컬', near:1.2, move:'curl' },
    gymRope:{ ...c(4.3, -0.15), face:Math.PI, label:'볼라드 배틀 로프', near:1.2, move:'rope' },
    gymCap:{ ...c(5.75, 0.2), face:Math.PI / 2, label:'캡스턴 밀기', near:1.1, move:'capstan' },
    gymSquat:{ ...c(-5.2, 1.55), face:0, label:'럼통 바벨 스쿼트', near:1.1, move:'squat' },
    gymWheel:{ ...c(2.6, 2.0), face:0, label:'타륜 돌리기', near:1.0, move:'wheel' },
  };
  Object.entries(S).forEach(([k, s]) => { ISLE_SPOTS[k] = { x:s.x, z:s.z, face:s.face, label:s.label, near:s.near, use:() => startGym(s.move, s) }; });
}
/* 매 프레임 (다모였섬 ambient 에서): 기구 움직임 · 운동 자세 */
function gymStep(dt, time){
  if (!GYM.wheel) return;
  gymMascots(dt, time);
  if (GYM.flag) GYM.flag.rotation.y = Math.sin(time * 1.4) * 0.15;
  GYM.lights.forEach((l, i) => { l.material.opacity = 0.35 + Math.sin(time * 2 + i) * 0.08; });
  const p = player.pose;
  GYM.wheel.rotation.z += (p === 'gymWheel' ? 3.2 : 0.05) * dt;
  if (p === 'gymPush' && player.gymAt){ GYM.capstan.rotation.y += 0.9 * dt; const a = GYM.capstan.rotation.y + Math.PI / 2, R = 1.45; player.x = GYM.capstan.position.x + Math.cos(-a) * R; player.z = GYM.capstan.position.z + Math.sin(-a) * R; player.r = -a + Math.PI; }
  if (GYM.squatBar){ const up = p === 'gymSquat'; GYM.squatBar.position.x = up ? player.x - Math.sin(player.r) * 0.16 : GYM.x - 5.2; GYM.squatBar.position.z = up ? player.z - Math.cos(player.r) * 0.16 : GYM.z + 2.2; GYM.squatBar.position.y = up ? 1.02 - (Math.sin(time * 3) * 0.5 + 0.5) * 0.18 : 1.72; GYM.squatBar.rotation.y = up ? player.r : 0; }
  if (GYM.ropes){ const on = p === 'gymRope'; GYM.ropes.forEach(R => { const pts = R.pts.map(([x, y, z], k) => [x, 0.1 + (on ? Math.sin(time * 12 - k * 0.9 + R.i * Math.PI) * 0.18 * (k / 10) : Math.sin(k + R.i) * 0.04), z]);
      R.segs.forEach((s, k) => { const a = pts[k], b = pts[k + 1]; s.position.set((a[0] + b[0]) / 2, (a[1] + b[1]) / 2, (a[2] + b[2]) / 2); const d = new THREE.Vector3(b[0] - a[0], b[1] - a[1], b[2] - a[2]).normalize(); s.quaternion.setFromUnitVectors(_gymUp, d); }); }); }
}
const _gymUp = new THREE.Vector3(0, 1, 0);
const CHEERS = { parrot:['끼룩! 한 개 더!', '강자 최고!', '선장님 멋져요!', '버텨! 버텨!', '끼룩끼룩 파이팅!'], monkey:['우끼끼! 힘내!', '코코넛 줄게!', '오늘 3세트 가자!', '자세 좋아요!', '우끼! 거의 다 왔어!'], idleP:['운동하러 왔어?', '끼룩! 근손실 조심!'], idleM:['우끼? 같이 운동해!', '코코넛 먹을래?'] };
function setBubble(sp, text, x, y, z){
  if (!sp) return; sp.position.set(x, y, z);
  if (sp.userData.text === text){ sp.visible = !!text; return; }
  sp.userData.text = text; sp.visible = !!text; if (!text) return;
  const c = sp.userData.c, g = c.getContext('2d'), W = c.width, H = c.height; g.clearRect(0, 0, W, H);
  g.fillStyle = 'rgba(255,250,240,.96)'; g.strokeStyle = '#3a2616'; g.lineWidth = 5;
  const r = 34; g.beginPath(); g.moveTo(r + 6, 6); g.arcTo(W - 6, 6, W - 6, H - 30, r); g.arcTo(W - 6, H - 30, 6, H - 30, r); g.lineTo(W / 2 + 18, H - 30); g.lineTo(W / 2, H - 6); g.lineTo(W / 2 - 18, H - 30); g.arcTo(6, H - 30, 6, 6, r); g.arcTo(6, 6, W - 6, 6, r); g.closePath(); g.fill(); g.stroke();
  g.fillStyle = '#2a1a0e'; g.textAlign = 'center'; g.textBaseline = 'middle'; let fs = 40; do { g.font = `700 ${fs}px ${FB}`; fs -= 2; } while (g.measureText(text).width > W - 40 && fs > 18); g.fillText(text, W / 2, (H - 24) / 2);
  sp.userData.t.needsUpdate = true;
}
function gymMascots(dt, time){
  if (!GYM.parrot) return;
  const working = (player.pose || '').startsWith('gym'), near = Math.hypot(player.x - GYM.x, player.z - GYM.z) < 9;
  /* 앵무새: 고개 까딱 · 날개 퍼덕 (운동 중엔 신나게) */
  const fl = working ? Math.abs(Math.sin(time * 14)) * 0.9 : Math.max(0, Math.sin(time * 0.7)) > 0.97 ? Math.abs(Math.sin(time * 14)) * 0.6 : 0;
  GYM.wings.forEach((w, i) => { w.rotation.z = (i ? -1 : 1) * fl; });
  GYM.parrotHead.rotation.x = Math.sin(time * (working ? 7 : 1.6)) * (working ? 0.35 : 0.15); GYM.parrotHead.rotation.y = Math.sin(time * 0.9) * 0.5;
  GYM.parrot.position.y = 2.56 + (working ? Math.abs(Math.sin(time * 7)) * 0.08 : 0);
  /* 원숭이: 박수 · 콩콩 뛰기 */
  const clap = working ? Math.sin(time * 10) : Math.sin(time * 1.2) * 0.2;
  GYM.mArms.forEach((a, i) => { const s = i ? 1 : -1; a.rotation.z = s * (working ? 0.25 + (clap * 0.5 + 0.5) * 0.9 : 0.4); a.rotation.x = working ? -1.3 : -0.2; });
  GYM.monkey.position.y = 0.8 + (working ? Math.abs(Math.sin(time * 5)) * 0.12 : 0); GYM.monkeyHead.rotation.z = Math.sin(time * (working ? 6 : 1)) * 0.15;
  /* 말풍선: 운동 중엔 2초마다 번갈아 응원 · 가까이 오면 가끔 말 걸기 */
  const k = Math.floor(time / 2.2), pp = GYM.parrot.position, mp = GYM.monkey.position;
  let pt = '', mt = '';
  if (working){ if (k % 2 === 0) pt = CHEERS.parrot[(k / 2 | 0) % CHEERS.parrot.length]; else mt = CHEERS.monkey[(k / 2 | 0) % CHEERS.monkey.length]; }
  else if (near){ const q = Math.floor(time / 4) % 6; if (q === 0) pt = CHEERS.idleP[Math.floor(time / 24) % 2]; else if (q === 3) mt = CHEERS.idleM[Math.floor(time / 24) % 2]; }
  setBubble(GYM.pBubble, pt, pp.x, pp.y + 0.85, pp.z); setBubble(GYM.mBubble, mt, mp.x, mp.y + 1.05, mp.z);
  /* 손에 든 닻 덤벨 (컬 할 때만) */
  const pm = player.mesh; if (!pm) return;
  if (!pm.userData.gymBells){ pm.userData.gymBells = [pm.userData.arm, pm.userData.rArm].map(a => { const b = new THREE.Group(); b.position.set(0, -0.38, 0.02); b.rotation.x = Math.PI; a.add(b);
      const ir = M.iron; const sh = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.022, 0.3, 6), ir); sh.position.y = 0.1; b.add(sh);
      const st = new THREE.Mesh(new THREE.CylinderGeometry(0.014, 0.014, 0.16, 5).rotateZ(Math.PI / 2), flat('#5a3e26')); st.position.y = 0.2; b.add(st);
      const arm = new THREE.Mesh(new THREE.TorusGeometry(0.1, 0.018, 5, 12, Math.PI), ir); arm.rotation.z = Math.PI; arm.position.y = 0.0; b.add(arm);
      [-1, 1].forEach(s => { const f = new THREE.Mesh(new THREE.ConeGeometry(0.03, 0.06, 4), ir); f.position.set(s * 0.1, 0.02, 0); f.rotation.z = -s * 0.5; b.add(f); });
      b.visible = false; return b; }); }
  const show = player.pose === 'gymLift'; pm.userData.gymBells.forEach(b => { b.visible = show; });
}
