/* ============================================================
   LOG POSE · 다모였섬 4단계: 현상금 게시판 (+ 주점 '현상금 선장')
   광장 북쪽, 지붕 얹은 큰 양면 게시판 (가로 14m)
   앞면 왼쪽: 이번 주 인기 캐릭터 순위 (라프텔 선장이 은화로 응원 → 순위가 올라요)
   앞면 오른쪽: 현상금 수배서 (모인 은화 = 현상금 · 1위가 가장 크게) + 지난 주 최고 현상금
   뒷면: 아직 비워 둬요 (무엇을 붙일지 고민 중)
   주점 안 벽: 현상금 선장 (시장에서 번 은화 순위 · 라프텔 선장만)
   규칙: 한 번에 10은화 · 하루 100은화까지 · 매주 월요일 0시(한국 시간) 새로 시작
   ============================================================ */
const CHEER_STEP = 10, CHEER_DAY = 100;
const BD = { front:null, frontTex:null, wall:null, wallTex:null, data:null, caps:[] };
const charKey = (workId, name) => `${workId}:${name}`;
function charOf(key){ const i = key.indexOf(':'), w = LPData.get(key.slice(0, i)); return w ? { key, name:key.slice(i + 1), work:w } : null; }
const todayKST = () => { const k = new Date(Date.now() + 9 * 3600e3); return k.toISOString().slice(0, 10); };
function cheerLeft(){ const s = shopData(), c = (LPProfile.get() || {}).shop || {}, ch = c.cheer || {}; return CHEER_DAY - (ch.day === todayKST() ? ch.spent | 0 : 0); }
const silverFmt = n => Number(n || 0).toLocaleString('ko-KR');

/* ---------- 수배서 한 장 그리기 (공식 그림 없이: 이름 · 작품 · 그린 실루엣) ---------- */
function drawPoster(g, x, y, w, h, o){
  g.save(); g.translate(x, y); g.rotate(o.tilt || 0);
  g.fillStyle = '#efe2bf'; g.fillRect(-w / 2, -h / 2, w, h); speckle(g, w, h, 300, '#8a6a48', .12);
  g.strokeStyle = 'rgba(90,64,40,.55)'; g.lineWidth = Math.max(2, w * 0.015); g.strokeRect(-w / 2 + w * .05, -h / 2 + w * .05, w * .9, h - w * .1);
  g.fillStyle = '#3a2616'; g.textAlign = 'center'; g.textBaseline = 'middle';
  g.font = `700 ${w * 0.15}px ${FD}`; g.fillText(o.rank === 'last' ? '지난 주 1위' : '현상수배', 0, -h / 2 + h * 0.1);
  /* 그림 칸: 작품 색 배경 + 실루엣 */
  const px = -w * .38, py = -h / 2 + h * .18, pw = w * .76, ph = h * .42;
  if (o.photo && o.photo.complete && o.photo.naturalWidth){   /* 선장이 올린 사진 (가운데 기준으로 꽉 차게) */
    const im = o.photo, k = Math.max(pw / im.naturalWidth, ph / im.naturalHeight), dw = im.naturalWidth * k, dh = im.naturalHeight * k;
    g.save(); g.beginPath(); g.rect(px, py, pw, ph); g.clip(); g.drawImage(im, px + (pw - dw) / 2, py + (ph - dh) / 2, dw, dh);
    g.fillStyle = 'rgba(120,80,40,.18)'; g.fillRect(px, py, pw, ph); g.restore();   /* 수배서 종이 느낌으로 살짝 바래게 */
  } else if (o.look){ captainArt(g, px, py, pw, ph, o.look); }   /* 내 캐릭터 모습 (옷 · 모자 · 안경 그대로) */
  else {
    g.fillStyle = `hsl(${o.hue}, 35%, 72%)`; g.fillRect(px, py, pw, ph);
    g.fillStyle = `hsl(${o.hue}, 30%, 30%)`;
    g.beginPath(); g.arc(0, py + ph * .42, pw * .17, 0, 7); g.fill();
    g.beginPath(); g.moveTo(-pw * .36, py + ph); g.quadraticCurveTo(-pw * .32, py + ph * .66, 0, py + ph * .64); g.quadraticCurveTo(pw * .32, py + ph * .66, pw * .36, py + ph); g.closePath(); g.fill();
    g.font = `700 ${w * 0.09}px ${FB}`; g.fillStyle = 'rgba(255,255,255,.85)'; g.fillText('?', 0, py + ph * .42);
  }
  g.strokeStyle = 'rgba(58,38,22,.55)'; g.lineWidth = Math.max(1.5, w * 0.008); g.strokeRect(px, py, pw, ph);
  /* 이름 · 작품 · 현상금 */
  const fit = (t, size, max, wt = 700, fam = FD) => { let s = size; do { g.font = `${wt} ${s}px ${fam}`; s -= 2; } while (g.measureText(t).width > max && s > 10); };
  g.fillStyle = '#2a1a0e'; fit(o.name, w * 0.13, w * .86); g.fillText(o.name, 0, py + ph + h * .08);
  g.fillStyle = '#6b4a2e'; fit(o.work, w * 0.07, w * .86, 600, FB); g.fillText(o.work, 0, py + ph + h * .15);
  g.fillStyle = '#8a2a1c'; fit(`현상금 ${silverFmt(o.amt)} 은화`, w * 0.1, w * .86); g.fillText(`현상금 ${silverFmt(o.amt)} 은화`, 0, h / 2 - h * .09);
  if (o.rank && o.rank !== 'last'){ const bx = px + pw - w * .08, by = py + w * .08; g.fillStyle = o.rank === 1 ? '#c9a15e' : '#5a4030'; g.beginPath(); g.arc(bx, by, w * .08, 0, 7); g.fill(); g.strokeStyle = '#efe2bf'; g.lineWidth = Math.max(2, w * .012); g.stroke(); g.fillStyle = o.rank === 1 ? '#2a1a0e' : '#fff'; g.font = `700 ${w * .09}px ${FB}`; g.fillText(String(o.rank), bx, by + 1); }   /* 순위: 그림 칸 오른쪽 위 */
  /* 압정 */
  g.fillStyle = '#8a2a1c'; g.beginPath(); g.arc(0, -h / 2 + w * .03, w * .025, 0, 7); g.fill();
  g.restore();
}

/* ---------- 게시판 양옆: LOG POSE 오리지널 해적 수배서 4장 (선장 캐릭터 모양을 본떠 직접 그린 그림) ----------
   특정 작품 · 캐릭터를 따라 그리지 않았어요. 둥근 머리 · 하얀 얼굴 · 쏙 들어간 눈 · 손목 로그포스 = 우리 선장 캐릭터 그대로 */
const WANTED_PIRATES = [
  { name:'외눈의 카이', title:'검은 삼각모 선장', fame:'INFAMOUS', amt:88000000, body:'#a82a22', shirt:'#f2ece0', pattern:'vest', hat:'tricorn', hatCol:'#1d1612', trim:'#c9a15e', patch:true, bg:'#d9c39a', slot:[150, 172, -0.05] },
  { name:'폭풍의 미르', title:'바람을 읽는 항해사', fame:'FAMOUS', amt:56000000, body:'#2f6f73', shirt:'#f4efe4', pattern:'jacket', hat:'flower', hatCol:'#e58fb0', hair:'#7a3b2e', female:true, bg:'#cfe0d8', slot:[150, 452, 0.04] },
  { name:'국자잡이 두부', title:'갑판 위 요리사', fame:'FAMOUS', amt:12000000, body:'#f4f1ea', shirt:'#24365a', pattern:'stripe', hat:'bandana', hatCol:'#c0392b', ladle:true, bg:'#e6d6b0', slot:[1250, 168, 0.05] },
  { name:'검은 돛의 렌', title:'그림자 함대 제독', fame:'INFAMOUS', amt:150000000, body:'#1f2d4a', shirt:'#ece6d8', pattern:'coat', hat:'feather', hatCol:'#2a1a2e', trim:'#c9a15e', scar:true, bg:'#c9c2b4', slot:[1250, 450, -0.04] },
];
function drawPirateArt(g, x, y, w, h, P){
  g.save(); g.beginPath(); g.rect(x, y, w, h); g.clip();
  /* 배경: 바다 수평선 + 햇살 */
  const bg = g.createLinearGradient(0, y, 0, y + h); bg.addColorStop(0, P.bg); bg.addColorStop(0.62, P.bg); bg.addColorStop(0.62, 'rgba(90,120,130,.35)'); bg.addColorStop(1, 'rgba(60,90,100,.45)');
  g.fillStyle = bg; g.fillRect(x, y, w, h);
  g.strokeStyle = 'rgba(255,255,255,.25)'; g.lineWidth = 2; for (let k = 0; k < 9; k++){ const a = -Math.PI/2 + (k - 4)*0.22; g.beginPath(); g.moveTo(x + w/2, y + h*0.42); g.lineTo(x + w/2 + Math.cos(a)*w, y + h*0.42 + Math.sin(a)*w); g.stroke(); }
  const cx = x + w/2, s = w / 112, ink = "#3a2616";
  g.lineJoin = 'round'; g.lineCap = 'round';
  /* 여자 캐릭터: 머리 뒤로 흘러내리는 긴 웨이브 머리 */
  const hy = y + h*0.5, hr = 27*s;
  if (P.female){ g.fillStyle = P.hair; g.beginPath(); g.moveTo(cx - hr*1.05, hy - hr*0.2); g.bezierCurveTo(cx - hr*1.5, hy + hr*1.0, cx - hr*1.0, hy + hr*1.9, cx - hr*1.3, hy + hr*2.4); g.lineTo(cx + hr*1.3, hy + hr*2.4); g.bezierCurveTo(cx + hr*1.0, hy + hr*1.9, cx + hr*1.5, hy + hr*1.0, cx + hr*1.05, hy - hr*0.2); g.closePath(); g.fill(); g.strokeStyle = 'rgba(0,0,0,.25)'; g.lineWidth = 1.5*s; g.stroke(); }
  /* 몸: 통통한 둥근 몸통 (옷 색 · 무늬) */
  const by = y + h*0.88, bw = 40*s, bh = 34*s;
  g.fillStyle = P.body; g.beginPath(); g.ellipse(cx, by + bh*0.35, bw, bh, 0, Math.PI, 0); g.lineTo(cx + bw, y + h); g.lineTo(cx - bw, y + h); g.closePath(); g.fill(); g.strokeStyle = ink; g.lineWidth = 2*s; g.stroke();
  g.save(); g.clip();
  if (P.pattern === 'stripe'){ g.fillStyle = P.shirt; for (let k = 0; k < 8; k++) g.fillRect(cx - bw, by - bh*0.7 + k*7*s, bw*2, 3*s); }
  if (P.pattern === 'vest'){ g.fillStyle = P.shirt; g.beginPath(); g.moveTo(cx - 9*s, by - bh); g.lineTo(cx + 9*s, by - bh); g.lineTo(cx + 5*s, y + h); g.lineTo(cx - 5*s, y + h); g.fill(); g.fillStyle = P.trim; g.fillRect(cx - bw, by + 14*s, bw*2, 5*s); g.fillStyle = '#f0d49a'; g.fillRect(cx - 4*s, by + 13*s, 8*s, 7*s); }
  if (P.pattern === 'coat'){ g.fillStyle = P.shirt; g.beginPath(); g.moveTo(cx - 7*s, by - bh); g.lineTo(cx + 7*s, by - bh); g.lineTo(cx, by + 6*s); g.fill(); g.fillStyle = P.trim; [-1, 1].forEach(sd => { for (let k = 0; k < 3; k++){ g.beginPath(); g.arc(cx + sd*9*s, by + 6*s + k*8*s, 2.2*s, 0, 7); g.fill(); } }); g.strokeStyle = P.trim; g.lineWidth = 2*s; g.beginPath(); g.moveTo(cx - bw*0.9, by - 4*s); g.lineTo(cx - 12*s, by + 2*s); g.moveTo(cx + bw*0.9, by - 4*s); g.lineTo(cx + 12*s, by + 2*s); g.stroke(); }
  if (P.pattern === 'jacket'){ g.fillStyle = P.shirt; g.beginPath(); g.moveTo(cx - 8*s, by - bh); g.lineTo(cx + 8*s, by - bh); g.lineTo(cx + 3*s, y + h); g.lineTo(cx - 3*s, y + h); g.fill(); g.strokeStyle = '#c9a15e'; g.lineWidth = 2*s; g.beginPath(); g.moveTo(cx - 8*s, by - bh*0.8); g.lineTo(cx - 3*s, y + h); g.moveTo(cx + 8*s, by - bh*0.8); g.lineTo(cx + 3*s, y + h); g.stroke(); g.fillStyle = '#e58fb0'; g.beginPath(); g.moveTo(cx - 6*s, by - bh*0.75); g.lineTo(cx, by - bh*0.55); g.lineTo(cx + 6*s, by - bh*0.75); g.lineTo(cx, by - bh*0.35); g.fill(); }
  g.restore();
  /* 팔 + 손목 로그포스 (우리 선장의 상징) */
  const ax = cx - bw*0.92, ay = by + 4*s;
  g.fillStyle = P.body; g.strokeStyle = ink; g.lineWidth = 2*s; g.beginPath(); g.ellipse(ax, ay + 6*s, 9*s, 15*s, 0.35, 0, 7); g.fill(); g.stroke();
  g.fillStyle = '#f4f2f7'; g.beginPath(); g.arc(ax - 4*s, ay + 19*s, 6.5*s, 0, 7); g.fill(); g.stroke();
  g.fillStyle = '#6a4628'; g.fillRect(ax - 11*s, ay + 11*s, 13*s, 4*s);
  const gl = g.createRadialGradient(ax - 4.5*s, ay + 12*s, 0, ax - 4.5*s, ay + 12*s, 9*s); gl.addColorStop(0, 'rgba(127,211,224,.9)'); gl.addColorStop(1, 'rgba(127,211,224,0)'); g.fillStyle = gl; g.beginPath(); g.arc(ax - 4.5*s, ay + 12*s, 9*s, 0, 7); g.fill();
  g.fillStyle = '#c9a15e'; g.beginPath(); g.arc(ax - 4.5*s, ay + 12*s, 3.6*s, 0, 7); g.fill(); g.fillStyle = '#bfeaf2'; g.beginPath(); g.arc(ax - 4.5*s, ay + 12*s, 2.5*s, 0, 7); g.fill();
  if (P.ladle){ const rx = cx + bw*0.95, ry = by; g.strokeStyle = '#8a8f96'; g.lineWidth = 3*s; g.beginPath(); g.moveTo(rx, ry + 12*s); g.lineTo(rx + 8*s, ry - 22*s); g.stroke(); g.fillStyle = '#9aa0a6'; g.beginPath(); g.ellipse(rx + 9*s, ry - 26*s, 7*s, 5*s, -0.3, 0, 7); g.fill(); g.strokeStyle = ink; g.lineWidth = 1.5*s; g.stroke();
    g.fillStyle = P.body; g.strokeStyle = ink; g.lineWidth = 2*s; g.beginPath(); g.arc(rx + 1*s, ry + 10*s, 6.5*s, 0, 7); g.fill(); g.stroke(); }
  /* 머리: 크고 동그란 하얀 얼굴 */
  const fg = g.createRadialGradient(cx - hr*0.35, hy - hr*0.4, hr*0.2, cx, hy, hr*1.05); fg.addColorStop(0, '#ffffff'); fg.addColorStop(1, '#ddd9e4');
  g.fillStyle = fg; g.beginPath(); g.ellipse(cx, hy, hr*1.04, hr*0.97, 0, 0, 7); g.fill(); g.strokeStyle = ink; g.lineWidth = 2.2*s; g.stroke();
  /* 앞머리 (여자) */
  if (P.female){ g.fillStyle = P.hair; g.beginPath(); g.moveTo(cx - hr*1.02, hy - hr*0.05); g.quadraticCurveTo(cx - hr*0.9, hy - hr*1.1, cx, hy - hr*0.98); g.quadraticCurveTo(cx + hr*0.9, hy - hr*1.1, cx + hr*1.02, hy - hr*0.05); g.quadraticCurveTo(cx + hr*0.6, hy - hr*0.55, cx + hr*0.1, hy - hr*0.45); g.quadraticCurveTo(cx - hr*0.2, hy - hr*0.62, cx - hr*0.55, hy - hr*0.4); g.quadraticCurveTo(cx - hr*0.85, hy - hr*0.4, cx - hr*1.02, hy - hr*0.05); g.fill(); }
  /* 눈: 쏙 들어간 짙은 타원 */
  const ey = hy + hr*0.02;
  const eye = ex => { g.fillStyle = '#2e2b34'; g.beginPath(); g.ellipse(ex, ey, 3.4*s, 4.6*s, 0, 0, 7); g.fill(); g.fillStyle = 'rgba(255,255,255,.85)'; g.beginPath(); g.arc(ex + 1.1*s, ey - 1.6*s, 1.1*s, 0, 7); g.fill(); };
  if (P.patch){ eye(cx + 10*s); g.fillStyle = '#15100c'; g.beginPath(); g.ellipse(cx - 10*s, ey, 7.5*s, 6.5*s, 0, 0, 7); g.fill(); g.strokeStyle = '#15100c'; g.lineWidth = 2*s; g.beginPath(); g.moveTo(cx - hr*1.0, hy - hr*0.45); g.lineTo(cx + hr*0.95, hy + hr*0.35); g.stroke(); }
  else { eye(cx - 10*s); eye(cx + 10*s); }
  if (P.female){ g.strokeStyle = '#2e2b34'; g.lineWidth = 1.4*s; [-1, 1].forEach(sd => { const ex = cx + sd*10*s; g.beginPath(); g.moveTo(ex + sd*2.5*s, ey - 4*s); g.lineTo(ex + sd*5.5*s, ey - 6.5*s); g.stroke(); }); }
  if (P.scar){ g.strokeStyle = '#b0505a'; g.lineWidth = 1.8*s; g.beginPath(); g.moveTo(cx + 15*s, ey - 10*s); g.lineTo(cx + 6*s, ey + 9*s); g.stroke(); [0.3, 0.6].forEach(t => { const px = cx + 15*s - 9*s*t, py = ey - 10*s + 19*s*t; g.beginPath(); g.moveTo(px - 3*s, py - 1*s); g.lineTo(px + 3*s, py + 1*s); g.stroke(); }); }
  /* 볼 홍조 */
  g.fillStyle = 'rgba(240,140,150,.35)'; [-1, 1].forEach(sd => { g.beginPath(); g.ellipse(cx + sd*17*s, ey + 8*s, 4.5*s, 2.6*s, 0, 0, 7); g.fill(); });
  /* 모자 */
  const top = hy - hr*0.72;
  if (P.hat === 'tricorn'){ g.fillStyle = P.hatCol; g.beginPath(); g.moveTo(cx - hr*1.45, top + 4*s); g.quadraticCurveTo(cx - hr*0.6, top - 4*s, cx, top - hr*0.95); g.quadraticCurveTo(cx + hr*0.6, top - 4*s, cx + hr*1.45, top + 4*s); g.quadraticCurveTo(cx, top + 8*s, cx - hr*1.45, top + 4*s); g.fill(); g.strokeStyle = P.trim; g.lineWidth = 2.4*s; g.stroke();
    g.fillStyle = '#efe2bf'; g.beginPath(); g.arc(cx, top - hr*0.32, 4.5*s, 0, 7); g.fill(); g.strokeStyle = '#efe2bf'; g.lineWidth = 1.6*s; g.beginPath(); g.moveTo(cx - 5*s, top - hr*0.12); g.lineTo(cx + 5*s, top - hr*0.02); g.moveTo(cx + 5*s, top - hr*0.12); g.lineTo(cx - 5*s, top - hr*0.02); g.stroke(); }
  if (P.hat === 'feather'){ g.fillStyle = P.hatCol; g.beginPath(); g.ellipse(cx, top + 3*s, hr*1.5, 7*s, 0, 0, 7); g.fill(); g.beginPath(); g.moveTo(cx - hr*0.7, top + 2*s); g.quadraticCurveTo(cx - hr*0.7, top - hr*0.85, cx, top - hr*0.85); g.quadraticCurveTo(cx + hr*0.7, top - hr*0.85, cx + hr*0.7, top + 2*s); g.fill();
    g.fillStyle = P.trim; g.fillRect(cx - hr*0.7, top - 4*s, hr*1.4, 4*s);
    g.fillStyle = '#efe4cc'; g.beginPath(); g.moveTo(cx + hr*0.5, top - 2*s); g.bezierCurveTo(cx + hr*1.2, top - hr*1.0, cx + hr*1.8, top - hr*1.3, cx + hr*1.9, top - hr*1.5); g.bezierCurveTo(cx + hr*1.5, top - hr*0.8, cx + hr*1.0, top - hr*0.3, cx + hr*0.5, top - 2*s); g.fill(); g.strokeStyle = 'rgba(0,0,0,.3)'; g.lineWidth = 1*s; g.stroke(); }
  if (P.hat === 'bandana'){ g.fillStyle = P.hatCol; g.beginPath(); g.moveTo(cx - hr*1.04, hy - hr*0.25); g.quadraticCurveTo(cx - hr*1.0, hy - hr*1.15, cx, hy - hr*1.05); g.quadraticCurveTo(cx + hr*1.0, hy - hr*1.15, cx + hr*1.04, hy - hr*0.25); g.quadraticCurveTo(cx, hy - hr*0.5, cx - hr*1.04, hy - hr*0.25); g.fill(); g.strokeStyle = ink; g.lineWidth = 1.6*s; g.stroke();
    g.fillStyle = '#f4f1ea'; for (let k = 0; k < 5; k++){ g.beginPath(); g.arc(cx - hr*0.6 + k*hr*0.3, hy - hr*0.72 - (k % 2)*4*s, 1.8*s, 0, 7); g.fill(); }
    g.fillStyle = P.hatCol; g.beginPath(); g.moveTo(cx + hr*0.95, hy - hr*0.35); g.lineTo(cx + hr*1.45, hy - hr*0.1); g.lineTo(cx + hr*1.3, hy + hr*0.15); g.closePath(); g.fill(); g.beginPath(); g.moveTo(cx + hr*0.95, hy - hr*0.35); g.lineTo(cx + hr*1.5, hy - hr*0.55); g.lineTo(cx + hr*1.45, hy - hr*0.25); g.closePath(); g.fill(); }
  if (P.hat === 'flower'){ const fx = cx + hr*0.72, fy = hy - hr*0.7; for (let k = 0; k < 5; k++){ const a = k/5*Math.PI*2; g.fillStyle = P.hatCol; g.beginPath(); g.ellipse(fx + Math.cos(a)*5*s, fy + Math.sin(a)*5*s, 4.5*s, 3*s, a, 0, 7); g.fill(); } g.fillStyle = '#f0d49a'; g.beginPath(); g.arc(fx, fy, 3*s, 0, 7); g.fill(); }
  g.restore();
}
/* 현상금 선장 수배서 그림: 그 선장의 지금 모습 (옷 색 · 모자 · 안경) 으로 그려요 */
const CAP_PATTERN = { stripe:'stripe', vest:'vest', coat:'coat', explorer:'jacket', scout:'jacket', school:'jacket', haori:'jacket', jersey:'stripe' };
function captainArt(g, x, y, w, h, look){
  const o = (typeof OUTFITS !== 'undefined' && OUTFITS.find(v => v.id === look.o)) || { torn:true }, c = outfitColors(o, '#2f5f8a');
  drawPirateArt(g, x, y, w, h, { bg:'#d9c39a', body:c.shirt, shirt:c.pants, pattern:CAP_PATTERN[look.o] || '', trim:'#c9a15e', hat:null });
  const s = w / 112, cx = x + w / 2, hy = y + h * 0.5, hr = 27 * s;
  g.save(); g.beginPath(); g.rect(x, y, w, h); g.clip();
  const icon = (draw, id, iw, ix, iy) => { const c2 = document.createElement('canvas'); c2.width = 120; c2.height = 90; const g2 = c2.getContext('2d'); if (!g2) return; draw(g2, id); g.drawImage(c2, ix - iw / 2, iy, iw, iw * 0.75); };
  if (look.g && look.g !== 'bare' && typeof glassesDraw === 'function') icon(glassesDraw, look.g, hr * 1.75, cx, hy - hr * 0.62);
  if (look.h && look.h !== 'none' && typeof hatDraw === 'function') icon(hatDraw, look.h, hr * 2.45, cx, hy - hr * 1.72);
  g.restore();
}
/* 선장 사진은 Image 로 한 번만 불러 두고, 다 불러지면 벽을 다시 그려요 */
const CAP_IMG = {};
function capPhoto(cp){
  if (!cp.photo) return null;
  const k = cp.id + '|' + cp.photo.length + cp.photo.slice(-16);
  if (!CAP_IMG[k]){ const im = new Image(); im.onload = () => drawWall(); im.src = cp.photo; CAP_IMG[k] = im; }
  return CAP_IMG[k];
}
function drawWantedPoster(g, x, y, w, P){
  const h = w * 1.42; g.save(); g.translate(x, y); g.rotate(P.slot[2]);
  /* 종이: 바랜 양피지 + 가장자리 그을음 */
  g.fillStyle = '#efe0b8'; g.fillRect(-w/2, -h/2, w, h);
  const bur = g.createRadialGradient(0, 0, w*0.35, 0, 0, h*0.75); bur.addColorStop(0, 'rgba(120,80,40,0)'); bur.addColorStop(1, 'rgba(120,80,40,.38)'); g.fillStyle = bur; g.fillRect(-w/2, -h/2, w, h);
  for (let k = 0; k < 160; k++){ g.globalAlpha = mrand(k, w)*0.15; g.fillStyle = '#6b4a2e'; g.fillRect(-w/2 + mrand(k, 1)*w, -h/2 + mrand(k, 2)*h, 1.5, 1.5); } g.globalAlpha = 1;
  g.fillStyle = '#2a1a0e'; g.textAlign = 'center'; g.textBaseline = 'middle';
  g.font = `700 ${w*0.2}px ${FD}`; g.fillText('WANTED', 0, -h/2 + h*0.085);
  const pw = w*0.8, ph = h*0.43, px = -pw/2, py = -h/2 + h*0.155;
  drawPirateArt(g, px, py, pw, ph, P);
  g.strokeStyle = '#2a1a0e'; g.lineWidth = Math.max(2, w*0.014); g.strokeRect(px, py, pw, ph);
  /* FAMOUS / INFAMOUS 띠 */
  const fy = py + ph + h*0.065; g.font = `700 italic ${w*0.11}px ${FD}`; g.fillStyle = P.fame === 'INFAMOUS' ? '#7a1c14' : '#1f4a3a';
  const fame = P.fame.split('').join(String.fromCharCode(8202)); g.fillText(fame, 0, fy);
  g.strokeStyle = 'rgba(42,26,14,.6)'; g.lineWidth = 1.5; [-1, 1].forEach(sd => { g.beginPath(); g.moveTo(sd*w*0.42, fy); g.lineTo(sd*w*0.42 - sd*w*0.06, fy); g.stroke(); });
  /* 이름 · 별명 · 현상금 */
  const fit = (t, size, max, font) => { let sz = size; do { g.font = font(sz); sz -= 1; } while (g.measureText(t).width > max && sz > 9); };
  g.fillStyle = '#2a1a0e'; fit(P.name, w*0.13, w*0.84, sz => `700 ${sz}px ${FD}`); g.fillText(P.name, 0, fy + h*0.085);
  g.fillStyle = '#6b4a2e'; fit(P.title, w*0.068, w*0.84, sz => `600 ${sz}px ${FB}`); g.fillText(P.title, 0, fy + h*0.145);
  g.fillStyle = '#2a1a0e'; const amt = `${silverFmt(P.amt)} 은화`; fit(amt, w*0.115, w*0.86, sz => `700 ${sz}px ${FD}`); g.fillText(amt, 0, h/2 - h*0.075);
  g.strokeStyle = 'rgba(42,26,14,.45)'; g.lineWidth = 1; g.beginPath(); g.moveTo(-w*0.38, h/2 - h*0.12); g.lineTo(w*0.38, h/2 - h*0.12); g.stroke();
  g.fillStyle = '#8a2a1c'; g.beginPath(); g.arc(0, -h/2 + w*0.035, w*0.028, 0, 7); g.fill();
  g.restore();
}

/* ---------- 앞면 그림: 한 판 · 1위는 가운데 크게, 나머지는 뒤에 덕지덕지 ---------- */
/* 뒤에 붙는 수배서 자리 (가운데 1위 둘레로 겹치게) — 캔버스 1400 × 610 */
/* 양 끝(왼쪽 · 오른쪽 세로 두 장씩)은 오리지널 해적 수배서 자리라 비워 둬요 */
const BD_SLOTS = [[430, 250, 210, -0.09], [970, 260, 205, 0.08], [520, 455, 175, 0.11], [880, 470, 180, -0.1],
  [345, 140, 150, 0.13], [1055, 135, 150, -0.12], [660, 130, 150, -0.05], [760, 520, 150, 0.07]];
const BD_NOTE = { x:905, y:405 };   /* 응원 쪽지 자리 (캔버스) → 3D 쪽지도 여기에 */
function drawFront(){
  const c = BD.frontCanvas, g = c.getContext('2d'); if (!g) return;
  const W = c.width, H = c.height, d = BD.data || { ranks:[], last:null };
  g.fillStyle = '#6b4528'; g.fillRect(0, 0, W, H); speckle(g, W, H, 4000, '#2a180c', .2);
  for (let y = 60; y < H; y += 64){ g.fillStyle = 'rgba(30,18,8,.3)'; g.fillRect(0, y, W, 3); }
  /* 오래된 종이 조각 · 찢긴 자국 (허름하게) */
  for (let k = 0; k < 18; k++){ const x = mrand(k, 1) * W, y = mrand(k, 2) * H, w = 30 + mrand(k, 3) * 60, h = 20 + mrand(k, 4) * 50; g.save(); g.translate(x, y); g.rotate((mrand(k, 5) - .5) * .6); g.fillStyle = `rgba(239,226,191,${.25 + mrand(k, 6) * .3})`; g.fillRect(-w / 2, -h / 2, w, h); g.restore(); }
  WANTED_PIRATES.forEach(P => drawWantedPoster(g, P.slot[0], P.slot[1], 182, P));
  const posters = d.ranks.map((r, i) => { const ch = charOf(r.key); return ch && { name:ch.name, work:ch.work.title, amt:r.amt, hue:ch.work.genre.hue, rank:i + 1 }; }).filter(Boolean);
  const back = posters.slice(1, 1 + BD_SLOTS.length);
  if (d.last){ const ch = charOf(d.last.key); if (ch) back.splice(Math.min(3, back.length), 0, { name:ch.name, work:ch.work.title, amt:d.last.amt, hue:ch.work.genre.hue, rank:'last' }); }
  /* 뒤쪽부터 (멀리 있는 자리 → 가까운 자리 순으로 그려서 겹쳐 보이게) */
  back.slice(0, BD_SLOTS.length).map((o, i) => ({ o, sl:BD_SLOTS[i] })).reverse().forEach(({ o, sl }) => { const [x, y, w, t] = sl; drawPoster(g, x, y, w, w * 1.38, { ...o, tilt:t }); });
  /* 가운데 1위 (크게) */
  if (posters[0]) drawPoster(g, W / 2, H / 2 + 6, 330, 470, { ...posters[0], tilt:-0.015 });
  else drawPoster(g, W / 2, H / 2 + 6, 330, 470, { name:'아직 비어 있어요', work:'옆 쪽지에서 첫 응원을!', amt:0, hue:30, rank:1, tilt:-0.015 });
  /* 맨 위 띠: 게시판 이름 · 이번 주 */
  g.save(); g.translate(W / 2, 30); g.rotate(-0.01); g.fillStyle = '#3a2414'; g.fillRect(-300, -24, 600, 48); g.fillStyle = '#f0d49a'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.font = `700 30px ${FD}`; g.fillText(`현상금 게시판 · ${weekRange()}`, 0, 2); g.restore();
  BD.frontTex.needsUpdate = true;
}
/* ---------- 주점 벽: 현상금 선장 ---------- */
function drawWall(){
  const c = BD.wallCanvas, g = c && c.getContext('2d'); if (!g) return;
  const W = c.width, H = c.height;
  g.fillStyle = '#5a3a20'; g.fillRect(0, 0, W, H); speckle(g, W, H, 1500, '#2a180c', .2);
  g.fillStyle = '#f0d49a'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.font = `700 46px ${FD}`; g.fillText('현상금 선장', W / 2, 50);
  g.font = `600 18px ${FB}`; g.fillStyle = '#e8d6a6'; g.fillText('시장에서 번 은화가 곧 선장님의 현상금 · 라프텔 선장만', W / 2, 88);
  const caps = BD.caps.slice(0, 5);
  if (!caps.length){ g.font = `600 24px ${FB}`; g.fillText('아직 현상금이 붙은 선장이 없어요', W / 2, H / 2); }
  caps.forEach((cp, i) => { const cx = i === 0 ? W / 2 : [W * .14, W * .86, W * .14, W * .86][i - 1], cy = i === 0 ? 290 : [210, 210, 430, 430][i - 1], s = i === 0 ? 1 : 0.62;
    drawPoster(g, cx, cy, 240 * s, 330 * s, { name:cp.name + ' 선장', work:'라프텔 선장', amt:cp.earned, hue:200, rank:i + 1, tilt:(i % 2 ? .03 : -.03), look:cp.look, photo:capPhoto(cp) }); });
  BD.wallTex.needsUpdate = true;
}
function refreshBoard(){
  return LPShare.board().then(d => { BD.data = d; drawFront(); if (BD.ui.open) boardRender(); }).catch(() => {});
}
function refreshCaptains(){ return LPShare.captains().then(c => { BD.caps = c || []; drawWall(); if (BD.ui.open) boardRender(); }).catch(() => {}); }
/* 내 현상금 올리기 (라프텔 선장 · 시장에서 판 은화) */
function myPosterLook(){ const s = shopData(); return { o:s.outfit, h:s.hat, g:s.glasses || 'bare' }; }
function myPosterPhoto(){ const sh = (LPProfile.get() || {}).shop || {}; return sh.posterMode === 'photo' && typeof sh.posterPhoto === 'string' ? sh.posterPhoto : ''; }
function syncCaptain(){ const p = LPProfile.get(); if (!isLaftelCaptain(p)) return; const s = (p.shop || {}); LPShare.putCaptain({ id:captainId(p), name:p.nickname, kind:p.kind, earned:s.earned | 0, look:myPosterLook(), photo:myPosterPhoto() }).then(refreshCaptains); }

/* ---------- 3D 게시판 ---------- */
function buildBountyBoard(){
  const G = new THREE.Group(); G.position.set(PL.board.x, 0, PL.board.z); isleScene.add(G);
  const m = (geo, mat, x, y, z) => { const o = new THREE.Mesh(geo, mat); o.position.set(x, y, z); G.add(o); return o; };
  const wood = flat('#6b4528'), dark = flat('#3a2414'), W = 14, H = 6.1, Y = 3.55;
  m(new THREE.BoxGeometry(W, H, 0.3), wood, 0, Y, 0);
  [-W / 2 - 0.2, W / 2 + 0.2].forEach(x => m(new THREE.BoxGeometry(0.4, Y + H / 2 + 0.6, 0.4), dark, x, (Y + H / 2 + 0.6) / 2, 0));   /* 양쪽 끝 기둥만 (가운데는 수배서를 가려서 뺐어요) */
  /* 지붕 (앞뒤로 기운 판자) */
  [1, -1].forEach(s => { const r = m(new THREE.BoxGeometry(W + 1.4, 0.14, 1.3), flat('#5a2e1e'), 0, Y + H / 2 + 0.75, s * 0.48); r.rotation.x = s * 0.42; });
  m(new THREE.BoxGeometry(W + 1.4, 0.2, 0.2), dark, 0, Y + H / 2 + 1.0, 0);
  /* 앞면 그림 */
  BD.frontCanvas = document.createElement('canvas'); BD.frontCanvas.width = 1400; BD.frontCanvas.height = 610;
  BD.frontTex = new THREE.CanvasTexture(BD.frontCanvas); if (THREE.sRGBEncoding) BD.frontTex.encoding = THREE.sRGBEncoding;
  m(new THREE.PlaneGeometry(W - 0.2, H - 0.2), new THREE.MeshStandardMaterial({ map:BD.frontTex, roughness:.9 }), 0, Y, 0.16);
  /* 뒷면: 문의함 쪽지 (가까이 가면 '문의함에 한마디 남기기') */
  const note = m(new THREE.PlaneGeometry(1.6, 1.1), new THREE.MeshStandardMaterial({ map:canvasTex(320, 220, (g, w, h) => { g.fillStyle = '#efe2bf'; g.fillRect(0, 0, w, h); speckle(g, w, h, 300, '#8a6a48', .15); g.fillStyle = '#3a2616'; g.textAlign = 'center'; g.font = `700 40px ${FD}`; g.fillText('문의함', w / 2, 80); g.font = `600 22px ${FB}`; g.fillText('선장님의 한마디를', w / 2, 132); g.fillText('남겨 주세요', w / 2, 164); }), roughness:.9 }), 0, 3.2, -0.16); note.rotation.y = Math.PI; note.rotation.z = 0.04;
  /* 양쪽 등불 · 계단 받침 */
  hangLantern(G, -W / 2 - 0.2, Y + H / 2 + 0.1, 0.5, IS.lamps); hangLantern(G, W / 2 + 0.2, Y + H / 2 + 0.1, 0.5, IS.lamps);
  m(new THREE.BoxGeometry(W + 0.6, 0.16, 1.4), flat('#8a6a48'), 0, 0.08, 0.6);
  iBox(PL.board.x, PL.board.z, W / 2 + 0.4, 0.35);
  G.userData.kind = 'board'; IS.clickables.push(G);
  /* 1위 옆 작은 쪽지 (살짝 튀어나와 펄럭여요) → 가까이 가면 '인기 캐릭터 응원하기' */
  const nx = (BD_NOTE.x - 700) / 100, ny = Y + (305 - BD_NOTE.y) / 100;
  const noteTex = canvasTex(280, 230, (g, w, h) => { g.fillStyle = '#f6efd8'; g.fillRect(0, 0, w, h); speckle(g, w, h, 300, '#8a6a48', .12);
    for (let y = 70; y < h; y += 34){ g.fillStyle = 'rgba(47,111,134,.25)'; g.fillRect(16, y, w - 32, 2); }
    g.fillStyle = '#8a2a1c'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.font = `700 38px ${FD}`; g.fillText('응원 모집!', w / 2, 42);
    g.fillStyle = '#2a1a0e'; g.font = `700 26px ${FB}`; g.fillText('인기 캐릭터', w / 2, 102); g.fillText('응원하기', w / 2, 138);
    g.font = `600 18px ${FB}`; g.fillStyle = '#5a4030'; g.fillText('10은화씩 · 라프텔 선장', w / 2, 184);
    g.fillStyle = '#c0392b'; g.beginPath(); g.arc(w / 2, 10, 8, 0, 7); g.fill(); });
  const noteG = new THREE.Group(); noteG.position.set(nx, ny, 0.24); G.add(noteG); BD.note = noteG;
  const nm = new THREE.Mesh(new THREE.PlaneGeometry(1.1, 0.9), new THREE.MeshStandardMaterial({ map:noteTex, roughness:.9, side:THREE.DoubleSide })); nm.geometry.translate(0, -0.45, 0); nm.position.y = 0.45; noteG.add(nm); noteG.rotation.z = 0.06;
  const pin = new THREE.Mesh(new THREE.SphereGeometry(0.05, 8, 6), flat('#c0392b')); pin.position.set(0, 0.42, 0.03); noteG.add(pin);
  noteG.userData.kind = 'bdNote'; IS.clickables.push(noteG);
  ISLE_SPOTS.bdNote = { x:PL.board.x + nx, z:PL.board.z + 1.7, face:Math.PI, label:'인기 캐릭터 응원하기', near:1.3, use:() => openBoard('find') };
  ISLE_SPOTS.board = { x:PL.board.x - 1.2, z:PL.board.z + 2.0, face:Math.PI, label:'현상금 수배서 보기', use:() => openBoard('rank') };
  ISLE_SPOTS.bdBack = { x:PL.board.x, z:PL.board.z - 1.6, face:0, label:'문의함에 한마디 남기기', use:() => openInbox() };
  drawFront(); refreshBoard();
}
function buildCaptainWall(){
  BD.wallCanvas = document.createElement('canvas'); BD.wallCanvas.width = 760; BD.wallCanvas.height = 560;
  BD.wallTex = new THREE.CanvasTexture(BD.wallCanvas); if (THREE.sRGBEncoding) BD.wallTex.encoding = THREE.sRGBEncoding;
  const w = new THREE.Mesh(new THREE.PlaneGeometry(3.4, 2.5), new THREE.MeshStandardMaterial({ map:BD.wallTex, roughness:.9 })); w.position.set(-6.93, 2.05, 0.3); w.rotation.y = Math.PI / 2; tavernScene.add(w);
  const fr = new THREE.Mesh(new THREE.BoxGeometry(0.08, 2.7, 3.6), flat('#3a2414')); fr.position.set(-6.98, 2.05, 0.3); tavernScene.add(fr);
  TAVERN_SPOTS.captains = { x:-5.7, z:0.3, face:-Math.PI / 2, label:'현상금 선장 보기', use:() => openBoard('captains') };
  drawWall(); refreshCaptains();
}

/* ---------- 게시판 화면 ---------- */
BD.ui = { open:false, tab:'rank', q:'' };
const BU = { root:$('#board'), tabs:$('#bdTabs'), body:$('#bdBody'), note:$('#bdNote'), coins:$('#bdCoins'), close:$('#bdClose'), title:$('#bdTitle'), kick:$('#bdKick') };
function boardRender(){
  const p = LPProfile.get(), s = shopData(), laftel = isLaftelCaptain(p), left = cheerLeft(), d = BD.data || { ranks:[], last:null };
  const capsMode = BD.ui.tab === 'captains';
  BU.kick.textContent = capsMode ? '주점 럼통 · 현상금 선장' : `다모였섬 · 현상금 게시판 · ${weekRange()}`;
  BU.title.textContent = capsMode ? '돈 많이 번 선장 순위' : BD.ui.tab === 'posters' ? '현상금 수배서' : BD.ui.tab === 'find' ? '응원할 캐릭터 찾기' : '이번 주 인기 캐릭터';
  BU.coins.innerHTML = `은화 <b>${silverFmt(s.silver)}</b>${capsMode ? '' : ` · 오늘 응원 <b>${laftel ? left : 0}</b>/${CHEER_DAY}`}`;
  BU.tabs.hidden = capsMode;
  BU.tabs.querySelectorAll('[data-tab]').forEach(b => { const on = b.dataset.tab === BD.ui.tab; b.setAttribute('aria-selected', String(on)); b.tabIndex = on ? 0 : -1; });
  const gate = laftel ? '' : `<p class="bd-gate">🔒 응원은 <b>라프텔로 로그인한 선장</b>만 할 수 있어요. 지금은 둘러보기만 돼요.${p ? '' : ''}</p>`;
  const cheerBtn = (key, extra = '') => `<button type="button" class="lm-b go" data-cheer="${escHTML(key)}" ${!laftel || left < CHEER_STEP || s.silver < CHEER_STEP ? 'disabled' : ''}>응원 +${CHEER_STEP}${extra}</button>`;
  const row = (r, i) => { const ch = charOf(r.key); if (!ch) return ''; return `<li><span class="bd-rk r${i + 1}">${i + 1}</span><div><b>${escHTML(ch.name)}</b><small>${escHTML(ch.work.title)} · 응원한 선장 ${r.cheerers}명</small></div><span class="bd-amt">${silverFmt(r.amt)}<small>은화</small></span>${cheerBtn(r.key)}</li>`; };
  let h = '';
  if (BD.ui.tab === 'rank'){
    h = gate + (d.ranks.length ? `<ol class="bd-list">${d.ranks.slice(0, 20).map(row).join('')}</ol>` : `<p class="sh-empty"><b>아직 응원이 없어요</b>'캐릭터 찾기'에서 좋아하는 캐릭터를 골라 첫 응원을 해 보세요.</p>`)
      + `<p class="sh-tip">한 번에 ${CHEER_STEP}은화 · 하루 ${CHEER_DAY}은화까지 · 매주 월요일 0시에 새로 시작해요.</p>`;
  } else if (BD.ui.tab === 'find'){
    const q = BD.ui.q.trim(), all = [];
    if (q){ const qs = q.replace(/\s/g, ''); LPData.all().forEach(w => { const hitW = w.title.replace(/\s/g, '').includes(qs); (w.chars || []).forEach(c => { if (hitW || c.name.replace(/\s/g, '').includes(qs)) all.push({ key:charKey(w.id, c.name), name:c.name, work:w }); }); }); }
    const amtOf = k => (d.ranks.find(r => r.key === k) || {}).amt || 0;
    h = gate + `<label class="rc-search"><span class="sr">캐릭터 찾기</span><input id="bdQ" type="search" value="${escHTML(q)}" placeholder="캐릭터 이름 또는 작품 제목 (예: 프리렌, 하이큐)" autocomplete="off"></label>
      <p class="rc-count">${q ? (all.length ? `${all.length}명` : `"${escHTML(q)}"에 맞는 캐릭터가 없어요`) : `63편 · ${LPData.all().reduce((a, w) => a + (w.chars || []).length, 0)}명 중에서 찾아요`}</p>
      <ul class="bd-list find">${all.slice(0, 40).map(c => `<li><span class="bd-dot" style="--gh:${c.work.genre.hue}"></span><div><b>${escHTML(c.name)}</b><small>${escHTML(c.work.title)}</small></div><span class="bd-amt">${silverFmt(amtOf(c.key))}<small>은화</small></span>${cheerBtn(c.key)}</li>`).join('')}</ul>`;
  } else if (BD.ui.tab === 'posters'){
    const P = d.ranks.slice(0, 6);
    h = (P.length ? `<ul class="bd-posters">${P.map((r, i) => { const ch = charOf(r.key); return ch ? `<li class="${i === 0 ? 'top' : ''}"><img src="${posterURL(ch, r.amt, i + 1)}" alt="${escHTML(ch.name)} 수배서 · 현상금 ${silverFmt(r.amt)}은화"><button type="button" class="lm-b" data-open="${ch.work.id}">작품 책상에서 열기</button></li>` : ''; }).join('')}</ul>` : `<p class="sh-empty"><b>아직 수배서가 없어요</b>응원이 모이면 1위부터 수배서가 붙어요.</p>`)
      + (d.last ? (() => { const ch = charOf(d.last.key); return ch ? `<div class="bd-last"><img src="${posterURL(ch, d.last.amt, 'last')}" alt=""><div><b>지난 주 최고 현상금</b><p>${escHTML(ch.name)} · ${escHTML(ch.work.title)}</p><small>${silverFmt(d.last.amt)}은화 · 응원한 선장 ${d.last.cheerers}명</small></div></div>` : ''; })() : '');
  } else if (capsMode){
    const me = p && captainId(p), mine = BD.caps.findIndex(c => c.id === me);
    h = (laftel ? `<p class="sh-tip">내 현상금 <b>${silverFmt((p.shop || {}).earned | 0)}은화</b>${mine >= 0 ? ` · 지금 <b>${mine + 1}위</b>` : ''} · 시장에서 물고기를 팔수록 올라가요.</p>` : `<p class="bd-gate">🔒 현상금 선장에는 <b>라프텔로 로그인한 선장</b>만 올라가요.</p>`)
      + (laftel ? posterEditor() : '')
      + (BD.caps.length ? `<ol class="bd-list">${BD.caps.slice(0, 20).map((c, i) => `<li class="${c.id === me ? 'me' : ''}"><span class="bd-rk r${i + 1}">${i + 1}</span><div><b>${escHTML(c.name)} 선장</b><small>${c.id === me ? '나' : '라프텔 선장'}</small></div><span class="bd-amt">${silverFmt(c.earned)}<small>은화</small></span></li>`).join('')}</ol>` : `<p class="sh-empty"><b>아직 현상금 선장이 없어요</b>라프텔 선장이 시장에서 물고기를 팔면 여기에 올라가요.</p>`);
  }
  BU.body.innerHTML = h;
  BU.body.querySelectorAll('[data-cheer]').forEach(b => b.addEventListener('click', () => cheerChar(b.dataset.cheer)));
  BU.body.querySelectorAll('[data-poster]').forEach(b => b.addEventListener('click', () => setPoster(b.dataset.poster)));
  BU.body.querySelectorAll('[data-posterfile]').forEach(inp => inp.addEventListener('change', () => {
    const file = inp.files && inp.files[0]; if (!file) return; BU.note.textContent = '사진을 수배서 크기로 맞추는 중…';
    makePosterPhoto(file).then(d => setPoster('photo', d)).catch(m => { BU.note.textContent = typeof m === 'string' ? m : '사진을 읽지 못했어요.'; }); }));
  BU.body.querySelectorAll('[data-open]').forEach(b => b.addEventListener('click', () => { const id = b.dataset.open; closeBoard(); openDeskInfo(id, {}); }));
  const q = $('#bdQ'); if (q){ /* 한글 입력(IME) 조합 중에 화면을 다시 그리면 'ㅅㅓㅇ'처럼 낱자로 깨져요 → 조합이 끝난 글자 단위로만 다시 그려요 */
    let composing = false;
    const rerender = () => { BD.ui.q = q.value; const pos = q.selectionStart; boardRender(); const q2 = $('#bdQ'); if (q2){ q2.focus(); try { q2.setSelectionRange(pos, pos); } catch(e){} } };
    q.addEventListener('compositionstart', () => { composing = true; });
    q.addEventListener('compositionend', () => { composing = false; rerender(); });
    q.addEventListener('input', e => { BD.ui.q = q.value; if (composing || e.isComposing) return; rerender(); }); }
}
/* ---------- 내 수배서 고치기 (주점 · 현상금 선장 창) ---------- */
function myPosterURL(){
  const p = LPProfile.get(); if (!p) return '';
  const c = document.createElement('canvas'); c.width = 240; c.height = 330; const g = c.getContext('2d'); if (!g) return '';
  const ph = myPosterPhoto(); let im = null;
  if (ph){ im = new Image(); im.src = ph; }   /* dataURL 은 바로 그려지지 않을 수 있어서, 불러진 뒤 한 번 더 그려요 */
  drawPoster(g, 120, 165, 240, 330, { name:p.nickname + ' 선장', work:'라프텔 선장', amt:(p.shop || {}).earned | 0, hue:200, look:myPosterLook(), photo:im });
  if (im && !im.complete) im.onload = () => { const el = $('#bdMyPoster'); if (el){ g.clearRect(0, 0, 240, 330); drawPoster(g, 120, 165, 240, 330, { name:p.nickname + ' 선장', work:'라프텔 선장', amt:(p.shop || {}).earned | 0, hue:200, look:myPosterLook(), photo:im }); el.src = c.toDataURL(); } };
  return c.toDataURL();
}
function posterEditor(){
  const sh = (LPProfile.get() || {}).shop || {}, photo = sh.posterMode === 'photo' && sh.posterPhoto;
  return `<div class="bd-me">
    <img id="bdMyPoster" src="${myPosterURL()}" alt="내 수배서 미리보기">
    <div><b class="bd-me-t">내 수배서 그림</b>
      <p>${photo ? '지금은 <b>내가 올린 사진</b>이 붙어 있어요.' : '지금은 <b>내 캐릭터 모습</b>이에요. 옷 · 모자 · 안경을 바꾸면 수배서도 같이 바뀌어요.'}</p>
      <div class="sh-acts">
        ${photo ? '<button type="button" class="lm-b" data-poster="art">캐릭터 모습으로</button>' : ''}
        <label class="lm-b go">${photo ? '다른 사진으로' : '사진으로 바꾸기'}<input type="file" accept="image/*" data-posterfile hidden></label>
        ${sh.posterPhoto && !photo ? '<button type="button" class="lm-b" data-poster="photo">전에 올린 사진</button>' : ''}
      </div>
      <small>사진은 주점 벽에 붙어 <b>다른 선장님도 봐요</b>. 다른 사람 얼굴 · 공식 작품 이미지 · 불쾌한 사진은 올리지 말아 주세요. 세로 사진이 잘 맞아요.</small>
    </div></div>`;
}
function makePosterPhoto(file){
  return new Promise((res, rej) => {
    if (!file || !/^image\//.test(file.type)) return rej('사진 파일만 쓸 수 있어요.');
    if (file.size > 15 * 1024 * 1024) return rej('사진이 너무 커요. 15MB 아래로 골라 주세요.');
    const url = URL.createObjectURL(file), img = new Image();
    img.onload = () => { try {
        const W = 150, H = 170, c = document.createElement('canvas'); c.width = W; c.height = H; const g = c.getContext('2d');
        const k = Math.max(W / img.width, H / img.height), dw = img.width * k, dh = img.height * k;
        g.drawImage(img, (W - dw) / 2, (H - dh) / 2, dw, dh); URL.revokeObjectURL(url); res(c.toDataURL('image/jpeg', 0.78)); } catch(e){ rej('사진을 읽지 못했어요.'); } };
    img.onerror = () => { URL.revokeObjectURL(url); rej('사진을 열 수 없어요. 다른 사진을 골라 주세요.'); };
    img.src = url;
  });
}
function setPoster(mode, photo){
  const p = LPProfile.get(); if (!p) return; const sh = { ...(p.shop || {}) };
  sh.posterMode = mode; if (photo) sh.posterPhoto = photo; LPProfile.update({ shop:sh });
  BU.note.innerHTML = mode === 'photo' ? '수배서에 <b>사진</b>을 붙였어요. 주점 벽에도 곧 붙어요.' : '수배서를 <b>내 캐릭터 모습</b>으로 바꿨어요.';
  syncCaptain(); boardRender();
}
const posterIcon = {};
function posterURL(ch, amt, rank){
  const k = `${ch.key}|${amt}|${rank}`; if (posterIcon[k]) return posterIcon[k];
  const c = document.createElement('canvas'); c.width = 240; c.height = 330; const g = c.getContext('2d'); if (!g) return '';
  drawPoster(g, 120, 165, 240, 330, { name:ch.name, work:ch.work.title, amt, hue:ch.work.genre.hue, rank });
  try { posterIcon[k] = c.toDataURL(); } catch(e){ posterIcon[k] = ''; } return posterIcon[k];
}
function cheerChar(key){
  const p = LPProfile.get(); if (!isLaftelCaptain(p)) return;
  const s = shopData(), left = cheerLeft(); if (left < CHEER_STEP || s.silver < CHEER_STEP){ BU.note.textContent = left < CHEER_STEP ? '오늘 응원은 다 했어요. 내일 또 와요!' : '은화가 모자라요.'; return; }
  s.silver -= CHEER_STEP;
  const raw = (p.shop || {}), ch = raw.cheer && raw.cheer.day === todayKST() ? raw.cheer : { day:todayKST(), spent:0 };
  ch.spent += CHEER_STEP; saveShop({ ...s, cheer:ch, earned:raw.earned | 0 });
  LPShare.cheer(key, CHEER_STEP, captainId(p)).then(r => { const c = charOf(key); BU.note.innerHTML = `<b>${escHTML(c ? c.name : '')}</b> 응원 +${CHEER_STEP}은화! 지금 현상금 <b>${silverFmt(r.amt)}은화</b>`; pulseLogpose(); return refreshBoard(); });
}
function openBoard(tab){
  if (BD.ui.open) return;
  BD.ui.open = true; BD.ui.tab = tab || 'rank'; uiOpen = true; keys.clear(); auto = null; $('#toast').hidden = true;
  BU.note.textContent = ''; BU.root.hidden = false; document.body.classList.add('board-open');
  boardRender(); if (tab === 'captains'){ const pp = LPProfile.get(); if (isLaftelCaptain(pp) && ((pp.shop || {}).earned | 0) > 0) syncCaptain(); else refreshCaptains(); } else refreshBoard();
  setTimeout(() => { try { (BU.tabs.hidden ? BU.close : BU.tabs.querySelector('[aria-selected="true"]')).focus({ preventScroll:true }); } catch(e){} }, 40);
}
function closeBoard(){ if (!BD.ui.open) return; BD.ui.open = false; BU.root.hidden = true; document.body.classList.remove('board-open'); uiOpen = false; try { renderer.domElement.focus({ preventScroll:true }); } catch(e){} }
BU.close.addEventListener('click', () => closeBoard());
BU.tabs.querySelectorAll('[data-tab]').forEach(b => b.addEventListener('click', () => { BD.ui.tab = b.dataset.tab; BU.note.textContent = ''; boardRender(); }));
window.addEventListener('keydown', e => {
  if (!BD.ui.open) return;
  if (e.key === 'Escape'){ e.preventDefault(); closeBoard(); return; }
  if (e.key === 'Tab'){ const f = [...BU.root.querySelectorAll('button:not([disabled]), input')].filter(b => b.offsetParent !== null); if (!f.length) return; const first = f[0], last = f[f.length - 1];
    if (e.shiftKey && document.activeElement === first){ e.preventDefault(); last.focus(); } else if (!e.shiftKey && document.activeElement === last){ e.preventDefault(); first.focus(); } }
});

function boardStep(dt, t){ if (BD.note) BD.note.rotation.x = Math.sin(t * 1.8) * 0.06 * (reduceMotion ? 0 : 1); }

/* ============================================================
   게시판 뒷면 · 문의함 (11/24)
   선장이 한 줄(120자)을 남기면 팀만 봐요. 다른 선장에게는 안 보여요.
   - 저장: Supabase 'feedback' 표 (넣기만 되고 읽기는 막혀 있어요 · supabase/schema.sql ④)
   - 보내는 것: 무작위 방문 번호 · 종류(문의/버그/의견) · 글 · PC/모바일. 닉네임 · 이메일은 보내지 않아요.
   - Supabase 가 없으면(파일로 열기) 이 기기에만 저장돼요.
   - 팀이 읽는 법: supabase/visits_queries.sql 의 '문의함' 질문
   ============================================================ */
const IB = { root:$('#inbox'), body:$('#ibBody'), note:$('#ibNote'), close:$('#ibClose') };
const inbox = { open:false, kind:'문의' };
const IB_KEY = 'logpose.inbox', IB_MAX = 120, IB_GAP = 30 * 1000, IB_DAY = 10;
const ibMine = () => { try { const v = JSON.parse(localStorage.getItem(IB_KEY) || '[]'); return Array.isArray(v) ? v : []; } catch(e){ return []; } };
const ibSave = list => { try { localStorage.setItem(IB_KEY, JSON.stringify(list.slice(-20))); } catch(e){} };
function ibServer(){ const c = window.LP_CONFIG || {}; return c.supabaseUrl && c.supabaseAnonKey ? c : null; }
function ibRender(){
  const mine = ibMine().slice(-3).reverse(), server = !!ibServer();
  IB.body.innerHTML = `<p class="sh-tip">궁금한 점 · 고장 난 곳 · 바라는 점을 한 줄로 남겨 주세요. <b>팀만 읽어요.</b> 다른 선장님에게는 보이지 않아요.</p>
    <div class="ib-kinds" role="group" aria-label="종류">${['문의', '버그', '의견'].map(k => `<button type="button" class="lm-b" data-kind="${k}" aria-pressed="${inbox.kind === k}">${k === '버그' ? '고장 · 버그' : k}</button>`).join('')}</div>
    <label class="sr" for="ibText">한마디</label>
    <textarea class="ib-text" id="ibText" maxlength="${IB_MAX}" placeholder="예: 망루에서 해역 이름이 잘 안 보여요"></textarea>
    <div class="ib-row"><span>닉네임 · 이메일은 보내지 않아요. 전화번호 같은 개인정보는 적지 말아 주세요.</span><span id="ibCount">0/${IB_MAX}</span></div>
    <div class="fi-btns"><button type="button" class="g-btn primary" data-send>문의함에 넣기</button><button type="button" class="g-btn ghost" data-close>닫기</button></div>
    ${server ? '' : '<p class="sh-tip">지금은 연습용(파일로 열기)이라 이 기기에만 저장돼요.</p>'}
    ${mine.length ? `<h3 class="fi-k" style="margin-top:14px">내가 남긴 한마디</h3><ul class="ib-mine">${mine.map(m => `<li>${escHTML(m.text)}<small>${escHTML(m.kind)} · ${escHTML(new Date(Date.parse(m.at) + 9 * 3600e3).toISOString().slice(5, 16).replace('-', '/').replace('T', ' '))}${m.sent ? ' · 팀에게 전달됨' : ' · 이 기기에만 저장'}</small></li>`).join('')}</ul>` : ''}`;
  const ta = $('#ibText'), cnt = $('#ibCount');
  ta.addEventListener('input', () => { cnt.textContent = `${ta.value.length}/${IB_MAX}`; });
  IB.body.querySelectorAll('[data-kind]').forEach(b => b.addEventListener('click', () => { inbox.kind = b.dataset.kind; IB.body.querySelectorAll('[data-kind]').forEach(x => x.setAttribute('aria-pressed', String(x === b))); }));
  IB.body.querySelector('[data-send]').addEventListener('click', () => ibSend(ta.value));
  IB.body.querySelector('[data-close]').addEventListener('click', () => closeInbox());
  setTimeout(() => { try { ta.focus({ preventScroll:true }); } catch(e){} }, 30);
}
function ibSend(raw){
  const text = String(raw || '').replace(/[\u0000-\u001f<>]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, IB_MAX);
  if (text.length < 2){ IB.note.textContent = '두 글자 이상 적어 주세요.'; return; }
  const mine = ibMine(), now = Date.now(), today = new Date(now + 9 * 3600e3).toISOString().slice(0, 10);
  const last = mine[mine.length - 1];
  if (last && now - Date.parse(last.at) < IB_GAP){ IB.note.textContent = '조금만 있다가 다시 남겨 주세요. (30초에 한 번)'; return; }
  if (mine.filter(m => String(m.day) === today).length >= IB_DAY){ IB.note.textContent = `오늘은 ${IB_DAY}번까지 남길 수 있어요. 내일 또 남겨 주세요!`; return; }
  const item = { at:new Date(now).toISOString(), day:today, kind:inbox.kind, text, sent:false };
  mine.push(item); ibSave(mine);
  const c = ibServer();
  const done = ok => { if (ok){ item.sent = true; const m2 = ibMine(); const k = m2.findIndex(x => x.at === item.at); if (k >= 0){ m2[k].sent = true; ibSave(m2); } }
    IB.note.innerHTML = ok ? '고마워요! 문의함에 넣었어요. <b>팀이 꼭 읽을게요.</b>' : (c ? '지금은 전달이 안 됐어요. 이 기기에 저장해 뒀어요.' : '이 기기에 저장했어요.'); ibRender(); };
  if (!c) return done(false);
  let visitor = ''; try { visitor = localStorage.getItem('logpose.vid') || ''; } catch(e){}
  if (visitor.length < 4){ visitor = 'v' + Math.random().toString(36).slice(2, 12); try { localStorage.setItem('logpose.vid', visitor); } catch(e){} }
  const headers = { apikey:c.supabaseAnonKey, 'Content-Type':'application/json', Prefer:'return=minimal' };
  if (!/^sb_/.test(c.supabaseAnonKey)) headers.Authorization = 'Bearer ' + c.supabaseAnonKey;
  let device = 'pc'; try { device = matchMedia('(pointer:coarse)').matches ? 'mobile' : 'pc'; } catch(e){}
  IB.note.textContent = '문의함에 넣는 중…';
  fetch(String(c.supabaseUrl).replace(/\/+$/, '') + '/rest/v1/feedback', { method:'POST', headers, body:JSON.stringify({ visitor:visitor.slice(0, 40), kind:item.kind, text, device }) })
    .then(r => done(r.ok)).catch(() => done(false));
}
function openInbox(){
  if (inbox.open) return;
  inbox.open = true; uiOpen = true; keys.clear(); auto = null; $('#toast').hidden = true;
  IB.note.textContent = ''; IB.root.hidden = false; document.body.classList.add('board-open'); ibRender();
  if (typeof LPTrack !== 'undefined' && LPTrack.event) LPTrack.event('inbox', 'isle');
}
function closeInbox(){ if (!inbox.open) return; inbox.open = false; IB.root.hidden = true; document.body.classList.remove('board-open'); uiOpen = false; try { renderer.domElement.focus({ preventScroll:true }); } catch(e){} }
IB.close.addEventListener('click', () => closeInbox());
window.addEventListener('keydown', e => { if (inbox.open && e.key === 'Escape'){ e.preventDefault(); closeInbox(); } });
