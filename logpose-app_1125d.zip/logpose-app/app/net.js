/* ---------- 다모였섬에서 서로 보이기 (실시간 방 · room) ----------
   다모였섬 · 주점에 있는 동안 내 위치 · 자세 · 옷 · 모자 · 이름표를 실시간으로 알려요.
   같은 곳에 있는 다른 선장님은 내 화면에 캐릭터로 그려져요. 내 배(선장실 · 갑판)는 나만 있어요.
   공유 링크 · 우리 웹사이트(Supabase)에서 켜지고, 파일로 열면 혼자 노는 지금 모습 그대로예요. */
const NETP = { room:null, peers:[], avatars:new Map(), area:null, last:'', sentAt:0, here:false };
const NET_AREAS = { isle:true, tavern:true };
(async () => {
  try {
    const room = await lpUse('room'); if (!room) return;   /* backend.js: 공유 링크 · Supabase · 없음 */
    NETP.room = room;
    room.onPeers(ch => { NETP.peers = ch.peers; }, () => { NETP.room = null; NETP.peers = []; });
  } catch(e){ NETP.room = null; }
})();

/* 남이 보낸 값은 믿지 않고 다듬어요 */
const nNum = (v, lo, hi, d = 0) => { const n = Number(v); return isFinite(n) ? Math.max(lo, Math.min(hi, n)) : d; };
const nStr = (v, n) => String(v == null ? '' : v).replace(/[\u0000-\u001f<>]/g, '').slice(0, n);
function peerState(pr){
  if (!pr || !NET_AREAS[pr.a]) return null;
  return { a:pr.a, x:nNum(pr.x, -200, 200), z:nNum(pr.z, -200, 200), r:nNum(pr.r, -10, 10), j:nNum(pr.j, 0, 3), sy:nNum(pr.sy, 0, 1.5),
    p:pr.p === 'sit' ? 'sit' : pr.p === 'drink' ? 'drink' : '', n:nStr(pr.n, 12) || '이름 없는', s:nStr(pr.s, 12), k:pr.k === 'laftel-demo' ? 'laftel-demo' : 'guest',
    o:OUTFITS.some(x => x.id === pr.o) ? pr.o : 'rags', h:HATS.some(x => x.id === pr.h) ? pr.h : 'none', g:typeof GLASSES !== 'undefined' && GLASSES.some(x => x.id === pr.g) ? pr.g : 'bare', t:nNum(pr.t, 0, 4) | 0 };
}
/* 다른 선장님 캐릭터 */
function setAvatarHat(av, id){
  const head = av.userData.head; if (!head) return;
  (head.userData.hatParts || []).forEach(m => m.visible = id === 'captain');
  if (head.userData.extraHat){ head.remove(head.userData.extraHat); head.userData.extraHat = null; }
  if (id !== 'captain' && id !== 'none'){ const h = hatMesh(id); head.add(h); head.userData.extraHat = h; }
}
function makeRemote(st){
  const av = makeAvatar('#2f5f8a'); if (av.parent) av.parent.remove(av); AREA.scene.add(av);
  const R = { av, st, x:st.x, z:st.z, r:st.r, bob:0, look:'', tagKey:'' };
  av.position.set(st.x, AREA.heightAt(st.x, st.z), st.z); av.rotation.y = st.r;
  dressRemote(R); return R;
}
function dressRemote(R){
  const st = R.st, look = st.o + '|' + st.h + '|' + st.g;
  if (look !== R.look){ R.look = look; dressAvatar(R.av, st.o); setAvatarHat(R.av, st.h); if (typeof setAvatarGlasses === 'function') setAvatarGlasses(R.av, st.g); }
  if ((R.av.userData.tipsy | 0) !== st.t && typeof blushAvatar === 'function') blushAvatar(R.av, st.t);
  const tk = st.s + '|' + st.n + '|' + st.k;
  if (tk !== R.tagKey){ R.tagKey = tk; const ud = R.av.userData; if (ud.tag){ R.av.remove(ud.tag); if (ud.tag.material.map) ud.tag.material.map.dispose(); }
    ud.tag = makeNameTag(st.s, st.n, st.k === 'laftel-demo'); R.av.add(ud.tag); }
}
function dropRemote(key){ const R = NETP.avatars.get(key); if (!R) return; if (R.av.parent) R.av.parent.remove(R.av); NETP.avatars.delete(key); }
function netClear(){ [...NETP.avatars.keys()].forEach(dropRemote); }

/* 내 상태 보내기: 다모였섬 · 주점에 있을 때만, 바뀌었을 때만 (초당 최대 10번) */
function myState(){
  const p = LPProfile.get(), s = typeof shopData === 'function' ? shopData() : { outfit:'rags', hat:'none' };
  if (!p || MODE !== 'cabin' || !NET_AREAS[AREA.id]) return null;
  const r2 = v => Math.round(v * 100) / 100;
  return { a:AREA.id, x:r2(player.x), z:r2(player.z), r:r2(((player.r % (Math.PI * 2)) + Math.PI * 3) % (Math.PI * 2) - Math.PI), j:r2(player.jy || 0),
    sy:player.pose === 'sit' ? r2(player.sitY || 0.4) : 0, p:player.pose === 'sit' || player.pose === 'drink' ? player.pose : '',
    n:p.nickname, s:p.ship || '', k:p.kind, o:s.outfit || 'rags', h:s.hat || 'none', g:s.glasses || 'bare', t:player.tipsy | 0 };
}
function netSend(now){
  const R = NETP.room; if (!R) return;
  const st = myState(), key = st ? JSON.stringify(st) : '';
  if (key === NETP.last || now - NETP.sentAt < 100) return;
  NETP.last = key; NETP.sentAt = now;
  R.presence(st ? st : { a:null }).catch(() => {});
}
function netLeave(){ NETP.last = ''; netClear(); if (NETP.room) NETP.room.presence({ a:null }).catch(() => {}); updateNetChip(0); }

/* 매 프레임: 보내기 · 다른 선장님 맞추기 · 부드럽게 따라가기 */
function netStep(dt, time){
  if (!NETP.room) return;
  netSend(performance.now());
  if (NETP.area !== AREA.id){ netClear(); NETP.area = AREA.id; }
  const here = NET_AREAS[AREA.id], seen = new Set();
  if (here) for (const pe of NETP.peers){
    if (pe.isMe || pe.kind !== 'viewer') continue;
    const st = peerState(pe.presence); if (!st || st.a !== AREA.id) continue;
    seen.add(pe.peer);
    let R = NETP.avatars.get(pe.peer);
    if (!R){ R = makeRemote(st); NETP.avatars.set(pe.peer, R); } else { R.st = st; dressRemote(R); }
  }
  [...NETP.avatars.keys()].forEach(k => { if (!seen.has(k)) dropRemote(k); });
  /* 움직임: 받은 위치로 부드럽게 · 걸으면 팔다리를 흔들어요 */
  const k = Math.min(1, dt * 10);
  NETP.avatars.forEach(R => {
    const st = R.st, dx = st.x - R.x, dz = st.z - R.z, dist = Math.hypot(dx, dz);
    if (dist > 6){ R.x = st.x; R.z = st.z; } else { R.x += dx * k; R.z += dz * k; }
    let dr = st.r - R.r; dr = Math.atan2(Math.sin(dr), Math.cos(dr)); R.r += dr * k;
    const moving = dist > 0.03 && st.p !== 'sit';
    R.bob += moving ? dt * 10 : 0;
    const av = R.av, ud = av.userData, swing = moving ? Math.sin(R.bob) * 0.5 : 0;
    av.position.set(R.x, AREA.heightAt(R.x, R.z) + st.j + (st.p === 'sit' ? st.sy : moving ? Math.abs(Math.sin(R.bob)) * 0.05 : 0), R.z); av.rotation.y = R.r;
    if (st.p === 'drink'){ ud.arm.rotation.x = 0; ud.rArm.rotation.x = -2.25; }
    else if (st.p === 'sit'){ ud.arm.rotation.x = -0.55; ud.rArm.rotation.x = -0.55; }
    else { ud.arm.rotation.x = swing; ud.rArm.rotation.x = -swing; }
    const wob = reduceMotion ? 0 : Math.sin(time * 2.1 + R.x) * 0.06;
    ud.arm.rotation.z = ud.armZ + wob; ud.rArm.rotation.z = -ud.armZ - wob;
    if (Array.isArray(ud.legs)){ const [L, Rl] = ud.legs, air = st.j > 0.02;
      const lx = st.p === 'sit' ? -1.25 : air ? -0.35 : swing * 1.1, rx = st.p === 'sit' ? -1.25 : air ? 0.2 : -swing * 1.1;
      L.rotation.x += (lx - L.rotation.x) * k; Rl.rotation.x += (rx - Rl.rotation.x) * k; }
  });
  updateNetChip(here ? NETP.avatars.size + 1 : 0);
}
/* 위쪽 작은 표시: 지금 이 섬에 나 포함 몇 명 */
let netChipN = -1;
function updateNetChip(n){
  if (n === netChipN) return; netChipN = n;
  const el = $('#netChip'); if (!el) return;
  if (!n || !NETP.room){ el.hidden = true; return; }
  el.hidden = false; el.innerHTML = `<i></i>${AREA.id === 'tavern' ? '주점' : '다모였섬'}에 <b>${n}</b>명${n === 1 ? ' · 다른 선장님을 기다리는 중' : ''}`;
}
