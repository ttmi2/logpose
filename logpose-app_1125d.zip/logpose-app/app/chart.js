/* ============================================================
   LOG POSE · 갑판 3단계: 해도 탁자의 항해 지도
   장르 6개 = 바다 구역 6곳 (A~F 해역). 저장한 작품 = 자기 해역에 찍힌 표식.
   저장한 순서대로 '출항(선장실)'에서부터 점선 항로가 이어져요.
   기록은 로그포스 메뉴의 '저장한 목적지'와 같아요 (한쪽에서 지우면 여기서도 빠져요).
   ============================================================ */
const CH = { persona:$('#chPersona'), root:$('#chart'), svg:$('#chSvg'), pins:$('#chPins'), list:$('#chList'), stats:$('#chStats'), empty:$('#chEmpty'), close:$('#chClose'), find:$('#chFind') };
const CW = 1000, CHH = 640, START = { x:500, y:320 };
let chSel = null, chOpen = false;

function chZones(){
  return LPData.genres().map((g, i) => { const c = i % 3, r = Math.floor(i / 3); return { g, x:36 + c * 310, y:22 + r * 328, w:298, h:268 }; });
}
const svgEsc = s => String(s).replace(/[&<>"]/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;' }[c]));

/* 바탕: 양피지 · 해역 · 작은 섬들 · 물결 · 나침반 (한 번만 그려요) */
function chartBase(){
  const zones = chZones();
  let s = `<defs><pattern id="chWave" width="46" height="26" patternUnits="userSpaceOnUse"><path d="M3 15 q8 -7 16 0 t16 0" fill="none" stroke="rgba(90,64,40,.18)" stroke-width="1.4"/></pattern></defs>`;
  s += `<rect x="0" y="0" width="${CW}" height="${CHH}" fill="url(#chWave)"/>`;
  zones.forEach((z, i) => {
    const { g } = z;
    s += `<rect x="${z.x}" y="${z.y}" width="${z.w}" height="${z.h}" rx="22" fill="hsla(${g.hue},45%,62%,.16)" stroke="rgba(90,64,40,.45)" stroke-width="1.6" stroke-dasharray="7 6"/>`;
    /* 해역마다 작은 섬 두세 개 (모양은 늘 같아요) */
    for (let k = 0; k < 3; k++){
      const cx = z.x + 40 + hash3(i, k, 1) * (z.w - 80), cy = z.y + 100 + hash3(i, k, 2) * (z.h - 130), r = 10 + hash3(i, k, 3) * 14;
      let d = ''; for (let a = 0; a <= 12; a++){ const t = a / 12 * Math.PI * 2, rr = r * (0.7 + hash3(i * 7 + k, a, 4) * 0.5); d += `${a ? 'L' : 'M'}${(cx + Math.cos(t) * rr).toFixed(1)} ${(cy + Math.sin(t) * rr * .7).toFixed(1)} `; }
      s += `<path d="${d}Z" fill="rgba(160,128,84,.35)" stroke="rgba(90,64,40,.45)" stroke-width="1.2"/>`;
    }
    s += `<text x="${z.x + 18}" y="${z.y + 30}" class="ch-zk">${svgEsc(g.zone)} 해역</text><text x="${z.x + 18}" y="${z.y + 56}" class="ch-zn" fill="hsl(${g.hue},45%,30%)">${svgEsc(g.name)}</text>`;
  });
  /* 가운데: 출항 지점(선장실) 나침반 */
  s += `<g transform="translate(${START.x} ${START.y})" class="ch-rose">`;
  for (let k = 0; k < 8; k++){ const big = k % 2 === 0, L = big ? 34 : 20; s += `<path d="M0 ${-L} L${big ? 6 : 4} 0 L0 ${L} L${big ? -6 : -4} 0 Z" transform="rotate(${k * 45})" fill="${k === 0 ? '#8a2a1c' : big ? '#5a4030' : 'rgba(90,64,40,.55)'}"/>`; }
  s += `<circle r="9" fill="#f3ead6" stroke="#5a4030" stroke-width="2"/><text x="46" y="6" class="ch-start">출항 · 선장실</text></g>`;
  s += `<path id="chRoute" class="ch-route" d="" fill="none"/>`;
  CH.svg.innerHTML = s;
}

/* 표식 자리: 해역 안에서 작품마다 정해진 자리, 겹치면 살짝 밀어내요 */
function chPlace(items){
  const zones = chZones(), byG = {};
  items.forEach(it => { (byG[it.w.genre.id] = byG[it.w.genre.id] || []).push(it); });
  Object.keys(byG).forEach(gid => {
    const z = zones.find(q => q.g.id === gid); if (!z) return;
    const box = { x0:z.x + 34, x1:z.x + z.w - 34, y0:z.y + 100, y1:z.y + z.h - 26 };
    const list = byG[gid];
    list.forEach(it => { let h = 0; for (const c of it.w.id) h = (h * 31 + c.charCodeAt(0)) >>> 0; it.x = box.x0 + (h % 997) / 997 * (box.x1 - box.x0); it.y = box.y0 + ((h >>> 10) % 991) / 991 * (box.y1 - box.y0); });
    for (let it = 0; it < 40; it++) for (let a = 0; a < list.length; a++) for (let b = a + 1; b < list.length; b++){
      const A = list[a], B = list[b], dx = B.x - A.x, dy = B.y - A.y, d = Math.hypot(dx, dy) || 0.01;
      if (d < 54){ const push = (54 - d) / 2, ux = dx / d, uy = dy / d; A.x -= ux * push; A.y -= uy * push; B.x += ux * push; B.y += uy * push; }
    }
    list.forEach(it => { it.x = Math.min(box.x1, Math.max(box.x0, it.x)); it.y = Math.min(box.y1, Math.max(box.y0, it.y)); });
  });
  return items;
}


/* 선장 성향: 저장한 기록 + 취향 답변으로만 읽어요 (지어낸 정보 없음) */
const ARCH = { action:'최전선의 돌격대장', adventure:'열혈 승부사', fantasy:'미지의 세계 탐험가', mystery:'수수께끼 추적자', romance:'감성 항해사', comedy:'느긋한 휴양 선장' };
const VMOD = { world:'세계관을 파고드는', art:'눈이 즐거운 장면을 쫓는', character:'인물에 마음을 주는' };
const PERSONA_MIN = 3;
function chJosa(w, a, b){ const ch = Array.from(String(w)).reverse().find(c => c >= '가' && c <= '힣'); return ch && (ch.charCodeAt(0) - 0xAC00) % 28 ? a : b; }
function readPersona(items){
  const p = LPProfile.get() || {}, taste = p.taste || {}, n = items.length;
  if (n < PERSONA_MIN) return { short:true, n };
  const count = {}; items.forEach(it => { count[it.w.genre.id] = (count[it.w.genre.id] || 0) + 1; });
  const ranked = Object.entries(count).sort((a, b) => b[1] - a[1]);
  const [topId, topN] = ranked[0], top = LPData.genres().find(g => g.id === topId);
  const seas = ranked.length, lead = topN / n;
  const mixed = lead < 0.4 && seas >= 4;
  const vals = (taste.values || []).filter(v => VMOD[v]);
  const title = `${vals.length ? VMOD[vals[0]] + ' ' : ''}${mixed ? '여러 바다를 누비는 수집가' : ARCH[topId] || '항해가'}`;
  const lines = [];
  /* 1) 가장 많이 간 해역 */
  if (mixed) lines.push(`${n}곳의 표식이 ${seas}개 해역에 고르게 흩어져 있어요. 한 장르에 머물기보다 이것저것 맛보는 선장님이에요.`);
  else lines.push(`표식 ${n}곳 중 ${topN}곳이 ‘${top.name}’ 해역이에요. ${top.tag.replace(/분께$/, '선장님')}이에요.`);
  /* 2) 처음 고른 취향과 비교 */
  const chosen = (taste.genres || []).filter(Boolean);
  if (chosen.length){
    const inChosen = items.filter(it => chosen.includes(it.w.genre.id)).length / n;
    const names = chosen.map(id => (LPData.genres().find(g => g.id === id) || {}).name).filter(Boolean).join(' · ');
    if (inChosen >= 0.7) lines.push(`처음 고른 취향(${names}) 그대로 항로를 지키는 한결같은 편이에요.`);
    else if (inChosen < 0.4) lines.push(`처음 고른 취향(${names}) 밖의 바다도 거침없이 찾아가는 모험파예요.`);
    else lines.push(`취향(${names})을 중심에 두고 가끔 옆 바다에도 들러요.`);
  }
  /* 3) 고르는 방식 */
  const reps = items.filter(it => it.w.isRep).length, heavy = items.filter(it => (it.w.tips || []).some(t => /잔혹|무거운/.test(t)) || it.w.tags.some(t => /잔혹|무거운/.test(t))).length;
  const easy = items.filter(it => it.w.tags.some(t => /부담 없이/.test(t))).length;
  if (heavy >= 2 || heavy / n >= 0.3) lines.push('잔혹하거나 묵직한 이야기도 마다하지 않는 담대함이 있어요.');
  else if (easy >= 2) lines.push('부담 없이 시작할 수 있는 작품을 즐겨 고르는 편이에요.');
  if (reps / n >= 0.5) lines.push('장르 대표작부터 차근차근 짚는 정석파예요.');
  /* 4) 다음 항해 제안: 아직 표식이 없는 해역 */
  const unvisited = LPData.genres().filter(g => !count[g.id]);
  const next = unvisited.find(g => chosen.includes(g.id)) || unvisited[0];
  const tip = next ? `아직 ‘${next.name}’ 해역엔 표식이 없어요. 다음 항해지로 어떠세요?` : '여섯 해역에 모두 표식을 남겼어요. 진정한 대항해가예요!';
  return { title, lines, tip, next };
}
function renderPersona(items){
  const P = readPersona(items), el = CH.persona;
  if (!items.length){ el.hidden = true; return; }
  el.hidden = false;
  if (P.short){ el.innerHTML = `<p class="ch-pk">선장 성향</p><p class="ch-pshort">표식이 ${PERSONA_MIN}곳 이상 모이면 어떤 선장님인지 읽어 드려요. <b>지금 ${P.n}곳</b></p>`; return; }
  el.innerHTML = `<p class="ch-pk">선장 성향</p><h4>${escHTML(P.title)}</h4><ul>${P.lines.map(t => `<li>${escHTML(t)}</li>`).join('')}</ul>
    <p class="ch-ptip">${escHTML(P.tip)}${P.next ? ` <button type="button" class="ch-pgo" data-genre="${P.next.id}">${escHTML(P.next.name)} 둘러보기</button>` : ''}</p>
    <p class="ch-pnote">저장한 기록과 취향 답변으로만 정리했어요.</p>`;
  const go = el.querySelector('[data-genre]');
  if (go) go.addEventListener('click', () => { const g = go.dataset.genre; closeChart(); openMenu('new'); lmGenre = g; LM.query.value = ''; renderLmFind(); });
}

function renderChart(){
  const saved = savedList().map(s => ({ s, w:LPData.get(s.id) })).filter(x => x.w)
    .sort((a, b) => String(a.s.at).localeCompare(String(b.s.at)));   // 먼저 저장한 것부터
  const items = chPlace(saved);
  const seas = new Set(items.map(it => it.w.genre.id)).size;
  CH.stats.textContent = items.length ? `저장한 목적지 ${items.length}곳 · 지나온 해역 ${seas}곳` : '아직 출항 전이에요';
  renderPersona(items);
  CH.empty.hidden = items.length > 0; CH.root.classList.toggle('is-empty', !items.length);
  /* 항로: 출항 → 1 → 2 → … (부드러운 곡선) */
  const pts = [START, ...items];
  let d = `M${START.x} ${START.y}`;
  for (let i = 1; i < pts.length; i++){ const a = pts[i - 1], b = pts[i], mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2, nx = -(b.y - a.y) * .18, ny = (b.x - a.x) * .18; d += ` Q${(mx + nx).toFixed(1)} ${(my + ny).toFixed(1)} ${b.x.toFixed(1)} ${b.y.toFixed(1)}`; }
  const route = CH.svg.querySelector('#chRoute'); if (route) route.setAttribute('d', items.length ? d : '');
  if (chSel && !items.some(it => it.w.id === chSel)) chSel = null;
  if (!chSel && items.length) chSel = items[items.length - 1].w.id;
  const last = items.length - 1;
  CH.pins.innerHTML = items.map((it, i) => `<button type="button" class="ch-pin${i === last ? ' now' : ''}" data-id="${it.w.id}" aria-pressed="${it.w.id === chSel}" style="left:${it.x / CW * 100}%;top:${it.y / CHH * 100}%;--gh:${it.w.genre.hue}" aria-label="${i + 1}번째 기록 · ${escHTML(it.w.title)} · ${escHTML(it.w.genre.name)} 해역"><b>${i + 1}</b>${i === last ? '<span class="ch-now">최근</span>' : ''}<span class="ch-tip">${escHTML(it.w.title)}</span></button>`).join('');
  CH.list.innerHTML = items.map((it, i) => `
    <li data-id="${it.w.id}" class="${it.w.id === chSel ? 'on' : ''}">
      <button type="button" class="ch-row" data-sel="${it.w.id}" aria-pressed="${it.w.id === chSel}"><span class="ch-n" style="--gh:${it.w.genre.hue}">${i + 1}</span><span><b>${escHTML(it.w.title)}</b><small>${escHTML(it.w.genre.zone)} 해역 · ${escHTML(it.w.genre.name)}${fmtDay(it.s.at) ? ` · ${fmtDay(it.s.at)}` : ''}</small></span></button>
      ${it.w.id === chSel ? `<div class="ch-detail"><img src="${coverURL(it.w)}" alt=""><p>${escHTML(it.w.line)}</p><button type="button" class="g-btn primary" data-open="${it.w.id}">책상에서 열기</button></div>` : ''}
    </li>`).join('');
  CH.pins.querySelectorAll('[data-id]').forEach(b => b.addEventListener('click', () => chSelect(b.dataset.id, true)));
  CH.list.querySelectorAll('[data-sel]').forEach(b => b.addEventListener('click', () => chSelect(b.dataset.sel, false)));
  CH.list.querySelectorAll('[data-open]').forEach(b => b.addEventListener('click', () => { const id = b.dataset.open; closeChart(); openDeskInfo(id, {}); }));
}
function chSelect(id, fromPin){
  chSel = id; renderChart();
  const li = CH.list.querySelector(`li[data-id="${id}"]`);
  if (li){ try { li.scrollIntoView({ block:'nearest', behavior:reduceMotion ? 'auto' : 'smooth' }); } catch(e){} }
  const again = fromPin ? CH.pins.querySelector(`[data-id="${id}"]`) : CH.list.querySelector(`[data-sel="${id}"]`);
  if (again) try { again.focus({ preventScroll:true }); } catch(e){}
}

function openChart(){
  if (chOpen || AREA !== DECK_AREA) return;
  chOpen = true; uiOpen = true; keys.clear(); auto = null; $('#toast').hidden = true;
  const pEnd = new THREE.Vector3(-1.7, 2.9, -1.9), lEnd = new THREE.Vector3(-1.7, 0.95, -3.5);
  if (!CH.svg.firstChild) chartBase();
  chSel = null; renderChart();
  document.body.classList.add('chart-open');
  const show = () => { if (!chOpen) return; CH.root.hidden = false; CH.root.classList.remove('ch-rollup'); CH.root.classList.add('ch-unroll'); try { (CH.pins.querySelector('.now') || CH.close).focus({ preventScroll:true }); } catch(e){} };
  if (reduceMotion){ DECK_AREA.view = { pos:pEnd, look:lEnd }; show(); return; }
  /* 탁자 위로 크게 돌아 올라갔다가 지도 위로 내려다보며 다가가요 (1.3초) */
  const p0 = camPos.clone(), l0 = camTarget.clone(), pMid = new THREE.Vector3(-0.2, 5.4, -0.4), tp = p0.clone(), tl = l0.clone(), a = new THREE.Vector3(), b = new THREE.Vector3();
  DECK_AREA.view = { pos:tp, look:tl };
  camTween(1.3, (t, e) => { lerpV(a, p0, pMid, e); lerpV(b, pMid, pEnd, e); lerpV(tp, a, b, e); lerpV(tl, l0, lEnd, Math.min(1, e * 1.4)); }, show);
}
function closeChart(){
  if (!chOpen) return;
  chOpen = false;
  const fin = () => { CH.root.hidden = true; CH.root.classList.remove('ch-rollup', 'ch-unroll'); document.body.classList.remove('chart-open'); DECK_AREA.view = null; uiOpen = false; };
  if (reduceMotion) fin(); else { CH.root.classList.remove('ch-unroll'); CH.root.classList.add('ch-rollup'); setTimeout(fin, 320); }
  try { renderer.domElement.focus({ preventScroll:true }); } catch(e){}
}
CH.close.addEventListener('click', () => closeChart());
CH.find.addEventListener('click', () => { closeChart(); openMenu('new'); });
window.addEventListener('keydown', e => {
  if (!chOpen || CH.root.hidden) return;
  if (e.key === 'Escape'){ e.preventDefault(); closeChart(); return; }
  if (e.key === 'Tab'){
    const f = [...CH.root.querySelectorAll('button')].filter(b => b.offsetParent !== null);
    if (!f.length) return; const first = f[0], last = f[f.length - 1];
    if (e.shiftKey && document.activeElement === first){ e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && document.activeElement === last){ e.preventDefault(); first.focus(); }
  }
});
DECK_SPOTS.chart.use = () => openChart();
menuHooks.push(() => { if (chOpen) renderChart(); });
