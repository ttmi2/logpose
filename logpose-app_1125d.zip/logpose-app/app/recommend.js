/* ============================================================
   LOG POSE · 추천 (단계 4)
   취향 답변 + 기존 작품 데이터로만 점수를 매겨요. 추천 이유도 점수를 올린 근거 그대로예요.
   점수: 좋아하는 장르 +3 · 본 작품과 같은 장르 +2 · (본 작품 없음) 부담 없이 시작 +1.5, 대표작 +1
         · 중요하게 보는 것(세계관/작화/캐릭터)과 강점이 맞으면 +1씩
   한 장르 상한: 장르를 1개 골랐으면 3편, 2개 골랐으면 2편씩. 동점은 선장마다 고정된 무작위 순서.
   ============================================================ */
const LPRecommend = (() => {
  const VNAME = { world:'탄탄한 세계관', art:'작화', character:'캐릭터' };
  /* 받침에 맞는 조사: 마지막 한글 글자 기준 */
  const hasBatchim = s => { const ch = Array.from(String(s)).reverse().find(c => c >= '가' && c <= '힣'); return ch ? (ch.charCodeAt(0) - 0xAC00) % 28 !== 0 : false; };
  /* 선장마다 고정된 무작위 동점 순서 */
  const hash = s => { let h = 2166136261; for (const c of String(s)) { h ^= c.charCodeAt(0); h = Math.imul(h, 16777619); } return h >>> 0; };
  const DRAFT = (typeof LP_STRENGTHS_DRAFT !== 'undefined' && LP_STRENGTHS_DRAFT) ? LP_STRENGTHS_DRAFT : {};
  /* 팀이 검토한 강점(extra.js)이 있으면 그걸, 없으면 단어 초안을 써요 */
  const strengthsOf = w => (w.strengths && w.strengths.length) ? w.strengths : (DRAFT[w.id] || []);

  function score(w, taste){
    let s = 0; const why = [];
    const genres = taste.genres || [], seen = taste.seen || [], values = taste.values || [];
    if (genres.includes(w.genre.id)){ s += 3; why.push({ k:'genre', t:`좋아하는 ‘${w.genre.name}’ 작품이에요` }); }
    const mate = seen.map(id => LPData.get(id)).find(x => x && x.genre.id === w.genre.id);
    if (mate){ s += 2; why.push({ k:'seen', t:`재밌게 본 ‘${mate.title}’${hasBatchim(mate.title) ? '과' : '와'} 같은 계열이에요` }); }
    if (taste.none){
      if (w.tags.includes('부담 없이 시작')){ s += 1.5; why.push({ k:'easy', t:'처음 보기 부담 없는 작품이에요' }); }
      if (w.isRep){ s += 1; why.push({ k:'rep', t:`‘${w.genre.name}’ 장르의 대표작이에요` }); }
    }
    for (const v of strengthsOf(w)) if (values.includes(v)){ s += 1; why.push({ k:'value', t:`선장님이 중요하게 보는 ‘${VNAME[v]}’${hasBatchim(VNAME[v]) ? '이' : '가'} 돋보이는 작품이에요` }); }
    return { s, why };
  }

  /* 상위 n편. 한 장르는 2편까지만, 이미 보여준 작품(exclude)과 본 작품은 빼요 */
  function recommend(taste, opts = {}){
    const n = opts.count || 4, exclude = new Set([...(taste.seen || []), ...(opts.exclude || [])]);
    const seed = String(opts.seed || '');
    const tie = w => hash(seed + ':' + w.id);
    const ranked = LPData.all().filter(w => !exclude.has(w.id)).map(w => Object.assign({ w }, score(w, taste)))
      .sort((a, b) => b.s - a.s || (b.w.isRep - a.w.isRep) || tie(a.w) - tie(b.w));
    const cap = (taste.genres || []).length <= 1 ? 3 : 2;
    const out = [], perGenre = {};
    for (const r of ranked){ if (out.length >= n) break; const g = r.w.genre.id; if ((perGenre[g] || 0) >= cap) continue; perGenre[g] = (perGenre[g] || 0) + 1; out.push(r); }
    for (const r of ranked){ if (out.length >= n) break; if (!out.includes(r)) out.push(r); }
    return out.map(r => ({ id:r.w.id, work:r.w, score:r.s, reasons:r.why.slice(0, 2).map(x => x.t) }));
  }
  return { recommend, score, strengthsOf, VNAME };
})();
