/* ============================================================
   LOG POSE · 다모였섬 한눈에 보기 (처음 도착했을 때 한 번)
   카메라가 섬 위를 날아다니며 장소를 하나씩 비추고, 아래 카드로 할 수 있는 일을 정리해 줘요.
   다시 보기: 다모였섬에서 '?' 도움말 → '다모였섬 한눈에 보기'.
   장소 · 문구를 바꾸려면 아래 TOUR 배열만 고치면 돼요 (pos = 카메라 위치, look = 바라볼 곳, 단위 m).
   ============================================================ */
const TOUR_KEY = 'logpose.isleTour';
const TOUR = [
  { k:'⚓', t:'다모였섬에 오신 걸 환영해요', d:'이름 그대로 <b>다 모였섬</b>! 모든 선장님이 모이는 공용 섬이에요. 어느 해적단의 것도 아닌 평화지대예요. 어디에 무엇이 있는지 한 바퀴 둘러볼게요.',
    pos:[0, 40, 48], look:[0, 0, -2] },
  { k:'⛵', t:'선착장 · 내 배', d:'처음 내리는 곳이에요. 내 배로 돌아가려면 위쪽 <b>선장실</b> · <b>갑판</b> 버튼을 누르면 돼요.',
    pos:[11, 7, 52], look:[-3, 0.5, 41] },
  { k:'🛒', t:'시장 거리', d:'잡은 물고기를 <b>은화</b>로 팔고, 그 은화로 <b>모자 · 옷 · 해적기</b>를 사요. 가진 은화는 위쪽 \'나가기\' 아래에 보여요.',
    pos:[7, 7, -3], look:[18, 1.2, -3] },
  { k:'📜', t:'현상금 게시판', d:'오리지널 해적 <b>수배서</b>를 구경하고, 좋아하는 <b>캐릭터를 응원</b>해요. 인기 캐릭터와 현상금 선장 순위도 여기 있어요.',
    pos:[0, 4.5, -8.5], look:[0, 2, -18] },
  { k:'💪', t:'강자 ZONE', d:'게시판 뒤 양양 서퍼비치 느낌의 해적 헬스장이에요. 돛대 밧줄 · 턱걸이 · 닻 덤벨 등 <b>운동 7가지</b>를 하면 세트가 기록돼요. 가까이 가면 운동 음악이 나와요.',
    pos:[13, 9, -16], look:[0, 0.8, -25] },
  { k:'🍺', t:'주점 럼통', d:'커다란 럼통 안의 주점이에요. 들어가면 <b>주점 노래</b>가 나오고, 바텐더에게 말을 걸거나 의자에 앉아 쉴 수 있어요.',
    pos:[-4, 7, 21], look:[-15, 2, 13] },
  { k:'🎣', t:'공용 낚시터', d:'섬 서쪽으로 길게 뻗은 잔교 끝에서 낚시해요. <b>낮과 밤</b>에 잡히는 물고기가 달라요. 아주 드물게 <b>보물 물고기</b>도 나와요.',
    pos:[-25, 10, 8], look:[-46, 0, -5] },
  { k:'🏖', t:'쉼터', d:'선착장 옆 <b>파라솔</b> 아래 누워 바다를 보거나, <b>모닥불</b> 곁 · <b>평상</b>에 앉아 쉴 수 있어요.',
    pos:[15, 5, 31], look:[6, 0.6, 23.5] },
  { k:'🗺', t:'길 찾기', d:'오른쪽 아래 <b>지도</b>를 누르면 그쪽으로 걸어가요 (휴대폰은 오른쪽 위). 가까이 가면 아래에 버튼이 떠요. 이 안내는 <b>?</b> 도움말에서 다시 볼 수 있어요.',
    pos:null, look:null }
];
const tourEl = document.createElement('section');
tourEl.className = 'lp-tour'; tourEl.hidden = true; tourEl.setAttribute('role', 'dialog'); tourEl.setAttribute('aria-labelledby', 'lpTourT');
document.body.appendChild(tourEl);
const TR = { on:false, i:0, wasUi:false, view:null, goal:null };

function tourShow(i){
  TR.i = Math.max(0, Math.min(TOUR.length - 1, i));
  const s = TOUR[TR.i], last = TR.i === TOUR.length - 1;
  if (s.pos){ TR.view.pos.set(...s.pos); TR.goal.set(...s.look); ISLE_AREA.view = TR.view; }   /* 위치는 cabin.js 가, 바라보는 곳은 아래 tourLook 이 부드럽게 옮겨요 */
  else ISLE_AREA.view = null;   /* 마지막 카드: 카메라는 다시 내 캐릭터로 */
  tourEl.innerHTML = `<div class="lp-tour-card">
    <p class="lp-tour-k"><span aria-hidden="true">${s.k}</span> 다모였섬 한눈에 보기 · ${TR.i + 1} / ${TOUR.length}</p>
    <h2 id="lpTourT">${s.t}</h2><p class="lp-tour-d">${s.d}</p>
    <div class="lp-tour-dots" aria-hidden="true">${TOUR.map((_, k) => `<i class="${k === TR.i ? 'on' : ''}"></i>`).join('')}</div>
    <div class="lp-tour-row">
      <button type="button" class="lp-tour-skip" data-act="end">${last ? '' : '건너뛰기'}</button>
      <span>${TR.i ? '<button type="button" class="lp-tour-btn ghost" data-act="prev">이전</button>' : ''}
      <button type="button" class="lp-tour-btn" data-act="${last ? 'end' : 'next'}">${last ? '둘러보기 시작' : '다음'}</button></span>
    </div></div>`;
  const skip = tourEl.querySelector('.lp-tour-skip'); if (last) skip.style.visibility = 'hidden';
  setTimeout(() => { const b = tourEl.querySelector(`[data-act="${last ? 'end' : 'next'}"]`); if (b) b.focus({ preventScroll:true }); }, 30);
}
function startIsleTour(){
  if (TR.on || MODE !== 'cabin' || !AREA || AREA.id !== 'isle') return;
  if (typeof closeHelp === 'function') closeHelp();
  TR.on = true; TR.wasUi = uiOpen; uiOpen = true; if (typeof keys !== 'undefined') keys.clear(); auto = null;
  if (player.pose === 'sit') standUp();
  TR.view = { pos:new THREE.Vector3(), look:camTarget.clone() }; TR.goal = camTarget.clone();
  requestAnimationFrame(tourLook);
  document.body.classList.add('tour-open'); tourEl.hidden = false; tourShow(0);
}
function tourLook(){ if (!TR.on) return; TR.view.look.lerp(TR.goal, reduceMotion ? 1 : 0.07); requestAnimationFrame(tourLook); }
function endIsleTour(){
  if (!TR.on) return;
  TR.on = false; tourEl.hidden = true; document.body.classList.remove('tour-open');
  LPTrack.event(TR.i === TOUR.length - 1 ? 'tour_done' : 'tour_skip', 'isle', String(TR.i + 1));   /* 방문 기록 (track.js) */
  if (ISLE_AREA.view === TR.view) ISLE_AREA.view = null;
  uiOpen = TR.wasUi;
  try { localStorage.setItem(TOUR_KEY, '1'); } catch(e){}
}
tourEl.addEventListener('click', e => {
  const b = e.target.closest('[data-act]'); if (!b) return;
  const a = b.dataset.act; if (a === 'next') tourShow(TR.i + 1); else if (a === 'prev') tourShow(TR.i - 1); else endIsleTour();
});
document.addEventListener('keydown', e => {   /* 안내 중엔 ← → 로 넘기고 Esc 로 끝내요 (카드에 초점이 없어도) */
  if (!TR.on) return;
  if (e.key === 'Escape'){ e.preventDefault(); endIsleTour(); }
  else if (e.key === 'ArrowRight'){ e.preventDefault(); if (TR.i < TOUR.length - 1) tourShow(TR.i + 1); }
  else if (e.key === 'ArrowLeft'){ e.preventDefault(); tourShow(TR.i - 1); }
  else return;
  e.stopPropagation();
}, true);
/* 다른 곳으로 이동하면 안내도 끝나요 */
setInterval(() => { if (TR.on && (MODE !== 'cabin' || !AREA || AREA.id !== 'isle')) endIsleTour(); }, 500);

/* 처음 도착하면 환영 인사 대신 한눈에 보기를 열어요 (한 번 보면 다음부턴 예전처럼 인사만) */
{ const hello = ISLE_AREA.welcome;
  ISLE_AREA.welcome = function(opts){
    let seen = false; try { seen = localStorage.getItem(TOUR_KEY) === '1'; } catch(e){ seen = TR.seenMem; }
    if (seen || (opts && opts.from === 'tavern')) return hello.call(this, opts);
    TR.seenMem = true; setTimeout(startIsleTour, 600);
  }; }
