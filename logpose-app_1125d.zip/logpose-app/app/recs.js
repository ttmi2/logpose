/* ============================================================
   LOG POSE · 로그포스 활성화 + 추천 카드 4장 (단계 4)
   취향 기록이 끝나면: 손목 로그포스에서 빛이 퍼지고 '빛이나요!' → 추천 카드가 부채꼴로 펼쳐져요.
   '다른 목적지 찾기'는 이미 보여준 작품을 빼고 다음 4편을 보여줘요.
   ============================================================ */
const RC = { fx:$('#lpfx'), root:$('#recs'), list:$('#rcList'), sub:$('#rcSub'), title:$('#rcTitle'), kick:$('.rc-k'), findBtn:$('#rcFindBtn') };
const coverCache = {};
/* 기존 데이터의 표지 재료(색 · 제목 줄)로 그린 표지 */
function coverURL(w){
  if (w.image) return w.image;
  if (coverCache[w.id]) return coverCache[w.id];
  const c = document.createElement('canvas'); c.width = 300; c.height = 420; const g = c.getContext('2d');
  if (!g) return '';
  const cv = w.cover || {}, bg = cv.bg || ['#5a3820', '#2a1a0f'], ink = cv.ink || '#f3e8d2';
  const gr = g.createLinearGradient(0, 0, 0, 420); gr.addColorStop(0, bg[0]); gr.addColorStop(1, bg[1]); g.fillStyle = gr; g.fillRect(0, 0, 300, 420);
  g.strokeStyle = 'rgba(217,179,108,.75)'; g.lineWidth = 3; g.strokeRect(14, 14, 272, 392); g.lineWidth = 1; g.strokeRect(22, 22, 256, 376);
  g.fillStyle = ink; g.textAlign = 'center'; g.textBaseline = 'middle';
  const lines = cv.lines && cv.lines.length ? cv.lines : [w.title];
  let size = 46; g.font = `700 ${size}px ${FD}`;
  while (size > 22 && lines.some(l => g.measureText(l).width > 236)){ size -= 2; g.font = `700 ${size}px ${FD}`; }
  const top = 190 - (lines.length - 1) * size * 0.62;
  lines.forEach((l, i) => g.fillText(l, 150, top + i * size * 1.24));
  if (cv.en){ g.font = `600 13px ${FB}`; g.globalAlpha = .75; g.fillText(cv.en, 150, top + lines.length * size * 1.24 + 6); g.globalAlpha = 1; }
  g.font = `500 14px ${FB}`; g.globalAlpha = .8; g.fillText(w.genre.name, 150, 372); g.globalAlpha = 1;
  try { coverCache[w.id] = c.toDataURL('image/png'); } catch(e){ coverCache[w.id] = ''; }
  return coverCache[w.id];
}

/* 손목 로그포스의 화면 위치 (못 구하면 화면 아래 가운데) */
const _wrist = new THREE.Vector3();
function wristScreen(){
  try {
    player.mesh.userData.logpose.group.getWorldPosition(_wrist); _wrist.project(camera);
    const x = (_wrist.x + 1) / 2 * window.innerWidth, y = (1 - _wrist.y) / 2 * window.innerHeight;
    if (Number.isFinite(x) && Number.isFinite(y) && x > 0 && y > 0 && x < window.innerWidth && y < window.innerHeight) return { x, y };
  } catch(e){}
  return { x:window.innerWidth / 2, y:window.innerHeight * 0.62 };
}

/* 빛 연출 */
function playGlow(big, then){
  const p = wristScreen(), fx = RC.fx;
  fx.style.setProperty('--x', p.x + 'px'); fx.style.setProperty('--y', p.y + 'px');
  fx.innerHTML = '';
  fx.className = 'lpfx on' + (big ? ' big' : '');
  fx.hidden = false;
  const glow = document.createElement('div'); glow.className = 'lp-glow'; fx.appendChild(glow);
  if (big && !reduceMotion){
    for (let i = 0; i < 26; i++){
      const s = document.createElement('i'); s.className = 'lp-spark';
      const a = Math.random() * Math.PI * 2, d = 90 + Math.random() * 260;
      s.style.setProperty('--dx', Math.cos(a) * d + 'px'); s.style.setProperty('--dy', Math.sin(a) * d - 60 + 'px');
      s.style.animationDelay = (Math.random() * 0.25).toFixed(2) + 's'; fx.appendChild(s);
    }
    const b = document.createElement('div'); b.className = 'lp-bubble'; b.textContent = '빛이나요!'; fx.appendChild(b);
  }
  pulseLogpose(); lpPulse = big ? 2.4 : 1.2;
  const wait = reduceMotion ? 250 : (big ? 1700 : 650);
  setTimeout(() => { then(); setTimeout(() => { fx.hidden = true; fx.className = 'lpfx'; fx.innerHTML = ''; }, reduceMotion ? 100 : 700); }, wait);
}

/* 추천 받기 · 보여주기 */
let rcCurrent = [];
function takeRecs(fresh){
  const p = LPProfile.get(); if (!p || !p.taste) return [];
  let shown = fresh ? [] : (p.recShown || []);
  let list = LPRecommend.recommend(p.taste, { exclude:shown, seed:p.nickname + (p.createdAt || '') });
  if (list.length < 4){ shown = []; list = LPRecommend.recommend(p.taste, { seed:p.nickname + (p.createdAt || '') + 'again' }); toast('모든 목적지를 한 번씩 보여드렸어요. 처음부터 다시 가리킬게요.'); }
  LPProfile.update({ recShown:[...shown, ...list.map(r => r.id)], lastRecs:list.map(r => r.id) });
  return list;
}
/* '직접 찾기' → 로그포스 메뉴의 새 목적지 탭 (menu.js) */
RC.findBtn.addEventListener('click', () => { closeRecs(); openMenu('new', { search:true }); });

function renderRecs(list){
  rcCurrent = list;
  const p = LPProfile.get();
  RC.sub.textContent = `${p ? p.nickname : ''} 선장님의 취향으로 고른 ${list.length}편이에요`;
  RC.list.innerHTML = list.map((r, i) => `
    <li style="--i:${i}">
      <button type="button" class="rc-card" data-rec="${r.id}">
        <img class="rc-cover" src="${coverURL(r.work)}" alt="">
        <span class="rc-genre" style="--gh:${r.work.genre.hue}">${escHTML(r.work.genre.name)}</span>
        <b class="rc-title">${escHTML(r.work.title)}</b>
        <ul class="rc-why">${r.reasons.map(t => `<li>${escHTML(t)}</li>`).join('') || `<li>${escHTML(r.work.line)}</li>`}</ul>
        <span class="rc-go">책상에서 자세히 보기</span>
      </button>
    </li>`).join('');
  RC.list.querySelectorAll('[data-rec]').forEach(b => b.addEventListener('click', () => pickRec(b.dataset.rec)));
}
function showRecs(opts = {}){
  const list = opts.list || takeRecs(!!opts.fresh); if (!list.length) return;
  uiOpen = true; keys.clear(); auto = null; $('#toast').hidden = true;
  cam.distT = 2.4;
  const open = () => { renderRecs(list); RC.root.hidden = false; RC.root.classList.remove('leave'); document.body.classList.add('recs-open'); setTimeout(() => { const b = RC.list.querySelector('.rc-card'); if (b) b.focus({ preventScroll:true }); }, 80); };
  if (opts.fx === 'none') open(); else playGlow(opts.fx === 'big', open);
}
function closeRecs(){
  RC.root.hidden = true; document.body.classList.remove('recs-open');
  uiOpen = false; cam.distT = isTouch ? 4.0 : 3.6;
}
/* 카드 고르기 → 단계 5(책상 정보창)로 이어질 자리 */
function pickRec(id){
  const w = LPData.get(id); if (!w) return;
  closeRecs();
  const r = rcCurrent.find(x => x.id === id);
  if (typeof openDeskInfo === 'function') { openDeskInfo(id, { reasons:r ? r.reasons : null }); return; }
  goTo(SPOTS.desk.x, SPOTS.desk.z, { face:SPOTS.desk.face, then:() => toast(`「${escHTML(w.title)}」의 자세한 정보는 곧 이 <strong>책상</strong> 위에 펼쳐질 거예요.`) });
}
$('#rcMore').addEventListener('click', () => { const list = takeRecs(false); if (!list.length) return; RC.root.classList.add('leave'); playGlow(false, () => { renderRecs(list); RC.root.classList.remove('leave'); setTimeout(() => { const b = RC.list.querySelector('.rc-card'); if (b) b.focus({ preventScroll:true }); }, 60); }); });
$('#rcClose').addEventListener('click', () => closeRecs());
window.addEventListener('keydown', e => { if (!RC.root.hidden && e.key === 'Escape'){ e.preventDefault(); closeRecs(); } });

/* 저장해 둔 마지막 추천(id 목록)을 다시 카드로 */
function recsFromIds(ids){
  const p = LPProfile.get(); if (!p || !p.taste) return [];
  return (ids || []).map(id => LPData.get(id)).filter(Boolean).map(w => ({ id:w.id, work:w, reasons:LPRecommend.score(w, p.taste).why.slice(0, 2).map(x => x.t) }));
}
/* 취향 기록이 끝나면 (taste.js 가 불러요): 큰 연출과 함께 첫 추천 */
function onTasteDone(){ setTimeout(() => showRecs({ fx:'big', fresh:true }), 350); }
