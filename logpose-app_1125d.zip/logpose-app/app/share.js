/* ============================================================
   LOG POSE · 공유 저장소 연결부 (LPShare)
   여러 선장이 함께 쓰는 데이터(유리병 · 신고 · 나중에 수배서)는 모두 이 객체만 거쳐요.
   공유 링크로 열면: 페이지의 공유 저장소(db)로 모두와 함께 써요 (각자 자기 문서만 써요).
   파일로 열면: '이 브라우저 안의 연습용 바다' (localStorage 'logpose.sea')
   나중에 웹사이트: 아래 LPShare 의 함수들만 서버(예: Supabase · Firebase · 자체 API)로 바꾸면 돼요.
         함수 이름 · 받는 값 · 돌려주는 값(모두 Promise)만 지켜 주세요. 자세한 건 README '공유 저장소 바꾸기'.
   ============================================================ */
/* 현상금 선장 수배서: 모습(옷 · 모자 · 안경 id)과 사진은 남이 보낸 값이라 다듬어서 써요 */
const capLook = l => { l = l && typeof l === 'object' ? l : {}; const id = v => String(v == null ? '' : v).replace(/[^a-z]/g, '').slice(0, 12);
  return { o:id(l.o) || 'rags', h:id(l.h) || 'none', g:id(l.g) || 'bare' }; };
const capPhotoOk = v => typeof v === 'string' && /^data:image\/jpeg;base64,[A-Za-z0-9+/=]+$/.test(v) && v.length < 40000 ? v : '';
const LPShare = (() => {
  const KEY = 'logpose.sea', MAX = 400, HIDE_AT = 2, MINE_MAX = 30;
  /* ---------- 함께 쓰는 바다 (이 공유 링크로 들어왔을 때: 페이지의 공유 저장소 db) ----------
     각 선장은 자기 문서 하나씩만 써요: bottles/<id> · reports/<id> · cheers/<id> · captains/<id>
     모두가 읽고, 페이지 주인만 남의 것을 고칠 수 있어요. db 를 못 쓰면(파일로 연 경우 등) 이 브라우저 안의 연습용 바다로 돌아가요. */
  const NET = { db:null, uid:null, tried:false };
  const timeout = (p, ms = 8000) => Promise.race([p, new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), ms))]);
  const netReady = (async () => {
    try {
      const [db, user] = await Promise.all([lpUse('db'), lpUse('user')]);   /* backend.js: 공유 링크 · Supabase · 없음 */
      if (!db || !user) return false;
      const uid = await user.id(); if (!uid) return false;
      NET.db = db; NET.uid = String(uid); return true;
    } catch(e){ return false; }
  })();
  const online = async () => { const ok = await netReady; return ok && NET.db ? NET.db : null; };
  const mine = col => NET.db.doc(col + '/' + NET.uid);
  const getMine = async col => { const s = await timeout(mine(col).get()); return s.exists ? (s.data() || {}) : {}; };
  const all = async col => { const q = await timeout(NET.db.collection(col).limit(400).get()); return q.docs.filter(d => d.exists).map(d => ({ id:d.id, data:d.data() || {} })); };

  const read = () => { try { const v = JSON.parse(localStorage.getItem(KEY) || 'null'); if (v && Array.isArray(v.bottles)) return { bottles:v.bottles, reports:v.reports || {} }; } catch(e){} return { bottles:[], reports:{} }; };
  const write = d => { try { localStorage.setItem(KEY, JSON.stringify(d)); return true; } catch(e){ return false; } };
  /* 병 하나의 모양 (서버로 옮겨도 같은 모양으로 주고받아요) — 남이 쓴 값이라 읽을 때마다 다시 다듬어요
     { id, work:작품 id, text:한줄평(60자), at:ISO 시각, from:{ name, kind }, owner:선장 id } */
  const str = (v, n) => String(v == null ? '' : v).replace(/[<>]/g, '').slice(0, n);
  const clean = b => ({ id:str(b.id, 40), work:str(b.work, 60), text:str(b.text, 60), at:str(b.at, 40), from:{ name:str((b.from && b.from.name) || '이름 없는', 12), kind:(b.from && b.from.kind) === 'laftel-demo' ? 'laftel-demo' : 'guest' }, owner:str(b.owner, 40) });
  const num = v => { const n = Number(v); return isFinite(n) && n > 0 ? Math.min(n, 1e7) : 0; };
  /* 수배서 게시판 저장 (연습용: localStorage 'logpose.board') */
  const BKEY = 'logpose.board';
  const readBoard = () => { try { const v = JSON.parse(localStorage.getItem(BKEY) || 'null'); if (v && v.totals) return { week:v.week, totals:v.totals, last:v.last || null, captains:v.captains || {} }; } catch(e){} return { week:weekKey(), totals:{}, last:null, captains:{} }; };
  const writeBoard = b => { try { localStorage.setItem(BKEY, JSON.stringify(b)); } catch(e){} };
  function rollBoard(){
    const b = readBoard(), now = weekKey();
    if (b.week !== now){
      const top = Object.entries(b.totals).sort((x, y) => y[1].amt - x[1].amt)[0];
      if (top) b.last = { week:b.week, key:top[0], amt:top[1].amt, cheerers:top[1].by.length };
      b.week = now; b.totals = {}; writeBoard(b);
    }
    return b;
  }
  const prevWeek = () => weekKey(new Date(Date.now() - 7 * 864e5));
  /* 모두의 응원 문서를 더해 이번 주 · 지난 주 순위를 만들어요 */
  async function netBoard(){
    const docs = await all('cheers'), now = weekKey(), pw = prevWeek(), cur = {}, last = {};
    const add = (T, totals, who) => Object.entries(totals || {}).forEach(([k, v]) => { const key = str(k, 80), a = num(v); if (!a) return; const t = T[key] = T[key] || { amt:0, by:new Set() }; t.amt += a; t.by.add(who); });
    docs.forEach(d => { const x = d.data;
      if (x.week === now) add(cur, x.totals, d.id); else if (x.week === pw) add(last, x.totals, d.id);
      if (x.prev && x.prev.week === pw) add(last, x.prev.totals, d.id); });
    const ranks = Object.entries(cur).map(([key, t]) => ({ key, amt:t.amt, cheerers:t.by.size })).sort((a, b) => b.amt - a.amt);
    const top = Object.entries(last).sort((a, b) => b[1].amt - a[1].amt)[0];
    return { week:now, ranks, last:top ? { week:pw, key:top[0], amt:top[1].amt, cheerers:top[1].by.size } : null };
  }
  return {
    /* 지금 연결된 저장소: { ok, mode:'local' | 'server', label } */
    async status(){ return (await online()) ? { ok:true, mode:'server', label:lpBackendLabel() } : { ok:true, mode:'local', label:'이 브라우저 안의 연습용 바다' }; },
    /* 내 병들을 공용 바다에 띄워요 (이미 있는 id 는 건너뛰어요) → 새로 띄운 개수 */
    async putBottles(list){
      if (!list || !list.length) return 0;
      if (await online()){
        try { const m = await getMine('bottles'), cur = Array.isArray(m.list) ? m.list.map(clean) : [], have = new Set(cur.map(b => b.id)); let n = 0;
          list.forEach(b => { const c = clean(b); if (!have.has(c.id)){ cur.push(c); n++; } });
          if (n) await timeout(mine('bottles').set({ list:cur.slice(-MINE_MAX), at:new Date().toISOString() }));
          return n; } catch(e){ return 0; }
      }
      const d = read(), have = new Set(d.bottles.map(b => b.id)); let n = 0;
      list.forEach(b => { if (!have.has(String(b.id))){ d.bottles.push(clean(b)); n++; } });
      if (d.bottles.length > MAX) d.bottles = d.bottles.slice(-MAX);
      return write(d) ? n : 0;
    },
    /* 낚을 수 있는 병: 내 병 · 숨겨진 병 · 이미 낚은 병은 빼요 */
    async listBottles({ notOwner = '', exclude = [] } = {}){
      const ex = new Set(exclude);
      if (await online()){
        try { const [bd, rd] = await Promise.all([all('bottles'), all('reports')]), rep = {};
          rd.forEach(d => (Array.isArray(d.data.ids) ? d.data.ids : []).slice(0, 200).forEach(id => { (rep[id] = rep[id] || new Set()).add(d.id); }));
          const out = [];
          bd.forEach(d => { if (d.id === NET.uid) return; (Array.isArray(d.data.list) ? d.data.list : []).slice(0, MINE_MAX).forEach(b => { const c = clean(b);
            if (c.owner !== notOwner && !ex.has(c.id) && (!rep[c.id] || rep[c.id].size < HIDE_AT)) out.push(c); }); });
          return out; } catch(e){ return []; }
      }
      const d = read();
      return d.bottles.filter(b => b.owner !== notOwner && !ex.has(b.id) && (d.reports[b.id] || []).length < HIDE_AT).map(clean);
    },
    /* 스포일러 신고: 같은 선장은 한 번만 · HIDE_AT 번 쌓이면 모두에게서 숨겨요 → { count, hidden } */
    async report(id, by){
      if (await online()){
        try { const m = await getMine('reports'), ids = Array.isArray(m.ids) ? m.ids.map(x => str(x, 40)) : [];
          if (!ids.includes(id)){ ids.push(id); await timeout(mine('reports').set({ ids:ids.slice(-200) })); }
          const rd = await all('reports'), count = rd.filter(d => Array.isArray(d.data.ids) && d.data.ids.includes(id)).length;
          return { count, hidden:count >= HIDE_AT }; } catch(e){ return { count:1, hidden:false }; }
      }
      const d = read(), r = d.reports[id] = d.reports[id] || [];
      if (!r.includes(by)) r.push(by); write(d);
      return { count:r.length, hidden:r.length >= HIDE_AT };
    },
    /* ---------- 수배서 게시판: 이번 주 캐릭터 응원 순위 ----------
       응원 하나의 모양: key = '작품id:캐릭터 이름' · amt(은화) · by(응원한 선장 id 들)
       매주 월요일 0시(한국 시간)에 새로 시작하고, 지난 주 1위는 last 에 남겨요. */
    async board(){
      if (await online()){ try { return await netBoard(); } catch(e){ /* 못 읽으면 연습용으로 */ } }
      const b = rollBoard(); return { week:b.week, ranks:Object.entries(b.totals).map(([key, t]) => ({ key, amt:t.amt, cheerers:t.by.length })).sort((x, y) => y.amt - x.amt), last:b.last };
    },
    async cheer(key, amount, by){
      if (await online()){
        try { const m = await getMine('cheers'), now = weekKey(), pw = prevWeek();
          let doc = { week:now, totals:{}, prev:null };
          if (m.week === now) doc = { week:now, totals:Object.assign({}, m.totals || {}), prev:m.prev || null };
          else if (m.week === pw) doc.prev = { week:pw, totals:m.totals || {} };
          doc.totals[key] = num(doc.totals[key]) + Math.max(0, amount | 0);
          await timeout(mine('cheers').set(doc));
          const b = await netBoard(), r = b.ranks.find(x => x.key === key) || { amt:doc.totals[key], cheerers:1 };
          return { amt:r.amt, cheerers:r.cheerers }; } catch(e){ /* 연습용으로 */ }
      }
      const b = rollBoard(), t = b.totals[key] = b.totals[key] || { amt:0, by:[] };
      t.amt += Math.max(0, amount | 0); if (!t.by.includes(by)) t.by.push(by); writeBoard(b);
      return { amt:t.amt, cheerers:t.by.length };
    },
    /* ---------- 주점 현상금 선장: 시장에서 번 은화 순위 (라프텔 선장만) ---------- */
    async putCaptain(c){
      const row = { id:str(c.id, 40), name:str(c.name, 12), kind:c.kind === 'laftel-demo' ? 'laftel-demo' : 'guest', earned:Math.max(0, c.earned | 0), look:capLook(c.look), photo:capPhotoOk(c.photo), at:new Date().toISOString() };
      if (await online()){ try { await timeout(mine('captains').set(row)); return true; } catch(e){ return false; } }
      const b = readBoard(); b.captains[row.id] = row; writeBoard(b); return true;
    },
    async captains(){
      if (await online()){ try { return (await all('captains')).map(d => ({ id:str(d.data.id || d.id, 40), name:str(d.data.name, 12), kind:d.data.kind === 'laftel-demo' ? 'laftel-demo' : 'guest', earned:num(d.data.earned), look:capLook(d.data.look), photo:capPhotoOk(d.data.photo), at:str(d.data.at, 40) })).filter(c => c.name && c.kind === 'laftel-demo').sort((a, b) => b.earned - a.earned).slice(0, 50); } catch(e){ return []; } }
      return Object.values(readBoard().captains).map(c => ({ ...c, look:capLook(c.look), photo:capPhotoOk(c.photo) })).sort((a, b) => b.earned - a.earned).slice(0, 50);
    },
    /* 관리자(페이지 주인)용: 병 지우기 — 연습용 바다에서는 누구나. 함께 쓰는 바다에선 주인이 저장소 관리에서 지워요 */
    async removeBottle(id){ if (await online()) return false; const d = read(); d.bottles = d.bottles.filter(b => b.id !== id); delete d.reports[id]; return write(d); },
    /* 바로 쓰는지 알려줘요 (화면 표시용) */
    ready:() => netReady
  };
})();
/* 이번 주 이름표 (한국 시간 · 월요일 시작) 예: '2026-W47' */
function weekKey(d = new Date()){
  const k = new Date(d.getTime() + 9 * 3600e3), day = (k.getUTCDay() + 6) % 7;
  const thu = new Date(Date.UTC(k.getUTCFullYear(), k.getUTCMonth(), k.getUTCDate() - day + 3));
  const y = thu.getUTCFullYear(), jan4 = new Date(Date.UTC(y, 0, 4));
  const wk = 1 + Math.round(((thu - jan4) / 864e5 - 3 + ((jan4.getUTCDay() + 6) % 7)) / 7);
  return `${y}-W${String(wk).padStart(2, '0')}`;
}
/* 이번 주 월요일 ~ 일요일 (화면 표시용) */
function weekRange(d = new Date()){
  const k = new Date(d.getTime() + 9 * 3600e3), day = (k.getUTCDay() + 6) % 7;
  const mon = new Date(Date.UTC(k.getUTCFullYear(), k.getUTCMonth(), k.getUTCDate() - day)), sun = new Date(mon.getTime() + 6 * 864e5);
  const f = x => `${x.getUTCMonth() + 1}월 ${x.getUTCDate()}일`; return `${f(mon)} ~ ${f(sun)}`;
}
/* 라프텔로 로그인한 선장만 응원 · 현상금 선장에 올라가요 */
const isLaftelCaptain = p => !!p && p.kind === 'laftel-demo';
/* 선장 id: 닉네임 + 만든 시각으로 만든 짧은 값 (서버로 옮기면 로그인 id 로 바꿔요) */
function captainId(p){ p = p || LPProfile.get(); if (!p) return ''; let h = 2166136261; for (const c of (p.nickname + '|' + p.createdAt)){ h ^= c.charCodeAt(0); h = Math.imul(h, 16777619) >>> 0; } return 'c' + h.toString(36); }
