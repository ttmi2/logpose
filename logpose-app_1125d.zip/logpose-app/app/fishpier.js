/* ============================================================
   LOG POSE · 다모였섬: 바다로 뻗은 공용 낚시터
   섬 서쪽 → 긴 잔교(약 22m) → 끝의 넓은 T자 낚시 마루. 낚시 자리 16곳.
   소품: 꽂아 둔 낚싯대 · 미끼통 · 양동이 · 통발 · 덕장 · 그물 난간 · 등불 · 구명 튜브 · 나룻배 · 부표 · 갈매기 · 긴 의자 · 낚시 도구 가게
   (낚시하기 · 유리병 낚기는 다모였섬 3단계에서)
   ============================================================ */
const FP = { vis:[{ x0:-51.5, x1:-29, z0:-6.6, z1:-3.4 }, { x0:-60, x1:-51, z0:-11, z1:1 }],   /* 마루 그림 */
  rects:[{ x0:-53.5, x1:-29, z0:-6.6, z1:-3.4 }, { x0:-60, x1:-51, z0:-11, z1:1 }],   /* 걷기용 (잔교와 끝 마루가 넉넉히 겹쳐요) */
  H:0.35, buoys:[], gulls:[], boat:null };
const onFishPier = (x, z) => FP.rects.some(r => x > r.x0 && x < r.x1 && z > r.z0 && z < r.z1);
const fpInside = (x, z, m) => FP.rects.some(r => x > r.x0 + m && x < r.x1 - m && z > r.z0 + m && z < r.z1 - m);
function fpClamp(p, m){
  if (fpInside(p.x, p.z, m)) return;
  let best = null, bd = Infinity;
  FP.rects.forEach(r => { const x = Math.min(r.x1 - m, Math.max(r.x0 + m, p.x)), z = Math.min(r.z1 - m, Math.max(r.z0 + m, p.z)), d = Math.hypot(x - p.x, z - p.z); if (d < bd){ bd = d; best = { x, z }; } });
  p.x = best.x; p.z = best.z;
}
/* 낚시 자리 16곳: 잔교 양옆 8곳 + 끝 마루 세 면 8곳 (얼굴은 바다 쪽) */
const FP_SEATS = [
  ...[-34, -38, -42, -46].map(x => ({ x, z:-3.85, face:0 })),
  ...[-34, -38, -42, -46].map(x => ({ x, z:-6.15, face:Math.PI })),
  ...[-9.4, -6.4, -3.6, -0.6].map(z => ({ x:-59.55, z, face:-Math.PI / 2 })),
  { x:-54, z:0.55, face:0 }, { x:-57.2, z:0.55, face:0 },
  { x:-54, z:-10.55, face:Math.PI }, { x:-57.2, z:-10.55, face:Math.PI }
];

function buildFishPier(){
  const G = new THREE.Group(); isleScene.add(G);
  const deckM = flat('#9a7a56'), dark = flat('#5a3e26'), plank = flat('#7a5c3e'), rope = flat('#c9b08a');
  const m = (geo, mat, x, y, z, parent = G) => { const o = new THREE.Mesh(geo, mat); o.position.set(x, y, z); parent.add(o); return o; };
  /* 마루 (위가 높이 0.35) · 판자 줄 · 물에 박힌 기둥 */
  FP.vis.forEach(r => {
    const w = r.x1 - r.x0, d = r.z1 - r.z0, cx = (r.x0 + r.x1) / 2, cz = (r.z0 + r.z1) / 2;
    const f = m(new THREE.BoxGeometry(w, 0.3, d), deckM, cx, FP.H - 0.15, cz); f.name = 'floor'; IS.floors.push(f);
    const along = w > d;
    if (along) for (let x = r.x0 + 0.5; x < r.x1; x += 0.55) m(new THREE.BoxGeometry(0.04, 0.02, d - 0.1), plank, x, FP.H + 0.005, cz);
    else for (let z = r.z0 + 0.5; z < r.z1; z += 0.55) m(new THREE.BoxGeometry(w - 0.1, 0.02, 0.04), plank, cx, FP.H + 0.005, z);
    for (let x = r.x0 + 0.3; x <= r.x1 - 0.2; x += 3) [r.z0 + 0.15, r.z1 - 0.15].forEach(z => m(new THREE.CylinderGeometry(0.2, 0.24, 3.8, 8), dark, x, -1.6, z));
    if (!along) for (let z = r.z0 + 0.3; z <= r.z1; z += 3) [r.x0 + 0.15, r.x1 - 0.15].forEach(x => m(new THREE.CylinderGeometry(0.2, 0.24, 3.8, 8), dark, x, -1.6, z));
  });
  /* 난간: 바깥 가장자리마다 (입구 · 잔교가 마루와 만나는 곳은 비워요) */
  const RH = 0.85;
  const rail = (x0, z0, x1, z1) => {
    const len = Math.hypot(x1 - x0, z1 - z0), n = Math.max(1, Math.round(len / 1.5));
    for (let i = 0; i <= n; i++){ const t = i / n; m(new THREE.CylinderGeometry(0.06, 0.07, RH, 6), dark, x0 + (x1 - x0) * t, FP.H + RH / 2, z0 + (z1 - z0) * t); }
    const top = m(new THREE.BoxGeometry(len, 0.08, 0.1), dark, (x0 + x1) / 2, FP.H + RH, (z0 + z1) / 2); top.rotation.y = -Math.atan2(z1 - z0, x1 - x0);
    const mid = m(new THREE.CylinderGeometry(0.025, 0.025, len, 4), rope, (x0 + x1) / 2, FP.H + RH * 0.5, (z0 + z1) / 2); mid.rotation.z = Math.PI / 2; mid.rotation.y = -Math.atan2(z1 - z0, x1 - x0);
  };
  rail(-51, -3.45, -32.5, -3.45); rail(-51, -6.55, -32.5, -6.55);
  rail(-59.95, 0.95, -51.05, 0.95); rail(-59.95, -10.95, -51.05, -10.95); rail(-59.95, -10.95, -59.95, 0.95);
  rail(-51.05, 0.95, -51.05, -3.45); rail(-51.05, -6.55, -51.05, -10.95);
  /* 그물: 잔교 북쪽 난간에 걸쳐 늘어뜨려요 */
  { const pts = [], x0 = -44.5, x1 = -39.5;
    for (let i = 0; i <= 10; i++){ const x = x0 + (x1 - x0) * i / 10; pts.push(new THREE.Vector3(x, FP.H + RH, -3.4), new THREE.Vector3(x + 0.1, -0.6 - Math.sin(i * 0.9) * 0.3, -3.1)); }
    for (let j = 0; j <= 5; j++){ const y = FP.H + RH - j * 0.32, zz = -3.4 + j * 0.06; pts.push(new THREE.Vector3(x0, y, zz), new THREE.Vector3(x1, y - 0.1, zz)); }
    G.add(new THREE.LineSegments(new THREE.BufferGeometry().setFromPoints(pts), new THREE.LineBasicMaterial({ color:'#c9b08a', transparent:true, opacity:.75 }))); }
  /* 낚시 자리: 낚싯대 꽂이 + 몇 자리엔 꽂아 둔 낚싯대와 늘어진 줄 */
  const holder = flat('#3a2414'), rodM = flat('#2a1a0e'), lineM = new THREE.LineBasicMaterial({ color:'#f4f0e6', transparent:true, opacity:.6 });
  FP_SEATS.forEach((s, i) => {
    const fx = Math.sin(s.face), fz = Math.cos(s.face), hx = s.x + fx * 0.45, hz = s.z + fz * 0.45;
    m(new THREE.CylinderGeometry(0.05, 0.05, 0.4, 6), holder, hx, FP.H + RH + 0.05, hz);
    if (i % 3 === 1) return;   /* 빈 자리도 조금 */
    const rod = new THREE.Group(); rod.position.set(hx, FP.H + RH - 0.1, hz); rod.rotation.y = s.face; G.add(rod);
    const st = m(new THREE.CylinderGeometry(0.012, 0.03, 2.6, 5), rodM, 0, 0, 0, rod); st.geometry.translate(0, 1.3, 0); st.rotation.x = 0.85;
    const tip = new THREE.Vector3(hx + fx * 2.6 * Math.sin(0.85), FP.H + RH - 0.1 + 2.6 * Math.cos(0.85), hz + fz * 2.6 * Math.sin(0.85));
    G.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints([tip, new THREE.Vector3(tip.x + fx * 0.6, -1.65, tip.z + fz * 0.6)]), lineM));
    const bob = m(new THREE.SphereGeometry(0.09, 8, 6), flat(i % 2 ? '#d23a2a' : '#f4f0e6'), tip.x + fx * 0.6, -1.62, tip.z + fz * 0.6); FP.buoys.push({ o:bob, base:-1.62, ph:i, amp:0.04 });
  });
  /* 미끼통 · 양동이 · 통발 · 밧줄 뭉치 (마루 여기저기) */
  const bucketM = flat('#6b8aa8'), bait = flat('#8a5a3a');
  [[-35.5, -4.1], [-43.5, -5.9], [-58.6, -1.9], [-52.5, -9.8]].forEach(([x, z], i) => { m(new THREE.CylinderGeometry(0.24, 0.19, 0.42, 12), i % 2 ? bucketM : bait, x, FP.H + 0.21, z); m(new THREE.TorusGeometry(0.2, 0.015, 4, 12), M.iron, x, FP.H + 0.46, z).rotation.x = 1.2; });
  const potM = new THREE.LineBasicMaterial({ color:'#3a2a1a' });
  [[-52.4, -1.0, 0], [-52.4, -1.0, 0.62], [-53.2, -0.9, 0]].forEach(([x, z, y]) => { const g = new THREE.BoxGeometry(0.8, 0.6, 0.6); const e = new THREE.LineSegments(new THREE.EdgesGeometry(g), potM); e.position.set(x, FP.H + 0.3 + y, z); G.add(e); m(new THREE.BoxGeometry(0.78, 0.02, 0.58), flat('#7a5c3e'), x, FP.H + 0.01 + y, z); });
  [[-47.5, -6.0], [-55.8, -10.2]].forEach(([x, z]) => { const r = m(new THREE.TorusGeometry(0.34, 0.09, 6, 16), rope, x, FP.H + 0.08, z); r.rotation.x = Math.PI / 2; m(new THREE.TorusGeometry(0.22, 0.08, 6, 14), rope, x, FP.H + 0.2, z).rotation.x = Math.PI / 2; });
  /* 끝 마루: 바다를 보는 긴 의자 둘 · 등불 · 구명 튜브 */
  bench(G, -56.6, -7.8, 2.0, Math.PI / 2); bench(G, -56.6, -2.6, 2.0, Math.PI / 2);
  iBox(-56.6, -7.8, 0.25, 1.0); iBox(-56.6, -2.6, 0.25, 1.0);
  FP.benchSeats = [{ x:-56.6, z:-8.3 }, { x:-56.6, z:-7.3 }, { x:-56.6, z:-3.1 }, { x:-56.6, z:-2.1 }];
  [[-59.6, 0.6], [-59.6, -10.6], [-41, -3.6], [-41, -6.4]].forEach(([x, z]) => { m(new THREE.CylinderGeometry(0.07, 0.08, 2.6, 6), dark, x, FP.H + 1.3, z); hangLantern(G, x, FP.H + 2.45, z, IS.lamps); });
  { const post = m(new THREE.CylinderGeometry(0.08, 0.08, 1.8, 6), dark, -51.4, FP.H + 0.9, 0.6); void post;
    const ring = m(new THREE.TorusGeometry(0.36, 0.11, 8, 18), flat('#e8e2d6'), -51.4, FP.H + 1.4, 0.75);
    [0, 1, 2, 3].forEach(k => { const st = new THREE.Mesh(new THREE.TorusGeometry(0.36, 0.115, 8, 3, 0.4), flat('#c0392b')); st.position.copy(ring.position); st.rotation.z = k * Math.PI / 2; G.add(st); }); }
  /* 묶어 둔 작은 나룻배 (잔교 남쪽) */
  { const boat = new THREE.Group(); boat.position.set(-44, -1.55, -8.0); G.add(boat); FP.boat = boat;
    const hull = new THREE.Mesh(new THREE.CylinderGeometry(0.85, 0.85, 3.4, 14, 1, true, Math.PI / 2, Math.PI), new THREE.MeshStandardMaterial({ color:'#8a5a3a', roughness:.8, side:THREE.DoubleSide })); hull.rotation.z = Math.PI / 2; boat.add(hull);
    [-1.7, 1.7].forEach(x => { const cap = new THREE.Mesh(new THREE.CircleGeometry(0.85, 14, Math.PI, Math.PI), flat('#7a4a2a')); cap.position.x = x; cap.rotation.y = Math.PI / 2; boat.add(cap); });
    [-0.6, 0.7].forEach(x => { const s = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.06, 1.5), flat('#b08458')); s.position.set(x, -0.25, 0); boat.add(s); });
    const oar = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 2.4, 5), flat('#b08458')); oar.position.set(0.2, -0.15, 0.3); oar.rotation.set(0, 0.3, Math.PI / 2); boat.add(oar);
    G.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(-45.6, FP.H + 0.6, -6.6), new THREE.Vector3(-45.5, -1.0, -7.4)]), new THREE.LineBasicMaterial({ color:'#c9b08a' }))); }
  /* 바다에 뜬 부표 (빨강 · 하양) */
  [[-63, -3], [-62, -13], [-48, -10], [-36, 0.5], [-64, 4]].forEach(([x, z], i) => {
    const b = new THREE.Group(); b.position.set(x, -1.7, z); G.add(b);
    m(new THREE.CylinderGeometry(0.32, 0.38, 0.5, 12), flat(i % 2 ? '#f4f0e6' : '#d23a2a'), 0, 0.1, 0, b); m(new THREE.CylinderGeometry(0.05, 0.05, 0.6, 5), dark, 0, 0.6, 0, b); m(new THREE.SphereGeometry(0.1, 8, 6), flat('#f2c230'), 0, 0.95, 0, b);
    FP.buoys.push({ o:b, base:-1.7, ph:i * 1.7, amp:0.12, tilt:true });
  });
  /* 기둥 위에 앉은 갈매기 */
  [[-51.2, 1.0], [-59.85, -11], [-32.7, -3.45]].forEach(([x, z], i) => {
    const g = new THREE.Group(); g.position.set(x, FP.H + RH + 0.04, z); g.rotation.y = i * 2.1; G.add(g);
    const body = m(new THREE.SphereGeometry(0.16, 10, 8), flat('#f4f4f0'), 0, 0.14, 0, g); body.scale.set(1, 0.85, 1.5);
    m(new THREE.SphereGeometry(0.1, 8, 6), flat('#f4f4f0'), 0, 0.3, 0.18, g);
    const beak = m(new THREE.ConeGeometry(0.03, 0.12, 5), flat('#f2a030'), 0, 0.29, 0.32, g); beak.rotation.x = Math.PI / 2;
    [-1, 1].forEach(s => { const w = m(new THREE.BoxGeometry(0.04, 0.1, 0.3), flat('#9aa0a6'), s * 0.15, 0.17, -0.02, g); w.rotation.z = s * 0.2; });
    FP.gulls.push({ g, ph:i });
  });
  /* 떠다니는 유리병: 끝 마루 바깥 바다 */
  IS.flags.filter(f => f.bottle).forEach((f, k) => f.bottle.position.set(-63 - k * 2.2, -1.75, -7 + k * 3.2));
  /* 땅 쪽: 안내판 · 낚시 도구 가게 · 물고기 덕장 · 술통 */
  signBoard('공용 낚시터', ISLE_BOTTLES ? '유리병이 떠다녀요' : '오늘도 손맛 좋아요', -29.6, 1.9, -1.6, Math.PI / 2, 2.8, true); iBox(-29.6, -1.6, 0.3, 1.4);
  const shop = new THREE.Group(); shop.position.set(-26.6, 0, -10.2); shop.rotation.y = Math.PI / 2 + 0.25; G.add(shop);
  m(new THREE.BoxGeometry(3.0, 1.0, 1.4), flat('#7a5636'), 0, 0.5, 0.5, shop);
  m(new THREE.BoxGeometry(3.2, 0.08, 1.6), flat('#b08458'), 0, 1.04, 0.5, shop);
  m(new THREE.BoxGeometry(3.0, 2.6, 0.2), flat('#6b4528'), 0, 1.3, -0.6, shop);
  for (let k = 0; k < 6; k++){ const st = m(new THREE.BoxGeometry(3.4 / 6, 0.06, 2.0), flat(k % 2 ? '#f2e8d2' : '#2f6f9f'), -1.7 + 3.4 / 12 + k * 3.4 / 6, 2.75, 0.4, shop); st.rotation.x = -0.25; }
  [-1.5, 1.5].forEach(x => m(new THREE.CylinderGeometry(0.06, 0.06, 2.7, 6), dark, x, 1.35, 1.3, shop));
  [[-0.9, '#6b8aa8'], [0, '#8a5a3a'], [0.9, '#5a7a4a']].forEach(([x, c]) => m(new THREE.CylinderGeometry(0.2, 0.17, 0.3, 10), flat(c), x, 1.23, 0.6, shop));
  [-1.0, -0.3, 0.4, 1.1].forEach((x, k) => { const r = m(new THREE.CylinderGeometry(0.01, 0.025, 2.0, 5), rodM, x, 1.3, -0.45, shop); r.rotation.z = 0.08 * (k - 1.5); });
  const ss = signBoard('낚시 도구', '미끼 · 낚싯대', 0, 0, 0, 0, 2.2); shop.add(ss); ss.position.set(0, 3.25, 1.2);
  shop.userData.kind = 'tackle'; IS.clickables.push(shop); iBox(-26.6, -10.2, 1.3, 1.9);
  const rack = new THREE.Group(); rack.position.set(-25.0, 0, 1.6); rack.rotation.y = 0.4; G.add(rack);
  [-1.4, 1.4].forEach(x => m(new THREE.CylinderGeometry(0.07, 0.08, 2.2, 6), dark, x, 1.1, 0, rack));
  m(new THREE.CylinderGeometry(0.04, 0.04, 3.0, 5), rope, 0, 2.05, 0, rack).rotation.z = Math.PI / 2;
  ['#3f7896', '#8fa3ad', '#cf5f58', '#a8935e', '#3f7896'].forEach((c, k) => { const x = -1.1 + k * 0.55; m(new THREE.CylinderGeometry(0.005, 0.005, 0.3, 3), rope, x, 1.9, 0, rack); const f = m(new THREE.SphereGeometry(0.14, 8, 6), flat(c), x, 1.55, 0, rack); f.scale.set(0.5, 1.6, 0.25); });
  { const c = Math.cos(0.4), s = Math.sin(0.4); [-1.4, 1.4].forEach(x => iBox(-25.0 + x * c, 1.6 - x * s, 0.2, 0.2)); }
  barrel(G, -27.6, 0, -6.9, 0.85); barrel(G, -28.1, 0, -7.6, 0.75); iBox(-27.8, -7.2, 0.7, 0.7);
  /* 마루 · 가게를 누르면 */
  G.userData.kind = 'pond'; IS.clickables.push(G);
}
/* 낚시 자리 · 가게 · 의자 */
function fishPierSpots(){
  FP_SEATS.forEach((s, i) => { ISLE_SPOTS['fp' + i] = { x:s.x, z:s.z, face:s.face, label:`낚시 자리 ${i + 1}에서 낚시하기`, near:0.9, use:() => openFishing({ seat:{ ...s, n:i + 1 } }) }; });
  ISLE_SPOTS.pond = { ...ISLE_SPOTS.fp10, label:'공용 낚시터에서 낚시하기' };
  FP.benchSeats.forEach((s, i) => { ISLE_SPOTS['fpb' + i] = { x:s.x - 0.5, z:s.z, face:-Math.PI / 2, label:'긴 의자에 앉기', near:0.8, use:() => sitDown(0.5, { x:s.x, z:s.z, face:-Math.PI / 2 }) }; });
  ISLE_SPOTS.tackle = { x:-24.4, z:-9.6, face:-Math.PI / 2 - 0.25, label:'낚시 도구 가게', use:() => toast('가게 주인: “어서 와요! 미끼는 공짜, 낚싯대도 빌려줄게요. 잔교 <strong>낚시 자리</strong>에 서서 던져 보세요. 가끔 <strong>유리병</strong>도 올라온대요!”', 4200) };
}
function fishPierStep(dt, t){
  FP.buoys.forEach(B => { B.o.position.y = B.base + Math.sin(t * 1.4 + B.ph) * B.amp; if (B.tilt){ B.o.rotation.z = Math.sin(t * 0.9 + B.ph) * 0.15; B.o.rotation.x = Math.cos(t * 0.8 + B.ph) * 0.1; } });
  if (FP.boat){ FP.boat.position.y = -1.55 + Math.sin(t * 0.9) * 0.08; FP.boat.rotation.x = Math.sin(t * 0.7) * 0.04; }
  FP.gulls.forEach(G => { G.g.rotation.y += Math.sin(t * 0.5 + G.ph) * 0.004; });
}
