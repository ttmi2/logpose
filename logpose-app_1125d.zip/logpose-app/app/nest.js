/* ============================================================
   LOG POSE · 갑판 4단계: 망루 (구경용)
   큰 돛대 옆 줄사다리 → 돛대 꼭대기 망루. 끌거나 화살표로 360도 둘러봐요.
   라프텔 · 다모였섬 쪽을 보면 이름표가 떠요. 기능 없이 바다 구경하는 곳이에요.
   ============================================================ */
const NE = { root:$('#nest'), drag:$('#neDrag'), dir:$('#neDir'), seen:$('#neSeen'), down:$('#neDown') };
const NEST_POS = { x:0, y:13.2 + 1.65, z:2.2 };
const nest = { open:false, yaw:0, pitch:-0.05, look:new THREE.Vector3(), pos:new THREE.Vector3(), keys:new Set() };

/* 바라보는 방향 이름 (뱃머리 = +z) */
function nestDirName(yaw){
  const a = ((yaw % (Math.PI * 2)) + Math.PI * 2) % (Math.PI * 2), k = Math.round(a / (Math.PI / 4)) % 8;
  return ['뱃머리 쪽 (앞)', '앞 왼쪽', '왼쪽 뱃전', '뒤 왼쪽', '고물 쪽 (뒤)', '뒤 오른쪽', '오른쪽 뱃전', '앞 오른쪽'][k];
}
/* 섬이 시야 가운데 근처에 있으면 이름표 */
function nestSeen(){
  let best = null, bestD = 0.32;
  ISLES.forEach(I => { const a = Math.atan2(I.ax - NEST_POS.x, I.az - NEST_POS.z); let d = Math.abs(((nest.yaw - a + Math.PI) % (Math.PI * 2) + Math.PI * 2) % (Math.PI * 2) - Math.PI); if (d < bestD){ bestD = d; best = I; } });
  return best;
}
let nestLastSeen = undefined, nestLastDir = '';
function nestUI(){
  const dir = nestDirName(nest.yaw); if (dir !== nestLastDir){ NE.dir.textContent = dir; nestLastDir = dir; }
  const I = nestSeen();
  const seenKey = I || (typeof seaSeen === 'function' ? seaSeen(nest.yaw) : null);
  if (seenKey !== nestLastSeen){
    nestLastSeen = seenKey;
    const Z = I ? null : (typeof seaSeen === 'function' ? seaSeen(nest.yaw) : null);
    NE.seen.innerHTML = I ? `<b>${escHTML(I.name)}</b>${chJosa(I.name, '이', '가')} 보여요 <small>뱃머리 망원경으로 자세히 볼 수 있어요</small>`
      : Z ? `<b>${Z.zone} 해역 · ${escHTML(Z.name)}</b> 바다가 펼쳐져 있어요 <small>${escHTML(Z.tag.replace(/분께$/, '분의 바다'))} · 해도 탁자에서 내 표식을 볼 수 있어요</small>`
      : '끌거나 ← → 로 바다를 둘러보세요';
  }
}

function openNest(){
  if (nest.open || AREA !== DECK_AREA || areaBusy) return;
  nest.open = true; uiOpen = true; keys.clear(); auto = null; $('#toast').hidden = true;
  nest.yaw = 0; nest.pitch = -0.05; nestLastSeen = undefined; nestLastDir = '';
  const go = () => {
    player.mesh.visible = false;
    nestStep(0, true);
    DECK_AREA.view = { pos:nest.pos, look:nest.look };
    camPos.copy(nest.pos);
    document.body.classList.add('nest-open'); NE.root.hidden = false; nestUI();
    try { NE.down.focus({ preventScroll:true }); } catch(e){}
  };
  if (reduceMotion){ go(); return; }
  /* 오르기 연출: 지금 시점 → 줄사다리 아래 → 줄을 타고 돛대 꼭대기로 (2.6초) */
  const s = DECK_SPOTS.nest, p0 = camPos.clone(), l0 = camTarget.clone();
  const p1 = new THREE.Vector3(s.x + 0.35, 1.7, s.z + 0.5), l1 = new THREE.Vector3(NEST_POS.x, NEST_POS.y * 0.75, NEST_POS.z);
  nestStep(0, true); const p2 = nest.pos.clone(), l2 = nest.look.clone();
  const tp = new THREE.Vector3(), tl = new THREE.Vector3(), up = new THREE.Vector3();
  DECK_AREA.view = { pos:tp, look:tl }; tp.copy(p0); tl.copy(l0);
  setTimeout(() => { player.mesh.visible = false; }, 500);
  camTween(2.6, (t) => {
    if (t < 0.22){ const k = t / 0.22, e = k*k*(3 - 2*k); lerpV(tp, p0, p1, e); lerpV(tl, l0, l1, e); }
    else { const k = (t - 0.22) / 0.78, e = k < .5 ? 2*k*k : 1 - Math.pow(-2*k + 2, 2)/2;
      lerpV(tp, p1, p2, e); tp.x += Math.sin(k * 22) * 0.05 * (1 - k); tp.y += Math.abs(Math.sin(k * 22)) * 0.06 * (1 - k);
      up.copy(l1).lerp(l2, Math.min(1, e * 1.15)); tl.copy(up); }
  }, () => { go(); toast('<strong>망루</strong>에 올라왔어요. 바람이 세네요!', 2600); });
}
function closeNest(instant){
  if (!nest.open || nest.descending) return;
  const go = () => {
    nest.open = false; NE.root.hidden = true; document.body.classList.remove('nest-open');
    player.mesh.visible = true; DECK_AREA.view = null; uiOpen = false; nest.keys.clear();
    const s = DECK_SPOTS.nest; player.x = s.x; player.z = s.z; player.r = s.face; cam.yaw = -Math.PI / 2; cam.pitch = 0.3;
    const cp = Math.cos(cam.pitch); camPos.set(player.x + Math.sin(cam.yaw) * cam.dist * cp, 1.25 + Math.sin(cam.pitch) * cam.dist, player.z + Math.cos(cam.yaw) * cam.dist * cp);
    try { renderer.domElement.focus({ preventScroll:true }); } catch(e){}
  };
  if (instant || reduceMotion){ go(); return; }
  /* 내려오기 연출: 꼭대기 → 줄사다리 아래 (1.6초) */
  NE.root.hidden = true; document.body.classList.remove('nest-open');
  const s = DECK_SPOTS.nest, p0 = nest.pos.clone(), l0 = nest.look.clone();
  const p1 = new THREE.Vector3(s.x + 0.35, 1.8, s.z + 0.5), l1 = new THREE.Vector3(s.x - 3, 1.2, s.z);
  const tp = new THREE.Vector3().copy(p0), tl = new THREE.Vector3().copy(l0);
  DECK_AREA.view = { pos:tp, look:tl }; nest.descending = true;
  camTween(1.6, (t, e) => { lerpV(tp, p0, p1, e); lerpV(tl, l0, l1, Math.min(1, e * 1.3)); tp.x += Math.sin(t * 18) * 0.04 * (1 - t); }, () => { nest.descending = false; go(); });
}
/* 매 프레임: 시선 방향 → 카메라 (돛대 기둥에 가리지 않게 시선 쪽으로 살짝 나가요) */
function nestStep(dt, force){
  if (!nest.open && !force) return;
  const k = nest.keys, sp = 1.4 * (dt || 0);
  if (k.has('arrowleft') || k.has('a')) nest.yaw += sp; if (k.has('arrowright') || k.has('d')) nest.yaw -= sp;
  if (k.has('arrowup') || k.has('w')) nest.pitch += sp * .6; if (k.has('arrowdown') || k.has('s')) nest.pitch -= sp * .6;
  nest.pitch = Math.max(-0.75, Math.min(0.45, nest.pitch));
  const fx = Math.sin(nest.yaw), fz = Math.cos(nest.yaw);
  /* 꼭대기는 돛대가 크게 흔들려요 (바람 · 파도) */
  const tw = performance.now() / 1000, sw = (reduceMotion || force) ? 0 : 1;
  const swx = Math.sin(tw * 0.62) * 0.14 * sw, swy = Math.sin(tw * 1.05 + 1) * 0.05 * sw, swz = Math.sin(tw * 0.47 + 2) * 0.09 * sw;
  nest.pos.set(NEST_POS.x + fx * 0.55 + swx, NEST_POS.y + swy, NEST_POS.z + fz * 0.55 + swz);
  const cp = Math.cos(nest.pitch);
  nest.look.set(nest.pos.x + fx * cp * 10 - swx * 0.6, nest.pos.y + Math.sin(nest.pitch) * 10, nest.pos.z + fz * cp * 10 - swz * 0.6);
  if (nest.open) nestUI();
}
/* 끌어서 둘러보기 */
{ let d = null;
  NE.drag.addEventListener('pointerdown', e => { d = { id:e.pointerId, x:e.clientX, y:e.clientY }; try { NE.drag.setPointerCapture(e.pointerId); } catch(_){} });
  NE.drag.addEventListener('pointermove', e => { if (!d || e.pointerId !== d.id) return; nest.yaw += (e.clientX - d.x) * 0.006; nest.pitch -= (e.clientY - d.y) * 0.004; d.x = e.clientX; d.y = e.clientY; });
  const end = e => { if (d && e.pointerId === d.id) d = null; };
  NE.drag.addEventListener('pointerup', end); NE.drag.addEventListener('pointercancel', end);
  NE.drag.addEventListener('wheel', e => { nest.yaw += e.deltaX * 0.003; }, { passive:true });
}
NE.down.addEventListener('click', () => closeNest());
window.addEventListener('keydown', e => {
  if (!nest.open) return;
  const k = e.key.toLowerCase();
  if (k === 'escape'){ e.preventDefault(); closeNest(); return; }
  if (['arrowleft', 'arrowright', 'arrowup', 'arrowdown', 'a', 'd', 'w', 's'].includes(k)){ e.preventDefault(); nest.keys.add(k); }
  if (k === 'tab'){ e.preventDefault(); NE.down.focus(); }
});
window.addEventListener('keyup', e => nest.keys.delete(e.key.toLowerCase()));
window.addEventListener('blur', () => nest.keys.clear());
DECK_SPOTS.nest.use = () => openNest();
