/* ---------- 선장실 구석 작은 책장: 저장한 로그포스(항해일지)가 한 권씩 꽂혀요 ---------- */
const SHELF = { x:ROOM.maxX - 0.24, z:-3.7, w:1.3, h:1.55, rows:3, per:11 };
const shelfRef = { books:null, plate:null };

function shelfPlateTex(n){
  return canvasTex(256, 64, (g, w, h) => {
    g.fillStyle = '#c9a15e'; g.fillRect(0, 0, w, h); g.strokeStyle = '#6a4a28'; g.lineWidth = 4; g.strokeRect(3, 3, w - 6, h - 6);
    g.fillStyle = '#3a2618'; g.font = `700 26px ${FB}`; g.textAlign = 'center'; g.textBaseline = 'middle';
    g.fillText(n ? `항해일지 ${n}권` : '항해일지 책장', w / 2, h / 2 + 1);
  });
}
function buildShelf(){
  const G = new THREE.Group(); G.position.set(SHELF.x, 0, SHELF.z); G.rotation.y = -Math.PI / 2; scene.add(G);   /* 앞면이 방 안쪽(-x)을 봐요 */
  const { w, h } = SHELF, d = 0.34;
  mesh(new THREE.BoxGeometry(w, h, 0.03), M.woodDark, 0, h / 2, -d / 2 + 0.015, G);                 // 뒤판
  [-1, 1].forEach(s => mesh(new THREE.BoxGeometry(0.05, h, d), M.wood, s * (w / 2 - 0.025), h / 2, 0, G));   // 옆판
  for (let r = 0; r <= SHELF.rows; r++) mesh(new THREE.BoxGeometry(w, 0.04, d), M.wood, 0, 0.08 + r * ((h - 0.12) / SHELF.rows), 0, G);
  mesh(new THREE.BoxGeometry(w + 0.08, 0.05, d + 0.06), M.woodRed, 0, h + 0.02, 0.01, G);                 // 머리판
  mesh(new THREE.BoxGeometry(w, 0.08, 0.02), M.woodRed, 0, 0.04, d / 2, G);                              // 걸레받이
  /* 위에 작은 랜턴 · 놋쇠 이름판 */
  mesh(new THREE.CylinderGeometry(0.06, 0.07, 0.16, 6), new THREE.MeshStandardMaterial({ color:'#ffe0a8', emissive:'#ffb860', emissiveIntensity:.7 }), -0.42, h + 0.13, 0, G);
  mesh(new THREE.ConeGeometry(0.08, 0.07, 6), M.brass, -0.42, h + 0.24, 0, G);
  const plate = mesh(new THREE.PlaneGeometry(0.5, 0.125), new THREE.MeshStandardMaterial({ map:shelfPlateTex(0), roughness:.5, metalness:.3 }), 0.12, h - 0.06, d / 2 + 0.012, G);
  shelfRef.plate = plate;
  const books = new THREE.Group(); G.add(books); shelfRef.books = books;
  addBox(SHELF.x - 0.02, SHELF.z, d / 2 + 0.04, w / 2 + 0.04);
  G.userData.kind = 'shelf'; clickables.push(G);
  refreshShelf();
}
/* 저장 목록이 바뀔 때마다 책을 다시 꽂아요 (장르 색 · 작품마다 조금씩 다른 두께와 키) */
function refreshShelf(){
  const B = shelfRef.books; if (!B) return;
  B.children.slice().forEach(c => { B.remove(c); if (c.material && c.material.dispose && c.material !== M.brass) c.material.dispose(); if (c.geometry && c.geometry.dispose) c.geometry.dispose(); });
  const list = (LPProfile.get() ? savedList() : []).map(s => LPData.get(s.id)).filter(Boolean).reverse();   /* 오래된 것부터 왼쪽 */
  const { w, h, rows, per } = SHELF, rowH = (h - 0.12) / rows, gold = M.brass;
  list.slice(0, rows * per).forEach((wk, i) => {
    const r = rows - 1 - Math.floor(i / per), c = i % per;                     /* 위 칸부터 채워요 */
    let hs = 0; for (const ch of wk.id) hs = (hs * 31 + ch.charCodeAt(0)) >>> 0;
    const bw = 0.075 + (hs % 4) * 0.01, bh = rowH * (0.68 + ((hs >> 3) % 5) * 0.05);
    const x = -w / 2 + 0.1 + c * ((w - 0.16) / per), y = 0.1 + r * rowH + bh / 2;
    const col = new THREE.Color().setHSL(((wk.genre && wk.genre.hue) || 30) / 360, 0.42, 0.34 + ((hs >> 6) % 3) * 0.05);
    const bk = mesh(new THREE.BoxGeometry(bw, bh, 0.24), new THREE.MeshStandardMaterial({ color:col, roughness:.8 }), x, y, 0.01, B);
    bk.rotation.z = (c === per - 1 || i === list.length - 1) && list.length % per ? 0.08 : 0;            /* 칸 끝 책은 살짝 기울게 */
    [0.32, -0.32].forEach(f => mesh(new THREE.BoxGeometry(bw + 0.004, 0.012, 0.006), gold, x, y + bh * f, 0.134, B));
  });
  if (!list.length){   /* 비어 있을 땐 쪽지 한 장 */
    const note = mesh(new THREE.PlaneGeometry(0.4, 0.26), new THREE.MeshStandardMaterial({ map:canvasTex(256, 168, (g, cw, ch) => {
      g.fillStyle = '#efe4cc'; g.fillRect(0, 0, cw, ch); g.fillStyle = '#5a4030'; g.font = `600 22px ${FB}`; g.textAlign = 'center';
      g.fillText('아직 비어 있어요', cw / 2, 70); g.font = `500 17px ${FB}`; g.fillText('로그포스에 저장하면', cw / 2, 108); g.fillText('여기 꽂혀요', cw / 2, 132);
    }), roughness:.9 }), 0, 0.1 + 1.5 * rowH, 0.12, B); note.rotation.z = -0.05;
  }
  const n = list.length, pm = shelfRef.plate.material; if (pm.map) pm.map.dispose(); pm.map = shelfPlateTex(n); pm.needsUpdate = true;
}
SPOTS.shelf = { x:SHELF.x - 1.05, z:SHELF.z, face:Math.PI / 2, label:'항해일지 책장 보기', use:() => openMenu('saved') };
menuHooks.push(refreshShelf);
