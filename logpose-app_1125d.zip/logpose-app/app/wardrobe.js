/* ---------- 선장실 옷장: 산 옷과 모자를 마음대로 입어 봐요 ----------
   왼쪽 벽(해도와 지도 꽂이 사이). 열면 문이 열리고, 카메라가 캐릭터 앞으로 와서 입은 모습을 보여 줘요. */
const WARD = { x:ROOM.minX + 0.32, z:1.05, w:1.15, h:2.0, d:0.56 };
const wardRef = { doors:[], open:0, want:0, rack:null };

function buildWardrobe(){
  const G = new THREE.Group(); G.position.set(WARD.x, 0, WARD.z); G.rotation.y = Math.PI / 2; scene.add(G);   /* 앞면이 방 안쪽(+x)을 봐요 */
  const { w, h, d } = WARD;
  mesh(new THREE.BoxGeometry(w, h, 0.04), M.woodDark, 0, h / 2, -d / 2 + 0.02, G);                          // 뒤판
  [-1, 1].forEach(s => mesh(new THREE.BoxGeometry(0.06, h, d), M.woodRed, s * (w / 2 - 0.03), h / 2, 0, G));   // 옆판
  mesh(new THREE.BoxGeometry(w, 0.08, d), M.woodRed, 0, 0.12, 0, G);                                          // 바닥판
  mesh(new THREE.BoxGeometry(w + 0.12, 0.1, d + 0.08), M.woodRed, 0, h + 0.03, 0.01, G);                      // 머리 장식
  mesh(new THREE.BoxGeometry(w + 0.04, 0.06, d + 0.04), M.brass, 0, h - 0.04, 0.01, G);
  [-1, 1].forEach(s => mesh(new THREE.CylinderGeometry(0.035, 0.045, 0.1, 8), M.woodDark, s * (w / 2 - 0.08), 0.05, d / 2 - 0.08, G));   // 발
  /* 안쪽: 옷걸이 봉 + 걸린 옷들 · 아래 서랍 */
  mesh(new THREE.CylinderGeometry(0.018, 0.018, w - 0.14, 8), M.brass, 0, h - 0.32, 0, G).rotation.z = Math.PI / 2;
  const rack = new THREE.Group(); G.add(rack); wardRef.rack = rack;
  mesh(new THREE.BoxGeometry(w - 0.14, 0.26, d - 0.06), M.wood, 0, 0.32, 0.02, G);
  mesh(new THREE.SphereGeometry(0.03, 8, 6), M.brass, 0, 0.32, d / 2 - 0.01, G);
  /* 문 두 짝: 바깥쪽 경첩을 축으로 열려요 */
  [-1, 1].forEach(s => {
    const hinge = new THREE.Group(); hinge.position.set(s * (w / 2 - 0.01), 0, d / 2); G.add(hinge);
    mesh(new THREE.BoxGeometry(w / 2 - 0.01, h - 0.44, 0.04), M.woodRed, -s * (w / 4), 0.24 + (h - 0.44) / 2, 0.01, hinge);
    mesh(new THREE.BoxGeometry(w / 2 - 0.12, h - 0.66, 0.02), M.wood, -s * (w / 4), 0.24 + (h - 0.44) / 2, 0.035, hinge);   // 문판 홈
    mesh(new THREE.SphereGeometry(0.028, 8, 6), M.brass, -s * (w / 2 - 0.08), 1.05, 0.05, hinge);                           // 손잡이
    wardRef.doors.push({ hinge, s });
  });
  /* 문 위 작은 놋쇠 이름판 */
  mesh(new THREE.PlaneGeometry(0.46, 0.11), new THREE.MeshStandardMaterial({ map:canvasTex(256, 60, (g, cw, ch) => {
    g.fillStyle = '#c9a15e'; g.fillRect(0, 0, cw, ch); g.strokeStyle = '#6a4a28'; g.lineWidth = 4; g.strokeRect(3, 3, cw - 6, ch - 6);
    g.fillStyle = '#3a2618'; g.font = `700 28px ${FB}`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('선장 옷장', cw / 2, ch / 2 + 1);
  }), roughness:.5, metalness:.3 }), 0, h - 0.13, d / 2 + 0.03, G);
  addBox(WARD.x, WARD.z, d / 2 + 0.04, w / 2 + 0.04);
  G.userData.kind = 'wardrobe'; clickables.push(G);
  refreshWardrobeRack();
}
/* 걸린 옷: 가진 옷만큼 (옷걸이에 걸린 작은 셔츠 모양) */
function refreshWardrobeRack(){
  const R = wardRef.rack; if (!R) return;
  R.children.slice().forEach(c => { R.remove(c); });
  const s = typeof shopData === 'function' ? shopData() : { owned:[] }, own = OUTFITS.filter(o => o.id === 'rags' || s.owned.includes(o.id));
  own.forEach((o, i) => { const x = -WARD.w / 2 + 0.2 + i * ((WARD.w - 0.4) / Math.max(1, OUTFITS.length - 1));
    const c = outfitColors(o, '#2f5f8a');
    const sh = mesh(new THREE.BoxGeometry(0.06, 0.5, 0.36), new THREE.MeshStandardMaterial({ color:c.shirt, roughness:.95 }), x, WARD.h - 0.62, 0, R);
    sh.rotation.y = (i % 2 ? 0.08 : -0.08);
    mesh(new THREE.BoxGeometry(0.055, 0.2, 0.3), new THREE.MeshStandardMaterial({ color:c.pants, roughness:.95 }), x, WARD.h - 0.98, 0, R);
    mesh(new THREE.TorusGeometry(0.035, 0.008, 4, 10, Math.PI), M.brass, x, WARD.h - 0.33, 0, R).rotation.y = Math.PI / 2;   // 옷걸이 고리
  });
}

/* ---------- 옷장 창 ---------- */
const WD = { root:$('#wardrobe'), body:$('#wdBody'), tabs:$('#wdTabs'), note:$('#wdNote'), close:$('#wdClose') };
const ward = { open:false, tab:'cloth' };
function wardRender(){
  const s = shopData();
  WD.tabs.querySelectorAll('[data-tab]').forEach(b => { b.setAttribute('aria-selected', String(b.dataset.tab === ward.tab)); b.tabIndex = b.dataset.tab === ward.tab ? 0 : -1; });
  const all = ward.tab === 'cloth' ? OUTFITS : ward.tab === 'eye' ? GLASSES : HATS, cur = ward.tab === 'cloth' ? s.outfit : ward.tab === 'eye' ? s.glasses : s.hat;
  const own = all.filter(it => ownsItem(s, it.id)), lock = all.filter(it => !ownsItem(s, it.id));
  WD.body.innerHTML = `<ul class="sh-grid wd-grid">${own.map(it => `<li class="${cur === it.id ? 'on' : ''}">
      <button type="button" class="wd-pick" data-wear="${it.id}" aria-pressed="${cur === it.id}"><img src="${ward.tab === 'cloth' ? clothURL(it) : ward.tab === 'eye' ? glassesURL(it.id) : hatURL(it.id)}" alt=""><b>${escHTML(it.name)}</b><small>${cur === it.id ? (ward.tab === 'cloth' ? '입는 중' : '쓰는 중') : (ward.tab === 'cloth' ? '눌러서 입기' : it.id === 'none' ? '눌러서 벗기' : '눌러서 쓰기')}</small></button></li>`).join('')}
    ${lock.map(it => `<li class="wd-lock"><img src="${ward.tab === 'cloth' ? clothURL(it) : ward.tab === 'eye' ? glassesURL(it.id) : hatURL(it.id)}" alt=""><b>${escHTML(it.name)}</b><small>시장에서 ${it.price}은화</small></li>`).join('')}</ul>
    ${lock.length ? `<p class="sh-tip">흐린 건 아직 없는 ${ward.tab === 'cloth' ? '옷' : ward.tab === 'eye' ? '안경' : '모자'}이에요. 다모였섬 시장 <b>모자·옷 가게</b>에서 살 수 있어요.</p>` : ''}`;
  WD.body.querySelectorAll('[data-wear]').forEach(b => b.addEventListener('click', () => {
    const id = b.dataset.wear; wearItem(id); const it = all.find(x => x.id === id);
    WD.note.innerHTML = ward.tab === 'eye' ? (id === 'bare' ? '안경을 벗었어요.' : `<b>${escHTML(it.name)}</b>${chJosa(it.name, '을', '를')} 썼어요.`) : ward.tab === 'cloth' ? `<b>${escHTML(it.name)}</b>${chJosa(it.name, '으로', '로')} 갈아입었어요.` : id === 'none' ? '모자를 벗었어요.' : `<b>${escHTML(it.name)}</b>${chJosa(it.name, '을', '를')} 썼어요.`;
    wardRender(); const n = WD.body.querySelector(`[data-wear="${id}"]`); if (n) n.focus({ preventScroll:true });
  }));
}
function openWardrobe(){
  if (ward.open) return;
  ward.open = true; uiOpen = true; keys.clear(); auto = null; $('#toast').hidden = true;
  /* 캐릭터가 방 쪽으로 돌아서고, 카메라는 앞에서 입은 모습을 비춰요 */
  player.r = Math.PI / 2; player.pose = null;
  deskView = { pos:new THREE.Vector3(player.x + 2.0, 1.25, player.z + 0.35), look:new THREE.Vector3(player.x, 0.72, player.z) };
  wardRef.want = 1; refreshWardrobeRack();
  WD.note.textContent = '입어 보고 싶은 걸 누르면 바로 갈아입어요.';
  WD.root.hidden = false; document.body.classList.add('wardrobe-open'); wardRender();
  setTimeout(() => { try { (WD.body.querySelector('[data-wear]') || WD.close).focus({ preventScroll:true }); } catch(e){} }, 40);
}
function closeWardrobe(){
  if (!ward.open) return;
  ward.open = false; WD.root.hidden = true; document.body.classList.remove('wardrobe-open'); uiOpen = false; deskView = null; wardRef.want = 0;
  try { renderer.domElement.focus({ preventScroll:true }); } catch(e){}
}
WD.close.addEventListener('click', () => closeWardrobe());
WD.tabs.querySelectorAll('[data-tab]').forEach(b => b.addEventListener('click', () => { ward.tab = b.dataset.tab; WD.note.textContent = ''; wardRender(); }));
window.addEventListener('keydown', e => { if (ward.open && e.key === 'Escape'){ e.preventDefault(); closeWardrobe(); } });
/* 문 여닫기 (선장실 ambient 에서 불러요) */
function wardrobeStep(dt){
  wardRef.open += (wardRef.want - wardRef.open) * Math.min(1, dt * 5);
  wardRef.doors.forEach(D => { D.hinge.rotation.y = D.s * wardRef.open * 1.75; });
}
SPOTS.wardrobe = { x:WARD.x + 1.0, z:WARD.z, face:-Math.PI / 2, label:'옷장 열기 · 갈아입기', use:() => openWardrobe() };
