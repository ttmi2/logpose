/* ============================================================
   LOG POSE · 다모였섬 2단계: 시장 (+ 주점 맥주)
   시장: 어창 물고기 팔기 → 은화 · 모자 4종 · 해적기 4종 (사면 바로 쓰고, 언제든 바꿔요)
   주점: 바텐더에게 맥주 한 잔 (5은화) → 건배 + 마실수록 얼굴이 더 빨개져요 (4단계)
   기록: LPProfile.shop = { silver, owned:[물건 id], hat, flag, beers }  (브라우저에 저장)
   ============================================================ */
const HATS = [
  { id:'none',    name:'맨머리',   price:0,  note:'처음 선장은 모자 없이 시작해요' },
  { id:'captain', name:'선장 모자', price:50, note:'금띠를 두른 진짜 선장의 검은 모자' },
  { id:'bandana', name:'빨간 두건', price:20, note:'바닷바람에도 끄떡없어요' },
  { id:'sailor',  name:'하얀 선원모', price:30, note:'파란 리본이 달린 갑판원 모자' },
  { id:'tricorn', name:'삼각 해적모', price:40, note:'금테를 두른 세 모서리 모자' },
  { id:'feather', name:'깃털 모자', price:60, note:'챙이 넓고 긴 깃털이 꽂혀 있어요' },
  { id:'explorer', name:'탐험가 챙모자', price:45, note:'가죽 챙모자 · 바다 탐험가 재킷과 한 벌' },
  { id:'straw',    name:'밀짚모자',     price:35, note:'햇볕 쨍한 바다엔 역시 밀짚모자 · 갈색 천 띠' }
];
/* 안경 (모자 · 옷과 따로 써요 · 'bare' = 안경 없음) */
const GLASSES = [
  { id:'bare',    name:'안경 없음',   price:0,  note:'맨눈으로 바다를 봐요' },
  { id:'round',   name:'동그란 안경', price:25, note:'검은 테 동글동글 · 정주행 선장 필수템' },
  { id:'sun',     name:'선글라스',   price:35, note:'쨍한 바다 햇볕도 끄떡없어요' },
  { id:'heart',   name:'하트 안경',   price:40, note:'최애를 볼 때 쓰는 분홍 하트' },
  { id:'monocle', name:'외알 안경',   price:45, note:'금테 외알에 사슬까지 · 노련한 선장 느낌' },
  { id:'goggle',  name:'항해 고글',   price:50, note:'가죽 끈 놋쇠 고글 · 폭풍 속에서도 앞이 보여요' }
];
const FLAGS = [
  { id:'anchor',  name:'빨간 닻 깃발', price:0,  bg:'#8a2a1c', fg:'#f2e8d2', note:'처음부터 달려 있던 깃발' },
  { id:'compass', name:'남색 나침반 깃발', price:30, bg:'#1f3a56', fg:'#f0d49a', note:'로그포스처럼 길을 가리켜요' },
  { id:'swords',  name:'검은 쌍칼 깃발', price:45, bg:'#1d1a14', fg:'#e8e2d6', note:'엇갈린 두 칼, 정통 해적 느낌' },
  { id:'whale',   name:'초록 고래 깃발', price:60, bg:'#2f6a4a', fg:'#f2e8d2', note:'큰 바다를 누비는 고래' },
  { id:'star',    name:'황금 별 깃발', price:80, bg:'#3a2a5a', fg:'#f2c230', note:'밤하늘 별처럼 반짝여요' }
];
const BEER_PRICE = 5;
/* 시험용: true 면 모자·옷·해적기를 은화 없이 살 수 있어요 (은화는 그대로). 시험 끝나면 false 로 */
const TEST_FREE = false;
const CUSTOM_FLAG_PRICE = 50;   /* 내 사진 해적기: 새 사진을 달 때마다 */
const priceOf = it => TEST_FREE ? 0 : it.price;
const shopData = () => { const p = LPProfile.get() || {}, s = p.shop || {}; return { silver:Math.max(0, s.silver | 0), owned:Array.isArray(s.owned) ? s.owned : [], hat:(s.hat && (s.hat === 'none' || (Array.isArray(s.owned) && s.owned.includes(s.hat)))) ? s.hat : 'none', outfit:(s.outfit && (s.outfit === 'rags' || (Array.isArray(s.owned) && s.owned.includes(s.outfit)))) ? s.outfit : 'rags', glasses:(s.glasses && (s.glasses === 'bare' || (Array.isArray(s.owned) && s.owned.includes(s.glasses)))) ? s.glasses : 'bare', flag:(s.flag === 'custom' && !s.customFlag) ? 'anchor' : (s.flag || 'anchor'), customFlag:typeof s.customFlag === 'string' ? s.customFlag : '', beers:s.beers | 0, earned:s.earned | 0, cheer:s.cheer || null }; };
const saveShop = s => LPProfile.update({ shop:s });
const ownsItem = (s, id) => id === 'none' || id === 'anchor' || id === 'rags' || id === 'bare' || (id === 'custom' ? !!s.customFlag : s.owned.includes(id));
const CLOTHES = OUTFITS;   /* cabin.js 에서 몸에 그려 입혀요 */

/* ---------- 해적기 그림 ---------- */
function drawFlag(g, w, h, f){
  g.fillStyle = f.bg; g.fillRect(0, 0, w, h); g.fillStyle = f.fg; g.strokeStyle = f.fg; g.lineCap = 'round';
  const cx = w / 2, cy = h / 2 + 2;
  if (f.id === 'anchor'){ g.font = `700 92px ${FD}`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('⚓', cx, cy + 4); }
  else if (f.id === 'compass'){ g.lineWidth = 6; g.beginPath(); g.arc(cx, cy, 44, 0, 7); g.stroke();
    [[0, -1], [1, 0], [0, 1], [-1, 0]].forEach(([x, y], k) => { g.beginPath(); g.moveTo(cx + x * 56, cy + y * 56); g.lineTo(cx + y * 9, cy - x * 9); g.lineTo(cx - y * 9, cy + x * 9); g.closePath(); g.fillStyle = k === 0 ? '#d24a3a' : f.fg; g.fill(); }); }
  else if (f.id === 'swords'){ g.lineWidth = 9; [[-1, 1], [1, 1]].forEach(([s]) => { g.beginPath(); g.moveTo(cx - s * 52, cy - 46); g.lineTo(cx + s * 40, cy + 38); g.stroke(); g.lineWidth = 7; g.beginPath(); g.moveTo(cx + s * 30, cy + 46); g.lineTo(cx + s * 52, cy + 26); g.stroke(); g.lineWidth = 9; }); }
  else if (f.id === 'whale'){ g.beginPath(); g.ellipse(cx - 6, cy + 6, 56, 30, 0, 0, 7); g.fill(); g.beginPath(); g.moveTo(cx + 44, cy + 2); g.lineTo(cx + 74, cy - 26); g.lineTo(cx + 66, cy + 8); g.lineTo(cx + 78, cy + 30); g.closePath(); g.fill();
    g.fillStyle = f.bg; g.beginPath(); g.arc(cx - 34, cy - 2, 5, 0, 7); g.fill(); g.strokeStyle = f.fg; g.lineWidth = 4; g.beginPath(); g.moveTo(cx - 20, cy - 26); g.quadraticCurveTo(cx - 24, cy - 50, cx - 36, cy - 54); g.moveTo(cx - 20, cy - 26); g.quadraticCurveTo(cx - 14, cy - 50, cx - 2, cy - 54); g.stroke(); }
  else if (f.id === 'star'){ g.beginPath(); for (let k = 0; k < 10; k++){ const r = k % 2 ? 22 : 54, a = -Math.PI / 2 + k * Math.PI / 5; g[k ? 'lineTo' : 'moveTo'](cx + Math.cos(a) * r, cy + Math.sin(a) * r); } g.closePath(); g.fill();
    [[30, 30], [w - 34, 36], [44, h - 28], [w - 46, h - 30]].forEach(([x, y]) => { g.beginPath(); g.arc(x, y, 4, 0, 7); g.fill(); }); }
}
const flagTexCache = {};
function flagTex(id){
  if (id === 'custom'){ const src = shopData().customFlag; if (src){ const key = 'custom:' + src.length + src.slice(-24);
      if (!flagTexCache[key]){ const t = canvasTex(320, 200, (g, w, h) => { g.fillStyle = '#1d1612'; g.fillRect(0, 0, w, h); }); flagTexCache[key] = t;
        const img = new Image(); img.onload = () => { try { const cv = t.image, g = cv.getContext('2d'); g.drawImage(img, 0, 0, cv.width, cv.height); t.needsUpdate = true; } catch(e){} }; img.src = src; }
      return flagTexCache[key]; } }
  const f = FLAGS.find(x => x.id === id) || FLAGS[0]; return flagTexCache[f.id] || (flagTexCache[f.id] = canvasTex(256, 160, (g, w, h) => drawFlag(g, w, h, f))); }
/* 내 사진 해적기: 고른 사진을 깃발 비율(8:5)로 가운데 맞춰 잘라 이 기기에만 저장해요 */
function makeCustomFlag(file){
  return new Promise((res, rej) => {
    if (!file || !/^image\//.test(file.type)) return rej('사진 파일만 쓸 수 있어요.');
    if (file.size > 15 * 1024 * 1024) return rej('사진이 너무 커요. 15MB 아래로 골라 주세요.');
    const url = URL.createObjectURL(file), img = new Image();
    img.onload = () => { try {
        const W = 320, H = 200, c = document.createElement('canvas'); c.width = W; c.height = H; const g = c.getContext('2d');
        const k = Math.max(W / img.width, H / img.height), dw = img.width * k, dh = img.height * k;
        g.fillStyle = '#1d1612'; g.fillRect(0, 0, W, H); g.drawImage(img, (W - dw) / 2, (H - dh) / 2, dw, dh);
        g.strokeStyle = 'rgba(20,12,6,.55)'; g.lineWidth = 6; g.strokeRect(3, 3, W - 6, H - 6);   /* 천 가장자리 */
        URL.revokeObjectURL(url); res(c.toDataURL('image/jpeg', 0.82)); } catch(e){ rej('사진을 읽지 못했어요.'); } };
    img.onerror = () => { URL.revokeObjectURL(url); rej('사진을 열 수 없어요. 다른 사진을 골라 주세요.'); };
    img.src = url;
  });
}
const FLAG_WHERE = '갑판의 <b>선장실 문 위 난간</b>과 <b>배 뒤 깃대</b>, 선장실 <b>문 옆 벽</b>, 다모였섬 부두의 내 배에서 볼 수 있어요.';
const flagIcon = {};
function flagURL(f){ if (f.id === 'custom') return shopData().customFlag; if (flagIcon[f.id]) return flagIcon[f.id]; const c = document.createElement('canvas'); c.width = 160; c.height = 100; const g = c.getContext('2d'); if (!g) return ''; g.scale(160 / 256, 100 / 160); drawFlag(g, 256, 160, f); try { flagIcon[f.id] = c.toDataURL(); } catch(e){ flagIcon[f.id] = ''; } return flagIcon[f.id]; }

/* ---------- 모자 (3D + 그림) ---------- */
function hatMesh(id){
  const G = new THREE.Group(), add = (geo, color, x, y, z, opts = {}) => { const m = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({ color, roughness:.7, ...opts })); m.position.set(x, y, z); G.add(m); return m; };
  if (id === 'bandana'){
    const cap = add(new THREE.SphereGeometry(0.215, 18, 10, 0, Math.PI * 2, 0, Math.PI * 0.55), '#c0392b', 0, 0.02, 0);
    add(new THREE.TorusGeometry(0.205, 0.025, 6, 20), '#a0301f', 0, 0.02, 0).rotation.x = Math.PI / 2; void cap;
    add(new THREE.SphereGeometry(0.05, 8, 6), '#c0392b', 0, 0.04, -0.21);
    [-0.4, 0.4].forEach(r => { const t = add(new THREE.BoxGeometry(0.06, 0.16, 0.02), '#c0392b', r * 0.12, -0.06, -0.24); t.rotation.z = r; });
    for (let k = 0; k < 6; k++){ const a = k * 1.05; add(new THREE.SphereGeometry(0.018, 6, 4), '#f6ecd2', Math.cos(a) * 0.17, 0.12, Math.sin(a) * 0.17); }
  } else if (id === 'straw'){
    const straw = { color:'#e6cb82', roughness:.95 };
    add(new THREE.CylinderGeometry(0.38, 0.4, 0.02, 28), straw.color, 0, 0.12, 0, { roughness:.95 });              // 넓고 얇은 챙
    const crown = add(new THREE.SphereGeometry(0.2, 20, 12, 0, Math.PI * 2, 0, Math.PI / 2), '#e0c378', 0, 0.12, 0, { roughness:.95 }); crown.scale.set(1, 0.85, 1);
    add(new THREE.TorusGeometry(0.198, 0.022, 6, 24), '#7a5634', 0, 0.15, 0).rotation.x = Math.PI / 2;                // 갈색 천 띠
    [0.24, 0.3, 0.36].forEach(r => add(new THREE.TorusGeometry(r, 0.004, 4, 32), '#c9ad62', 0, 0.133, 0).rotation.x = Math.PI / 2);   // 엮은 결
  } else if (id === 'explorer'){
    add(new THREE.CylinderGeometry(0.36, 0.37, 0.025, 24), '#7a5634', 0, 0.12, 0);                       // 넓은 가죽 챙
    add(new THREE.CylinderGeometry(0.17, 0.2, 0.17, 18), '#8a6440', 0, 0.21, 0);
    add(new THREE.TorusGeometry(0.195, 0.02, 6, 22), '#3a2616', 0, 0.15, 0).rotation.x = Math.PI / 2;    // 띠
    add(new THREE.BoxGeometry(0.06, 0.05, 0.02), '#e0b85a', 0.0, 0.15, 0.2);                              // 금 고리
  } else if (id === 'sailor'){
    add(new THREE.CylinderGeometry(0.2, 0.215, 0.12, 20), '#f6f4ee', 0, 0.12, 0);
    add(new THREE.CylinderGeometry(0.235, 0.235, 0.03, 20), '#f6f4ee', 0, 0.19, 0);
    add(new THREE.TorusGeometry(0.213, 0.018, 6, 22), '#1f4a8a', 0, 0.1, 0).rotation.x = Math.PI / 2;
    [-0.3, 0.3].forEach(r => { const t = add(new THREE.BoxGeometry(0.04, 0.18, 0.01), '#1f4a8a', r * 0.1, 0.0, -0.215); t.rotation.z = r; });
  } else if (id === 'tricorn'){
    const brim = add(new THREE.CylinderGeometry(0.36, 0.36, 0.05, 3), '#1d1612', 0, 0.15, 0); brim.rotation.y = Math.PI; brim.scale.set(1, 1, 0.9);
    [0, 1, 2].forEach(k => { const a = k * Math.PI * 2 / 3 + Math.PI / 2; const up = add(new THREE.BoxGeometry(0.34, 0.12, 0.03), '#1d1612', Math.cos(a) * 0.17, 0.21, Math.sin(a) * 0.17); up.rotation.y = -a + Math.PI / 2; up.rotation.x = -0.5; });
    add(new THREE.CylinderGeometry(0.15, 0.19, 0.16, 16), '#1d1612', 0, 0.25, 0);
    const trim = add(new THREE.TorusGeometry(0.33, 0.012, 4, 3), '#c9a15e', 0, 0.18, 0, { metalness:.5 }); trim.rotation.x = Math.PI / 2; trim.rotation.z = Math.PI / 2;
  } else if (id === 'feather'){
    add(new THREE.CylinderGeometry(0.42, 0.42, 0.04, 24), '#6b4528', 0, 0.15, 0);
    add(new THREE.CylinderGeometry(0.17, 0.2, 0.2, 18), '#6b4528', 0, 0.27, 0);
    add(new THREE.TorusGeometry(0.19, 0.02, 6, 20), '#8a2a1c', 0, 0.19, 0).rotation.x = Math.PI / 2;
    const fth = add(new THREE.SphereGeometry(0.06, 10, 8), '#f2e8d2', 0.16, 0.42, -0.08); fth.scale.set(0.5, 3.6, 1); fth.rotation.set(-0.6, 0, -0.5);
    const f2 = add(new THREE.SphereGeometry(0.05, 10, 8), '#2f9fbf', 0.13, 0.38, -0.04); f2.scale.set(0.5, 2.8, 1); f2.rotation.set(-0.4, 0, -0.35);
  }
  return G;
}
/* ---------- 안경: 3D (머리에 붙여요) · 그림(가게 아이콘) ---------- */
function glassesMesh(id){
  const G = new THREE.Group(); G.name = 'glasses'; if (!id || id === 'bare') return G;
  const add = (geo, mat, x, y, z) => { const o = new THREE.Mesh(geo, mat); o.position.set(x, y, z); G.add(o); return o; };
  const ink = new THREE.MeshStandardMaterial({ color:'#1d1a1f', roughness:.5 }), gold = new THREE.MeshStandardMaterial({ color:'#c9a15e', roughness:.35, metalness:.5 });
  const pink = new THREE.MeshStandardMaterial({ color:'#ff6fa8', roughness:.45 }), leather = new THREE.MeshStandardMaterial({ color:'#6b4528', roughness:.85 });
  const EX = 0.07, EY = -0.01, EZ = 0.198;
  const temples = (mat, w = 0.006) => [-1, 1].forEach(s => { const t = add(new THREE.BoxGeometry(w, w, 0.2), mat, s * 0.16, EY + 0.005, 0.1); t.rotation.y = s * 0.42; });
  if (id === 'round' || id === 'sun'){
    const fm = id === 'sun' ? ink : ink;
    [-1, 1].forEach(s => { add(new THREE.TorusGeometry(0.043, 0.0065, 6, 22), fm, s * EX, EY, EZ);
      if (id === 'sun'){ const l = add(new THREE.CircleGeometry(0.042, 20), new THREE.MeshStandardMaterial({ color:'#15161c', roughness:.15, metalness:.3, transparent:true, opacity:.92 }), s * EX, EY, EZ - 0.001); l.scale.y = 0.86; } });
    add(new THREE.BoxGeometry(0.05, 0.007, 0.007), fm, 0, EY + 0.012, EZ); temples(fm);
  } else if (id === 'heart'){
    const sh = new THREE.Shape(); sh.moveTo(0, -0.04); sh.bezierCurveTo(-0.05, -0.005, -0.05, 0.035, -0.024, 0.038); sh.bezierCurveTo(-0.01, 0.04, 0, 0.03, 0, 0.022);
    sh.bezierCurveTo(0, 0.03, 0.01, 0.04, 0.024, 0.038); sh.bezierCurveTo(0.05, 0.035, 0.05, -0.005, 0, -0.04);
    const geo = new THREE.ExtrudeGeometry(sh, { depth:0.008, bevelEnabled:false });
    [-1, 1].forEach(s => { add(geo, pink, s * EX, EY, EZ - 0.006);
      const l = add(new THREE.ShapeGeometry(sh), new THREE.MeshStandardMaterial({ color:'#ffc2da', roughness:.2, transparent:true, opacity:.75 }), s * EX, EY, EZ + 0.003); l.scale.setScalar(0.78); });
    add(new THREE.BoxGeometry(0.05, 0.007, 0.007), pink, 0, EY + 0.014, EZ); temples(pink);
  } else if (id === 'monocle'){
    add(new THREE.TorusGeometry(0.046, 0.007, 6, 22), gold, -EX, EY, EZ);
    add(new THREE.CircleGeometry(0.044, 20), new THREE.MeshStandardMaterial({ color:'#dff0f5', roughness:.05, transparent:true, opacity:.35 }), -EX, EY, EZ - 0.001);
    for (let k = 0; k < 6; k++){ const c = add(new THREE.TorusGeometry(0.008, 0.002, 4, 8), gold, -EX - 0.03 - k * 0.006, EY - 0.05 - k * 0.018, EZ - 0.01 - k * 0.012); c.rotation.y = k % 2 ? Math.PI / 2 : 0; }
  } else if (id === 'goggle'){
    [-1, 1].forEach(s => { const r = add(new THREE.CylinderGeometry(0.05, 0.05, 0.035, 18, 1, true), gold, s * EX, EY, EZ - 0.006); r.rotation.x = Math.PI / 2;
      add(new THREE.CircleGeometry(0.048, 18), new THREE.MeshStandardMaterial({ color:'#7fc4d6', roughness:.1, metalness:.2, transparent:true, opacity:.8 }), s * EX, EY, EZ + 0.012); });
    add(new THREE.BoxGeometry(0.04, 0.014, 0.012), leather, 0, EY, EZ);
    const strap = add(new THREE.TorusGeometry(0.2, 0.012, 6, 32), leather, 0, EY, 0.0); strap.rotation.x = Math.PI / 2; strap.scale.set(1.06, 1.0, 1);
  }
  return G;
}
function setAvatarGlasses(av, id){
  const head = av && av.userData && av.userData.head; if (!head) return;
  if (head.userData.glasses){ head.remove(head.userData.glasses); head.userData.glasses = null; }
  if (id && id !== 'bare'){ const g = glassesMesh(id); head.add(g); head.userData.glasses = g; }
  av.userData.glassesId = id || 'bare';
}
function glassesDraw(g, id){
  const W = 120, H = 90; g.clearRect(0, 0, W, H); g.lineCap = 'round'; g.lineJoin = 'round';
  const cy = 46, L = 38, R = 82;
  if (id === 'bare'){ g.strokeStyle = 'rgba(90,70,50,.35)'; g.setLineDash([5, 5]); g.lineWidth = 3; [L, R].forEach(x => { g.beginPath(); g.arc(x, cy, 15, 0, Math.PI * 2); g.stroke(); }); g.setLineDash([]); return; }
  const bridge = col => { g.strokeStyle = col; g.lineWidth = 4; g.beginPath(); g.moveTo(L + 15, cy - 4); g.quadraticCurveTo(60, cy - 10, R - 15, cy - 4); g.stroke(); g.beginPath(); g.moveTo(L - 16, cy - 4); g.lineTo(8, cy - 10); g.moveTo(R + 16, cy - 4); g.lineTo(112, cy - 10); g.stroke(); };
  if (id === 'round' || id === 'sun'){
    [L, R].forEach(x => { g.beginPath(); g.arc(x, cy, 16, 0, Math.PI * 2); if (id === 'sun'){ g.fillStyle = '#1b1c22'; g.fill(); g.fillStyle = 'rgba(255,255,255,.35)'; g.beginPath(); g.ellipse(x - 5, cy - 6, 5, 3, -0.5, 0, Math.PI * 2); g.fill(); g.beginPath(); g.arc(x, cy, 16, 0, Math.PI * 2); }
      g.strokeStyle = '#1d1a1f'; g.lineWidth = 5; g.stroke(); });
    bridge('#1d1a1f');
  } else if (id === 'heart'){
    const heart = (x, s) => { g.beginPath(); g.moveTo(x, cy + 15 * s); g.bezierCurveTo(x - 22 * s, cy, x - 18 * s, cy - 18 * s, x, cy - 8 * s); g.bezierCurveTo(x + 18 * s, cy - 18 * s, x + 22 * s, cy, x, cy + 15 * s); g.closePath(); };
    [L, R].forEach(x => { heart(x, 1); g.fillStyle = 'rgba(255,170,205,.75)'; g.fill(); g.strokeStyle = '#ff5a9a'; g.lineWidth = 5; g.stroke(); });
    bridge('#ff5a9a');
  } else if (id === 'monocle'){
    g.beginPath(); g.arc(R - 18, cy, 20, 0, Math.PI * 2); g.fillStyle = 'rgba(210,235,242,.45)'; g.fill(); g.strokeStyle = '#c9a15e'; g.lineWidth = 6; g.stroke();
    g.strokeStyle = '#b08a48'; g.lineWidth = 2.5; g.setLineDash([4, 3]); g.beginPath(); g.moveTo(R - 30, cy + 16); g.quadraticCurveTo(R - 40, cy + 40, R - 8, cy + 40); g.stroke(); g.setLineDash([]);
  } else if (id === 'goggle'){
    g.strokeStyle = '#6b4528'; g.lineWidth = 8; g.beginPath(); g.moveTo(6, cy); g.lineTo(114, cy); g.stroke();
    [L, R].forEach(x => { g.beginPath(); g.arc(x, cy, 18, 0, Math.PI * 2); g.fillStyle = '#7fc4d6'; g.fill(); g.strokeStyle = '#c9a15e'; g.lineWidth = 7; g.stroke();
      g.fillStyle = 'rgba(255,255,255,.5)'; g.beginPath(); g.ellipse(x - 6, cy - 7, 5, 3, -0.5, 0, Math.PI * 2); g.fill(); });
  }
}
const glassIcon = {};
function glassesURL(id){ if (glassIcon[id]) return glassIcon[id]; const c = document.createElement('canvas'); c.width = 120; c.height = 90; const g = c.getContext('2d'); if (!g) return ''; glassesDraw(g, id); return (glassIcon[id] = c.toDataURL()); }
function hatDraw(g, id){
  g.clearRect(0, 0, 120, 90); g.save(); g.translate(60, 56);
  g.fillStyle = '#f4f2f7'; g.beginPath(); g.arc(0, 8, 24, 0, 7); g.fill();
  g.fillStyle = '#2b2832'; [-8, 8].forEach(x => { g.beginPath(); g.ellipse(x, 9, 2.6, 3.4, 0, 0, 7); g.fill(); });
  if (id === 'captain'){ g.fillStyle = '#1d1612'; g.fillRect(-34, -14, 68, 9); g.fillRect(-20, -32, 40, 20); g.fillStyle = '#c9a15e'; g.fillRect(-22, -15, 44, 3); }
  else if (id === 'bandana'){ g.fillStyle = '#c0392b'; g.beginPath(); g.arc(0, -4, 26, Math.PI, 0); g.fill(); g.fillRect(-26, -6, 52, 6); g.beginPath(); g.moveTo(24, -2); g.lineTo(40, 8); g.lineTo(34, 14); g.closePath(); g.fill(); g.fillStyle = '#f6ecd2'; [[-12, -14], [4, -20], [14, -10]].forEach(([x, y]) => { g.beginPath(); g.arc(x, y, 3, 0, 7); g.fill(); }); }
  else if (id === 'straw'){ g.fillStyle = '#e6cb82'; g.beginPath(); g.ellipse(0, -8, 50, 9, 0, 0, 7); g.fill(); g.fillStyle = '#e0c378'; g.beginPath(); g.ellipse(0, -12, 24, 20, 0, Math.PI, 0); g.fill(); g.fillStyle = '#7a5634'; g.fillRect(-24, -16, 48, 6); g.strokeStyle = '#c9ad62'; g.lineWidth = 1; for (let x = -44; x <= 44; x += 8){ g.beginPath(); g.moveTo(x, -13); g.lineTo(x * 1.05, -3); g.stroke(); } }
  else if (id === 'explorer'){ g.fillStyle = '#7a5634'; g.beginPath(); g.ellipse(0, -8, 48, 8, 0, 0, 7); g.fill(); g.fillStyle = '#8a6440'; g.fillRect(-20, -30, 40, 22); g.fillStyle = '#3a2616'; g.fillRect(-20, -14, 40, 5); g.fillStyle = '#e0b85a'; g.fillRect(-3, -15, 6, 7); }
  else if (id === 'sailor'){ g.fillStyle = '#f6f4ee'; g.fillRect(-26, -24, 52, 18); g.fillRect(-30, -26, 60, 5); g.fillStyle = '#1f4a8a'; g.fillRect(-26, -10, 52, 4); g.fillRect(24, -8, 5, 18); }
  else if (id === 'tricorn'){ g.fillStyle = '#1d1612'; g.beginPath(); g.moveTo(-42, -6); g.quadraticCurveTo(0, -48, 42, -6); g.quadraticCurveTo(0, -14, -42, -6); g.fill(); g.strokeStyle = '#c9a15e'; g.lineWidth = 2.5; g.beginPath(); g.moveTo(-40, -7); g.quadraticCurveTo(0, -46, 40, -7); g.stroke(); }
  else if (id === 'feather'){ g.fillStyle = '#6b4528'; g.beginPath(); g.ellipse(0, -8, 46, 8, 0, 0, 7); g.fill(); g.fillRect(-18, -32, 36, 24); g.fillStyle = '#8a2a1c'; g.fillRect(-18, -14, 36, 5); g.fillStyle = '#f2e8d2'; g.beginPath(); g.ellipse(26, -38, 6, 26, 0.6, 0, 7); g.fill(); g.fillStyle = '#2f9fbf'; g.beginPath(); g.ellipse(20, -34, 4, 18, 0.4, 0, 7); g.fill(); }
  g.restore();
}
/* 옷 아이콘: 작은 몸통에 그 옷을 그려요 */
const clothIcon = {};
function clothURL(o){
  if (clothIcon[o.id]) return clothIcon[o.id];
  const c = document.createElement('canvas'); c.width = 120; c.height = 90; const g = c.getContext('2d'); if (!g) return '';
  clothDraw(g, o); try { clothIcon[o.id] = c.toDataURL(); } catch(e){ clothIcon[o.id] = ''; } return clothIcon[o.id];
}
function clothDraw(g, o){
  const col = outfitColors(o, '#2f5f8a');
  g.save(); g.translate(60, 46);
  g.fillStyle = '#f4f2f7'; [-12, 12].forEach(x => { g.beginPath(); g.ellipse(x, 30, 9, 12, 0, 0, 7); g.fill(); });
  g.fillStyle = col.pants; g.beginPath(); g.ellipse(0, 14, 30, 18, 0, 0, Math.PI); g.fill(); g.fillRect(-30, 6, 60, 9); [-12, 12].forEach(x => g.fillRect(x - 9, 18, 18, o.long ? 16 : 10));
  g.fillStyle = col.shirt; g.beginPath(); g.moveTo(-14, -30); g.quadraticCurveTo(-34, -20, -30, 10); g.lineTo(30, 10); g.quadraticCurveTo(34, -20, 14, -30); g.closePath(); g.fill();
  [-1, 1].forEach(sd => { g.beginPath(); g.ellipse(sd * 30, -10, 8, 15, sd * 0.7, 0, 7); g.fill(); });
  if (o.pattern === 'stripe'){ g.fillStyle = '#2f5a9a'; for (let y = -22; y < 8; y += 8) g.fillRect(-31, y, 62, 3); }
  if (o.pattern === 'flower'){ g.fillStyle = '#fff3d6'; [[-16, -14], [8, -20], [16, 0], [-6, 2]].forEach(([x, y]) => { g.beginPath(); g.arc(x, y, 3.4, 0, 7); g.fill(); }); }
  if (o.pattern === 'vest'){ g.fillStyle = o.acc; g.fillRect(-30, -24, 24, 34); g.fillRect(6, -24, 24, 34); }
  if (o.pattern === 'scout'){ g.fillStyle = 'rgba(0,0,0,.2)'; g.fillRect(-20, -16, 12, 9); g.fillRect(8, -16, 12, 9); g.fillStyle = o.acc; g.beginPath(); g.arc(-14, -22, 3.5, 0, 7); g.fill(); g.fillStyle = col.belt; g.fillRect(-30, 3, 60, 4); }
  if (o.pattern === 'haori'){ g.strokeStyle = 'rgba(242,239,230,.85)'; g.lineWidth = 1.4; for (let y = -20; y < 8; y += 8) for (let x = -30; x < 32; x += 12){ g.beginPath(); g.arc(x, y, 5, Math.PI, 0); g.stroke(); } g.fillStyle = '#1d1d24'; g.fillRect(-5, -30, 10, 40); }
  if (o.pattern === 'jersey'){ g.fillStyle = o.acc; g.fillRect(-31, -26, 62, 5); g.fillRect(-31, -20, 7, 30); g.fillRect(24, -20, 7, 30); g.font = `800 18px ${FB}`; g.textAlign = 'center'; g.fillText('7', 0, 0); }
  if (o.pattern === 'explorer'){ g.fillStyle = '#f2ece0'; g.fillRect(-5, -30, 10, 40); g.fillStyle = o.acc; g.fillRect(-7, -30, 2, 40); g.fillRect(5, -30, 2, 40); }
  if (o.pattern === 'school'){ g.fillStyle = '#f4f2ee'; g.beginPath(); g.moveTo(-9, -30); g.lineTo(9, -30); g.lineTo(0, -8); g.closePath(); g.fill(); g.fillStyle = o.acc; g.fillRect(-6, -27, 12, 5); g.fillStyle = '#c9a15e'; [-4, 3].forEach(y => { g.beginPath(); g.arc(0, y, 1.8, 0, 7); g.fill(); }); }
  if (o.pattern === 'coat'){ g.fillStyle = '#c9a15e'; [-5, 5].forEach(x => [-18, -8, 2].forEach(y => { g.beginPath(); g.arc(x, y, 2.2, 0, 7); g.fill(); })); g.fillRect(-30, 8, 60, 2); }
  if (o.torn){ g.fillStyle = '#a8543a'; g.fillRect(6, -16, 10, 8); g.fillStyle = '#f4f2f7'; for (let x = -28; x < 30; x += 8){ g.beginPath(); g.moveTo(x, 11); g.lineTo(x + 4, 4); g.lineTo(x + 8, 11); g.fill(); } }
  g.fillStyle = col.belt; if (!o.long) g.fillRect(-30, 6, 60, 3);
  g.restore();
}
const hatIcon = {};
function hatURL(id){ if (hatIcon[id]) return hatIcon[id]; const c = document.createElement('canvas'); c.width = 120; c.height = 90; const g = c.getContext('2d'); if (!g) return ''; hatDraw(g, id); try { hatIcon[id] = c.toDataURL(); } catch(e){ hatIcon[id] = ''; } return hatIcon[id]; }

/* ---------- 모습 바꾸기 ---------- */
let lookHat = null, lookFlag = null, lookOutfit = null, lookGlasses = null;
function applyLooks(){
  const s = shopData();
  const head = player.mesh && player.mesh.userData.head;
  if (head && lookHat !== s.hat){
    lookHat = s.hat;
    (head.userData.hatParts || []).forEach(m => m.visible = s.hat === 'captain');
    if (head.userData.extraHat){ head.remove(head.userData.extraHat); head.userData.extraHat = null; }
    if (s.hat !== 'captain' && s.hat !== 'none'){ const h = hatMesh(s.hat); head.add(h); head.userData.extraHat = h; }
  }
  if (player.mesh && lookOutfit !== s.outfit){ lookOutfit = s.outfit; dressAvatar(player.mesh, s.outfit); }
  if (player.mesh && lookGlasses !== s.glasses){ lookGlasses = s.glasses; setAvatarGlasses(player.mesh, s.glasses); }
  const fk = s.flag === 'custom' ? 'custom:' + s.customFlag.length + s.customFlag.slice(-24) : s.flag;
  if (lookFlag !== fk){
    lookFlag = fk; const t = flagTex(s.flag);
    [IN.flag, DK3.flag].forEach(f => { if (f && f.material){ f.material.map = t; f.material.needsUpdate = true; } });
    flagShows.forEach(m => { m.map = t; m.needsUpdate = true; });
  }
}

/* ---------- 맥주 ---------- */
let mugMesh = null, tipsyT = 0;
function drinkBeer(){
  const pm = player.mesh; if (!pm) return;
  if (!mugMesh){ mugMesh = new THREE.Group();
    const c = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.06, 0.16, 10), new THREE.MeshStandardMaterial({ color:'#e8b84a', roughness:.4 })); mugMesh.add(c);
    const f = new THREE.Mesh(new THREE.CylinderGeometry(0.075, 0.075, 0.04, 10), new THREE.MeshStandardMaterial({ color:'#fff6e0' })); f.position.y = 0.09; mugMesh.add(f);
    mugMesh.position.set(0, -0.4, 0.06); }
  pm.userData.rArm.add(mugMesh);
  player.pose = 'drink';
  setTimeout(() => { if (player.pose === 'drink') player.pose = null; if (mugMesh.parent) mugMesh.parent.remove(mugMesh); setTipsy(true); }, reduceMotion ? 600 : 2200);
  toast('🍺 <strong>캬~!</strong> 건배! 시원한 맥주 한 잔이에요.', 2600);
}
/* 취기: 한 잔 마실 때마다 한 단계씩 (최대 4) · 40초마다 한 단계씩 깨요
   1 볼이 발그레 → 2 볼이 크게 빨개지고 얼굴이 분홍 → 3 얼굴이 빨갛게 + 코끝까지 → 4 새빨간 홍당무 + 몸이 휘청 */
let tipsyLv = 0;
const TIPSY_FACE = ['', '#ffd9cc', '#ffb3a1', '#ff8a78', '#ff5f52'];
function blushAvatar(av, lv){
  const head = av && av.userData && av.userData.head; if (!head) return;
  const face = head.userData.face || head;
  if (!head.userData.cheeks){
    const cm = new THREE.MeshBasicMaterial({ color:'#ff5a5a', transparent:true, opacity:.8, depthWrite:false });
    head.userData.cheeks = [-1, 1].map(s => { const c = new THREE.Mesh(new THREE.CircleGeometry(0.045, 16), cm); c.position.set(s * 0.115, -0.055, 0.17); c.rotation.y = s * 0.6; head.add(c); return c; });
    const nm = new THREE.MeshBasicMaterial({ color:'#ff3b3b', transparent:true, opacity:.85, depthWrite:false });
    head.userData.nose = new THREE.Mesh(new THREE.CircleGeometry(0.028, 14), nm); head.userData.nose.position.set(0, -0.045, 0.2); head.add(head.userData.nose);
    head.userData.skin = face.material.color.clone();
  }
  lv = Math.max(0, Math.min(4, lv | 0));
  const sc = [0, 0.8, 0.85, 0.9, 0.95][lv];   /* 볼 크기는 거의 그대로 · 진해지는 건 색으로 (11/24: 갈수록 너무 커진다는 의견) */
  head.userData.cheeks.forEach(c => { c.visible = lv > 0; c.scale.setScalar(sc || 1); c.material.opacity = [0, .45, .6, .75, .85][lv]; });
  head.userData.nose.visible = lv >= 3; head.userData.nose.scale.setScalar(lv >= 4 ? 0.75 : 0.6);
  face.material.color.copy(lv ? new THREE.Color(TIPSY_FACE[lv]) : head.userData.skin);
  av.userData.tipsy = lv;
}
function setTipsy(on){
  tipsyLv = on === true ? Math.min(4, tipsyLv + 1) : on === false ? 0 : Math.max(0, Math.min(4, on | 0));
  player.tipsy = tipsyLv;
  blushAvatar(player.mesh, tipsyLv);
  clearTimeout(tipsyT); if (tipsyLv > 0) tipsyT = setTimeout(() => setTipsy(tipsyLv - 1), 40000);
  if (tipsyLv >= 3) toast(tipsyLv >= 4 ? '🍺 <strong>딸꾹!</strong> 얼굴이 홍당무가 됐어요. 조금 쉬었다 가요~' : '🍺 얼굴이 <strong>빨개졌어요</strong>. 딸꾹!', 2400);
}

/* ---------- 가게 화면 ---------- */
const SH = { root:$('#shop'), title:$('#shTitle'), kick:$('#shKick'), coins:$('#shCoins'), tabs:$('#shTabs'), body:$('#shBody'), note:$('#shNote'), close:$('#shClose') };
const shop = { open:false, mode:'market', tab:'sell' };
function shopRender(){
  const s = shopData(), f = fishData();
  SH.coins.innerHTML = `은화 <b>${s.silver}</b>${TEST_FREE && shop.mode === 'market' ? ' · <em>시험용 무료</em>' : ''}`;
  SH.tabs.hidden = shop.mode !== 'market';
  SH.tabs.querySelectorAll('[data-tab]').forEach(b => { b.setAttribute('aria-selected', String(b.dataset.tab === shop.tab)); b.tabIndex = b.dataset.tab === shop.tab ? 0 : -1; });
  let h = '';
  if (shop.mode === 'tavern'){
    h = `<div class="sh-beer"><div class="sh-mug" aria-hidden="true">🍺</div><div><b>시원한 맥주 한 잔</b><p>바텐더가 거품 가득 따라 줘요. 마실수록 얼굴이 더 빨개져요. 네 잔이면 홍당무!</p></div></div>
      <div class="fi-btns"><button type="button" class="g-btn primary" data-beer ${s.silver < BEER_PRICE ? 'disabled' : ''}>마시기 · ${BEER_PRICE}은화</button><button type="button" class="g-btn ghost" data-close>괜찮아요</button></div>
      ${s.silver < BEER_PRICE ? `<p class="sh-tip">은화가 모자라요. 갑판 낚시터에서 물고기를 낚아 <b>시장</b>에 팔아 보세요.</p>` : ''}`;
  } else if (shop.tab === 'sell'){
    const groups = FISH.map(sp => ({ sp, list:f.hold.map((x, i) => ({ ...x, i, v:fishValue(sp, x.size) })).filter(x => x.sp === sp.id).sort((a, b) => b.v - a.v) })).filter(g => g.list.length);
    const total = groups.reduce((a, g) => a + g.list.reduce((b, x) => b + x.v, 0), 0);
    h = groups.length ? `<p class="sh-tip">어창에 ${f.hold.length}마리 · 모두 팔면 <b>${total}은화</b></p>
      <ul class="sh-list">${groups.map(({ sp, list }) => { const sum = list.reduce((a, x) => a + x.v, 0);
        return `<li><img src="${catchURL(sp)}" alt=""><div><b>${escHTML(sp.name)} <span>×${list.length}</span></b><small>한 마리 ${list[0].v}은화${list.length > 1 ? ` · 모두 ${sum}은화` : ''}</small></div>
          <div class="sh-acts"><button type="button" class="lm-b go" data-sell1="${sp.id}">한 마리 팔기 +${list[0].v}</button>${list.length > 1 ? `<button type="button" class="lm-b" data-sellall="${sp.id}">모두 +${sum}</button>` : ''}</div></li>`; }).join('')}</ul>
      <div class="fi-btns"><button type="button" class="g-btn primary" data-sellevery>어창 전부 팔기 · +${total}은화</button></div>`
      : `<p class="sh-empty"><b>어창이 비었어요</b>내 배 갑판의 <em>고물 낚시터</em>에서 물고기를 낚아 오면 여기서 은화로 바꿔 줄게요.</p>`;
  } else {
    const list = shop.tab === 'hat' ? HATS : shop.tab === 'cloth' ? CLOTHES : shop.tab === 'eye' ? GLASSES : FLAGS, cur = shop.tab === 'hat' ? s.hat : shop.tab === 'cloth' ? s.outfit : shop.tab === 'eye' ? s.glasses : s.flag;
    const custom = shop.tab === 'flag' ? `<li class="sh-custom${cur === 'custom' ? ' on' : ''}">${s.customFlag ? `<img src="${s.customFlag}" alt="내 사진 해적기">` : '<div class="sh-ph" aria-hidden="true">📷</div>'}<b>내 사진 해적기</b><small>직접 찍거나 그린 사진으로 깃발을 만들어요 · 새 사진마다 ${CUSTOM_FLAG_PRICE}은화</small>
        <details class="sh-guide"><summary>사진 고르는 법</summary><ul>
          <li><b>가로 사진</b>이 잘 맞아요. 깃발은 가로:세로 <b>8:5</b>예요.</li>
          <li><b>가운데를 기준</b>으로 잘려요. 세로 사진은 위아래가, 아주 넓은 사진은 양옆이 잘려요.</li>
          <li>보여 주고 싶은 그림·글자는 <b>가운데</b>에 두세요. 가장자리는 천 테두리로 살짝 어두워져요.</li>
          <li>작게 줄여 저장해요(320×200). 아주 작은 글씨는 잘 안 보여요.</li>
          <li>다른 사람 얼굴, 공식 작품 이미지, 불쾌한 사진은 쓰지 말아 주세요. 사진은 이 기기에만 저장돼요.</li>
        </ul></details>
        <div class="sh-acts">${cur === 'custom' ? '<span class="sh-state">다는 중</span>' : s.customFlag ? '<button type="button" class="lm-b go" data-use="custom">달기</button>' : ''}${s.silver < priceOf({ price:CUSTOM_FLAG_PRICE }) ? `<span class="lm-b" aria-disabled="true">${s.customFlag ? '바꾸기' : '사진 고르기'} · ${CUSTOM_FLAG_PRICE}은화 부족</span>` : `<label class="lm-b${s.customFlag ? '' : ' go'} sh-file">${s.customFlag ? '바꾸기' : '사진 고르기'} · ${priceOf({ price:CUSTOM_FLAG_PRICE }) || '무료'}${priceOf({ price:CUSTOM_FLAG_PRICE }) ? '은화' : ''}<input type="file" accept="image/*" data-flagfile></label>`}</div></li>` : '';
    h = `<ul class="sh-grid">${custom}${list.map(it => { const own = ownsItem(s, it.id), on = cur === it.id, poor = !own && s.silver < priceOf(it);
      return `<li class="${on ? 'on' : ''}"><img src="${shop.tab === 'hat' ? hatURL(it.id) : shop.tab === 'cloth' ? clothURL(it) : shop.tab === 'eye' ? glassesURL(it.id) : flagURL(it)}" alt=""><b>${escHTML(it.name)}</b><small>${escHTML(it.note)}</small>
        ${on ? `<span class="sh-state">${shop.tab === 'cloth' ? '입는 중' : '쓰는 중'}</span>` : own ? `<button type="button" class="lm-b go" data-use="${it.id}">${it.id === 'none' || it.id === 'bare' ? '벗기' : shop.tab === 'hat' || shop.tab === 'eye' ? '쓰기' : shop.tab === 'cloth' ? '입기' : '달기'}</button>`
             : `<button type="button" class="lm-b${poor ? '' : ' go'}" data-buy="${it.id}" ${poor ? 'disabled' : ''}>${TEST_FREE ? `<s>${it.price}</s> 무료 · 사기` : `${it.price}은화${poor ? ' · 부족' : ' · 사기'}`}</button>`}</li>`; }).join('')}</ul>`;
  }
  SH.body.innerHTML = h;
  SH.body.querySelectorAll('[data-sell1]').forEach(b => b.addEventListener('click', () => sellFish(b.dataset.sell1, 1)));
  SH.body.querySelectorAll('[data-sellall]').forEach(b => b.addEventListener('click', () => sellFish(b.dataset.sellall, Infinity)));
  SH.body.querySelectorAll('[data-sellevery]').forEach(b => b.addEventListener('click', () => sellFish(null, Infinity)));
  SH.body.querySelectorAll('[data-buy]').forEach(b => b.addEventListener('click', () => buyItem(b.dataset.buy)));
  SH.body.querySelectorAll('[data-use]').forEach(b => b.addEventListener('click', () => useItem(b.dataset.use)));
  SH.body.querySelectorAll('[data-beer]').forEach(b => b.addEventListener('click', () => buyBeer()));
  SH.body.querySelectorAll('[data-flagfile]').forEach(inp => inp.addEventListener('change', () => {
    const file = inp.files && inp.files[0]; if (!file) return; shopSay('사진으로 깃발을 짓는 중…');
    const cost = priceOf({ price:CUSTOM_FLAG_PRICE }); if (shopData().silver < cost){ shopSay('은화가 모자라요.'); return; }
    makeCustomFlag(file).then(data => { const s2 = shopData(); if (s2.silver < cost){ shopSay('은화가 모자라요.'); return; } s2.silver -= cost; s2.customFlag = data; s2.flag = 'custom'; saveShop(s2); lookFlag = null; applyLooks(); pulseLogpose();
      shopSay(`<b>내 사진 해적기</b>를 달았어요!${cost ? ` (−${cost}은화)` : ''} ` + FLAG_WHERE); shopRender(); })
    .catch(msg => shopSay(typeof msg === 'string' ? msg : '사진을 읽지 못했어요.'));
  }));
  SH.body.querySelectorAll('[data-close]').forEach(b => b.addEventListener('click', () => closeShop()));
}
const shopSay = t => { SH.note.innerHTML = t; };
function sellFish(spId, n){
  const f = fishData(), s = shopData();
  const pick = f.hold.map((x, i) => ({ x, i, v:fishValue(spOf(x.sp), x.size) })).filter(o => !spId || o.x.sp === spId).sort((a, b) => b.v - a.v).slice(0, n);
  if (!pick.length) return;
  const gain = pick.reduce((a, o) => a + o.v, 0), drop = new Set(pick.map(o => o.i));
  f.hold = f.hold.filter((_, i) => !drop.has(i)); saveFish(f);
  s.silver += gain; s.earned += gain; saveShop(s); syncCaptain();   /* 번 은화 = 현상금 선장 (라프텔 선장) */
  shopSay(`${pick.length}마리를 팔아 <b>+${gain}은화</b>를 받았어요.`); pulseLogpose(); shopRender();
  const next = SH.body.querySelector('[data-sell1]') || SH.close; try { next.focus({ preventScroll:true }); } catch(e){}
}
function buyItem(id){
  const it = [...HATS, ...CLOTHES, ...GLASSES, ...FLAGS].find(x => x.id === id), s = shopData(); if (!it || ownsItem(s, id)) return;
  if (s.silver < priceOf(it)){ shopSay('은화가 모자라요.'); return; }
  const kind = HATS.includes(it) ? 'hat' : CLOTHES.includes(it) ? 'cloth' : GLASSES.includes(it) ? 'eye' : 'flag';
  s.silver -= priceOf(it); s.owned.push(id); if (kind === 'hat') s.hat = id; else if (kind === 'cloth') s.outfit = id; else if (kind === 'eye') s.glasses = id; else s.flag = id; saveShop(s);
  applyLooks(); pulseLogpose();
  shopSay(kind === 'hat' || kind === 'eye' ? `<b>${escHTML(it.name)}</b>${chJosa(it.name, '을', '를')} 샀어요! 바로 써 봤어요.${kind === 'eye' ? ' 선장실 <b>옷장</b>에서 언제든 바꿔 쓸 수 있어요.' : ''}` : kind === 'cloth' ? `<b>${escHTML(it.name)}</b>${chJosa(it.name, '을', '를')} 샀어요! 바로 입어 봤어요. 선장실 <b>옷장</b>에서 언제든 갈아입을 수 있어요.` : `<b>${escHTML(it.name)}</b>을 샀어요! 내 배에 달았어요. ${FLAG_WHERE}`); shopRender();
}
function wearItem(id){ const s = shopData(); if (!ownsItem(s, id)) return null; const kind = HATS.some(x => x.id === id) ? 'hat' : CLOTHES.some(x => x.id === id) ? 'cloth' : GLASSES.some(x => x.id === id) ? 'eye' : 'flag'; if (kind === 'hat') s.hat = id; else if (kind === 'cloth') s.outfit = id; else if (kind === 'eye') s.glasses = id; else s.flag = id; saveShop(s); applyLooks(); if (kind !== 'flag' && typeof syncCaptain === 'function') syncCaptain(); return kind; }
function useItem(id){ const kind = wearItem(id); if (!kind) return; shopSay(kind === 'eye' ? (id === 'bare' ? '안경을 벗었어요.' : '안경을 바꿔 썼어요.') : kind === 'hat' ? (id === 'none' ? '모자를 벗었어요. 시원하네요!' : '모자를 바꿔 썼어요.') : kind === 'cloth' ? '옷을 갈아입었어요.' : '깃발을 바꿔 달았어요. ' + FLAG_WHERE); shopRender(); }
function buyBeer(){ const s = shopData(); if (s.silver < BEER_PRICE) return; s.silver -= BEER_PRICE; s.beers += 1; saveShop(s); closeShop(); drinkBeer(); }
const SHOP_WHO = { fish:['생선 매입 가게', '생선 삽니다! 은화로 바로 드려요'], hat:['모자·옷 가게', '모자도 옷도 안경도 골라 보세요, 선장님!'], flag:['깃발 가게', '어떤 깃발을 달아 볼까요?'] };
function openShop(mode, tab = 'sell', who){
  if (shop.open) return;
  shop.open = true; shop.mode = mode; shop.tab = tab; uiOpen = true; keys.clear(); auto = null; $('#toast').hidden = true;
  const W = SHOP_WHO[who];
  SH.kick.textContent = mode === 'tavern' ? '주점 럼통 · 바텐더' : W ? `다모였섬 시장 · ${W[0]}` : '다모였섬 시장';
  SH.title.textContent = mode === 'tavern' ? '맥주 한 잔 할래요?' : W ? W[1] : '어서 오세요, 선장님!';
  shopSay(mode === 'tavern' ? '' : '물고기를 팔아 은화를 모으고, 모자·옷·안경·해적기를 사 보세요.');
  SH.root.hidden = false; document.body.classList.add('shop-open'); shopRender();
  setTimeout(() => { try { (SH.body.querySelector('button:not([disabled])') || SH.close).focus({ preventScroll:true }); } catch(e){} }, 40);
}
function closeShop(){ if (!shop.open) return; shop.open = false; SH.root.hidden = true; document.body.classList.remove('shop-open'); uiOpen = false; try { renderer.domElement.focus({ preventScroll:true }); } catch(e){} }
SH.close.addEventListener('click', () => closeShop());
SH.tabs.querySelectorAll('[data-tab]').forEach(b => b.addEventListener('click', () => { shop.tab = b.dataset.tab; shopSay(''); shopRender(); }));
SH.tabs.addEventListener('keydown', e => { if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return; e.preventDefault(); const t = ['sell', 'hat', 'cloth', 'flag'], i = t.indexOf(shop.tab); shop.tab = t[(i + (e.key === 'ArrowRight' ? 1 : 3)) % 4]; shopRender(); const b = SH.tabs.querySelector(`[data-tab="${shop.tab}"]`); if (b) b.focus(); });
window.addEventListener('keydown', e => {
  if (!shop.open) return;
  if (e.key === 'Escape'){ e.preventDefault(); closeShop(); return; }
  if (e.key === 'Tab'){ const f = [...SH.root.querySelectorAll('button:not([disabled])')].filter(b => b.offsetParent !== null); if (!f.length) return; const first = f[0], last = f[f.length - 1];
    if (e.shiftKey && document.activeElement === first){ e.preventDefault(); last.focus(); } else if (!e.shiftKey && document.activeElement === last){ e.preventDefault(); first.focus(); } }
});
/* 시장 · 바텐더 연결 */
TAVERN_SPOTS.bar.use = () => openShop('tavern');
