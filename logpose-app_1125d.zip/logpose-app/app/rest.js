/* ---------- 쉬는 자리: 갑판 · 다모였섬 해적 마을 ----------
   앉기는 tavern.js 의 sitDown(높이, 자리) 를 같이 써요. 자리마다 { x, z, face(바라볼 방향) } */
const REST = { fires:[] };
const faceTo = (x, z, tx, tz) => Math.atan2(tx - x, tz - z);   /* (x,z)에서 (tx,tz)를 바라보는 방향 */
const cush = c => new THREE.MeshStandardMaterial({ color:c, roughness:.95 });

/* 갑판 의자 (비치 체어): 나무 틀 + 천을 씌운 앉는 판 + 뒤로 젖혀진 등받이 + 팔걸이 — 앞쪽 = +z (그룹을 돌려서 써요) */
function loungeChair(parent, x, y, z, ry, cloth){
  const g = new THREE.Group(); g.position.set(x, y, z); g.rotation.y = ry; parent.add(g);
  const wood = new THREE.MeshStandardMaterial({ color:'#a07a52', roughness:.85 }), dark = new THREE.MeshStandardMaterial({ color:'#6a4628', roughness:.85 });
  const fab = new THREE.MeshStandardMaterial({ map:canvasTex(64, 128, (cg, w, h) => { cg.fillStyle = cloth; cg.fillRect(0, 0, w, h); cg.fillStyle = 'rgba(255,255,255,.85)'; for (let i = 0; i < 4; i++) cg.fillRect(i * 16 + 2, 0, 6, h); }), roughness:.95 });
  const box = (w, h, d, m, px, py, pz, rx = 0) => { const o = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), m); o.position.set(px, py, pz); o.rotation.x = rx; g.add(o); return o; };
  /* 다리 넷 · 옆 틀 */
  [-0.3, 0.3].forEach(sx => { [-0.12, 0.46].forEach(sz => box(0.05, 0.3, 0.05, dark, sx, 0.15, sz)); box(0.05, 0.05, 0.66, wood, sx, 0.3, 0.17); });
  /* 앉는 판: 천 (앞으로 살짝 높게) */
  box(0.56, 0.035, 0.6, fab, 0, 0.33, 0.17, 0.06);
  /* 등받이: 앉는 판 뒤끝에서 뒤로 젖혀져 올라가요 (아래 끝 z -0.12, y 0.33 → 위 끝 z -0.55, y 0.85) */
  const L = 0.68, A = 0.7, mz = -0.12 - Math.sin(A) * L / 2, my = 0.33 + Math.cos(A) * L / 2;
  box(0.56, L, 0.035, fab, 0, my, mz, -A);
  [-0.3, 0.3].forEach(sx => box(0.05, L + 0.04, 0.05, wood, sx, my, mz - 0.02, -A));
  box(0.62, 0.05, 0.05, wood, 0, 0.33 + Math.cos(A) * L, -0.12 - Math.sin(A) * L - 0.02);   /* 등받이 윗막대 */
  /* 팔걸이 */
  [-0.33, 0.33].forEach(sx => { box(0.07, 0.03, 0.46, wood, sx, 0.5, 0.12); box(0.04, 0.2, 0.04, dark, sx, 0.4, 0.32); });
  return g;
}

/* ===== 갑판 ===== */
function buildDeckRest(){
  /* ① 주갑판 왼쪽 난간 아래 긴 의자 + 술통 탁자 · 등불 */
  const bx = -(deckHalf(2.4) - 0.55), G = new THREE.Group(); deckScene.add(G);
  bench(G, bx, 2.4, 1.8, Math.PI / 2);
  dBox(bx, 2.4, 0.24, 0.92);
  const bar = new THREE.MeshStandardMaterial({ color:'#7a5230', roughness:.7 });
  dMesh(new THREE.CylinderGeometry(0.28, 0.28, 0.7, 12), bar, bx, 0.35, 1.0, G); dBox(bx, 1.0, 0.3, 0.3);
  dMesh(new THREE.CylinderGeometry(0.3, 0.3, 0.04, 12), M.iron, bx, 0.7, 1.0, G);
  const mug = dMesh(new THREE.CylinderGeometry(0.06, 0.05, 0.13, 8), new THREE.MeshStandardMaterial({ color:'#e8b84a', roughness:.4 }), bx + 0.1, 0.78, 0.95, G); void mug;
  const lamp = dMesh(new THREE.CylinderGeometry(0.08, 0.08, 0.2, 6), new THREE.MeshStandardMaterial({ color:'#ffe0a8', emissive:'#ffb050', emissiveIntensity:.8 }), bx - 0.08, 0.82, 1.08, G); void lamp;
  dMesh(new THREE.TorusGeometry(0.3, 0.07, 6, 16), new THREE.MeshStandardMaterial({ color:'#c9b08a', roughness:.9 }), bx + 0.1, 0.07, 3.6, G).rotation.x = Math.PI / 2;   // 감아 둔 밧줄
  G.userData.kind = 'restBench0'; DK3.clickables.push(G);
  [2.0, 2.8].forEach((z, i) => { DECK_SPOTS['restBench' + i] = { x:bx + 0.05, z, face:Math.PI / 2, label:'긴 의자에 앉아 쉬기', near:0.9, use:() => sitDown(0.5, { x:bx + 0.05, z, face:Math.PI / 2 }) }; });
  /* ② 선미루(뒷갑판) 갑판 의자 두 개 + 작은 탁자: 난간 너머 바다를 봐요 */
  const Q = new THREE.Group(); deckScene.add(Q);
  [[-7.3, '#2f6f9f'], [-8.6, '#c0392b']].forEach(([z, c], i) => {
    loungeChair(Q, -2.7, DECK.qH, z, -Math.PI / 2, c);
    dBox(-2.85, z, 0.42, 0.34);
    DECK_SPOTS['restLounge' + i] = { x:-2.82, z, face:-Math.PI / 2, label:'갑판 의자에 기대 쉬기', near:1.1, use:() => sitDown(0.37, { x:-2.82, z, face:-Math.PI / 2 }) };
  });
  dMesh(new THREE.CylinderGeometry(0.22, 0.22, 0.05, 12), new THREE.MeshStandardMaterial({ color:'#8a6440' }), -2.75, DECK.qH + 0.42, -7.95, Q);
  dMesh(new THREE.CylinderGeometry(0.04, 0.06, 0.4, 6), M.woodDark, -2.75, DECK.qH + 0.2, -7.95, Q); dBox(-2.75, -7.95, 0.22, 0.22);
  Q.userData.kind = 'restLounge0'; DK3.clickables.push(Q);
}

/* ===== 다모였섬: 해적 마을 쉼터 ===== */
const IGY = (x, z) => (typeof ISLE_AREA !== 'undefined' ? ISLE_AREA.heightAt(x, z) : 0) || 0;
function buildIsleRest(){
  const wood = flat('#8a6440'), woodD = flat('#5a3e26'), stone = flat('#9a8e78');
  /* ① 모닥불 쉼터: 돌 화덕 + 통나무 의자 셋 + 우물 */
  const C = { x:-9, z:-13 }, F = new THREE.Group(); F.position.set(C.x, IGY(C.x, C.z), C.z); isleScene.add(F);
  for (let k = 0; k < 10; k++){ const a = k / 10 * Math.PI * 2; const s = new THREE.Mesh(rough(new THREE.IcosahedronGeometry(0.17, 0), 0.25), stone); s.position.set(Math.cos(a) * 0.55, 0.1, Math.sin(a) * 0.55); F.add(s); }
  [0, 1.1, 2.2].forEach(a => { const l = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.07, 0.7, 6), woodD); l.position.set(0, 0.12, 0); l.rotation.set(Math.PI / 2 - 0.25, a, 0); F.add(l); });
  const fire = new THREE.Sprite(new THREE.SpriteMaterial({ map:glowTex, color:'#ff8a30', transparent:true, opacity:.95, blending:THREE.AdditiveBlending, depthWrite:false })); fire.scale.set(1.1, 1.4, 1); fire.position.y = 0.45; F.add(fire);
  const fl = new THREE.PointLight('#ff8a40', 0.9, 7, 2); fl.position.y = 0.8; F.add(fl); REST.fires.push({ fire, fl });
  iBox(C.x, C.z, 0.75, 0.75);
  F.userData.kind = 'restFire0'; IS.clickables.push(F);
  let n = 0;
  [-0.4, 1.7, 3.8].forEach((a, li) => {
    const lx = C.x + Math.cos(a) * 1.95, lz = C.z + Math.sin(a) * 1.95, gy = IGY(lx, lz);
    const log = iMesh(new THREE.CylinderGeometry(0.22, 0.24, 1.5, 10), flat('#7a5634'), lx, gy + 0.22, lz); log.rotation.set(0, -a - Math.PI / 2, Math.PI / 2);   /* 화덕 둘레를 따라 누워요 */
    [-1, 1].forEach(s => iMesh(new THREE.CircleGeometry(0.2, 10), flat('#c9a46a'), lx + Math.sin(a) * 0.76 * s * -1, gy + 0.22, lz + Math.cos(a) * 0.76 * s).lookAt(lx + Math.sin(a) * 2 * s * -1, gy + 0.22, lz + Math.cos(a) * 2 * s));
    iBox(lx, lz, 0.45, 0.45);
    [-0.38, 0.38].forEach(t => { const sx = lx - Math.sin(a) * t, sz = lz + Math.cos(a) * t, key = 'restFire' + n++;
      ISLE_SPOTS[key] = { x:sx, z:sz, face:faceTo(sx, sz, C.x, C.z), label:'모닥불 곁에 앉기', near:0.95, use:() => sitDown(0.44, { x:sx, z:sz, face:faceTo(sx, sz, C.x, C.z) }) }; });
    void li;
  });
  /* 우물 (마을 느낌) */
  const W = { x:-12.8, z:-15.6 }, wy = IGY(W.x, W.z);
  iMesh(new THREE.CylinderGeometry(0.62, 0.66, 0.7, 14), stone, W.x, wy + 0.35, W.z);
  iMesh(new THREE.CylinderGeometry(0.5, 0.5, 0.05, 14), new THREE.MeshStandardMaterial({ color:'#2a4a5a', roughness:.2 }), W.x, wy + 0.62, W.z);
  [-1, 1].forEach(s => iMesh(new THREE.BoxGeometry(0.08, 1.3, 0.08), woodD, W.x + s * 0.55, wy + 1.0, W.z));
  const wr = iMesh(new THREE.ConeGeometry(0.85, 0.5, 4), flat('#7a3a24'), W.x, wy + 1.85, W.z); wr.rotation.y = Math.PI / 4;
  iMesh(new THREE.CylinderGeometry(0.05, 0.05, 1.1, 6), woodD, W.x, wy + 1.4, W.z).rotation.z = Math.PI / 2;
  iMesh(new THREE.CylinderGeometry(0.12, 0.1, 0.18, 8), flat('#8a6440'), W.x, wy + 1.05, W.z);   // 두레박
  iBox(W.x, W.z, 0.7, 0.7);

  /* ② 그늘 평상: 천막 지붕 아래 방석 두 개 · 옆에 술통 더미 */
  const P = { x:8.6, z:-10.4 }, py = IGY(P.x, P.z), PG = new THREE.Group(); PG.position.set(P.x, py, P.z); isleScene.add(PG);
  const plat = new THREE.Mesh(new THREE.BoxGeometry(3.0, 0.3, 1.6), wood); plat.position.y = 0.15; PG.add(plat);
  for (let k = -5; k <= 5; k++){ const b = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.02, 1.6), woodD); b.position.set(k * 0.27, 0.31, 0); PG.add(b); }
  [[-1.4, -0.7], [1.4, -0.7], [-1.4, 0.7], [1.4, 0.7]].forEach(([x, z]) => { const p = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.07, 2.3, 6), woodD); p.position.set(x, 1.15, z); PG.add(p); });
  const awn = new THREE.Mesh(new THREE.PlaneGeometry(3.3, 1.9), new THREE.MeshStandardMaterial({ map:canvasTex(256, 128, (g, w, h) => { for (let i = 0; i < 8; i++){ g.fillStyle = i % 2 ? '#f2e8d2' : '#2f6f9f'; g.fillRect(i * w / 8, 0, w / 8, h); } g.fillStyle = 'rgba(0,0,0,.12)'; for (let i = 0; i < 300; i++) g.fillRect(Math.random() * w, Math.random() * h, 2, 2); }), side:THREE.DoubleSide, roughness:.95 }));
  awn.position.set(0, 2.3, 0); awn.rotation.x = -Math.PI / 2 + 0.12; PG.add(awn);
  [['#c0392b', -0.6], ['#e0b85a', 0.6]].forEach(([c, x]) => { const cu = new THREE.Mesh(new THREE.BoxGeometry(0.62, 0.1, 0.55), cush(c)); cu.position.set(x, 0.36, 0.42); PG.add(cu);
    const bk = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.4, 0.14), cush(c)); bk.position.set(x, 0.55, 0.05); bk.rotation.x = -0.2; PG.add(bk); });
  const tea = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.12, 0.4), woodD); tea.position.set(0, 0.36, 0.3); PG.add(tea);
  iBox(P.x, P.z, 1.5, 0.8);
  PG.userData.kind = 'restDeck0'; IS.clickables.push(PG);
  [-0.6, 0.6].forEach((dx, i) => { const sx = P.x + dx, sz = P.z + 0.45;
    ISLE_SPOTS['restDeck' + i] = { x:sx, z:sz, face:0, label:'평상에 앉아 쉬기', near:0.95, use:() => sitDown(0.42, { x:sx, z:sz, face:0 }) }; });
  [[6.6, -12.0, 0.34], [6.0, -11.5, 0.3], [11.2, -11.9, 0.34]].forEach(([x, z, r]) => { const gy = IGY(x, z);
    iMesh(new THREE.CylinderGeometry(r, r, r * 2.4, 12), flat('#7a5230'), x, gy + r * 1.2, z); [0.2, 0.8].forEach(t => iMesh(new THREE.CylinderGeometry(r + 0.015, r + 0.015, 0.05, 12, 1, true), M.iron, x, gy + r * 2.4 * t, z)); iBox(x, z, r + 0.02, r + 0.02); });
  [[11.4, -9.4, 0.7, 0.2], [11.3, -9.3, 0.5, 0.75]].forEach(([x, z, s, y]) => { const c = iMesh(new THREE.BoxGeometry(s, s, s), flat('#9a7448'), x, IGY(x, z) + y + s / 2 - (y ? 0.05 : 0), z); c.rotation.y = 0.4; }); iBox(11.4, -9.4, 0.42, 0.42);

  /* ③ 해변 파라솔 · 갑판 의자 두 개: 선착장 옆 모래밭에서 바다를 봐요 */
  const B = new THREE.Group(); isleScene.add(B);
  [[5.0, 24.0, '#2f6f9f'], [7.0, 23.8, '#e0b85a']].forEach(([x, z, c], i) => {
    const gy = IGY(x, z); loungeChair(B, x, gy, z, 0, c);   /* 모래밭 의자는 막지 않아요 (뒤에서 와도 앞으로 돌아갈 수 있게) */
    ISLE_SPOTS['restBeach' + i] = { x, z:z + 0.12, face:0, label:'파라솔 아래 누워 쉬기', near:0.95, use:() => sitDown(0.37, { x, z:z + 0.05, face:0, lie:true }) };
  });
  const ux = 6.0, uz = 23.1, uy = IGY(ux, uz);
  iMesh(new THREE.CylinderGeometry(0.035, 0.035, 2.4, 6), flat('#f2e8d2'), ux, uy + 1.2, uz);
  const um = iMesh(new THREE.ConeGeometry(1.5, 0.55, 12, 1, true), new THREE.MeshStandardMaterial({ map:canvasTex(256, 64, (g, w, h) => { for (let i = 0; i < 12; i++){ g.fillStyle = i % 2 ? '#f2e8d2' : '#c0392b'; g.fillRect(i * w / 12, 0, w / 12, h); } }), side:THREE.DoubleSide, roughness:.9 }), ux, uy + 2.35, uz); void um;
  iBox(ux, uz, 0.12, 0.12);
  const tb = iMesh(new THREE.CylinderGeometry(0.24, 0.24, 0.04, 10), flat('#8a6440'), 6.0, IGY(6, 24.1) + 0.42, 24.1); void tb;
  iMesh(new THREE.CylinderGeometry(0.04, 0.05, 0.42, 6), woodD, 6.0, IGY(6, 24.1) + 0.21, 24.1);
  iMesh(new THREE.SphereGeometry(0.09, 8, 6), flat('#6a8a3a'), 6.05, IGY(6, 24.1) + 0.52, 24.1);   // 코코넛 음료
  B.userData.kind = 'restBeach0'; IS.clickables.push(B);
}
/* 모닥불 일렁임 (섬 ambient 에서 불러요) */
function restStep(t){ REST.fires.forEach(F => { const k = 1 + Math.sin(t * 9) * 0.1 + Math.sin(t * 13.3) * 0.07; F.fire.scale.set(1.1 * k, 1.4 * k, 1); F.fl.intensity = 0.85 + Math.sin(t * 11) * 0.12; }); }
