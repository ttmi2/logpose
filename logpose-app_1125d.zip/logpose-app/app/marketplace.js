/* ============================================================
   LOG POSE · 다모였섬 시장 거리 (허름한 해적 장터)
   광장 동쪽, 옆으로 길게 늘어선 나무 판자 장터 (약 21m)
   ① 생선 매입 가게: 얼음 상자 · 매달린 생선 · 놋쇠 저울 · '생선 삽니다' 칠판 · 생선 장수 → 물고기 팔기
   ② 모자·옷 가게: 마네킹 머리 진열대 · 가게 앞 옷 마네킹 둘 · 주인 → 모자 / 옷
   ③ 깃발 가게: 줄에 건 해적기 · 깃발 통 · 주인 → 해적기
   + 잡화 좌판(바구니 · 자루 · 항아리) · 기운 천막 · 비뚤어진 기둥 · 빠진 판자 · 삼각 깃발줄 · 등불
   좌표: 장터 기준 x = 옆(섬의 z 방향), +z = 광장 쪽(앞)
   ============================================================ */
const MK = { r:-Math.PI / 2, lamps:[], hanging:[], flags:[] };
/* 옷 마네킹: 나무 삼발이 받침 + 기둥 + 캐릭터와 같은 몸통(옷을 그려 입힘) + 짧은 팔 + 둥근 나무 머리 */
function mannequin(parent, x, z, outfitId, hatId){
  const g = new THREE.Group(); g.position.set(x, 0, z); parent.add(g);
  const woodM = new THREE.MeshStandardMaterial({ color:'#b08a5a', roughness:.8 }), darkM = new THREE.MeshStandardMaterial({ color:'#5a3e26', roughness:.8 });
  const add = (geo, mat, px, py, pz, p = g) => { const o = new THREE.Mesh(geo, mat); o.position.set(px, py, pz); p.add(o); return o; };
  for (let k = 0; k < 3; k++){ const a = k / 3 * Math.PI * 2, leg = add(new THREE.BoxGeometry(0.05, 0.04, 0.42), darkM, Math.sin(a) * 0.17, 0.03, Math.cos(a) * 0.17); leg.rotation.y = a; }
  add(new THREE.CylinderGeometry(0.03, 0.035, 0.5, 8), darkM, 0, 0.27, 0);
  const o = outfitOf(outfitId), body = new THREE.Group(); body.position.y = 0.3; body.scale.setScalar(0.92); g.add(body);
  add(new THREE.LatheGeometry(BODY_PROFILE.map(([r, y]) => new THREE.Vector2(r, y)), 32, Math.PI), new THREE.MeshStandardMaterial({ map:bodyClothTex(o, '#2f5f8a', 3), roughness:.9 }), 0, -0.2, 0, body);
  const armM = new THREE.MeshStandardMaterial({ map:armClothTex(o, '#2f5f8a', 3), roughness:.9 });
  [-1, 1].forEach(s => { const a = new THREE.Group(); a.position.set(s * 0.1, 0.55, 0); a.rotation.z = s * 1.0; body.add(a);
    const arm = add(new THREE.CapsuleGeometry(0.07, 0.14, 4, 10), armM, 0, -0.15, 0, a); void arm; });
  const head = add(new THREE.SphereGeometry(0.17, 16, 12), woodM, 0, 1.05, 0);
  if (hatId && typeof hatMesh === 'function'){ const h = hatMesh(hatId); h.scale.setScalar(0.85); head.add(h); }
  add(new THREE.CylinderGeometry(0.03, 0.03, 0.12, 6), darkM, 0, 0.9, 0);
  return g;
}
function mkW(lx, lz){ const c = Math.cos(MK.r), s = Math.sin(MK.r); return { x:PL.market.x + lx * c + lz * s, z:PL.market.z - lx * s + lz * c }; }
const mkFace = a => MK.r + a;
function mkBox(lx, lz, hx, hz){ const w = mkW(lx, lz); iBox(w.x, w.z, hz, hx); }   /* 90도 돌아 있어서 가로 · 세로가 바뀌어요 */
const mrand = (i, k = 0) => { const s = Math.sin(i * 12.9898 + k * 78.233) * 43758.5453; return s - Math.floor(s); };

/* 기운 천막 천: 줄무늬 + 덧댄 조각 + 얼룩 + 해진 가장자리 */
function awningTex(c1, c2, seed){ return canvasTex(512, 256, (g, w, h) => {
  const n = 6; for (let k = 0; k < n; k++){ g.fillStyle = k % 2 ? c2 : c1; g.fillRect(k * w / n, 0, w / n + 1, h); }
  for (let k = 0; k < 3; k++){ const x = 40 + mrand(seed, k) * (w - 140), y = 20 + mrand(seed, k + 9) * (h - 120), pw = 60 + mrand(seed, k + 3) * 50, ph = 40 + mrand(seed, k + 5) * 40;
    g.fillStyle = ['#a8925e', '#6b7a5a', '#8a6a5a'][k % 3]; g.fillRect(x, y, pw, ph); g.strokeStyle = 'rgba(30,20,10,.6)'; g.setLineDash([6, 5]); g.lineWidth = 2; g.strokeRect(x + 3, y + 3, pw - 6, ph - 6); g.setLineDash([]); }
  for (let k = 0; k < 7; k++){ const x = mrand(seed, k + 20) * w, y = mrand(seed, k + 30) * h, r = 14 + mrand(seed, k + 40) * 30; const gr = g.createRadialGradient(x, y, 0, x, y, r); gr.addColorStop(0, 'rgba(40,28,14,.35)'); gr.addColorStop(1, 'rgba(40,28,14,0)'); g.fillStyle = gr; g.fillRect(x - r, y - r, r * 2, r * 2); }
  speckle(g, w, h, 1500, '#2a1a0e', .15);
  /* 아래쪽 해진 가장자리 (투명하게 오려요) */
  g.globalCompositeOperation = 'destination-out'; g.beginPath(); g.moveTo(0, h);
  for (let x = 0; x <= w; x += 16){ const d = 10 + mrand(seed, x) * 22; g.lineTo(x, h - d); g.lineTo(x + 8, h); }
  g.lineTo(w, h); g.closePath(); g.fill(); g.globalCompositeOperation = 'source-over';
}); }
function chalkTex(){ return canvasTex(384, 288, (g, w, h) => {
  g.fillStyle = '#2a2e28'; g.fillRect(0, 0, w, h); speckle(g, w, h, 900, '#f6f4ee', .05);
  g.strokeStyle = '#7a5230'; g.lineWidth = 18; g.strokeRect(9, 9, w - 18, h - 18);
  g.fillStyle = '#f2efe6'; g.textAlign = 'center'; g.font = `700 54px ${FD}`; g.fillText('생선 삽니다', w / 2, 76);
  g.font = `600 26px ${FB}`; g.fillStyle = '#e8e0c8';
  ['고등어 · 전갱이 ~3', '참돔 ~8 · 문어 ~7', '황금 참치 40+ !!'].forEach((t, i) => g.fillText(t, w / 2, 132 + i * 38));
  g.fillStyle = '#f0c070'; g.font = `700 28px ${FB}`; g.fillText('은화로 바로 드려요', w / 2, 256);
}); }
function vendor(parent, color, hat, x, z, ry){
  const v = makeAvatar(color); v.position.set(x, 0, z); v.rotation.y = ry; parent.add(v);
  const head = v.userData.head; (head.userData.hatParts || []).forEach(m => m.visible = !hat); if (hat) head.add(hatMesh(hat));
  const apron = new THREE.Mesh(new THREE.CylinderGeometry(0.255, 0.27, 0.5, 14, 1, true, -1.2, 2.4), flat('#d8ccb0')); apron.position.y = 0.55; v.add(apron);
  return v;
}
function crate(parent, x, y, z, w = 1, d = 0.7, h = 0.45, tilt = 0){
  const g = new THREE.Group(); g.position.set(x, y, z); g.rotation.y = tilt; parent.add(g);
  const b = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), flat(['#8a6440', '#7a5636', '#9a7048'][Math.floor(mrand(x, z) * 3)])); b.position.y = h / 2; g.add(b);
  [-1, 1].forEach(s => { const sl = new THREE.Mesh(new THREE.BoxGeometry(w + 0.02, 0.06, 0.04), flat('#5a3e26')); sl.position.set(0, h * (s > 0 ? 0.8 : 0.25), d / 2 + 0.01); g.add(sl); });
  return g;
}
function basket(parent, x, z, r = 0.35, h = 0.4, fill){
  const b = new THREE.Mesh(new THREE.CylinderGeometry(r, r * 0.8, h, 12, 1, true), new THREE.MeshStandardMaterial({ color:'#b08850', roughness:.95, side:THREE.DoubleSide, flatShading:true })); b.position.set(x, h / 2, z); parent.add(b);
  const rim = new THREE.Mesh(new THREE.TorusGeometry(r, 0.03, 4, 14), flat('#8a6440')); rim.rotation.x = Math.PI / 2; rim.position.set(x, h, z); parent.add(rim);
  if (fill){ const f = new THREE.Mesh(new THREE.SphereGeometry(r * 0.92, 10, 6, 0, Math.PI * 2, 0, Math.PI / 2), flat(fill)); f.position.set(x, h - 0.08, z); f.scale.y = 0.4; parent.add(f); }
}
function fishProp(parent, x, y, z, color, ry = 0, s = 1){
  const f = new THREE.Group(); f.position.set(x, y, z); f.rotation.y = ry; f.scale.setScalar(s); parent.add(f);
  const body = new THREE.Mesh(new THREE.SphereGeometry(0.12, 10, 6), flat(color)); body.scale.set(2.2, 0.75, 0.55); f.add(body);
  const tail = new THREE.Mesh(new THREE.ConeGeometry(0.09, 0.16, 4), flat(color)); tail.rotation.z = Math.PI / 2; tail.position.x = 0.32; f.add(tail);
  const eye = new THREE.Mesh(new THREE.SphereGeometry(0.018, 6, 4), flat('#1a100a')); eye.position.set(-0.19, 0.03, 0.06); f.add(eye);
  return f;
}
/* 비뚤어진 기둥 두 개 + 기운 천막 + 해진 가장자리 */
function stallFrame(G, x0, x1, depth, c1, c2, seed){
  const W = x1 - x0, cx = (x0 + x1) / 2, poleM = flat('#5a3e26');
  [[x0, 1.4], [x1, 1.4], [x0, -0.9], [x1, -0.9]].forEach(([x, z], i) => { const p = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.09, i < 2 ? 2.7 : 3.2, 6), poleM); p.position.set(x, (i < 2 ? 2.7 : 3.2) / 2, z); p.rotation.set((mrand(seed, i) - .5) * 0.12, 0, (mrand(seed, i + 4) - .5) * 0.14); G.add(p); });
  const aw = new THREE.Mesh(new THREE.PlaneGeometry(W + 0.5, depth + 0.6, 8, 1), new THREE.MeshStandardMaterial({ map:awningTex(c1, c2, seed), roughness:.95, side:THREE.DoubleSide, transparent:true, alphaTest:.4 }));
  const p = aw.geometry.attributes.position; for (let i = 0; i < p.count; i++){ const xx = p.getX(i); p.setZ(i, Math.sin((xx / (W + 0.5) + .5) * Math.PI * 3) * 0.06); }   /* 처진 천 */
  aw.geometry.computeVertexNormals();
  aw.rotation.x = -Math.PI / 2 + 0.214; aw.position.set(cx, 2.95, 0.25);   /* 앞기둥(2.7m) · 뒷기둥(3.2m) 꼭대기에 딱 얹히는 기울기 (예전 0.3은 앞기둥이 천막을 뚫고 뒤는 떠 있었어요) */ aw.rotation.z = (mrand(seed, 9) - .5) * 0.05; G.add(aw);
  const flap = new THREE.Mesh(new THREE.PlaneGeometry(W + 0.5, 0.45), new THREE.MeshStandardMaterial({ map:awningTex(c1, c2, seed + 3), roughness:.95, side:THREE.DoubleSide, transparent:true, alphaTest:.4 })); flap.position.set(cx, 2.4, 1.62);   /* 천막 앞 가장자리 아래로 늘어지게 (위로 삐져나오지 않게) */ G.add(flap);
  const back = new THREE.Mesh(new THREE.PlaneGeometry(W, 2.6), new THREE.MeshStandardMaterial({ map:awningTex('#6b5a44', '#5a4a38', seed + 7), roughness:.95, side:THREE.DoubleSide })); back.position.set(cx, 1.6, -0.92); G.add(back);
}

function buildMarketStreet(){
  const G = new THREE.Group(); G.position.set(PL.market.x, 0, PL.market.z); G.rotation.y = MK.r; isleScene.add(G); MK.g = G;
  const m = (geo, mat, x, y, z, parent = G) => { const o = new THREE.Mesh(geo, mat); o.position.set(x, y, z); parent.add(o); return o; };
  /* 바닥: 색이 제각각인 낡은 판자 (군데군데 빠져 있어요) */
  for (let x = -10.6, i = 0; x < 10.6; x += 0.62, i++){ if (mrand(i, 7) < 0.07) continue;
    const pl = m(new THREE.BoxGeometry(0.58, 0.06, 4.6 - mrand(i) * 0.5), flat(['#8a6a48', '#7a5c3e', '#9a7a56', '#6b5236'][i % 4]), x, 0.03, 0.75 + (mrand(i, 2) - .5) * 0.3); pl.rotation.y = (mrand(i, 3) - .5) * 0.03; }

  /* ① 생선 매입 가게 (x -9 ~ -2) */
  stallFrame(G, -9, -2, 2.4, '#3f8a8a', '#e8dcc2', 11);
  const ctr = m(new THREE.BoxGeometry(6.6, 0.85, 1.0), flat('#6b4a2e'), -5.5, 0.43, 0.75); void ctr;
  for (let k = 0; k < 4; k++){ const cx = -8.1 + k * 1.75;
    const box = m(new THREE.BoxGeometry(1.6, 0.18, 0.9), flat('#9a7048'), cx, 0.95, 0.75); void box;
    m(new THREE.BoxGeometry(1.48, 0.06, 0.78), new THREE.MeshStandardMaterial({ color:'#e6f2f6', roughness:.3 }), cx, 1.05, 0.75);
    const sp = FISH[[0, 1, 5, 2][k]];
    for (let j = 0; j < 5; j++){ if (k === 3 && j % 3) continue;   /* 마지막 상자: 놋쇠 저울 자리는 비워요 (생선을 뚫지 않게) */
      fishProp(G, cx - 0.5 + (j % 3) * 0.45, 1.12, 0.55 + Math.floor(j / 3) * 0.35, sp.color, (mrand(k, j) - .5) * 0.6, 0.9); }
  }
  /* 매달린 생선 (처마 아래 막대) */
  m(new THREE.CylinderGeometry(0.03, 0.03, 5.6, 5), flat('#5a3e26'), -5.5, 2.35, 1.35).rotation.z = Math.PI / 2;
  ['#cf5f58', '#3f7896', '#a8935e', '#3f7896', '#cf5f58', '#8fa3ad'].forEach((c, k) => { const x = -7.8 + k * 0.9; m(new THREE.CylinderGeometry(0.006, 0.006, 0.25, 3), flat('#c9b08a'), x, 2.22, 1.35); const f = fishProp(G, x, 1.92, 1.35, c, 0, 1.1); f.rotation.z = Math.PI / 2; MK.hanging.push({ f, ph:k }); });
  /* 놋쇠 저울 */
  { const sc = new THREE.Group(); sc.position.set(-2.7, 0.88, 0.55); G.add(sc);
    m(new THREE.CylinderGeometry(0.03, 0.04, 0.7, 6), M.brass, 0, 0.35, 0, sc); m(new THREE.BoxGeometry(0.7, 0.03, 0.03), M.brass, 0, 0.7, 0, sc);
    [-0.33, 0.33].forEach(x => { m(new THREE.CylinderGeometry(0.004, 0.004, 0.3, 3), M.iron, x, 0.55, 0, sc); m(new THREE.CylinderGeometry(0.14, 0.1, 0.04, 10), M.brass, x, 0.4, 0, sc); }); }
  /* '생선 삽니다' 칠판 (이젤) */
  { /* 이젤 한 덩어리로 묶어서: 앞다리 둘은 칠판 '뒤'에 붙고, 뒷다리 하나가 받쳐요 (예전엔 다리가 칠판 앞으로 튀어나왔어요) */
    const E = new THREE.Group(); E.position.set(-8.6, 0, 2.25); E.rotation.y = 0.35; G.add(E);
    const wood = flat('#5a3e26');
    const frame = m(new THREE.BoxGeometry(1.42, 1.1, 0.05), wood, 0, 1.15, -0.035, E); frame.rotation.x = -0.15;
    const cb = m(new THREE.PlaneGeometry(1.3, 0.98), new THREE.MeshStandardMaterial({ map:chalkTex(), roughness:.9 }), 0, 1.15, 0.0, E); cb.rotation.x = -0.15;
    [-0.5, 0.5].forEach(x => { const l = m(new THREE.CylinderGeometry(0.03, 0.035, 1.75, 5), wood, x, 0.86, -0.12, E); l.rotation.x = -0.15; });
    const back = m(new THREE.CylinderGeometry(0.028, 0.032, 1.7, 5), wood, 0, 0.8, -0.42, E); back.rotation.x = 0.4;
    m(new THREE.BoxGeometry(1.2, 0.05, 0.08), wood, 0, 0.6, -0.1, E);   /* 분필 받침 */ }
  barrel(G, -9.6, 0, 0.0, 0.8); barrel(G, -9.4, 0, 1.0, 0.7); basket(G, -1.6, 2.0, 0.32, 0.38, '#cfd8dc');
  crate(G, -7.0, 0, -0.45, 1.1, 0.6, 0.5, 0.1); crate(G, -6.9, 0.5, -0.45, 0.9, 0.55, 0.4, -0.15);
  MK.fishVendor = vendor(G, '#3f5a6a', 'bandana', -5.0, -0.1, 0);
  mkBox(-5.5, 0.75, 3.4, 0.55); mkBox(-9.5, 0.5, 0.5, 0.9);

  /* ② 모자 가게 (x -1 ~ 3.6) */
  stallFrame(G, -1, 3.6, 2.4, '#8a2a1c', '#d9c49a', 23);
  m(new THREE.BoxGeometry(4.2, 0.8, 0.9), flat('#7a5636'), 1.3, 0.4, 0.75);
  m(new THREE.BoxGeometry(4.3, 0.06, 1.0), flat('#a07a52'), 1.3, 0.83, 0.75);
  ['tricorn', 'feather', 'sailor', 'bandana'].forEach((h, k) => { const x = -0.2 + k * 1.0;
    m(new THREE.CylinderGeometry(0.03, 0.04, 0.4, 6), flat('#5a3e26'), x, 1.06, 0.75);
    const head = m(new THREE.SphereGeometry(0.2, 14, 10), flat('#e8d6b8'), x, 1.42, 0.75); head.add(hatMesh(h)); head.rotation.y = (k - 1.5) * 0.2; });
  /* 뒤 선반: 쌓아 둔 선장 모자 */
  m(new THREE.BoxGeometry(4.0, 0.06, 0.4), flat('#7a5636'), 1.3, 1.6, -0.7);
  [0, 1, 2].forEach(k => { m(new THREE.CylinderGeometry(0.28, 0.3, 0.06, 14), flat('#1d1612'), 0.2 + k * 1.1, 1.66, -0.7); m(new THREE.CylinderGeometry(0.17, 0.2, 0.14, 14), flat('#1d1612'), 0.2 + k * 1.1, 1.76, -0.7); });
  /* 가게 앞 양쪽 마네킹: 파는 옷을 입혀 세워 둬요 (오른쪽은 탐험가 챙모자까지) */
  [[-0.55, 'haori', null], [3.15, 'explorer', 'explorer']].forEach(([lx, id, hat]) => { mannequin(G, lx, 1.7, id, hat); mkBox(lx, 1.7, 0.34, 0.34); });
  MK.hatVendor = vendor(G, '#5a3a5a', 'tricorn', 1.9, -0.1, 0);
  mkBox(1.3, 0.75, 2.15, 0.5);

  /* ③ 깃발 가게 (x 4.4 ~ 8.8) */
  stallFrame(G, 4.4, 8.8, 2.4, '#2f4a6a', '#e8dcc2', 37);
  m(new THREE.BoxGeometry(4.0, 0.8, 0.9), flat('#6b4a2e'), 6.6, 0.4, 0.75);
  /* 줄에 건 해적기 4장 */
  m(new THREE.CylinderGeometry(0.015, 0.015, 4.3, 4), flat('#c9b08a'), 6.6, 2.3, 1.2).rotation.z = Math.PI / 2;
  FLAGS.slice(1).forEach((f, k) => { const fl = m(new THREE.PlaneGeometry(0.9, 0.56), new THREE.MeshStandardMaterial({ map:flagTex(f.id), side:THREE.DoubleSide, roughness:.85 }), 5.1 + k * 1.0, 1.98, 1.2); MK.flags.push({ fl, ph:k }); });
  /* 깃발 통 · 접어 둔 깃발 */
  barrel(G, 8.4, 0, 1.6, 0.7);
  ['#8a2a1c', '#1d1a14', '#2f6a4a', '#3a2a5a'].forEach((c, k) => { const r = m(new THREE.CylinderGeometry(0.06, 0.06, 0.9, 6), flat(c), 8.3 + (k % 2) * 0.2 - 0.1, 1.05, 1.5 + Math.floor(k / 2) * 0.2); r.rotation.set((k - 1.5) * 0.12, 0, (k % 2 - .5) * 0.25); });
  [[5.2, '#8a2a1c'], [6.0, '#1f3a56'], [6.8, '#1d1a14']].forEach(([x, c]) => { const fd = m(new THREE.BoxGeometry(0.6, 0.12, 0.45), flat(c), x, 0.87, 0.7); fd.rotation.y = (x - 6) * 0.1; });
  MK.flagVendor = vendor(G, '#6a4a2a', 'sailor', 7.2, -0.1, 0);
  mkBox(6.6, 0.75, 2.0, 0.5); mkBox(8.4, 1.6, 0.4, 0.4);

  /* 잡화 좌판 (양쪽 끝): 바구니 · 자루 · 항아리 · 밧줄 */
  [[-10.2, 2.2, '#c9a24e'], [9.6, 2.4, '#8fa3ad'], [10.1, 1.4, '#cf5f58']].forEach(([x, z, f]) => basket(G, x, z, 0.36, 0.42, f));
  [[9.4, 0.2], [10.0, 0.6], [-10.0, -0.5]].forEach(([x, z], k) => { const sack = m(new THREE.SphereGeometry(0.34, 10, 8), flat('#b8a07a'), x, 0.3, z); sack.scale.set(1, 0.95, 0.85); m(new THREE.CylinderGeometry(0.08, 0.12, 0.16, 8), flat('#a08860'), x, 0.64, z); void k; });
  [[-10.4, 1.2], [9.9, -0.6]].forEach(([x, z]) => { m(new THREE.SphereGeometry(0.28, 10, 8), flat('#a0603a'), x, 0.28, z); m(new THREE.CylinderGeometry(0.1, 0.14, 0.18, 8), flat('#a0603a'), x, 0.6, z); });
  { const r = m(new THREE.TorusGeometry(0.32, 0.09, 6, 16), flat('#c9b08a'), 3.9, 0.09, 2.2); r.rotation.x = Math.PI / 2; m(new THREE.TorusGeometry(0.2, 0.08, 6, 14), flat('#c9b08a'), 3.9, 0.2, 2.2).rotation.x = Math.PI / 2; }
  mkBox(9.8, 0.8, 0.6, 1.2); mkBox(-10.2, 1.0, 0.5, 1.2);

  /* 삼각 깃발줄 · 비뚤어진 등불 기둥 */
  const bunt = []; for (let k = 0; k <= 40; k++){ const x = -10 + k * 0.5; bunt.push(new THREE.Vector3(x, 3.55 - Math.abs(Math.sin(k / 40 * Math.PI * 3)) * 0.35, 1.7)); }
  G.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(bunt), new THREE.LineBasicMaterial({ color:'#5a3e26' })));
  bunt.forEach((p, k) => { if (k % 2) return; const tri = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(-0.18, 0, 0), new THREE.Vector3(0.18, 0, 0), new THREE.Vector3(0, -0.36, 0)]); tri.computeVertexNormals();
    const t = new THREE.Mesh(tri, new THREE.MeshBasicMaterial({ color:['#c0392b', '#e8dcc2', '#2f6f9f', '#c9a24e'][k / 2 % 4], side:THREE.DoubleSide })); t.position.copy(p); G.add(t); });
  [[-10.6, 1.7], [-1.5, 1.8], [4.0, 1.8], [10.6, 1.7]].forEach(([x, z], k) => { const p = m(new THREE.CylinderGeometry(0.07, 0.09, 3.7, 6), flat('#4a2e18'), x, 1.85, z); p.rotation.z = (mrand(k, 5) - .5) * 0.12;
    if (k % 3 === 0) hangLantern(G, x + (k ? -0.35 : 0.35), 2.9, z + 0.1, IS.lamps); });
  [[-10.6, 1.7], [-1.5, 1.8], [4.0, 1.8], [10.6, 1.7]].forEach(([x, z]) => mkBox(x, z, 0.12, 0.12));

  /* 가게 뒷천 · 주인: 뒤나 옆으로 파고들지 않게 */
  [[-5.5, 3.5], [1.3, 2.3], [6.6, 2.2]].forEach(([x, hx]) => mkBox(x, -0.92, hx, 0.14));
  [[-5.0], [1.9], [7.2]].forEach(([x]) => mkBox(x, -0.1, 0.3, 0.3));
  /* 가게마다 말 걸기 */
  const stall = (kind, lx, label, tab, who) => { const w = mkW(lx, 2.55); ISLE_SPOTS[kind] = { x:w.x, z:w.z, face:mkFace(Math.PI), label, use:() => openShop('market', tab, who) }; };
  stall('mkFish', -5.0, '생선 팔기', 'sell', 'fish'); stall('mkHat', 1.9, '모자·옷 가게', 'hat', 'hat'); stall('mkFlag', 7.2, '깃발 가게', 'flag', 'flag');
  ISLE_SPOTS.market = ISLE_SPOTS.mkFish;
  G.userData.kind = 'market'; IS.clickables.push(G);
}
function marketStep(dt, t){
  const sw = reduceMotion ? 0 : 1;
  MK.hanging.forEach(H => { H.f.rotation.x = Math.sin(t * 1.6 + H.ph) * 0.15 * sw; });
  MK.flags.forEach(F => { F.fl.rotation.y = Math.sin(t * 2 + F.ph) * 0.25 * sw; });
  [MK.fishVendor, MK.hatVendor, MK.flagVendor].forEach((v, k) => { if (v) v.rotation.y = Math.sin(t * 0.4 + k * 2) * 0.35 * sw; });
}
