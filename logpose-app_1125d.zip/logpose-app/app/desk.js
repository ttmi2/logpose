/* ============================================================
   LOG POSE · 선장 책상 정보창 (단계 5)
   작품을 고르면 → 책상 앞으로, 카메라는 어깨 너머로 책상을 내려다보고 → 양피지 정보창.
   기존 데이터에 있는 정보만 보여주고, 없는 항목은 칸 자체를 숨겨요.
   버튼: 라프텔 항해일지 펼치기(라프텔 회원만 · 라프텔 시청 화면의 AI 길잡이를 체험용으로 옮겨 둔 것) · 내 로그포스에 저장 · 로그포스 닫기
   ============================================================ */
const DK = { root:$('#desk'), body:$('#dkBody'), cover:$('#dkCover'), title:$('#dkTitle'), genre:$('#dkGenre'), meta:$('#dkMeta'),
  save:$('#dkSave'), guide:$('#dkGuide'), close:$('#dkClose'), note:$('#dkNote') };
let dkWork = null;

const savedList = () => { const p = LPProfile.get(); return (p && Array.isArray(p.saved)) ? p.saved : []; };
const isSaved = id => savedList().some(s => s.id === id);
function toggleSave(id){
  const list = savedList();
  const next = isSaved(id) ? list.filter(s => s.id !== id) : [{ id, at:new Date().toISOString() }, ...list];
  LPProfile.update({ saved:next });
  if (typeof menuSync === 'function') menuSync();
  return isSaved(id);
}

/* 추천 이유: 추천 카드에서 왔으면 그 이유, 아니면 저장된 취향과 맞는 점만 */
function reasonsFor(w, given){
  if (given && given.length) return given;
  const p = LPProfile.get();
  if (!p || !p.taste) return [];
  return LPRecommend.score(w, p.taste).why.filter(x => x.k !== 'rep' && x.k !== 'easy').slice(0, 2).map(x => x.t);
}

function section(title, inner, cls = ''){ return inner ? `<section class="dk-sec ${cls}"><h3>${title}</h3>${inner}</section>` : ''; }
function renderDesk(w, reasons){
  DK.cover.src = coverURL(w); DK.cover.alt = `${w.title} 표지`;
  DK.title.textContent = w.title;
  DK.genre.textContent = w.genre.name; DK.genre.style.setProperty('--gh', w.genre.hue);
  DK.meta.textContent = [w.season, w.isRep ? '장르 대표작' : ''].filter(Boolean).join(' · ');
  const cast = w.cast.slice(0, 4), terms = w.terms.slice(0, 3);
  const tips = [...w.tips, ...w.tags.filter(t => t.includes('주의'))];
  const easy = w.tags.filter(t => !t.includes('주의'));
  DK.body.innerHTML =
    section('간단한 줄거리', `<p>${escHTML(w.summary)}</p>`) +
    section('추천한 이유', reasons.length ? `<ul class="dk-why">${reasons.map(t => `<li>${escHTML(t)}</li>`).join('')}</ul>` : '', 'why') +
    section('주요 특징', w.features.length ? `<ul>${w.features.map(t => `<li>${escHTML(t)}</li>`).join('')}</ul>` : '') +
    section('세계관 · 등장인물 <small>1화 기준 · 스포일러 없음</small>',
      (cast.length ? `<dl class="dk-cast">${cast.map(c => `<div><dt>${escHTML(c.name)}</dt><dd>${escHTML(c.intro)}</dd></div>`).join('')}</dl>` : '') +
      (terms.length ? `<dl class="dk-terms">${terms.map(t => `<div><dt>${escHTML(t.name)}</dt><dd>${escHTML(t.text)}</dd></div>`).join('')}</dl>` : '')) +
    (w.ep1 ? `<details class="dk-sec dk-ep1"><summary>1화 미리보기 <small>1화 결말까지 담겨 있어요</small></summary><p><b>「${escHTML(w.ep1.title)}」</b> ${escHTML(w.ep1.summary)}</p></details>` : '') +
    section('볼 때 참고', (easy.length ? `<p class="dk-tags">${easy.map(t => `<span>${escHTML(t)}</span>`).join('')}</p>` : '') + (tips.length ? `<ul>${tips.map(t => `<li>${escHTML(t)}</li>`).join('')}</ul>` : ''));
  /* 버튼 */
  setSaveBtn(isSaved(w.id));
  /* 라프텔 항해일지: 라프텔 시청 화면 옆에서 함께하는 AI 길잡이 (여기선 체험용으로 대략 옮겨 뒀어요) · 라프텔 회원만 */
  const member = isLaftelCaptain(LPProfile.get());
  DK.guide.hidden = !w.hasGuide;
  DK.guide.setAttribute('aria-disabled', String(!member));
  DK.guide.classList.toggle('locked', !member);
  DK.guide.innerHTML = member ? `라프텔 항해일지 펼치기 <small>${w.eps > 2 ? `${escHTML(w.season)} ${w.eps}화` : '1~2화'}</small>` : '🔒 라프텔 항해일지 <small>라프텔 회원 전용</small>';
  DK.note.textContent = !w.hasGuide ? '이 작품의 라프텔 항해일지는 준비 중이에요.' : member ? '라프텔에서 볼 때 옆에서 함께하는 AI 길잡이예요.' : '라프텔 계정으로 로그인한 선장만 펼칠 수 있어요.';
}
function setSaveBtn(on){ DK.save.textContent = on ? '✓ 내 로그포스에 저장됨' : '내 로그포스에 저장하기'; DK.save.setAttribute('aria-pressed', String(on)); }

/* 열기: 책상 앞으로 옮기고, 카메라를 책상 위로 */
function openDeskInfo(id, opts = {}){
  const w = LPData.get(id); if (!w) return;
  dkWork = id;
  uiOpen = true; keys.clear(); auto = null; $('#toast').hidden = true;
  const show = () => {
    /* 어디서든 그 자리에서 열려요. 선장실에 있을 때만 책상 위로 카메라를 옮겨요 */
    if (AREA === CABIN_AREA){
      player.x = SPOTS.desk.x; player.z = SPOTS.desk.z + 0.15; player.r = Math.PI;
      cam.yaw = 0; deskView = { pos:new THREE.Vector3(0.9, 2.55, DESK.z + 2.35), look:new THREE.Vector3(-0.2, 0.9, DESK.z - 0.1) };
    } else deskView = null;
    renderDesk(w, reasonsFor(w, opts.reasons));
    DK.root.hidden = false; DK.root.scrollTop = 0; document.body.classList.add('desk-open');
    LPProfile.update({ lastDesk:id });
    setTimeout(() => { try { DK.close.focus({ preventScroll:true }); } catch(e){} }, 80);
  };
  if (opts.instant || reduceMotion || AREA !== CABIN_AREA){ show(); return; }
  $('#fade').classList.add('on');
  setTimeout(() => { show(); setTimeout(() => $('#fade').classList.remove('on'), 60); }, 380);
}
function closeDeskInfo(){
  DK.root.hidden = true; document.body.classList.remove('desk-open');
  deskView = null; uiOpen = false; dkWork = null;
}

/* 버튼 */
DK.close.addEventListener('click', () => closeDeskInfo());
DK.save.addEventListener('click', () => { if (!dkWork) return; const on = toggleSave(dkWork); setSaveBtn(on); pulseLogpose(); toast(on ? '<strong>내 로그포스</strong>에 저장했어요.' : '저장한 목록에서 뺐어요.', 2200); });
DK.guide.addEventListener('click', () => {
  if (!dkWork) return;
  if (!isLaftelCaptain(LPProfile.get())){ toast('<strong>라프텔 항해일지</strong>는 라프텔 회원 전용이에요.<br>라프텔 계정으로 로그인하면 시청 화면 옆 AI 길잡이를 써 볼 수 있어요.', 3600); return; }
  if (!Guide.open(dkWork)) { toast('이 작품의 라프텔 항해일지는 아직 준비 중이에요.'); return; }
  LPTrack.event('guide', AREA && AREA.id, dkWork);   /* 방문 기록 (track.js) */
  DK.root.hidden = true; document.body.classList.add('guide-open');
});
/* 항해일지의 '← 선장 책상으로' */
$('#gbBack').addEventListener('click', () => { Guide.close(); document.body.classList.remove('guide-open'); if (dkWork){ DK.root.hidden = false; } else uiOpen = false; });
window.addEventListener('keydown', e => {
  if (e.key !== 'Escape') return;
  if (Guide.isOpen()){ e.preventDefault(); $('#gbBack').click(); return; }
  if (!DK.root.hidden){ e.preventDefault(); closeDeskInfo(); }
});

/* 책상을 그냥 살펴볼 때: 마지막으로 본 작품이 있으면 다시 펼치고, 없으면 안내 */
function useDeskSpot(){
  const p = LPProfile.get();
  if (p && p.lastDesk && LPData.get(p.lastDesk)){ openDeskInfo(p.lastDesk, { instant:true }); return; }
  toast('선장 책상이에요. 오른쪽 <strong>로그포스</strong>로 목적지를 찾으면 이 위에 펼쳐져요.');
}
