/* ============================================================
   LOG POSE · 갑판 (갑판 1단계: 공간 + 오가는 길)
   첫 화면에서 내려다보던 배와 같은 모양: 남색 띠 · 금색 난간 · 돛대 셋(가운데 돛에 LOG POSE 문장) · 빨간 깃발
   좌표: +z = 뱃머리(앞), -z = 고물(뒤). 선장실은 고물 쪽 높은 갑판(선미루) 아래에 있어요.
     z -13 ~ -6  선미루 (높이 2.6) — 고물 난간 = 낚시터 자리
     z  -6       선장실 문 · 양옆 계단
     z  -6 ~ 16  주갑판 — 해도 탁자 · 큰 돛대(망루) · 뱃머리 망원경
   다음 단계 자리(망원경 · 항해 지도 · 망루 · 낚시)는 지금은 '준비 중'으로 알려줘요.
   ============================================================ */
const deckScene = new THREE.Scene();
const DK3 = { sea:null, seaBase:null, far:null, sky:null, sun:null, hemi:null, light:null, out:null, sails:[], flag:null, flagBase:null, gulls:[], lamps:[], colliders:[], clickables:[], floors:[] };
const DECK = { stern:-13, qEnd:-6, bow:16, half:4.2, qH:2.6, rail:0.95, stairIn:2.85, stairTop:-6, stairBot:-2.6 };

/* 선체 폭: 고물 쪽은 살짝 좁고, 뱃머리로 갈수록 둥글게 모여요 */
function deckHalf(z){
  if (z > 9){ const k = Math.min(1, (z - 9) / 7.4); return DECK.half * Math.sqrt(Math.max(0.02, 1 - k * k)); }
  if (z < -11) return DECK.half - (-11 - z) * 0.2;
  return DECK.half;
}
/* 바닥 높이: 선미루 2.6 · 계단은 비스듬히 · 나머지 0 */
function deckHeight(x, z){
  if (z < DECK.qEnd) return DECK.qH;
  if (Math.abs(x) > DECK.stairIn && z < DECK.stairBot) return DECK.qH * Math.min(1, (DECK.stairBot - z) / (DECK.stairBot - DECK.stairTop));
  return 0;
}
const dBox = (cx, cz, hx, hz) => DK3.colliders.push({ minX:cx - hx, maxX:cx + hx, minZ:cz - hz, maxZ:cz + hz });
const dMesh = (geo, mat, x, y, z, parent = deckScene) => { const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); parent.add(m); return m; };

/* 점들을 따라 세운 벽 (선체 옆판 · 난간 벽) */
function ribbon(pts, y0, y1, mat){
  const pos = [], idx = [];
  pts.forEach((p, i) => { pos.push(p.x, y0, p.z, p.x, y1, p.z); if (i){ const a = (i - 1) * 2; idx.push(a, a + 2, a + 1, a + 1, a + 2, a + 3); } });
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.setIndex(idx); g.computeVertexNormals();
  const m = new THREE.Mesh(g, mat); deckScene.add(m); return m;
}
/* 점들을 따라 놓는 둥근 손잡이 난간 */
function railLine(pts, y, r, mat){
  for (let i = 1; i < pts.length; i++){
    const a = pts[i - 1], b = pts[i], len = Math.hypot(b.x - a.x, b.z - a.z); if (len < 0.01) continue;
    const m = dMesh(new THREE.CylinderGeometry(r, r, len + 0.02, 6), mat, (a.x + b.x) / 2, y, (a.z + b.z) / 2);
    m.lookAt(b.x, y, b.z); m.rotateX(Math.PI / 2);
  }
}
const sidePts = (s, z0, z1, step = 0.5) => { const out = []; for (let z = z0; z <= z1 + 1e-6; z += step) out.push({ x:s * deckHalf(z), z }); return out; };

function buildDeckShip(){
  const plank = M.floor.clone(); plank.map = M.floor.map.clone(); plank.map.needsUpdate = true; plank.map.wrapS = plank.map.wrapT = THREE.RepeatWrapping; plank.map.repeat.set(2.2, 7);
  const hullMat = new THREE.MeshStandardMaterial({ color:'#4a2c18', roughness:.75, side:THREE.DoubleSide });
  const paint = new THREE.MeshStandardMaterial({ color:'#1f3a56', roughness:.6, side:THREE.DoubleSide });
  const gold = new THREE.MeshStandardMaterial({ color:'#c9a15e', roughness:.35, metalness:.6 });
  const inner = new THREE.MeshStandardMaterial({ color:'#5a3820', roughness:.85, side:THREE.DoubleSide });

  /* 주갑판 바닥: 선체 모양 */
  const sh = new THREE.Shape();
  const right = sidePts(1, DECK.qEnd - 0.2, DECK.bow, 0.4), left = sidePts(-1, DECK.qEnd - 0.2, DECK.bow, 0.4).reverse();
  sh.moveTo(right[0].x, -right[0].z); right.forEach(p => sh.lineTo(p.x, -p.z)); left.forEach(p => sh.lineTo(p.x, -p.z)); sh.closePath();
  const fg = new THREE.ShapeGeometry(sh); fg.rotateX(-Math.PI / 2);
  { const uv = fg.attributes.uv, pp = fg.attributes.position; for (let i = 0; i < uv.count; i++) uv.setXY(i, (pp.getX(i) + 5) / 10, (pp.getZ(i) + 10) / 30); }
  const main = new THREE.Mesh(fg, plank); main.name = 'floor'; deckScene.add(main); DK3.floors.push(main);
  /* 선미루 바닥 */
  const qMat = plank.clone(); qMat.map = plank.map.clone(); qMat.map.needsUpdate = true; qMat.map.repeat.set(2.2, 2);
  const q = dMesh(new THREE.PlaneGeometry(DECK.half * 2, DECK.qEnd - DECK.stern), qMat, 0, DECK.qH, (DECK.stern + DECK.qEnd) / 2); q.rotation.x = -Math.PI / 2; q.name = 'floor'; DK3.floors.push(q);

  /* 선체 옆판 (물 위로 보이는 부분) · 남색 띠 · 금색 테 */
  [1, -1].forEach(s => {
    const pts = sidePts(s, DECK.stern, DECK.bow + 0.5, 0.5);
    ribbon(pts, -2.8, -0.9, hullMat); ribbon(pts.map(p => ({ x:p.x * 1.002, z:p.z })), -0.9, -0.3, paint);
    const main = pts.filter(p => p.z >= DECK.qEnd);
    ribbon(main, -0.3, DECK.rail, inner);                       // 주갑판 난간 벽
    railLine(main, DECK.rail + 0.04, 0.07, gold);
    const qs = pts.filter(p => p.z <= DECK.qEnd);
    ribbon(qs, -0.3, DECK.qH + DECK.rail, hullMat);             // 선미루 옆벽
    railLine(qs, DECK.qH + DECK.rail + 0.04, 0.07, gold);
    for (let z = DECK.qEnd + 1; z < DECK.bow; z += 1.6){ const x = s * (deckHalf(z) - 0.06); dMesh(new THREE.BoxGeometry(0.12, DECK.rail, 0.12), M.woodDark, x, DECK.rail / 2, z); }
  });
  /* 뱃머리 끝 · 고물 판 */
  { const bz = DECK.bow + 0.5; ribbon([{ x:-deckHalf(bz), z:bz }, { x:deckHalf(bz), z:bz }], -2.8, DECK.rail, hullMat); }
  const sw = deckHalf(DECK.stern);
  ribbon([{ x:-sw, z:DECK.stern }, { x:sw, z:DECK.stern }], -2.8, DECK.qH + DECK.rail, hullMat);
  railLine([{ x:-sw, z:DECK.stern + 0.05 }, { x:sw, z:DECK.stern + 0.05 }], DECK.qH + DECK.rail + 0.04, 0.07, gold);
  /* 고물 등불 (첫 화면의 그 등불) */
  const post = dMesh(new THREE.CylinderGeometry(0.05, 0.05, 1.0, 6), gold, 0, DECK.qH + DECK.rail + 0.5, DECK.stern + 0.1);
  const lampGlow = new THREE.Sprite(new THREE.SpriteMaterial({ map:glowTex, color:'#ffcf7a', transparent:true, opacity:.8, blending:THREE.AdditiveBlending, depthWrite:false })); lampGlow.scale.set(1.4, 1.4, 1); lampGlow.position.set(0, DECK.qH + DECK.rail + 1.1, DECK.stern + 0.1); deckScene.add(lampGlow); void post;
  const lampBox = dMesh(new THREE.BoxGeometry(0.3, 0.42, 0.3), new THREE.MeshStandardMaterial({ color:'#ffe0a8', emissive:'#ffb050', emissiveIntensity:1 }), 0, DECK.qH + DECK.rail + 1.1, DECK.stern + 0.1);
  DK3.lamps.push({ glow:lampGlow, box:lampBox });

  /* 선장실 앞벽 (문 · 창 · 등불) */
  const wallMat = M.wall.clone(); wallMat.map = M.wall.map.clone(); wallMat.map.needsUpdate = true; wallMat.map.repeat.set(1, 3);
  const fw = dMesh(new THREE.PlaneGeometry(DECK.half * 2, DECK.qH), wallMat, 0, DECK.qH / 2, DECK.qEnd); void fw;
  dMesh(new THREE.BoxGeometry(DECK.half * 2, 0.18, 0.3), M.beam, 0, DECK.qH - 0.05, DECK.qEnd + 0.05);
  const door = dMesh(new THREE.BoxGeometry(1.3, 2.1, 0.1), M.woodRed, 0, 1.05, DECK.qEnd + 0.06);
  dMesh(new THREE.SphereGeometry(0.05, 10, 8), M.brass, -0.48, 1.05, DECK.qEnd + 0.13);
  dMesh(new THREE.BoxGeometry(1.5, 0.12, 0.16), M.woodDark, 0, 2.16, DECK.qEnd + 0.08);
  door.userData.kind = 'door'; DK3.clickables.push(door);
  const winMat = new THREE.MeshStandardMaterial({ color:'#ffd58a', emissive:'#ffb050', emissiveIntensity:.8 });
  /* 선장실 창: 타원 놋쇠 테두리에 꼭 맞는 타원 유리 + 십자 창살 */
  [-1.7, 1.7].forEach(x => { const gl = dMesh(new THREE.CircleGeometry(0.4, 24), winMat, x, 1.5, DECK.qEnd + 0.02); gl.scale.y = 1.25;
    const fr = dMesh(new THREE.TorusGeometry(0.42, 0.05, 8, 28), M.brass, x, 1.5, DECK.qEnd + 0.04); fr.scale.y = 1.25;
    dMesh(new THREE.BoxGeometry(0.03, 1.0, 0.02), M.brass, x, 1.5, DECK.qEnd + 0.035); dMesh(new THREE.BoxGeometry(0.8, 0.03, 0.02), M.brass, x, 1.5, DECK.qEnd + 0.035); });
  DK3.lamps.push({ box:{ material:winMat }, glow:null, win:true });
  /* 선미루 앞 난간 (계단 자리는 비워요) */
  railLine([{ x:-DECK.stairIn, z:DECK.qEnd - 0.05 }, { x:DECK.stairIn, z:DECK.qEnd - 0.05 }], DECK.qH + DECK.rail, 0.06, gold);
  for (let x = -DECK.stairIn; x <= DECK.stairIn + 0.01; x += DECK.stairIn / 4) dMesh(new THREE.CylinderGeometry(0.05, 0.05, DECK.rail, 6), gold, x, DECK.qH + DECK.rail / 2, DECK.qEnd - 0.05);
  dBox(0, DECK.qEnd, DECK.stairIn, 0.14);   // 앞벽 = 선미루 앞 난간 (위아래 모두 막아요)
  /* 양옆 계단 */
  [1, -1].forEach(s => {
    const n = 8, depth = (DECK.stairBot - DECK.stairTop) / n, cx = s * (DECK.stairIn + 0.55);
    for (let k = 0; k < n; k++){ const h = DECK.qH * (k + 1) / n; dMesh(new THREE.BoxGeometry(1.1, h, depth), M.wood, cx, h / 2, DECK.stairBot - depth * (k + 0.5)); }
    const a = { x:s * DECK.stairIn, z:DECK.stairBot }, b = { x:s * DECK.stairIn, z:DECK.stairTop };
    for (let k = 0; k <= 4; k++){ const z = DECK.stairBot - (DECK.stairBot - DECK.stairTop) * k / 4, y = DECK.qH * k / 4; dMesh(new THREE.CylinderGeometry(0.045, 0.045, 0.9, 6), gold, a.x, y + 0.45, z); }
    const rl = dMesh(new THREE.CylinderGeometry(0.05, 0.05, Math.hypot(DECK.stairBot - DECK.stairTop, DECK.qH), 6), gold, a.x, DECK.qH / 2 + 0.9, (DECK.stairBot + DECK.stairTop) / 2);
    rl.rotation.x = Math.PI / 2 - Math.atan2(DECK.qH, DECK.stairBot - DECK.stairTop);
    dBox(s * (DECK.stairIn - 0.05), (DECK.stairBot + DECK.stairTop) / 2, 0.1, (DECK.stairBot - DECK.stairTop) / 2);   // 계단 안쪽 난간
  });

  /* 돛대 · 활대 · 돛 (가운데 큰 돛대 아래 돛에 LOG POSE 문장) */
  const mastMat = new THREE.MeshStandardMaterial({ color:'#5a3820', roughness:.7 });
  const sailMat = new THREE.MeshStandardMaterial({ color:'#f2e8d2', roughness:.9, side:THREE.DoubleSide });
  const emblemMat = new THREE.MeshStandardMaterial({ map:emblemTex(), roughness:.9, side:THREE.DoubleSide });
  const masts = [{ z:2.2, y0:0, h:17, sails:[[9.0, 5.2, 6.2, emblemMat], [7.4, 3.6, 11.0, sailMat]], nest:true },
                 { z:10.2, y0:0, h:14.5, sails:[[7.4, 4.4, 5.6, sailMat], [6.0, 3.0, 9.6, sailMat]] },
                 { z:-9.6, y0:DECK.qH, h:11, sails:[[6.0, 3.8, DECK.qH + 4.4, sailMat]] }];
  masts.forEach(m => {
    dMesh(new THREE.CylinderGeometry(0.2, 0.3, m.h, 12), mastMat, 0, m.y0 + m.h / 2, m.z);
    dMesh(new THREE.CylinderGeometry(0.42, 0.48, 0.5, 12), M.woodDark, 0, m.y0 + 0.25, m.z);
    dBox(0, m.z, 0.42, 0.42);
    m.sails.forEach(([w, hh, y, mat]) => {
      const yard = dMesh(new THREE.CylinderGeometry(0.1, 0.1, w + 0.8, 8), mastMat, 0, y + hh / 2, m.z + 0.25); yard.rotation.z = Math.PI / 2;
      const sail = dMesh(sailGeo(w, hh, 0.9), mat, 0, y, m.z + 0.35); DK3.sails.push(sail);
    });
  });
  /* 망루 (큰 돛대 위) · 줄사다리 */
  const nestY = 13.2;
  dMesh(new THREE.CylinderGeometry(1.15, 1.0, 0.18, 20), M.woodDark, 0, nestY, 2.2);
  dMesh(new THREE.CylinderGeometry(1.15, 1.15, 0.8, 20, 1, true), new THREE.MeshStandardMaterial({ color:'#6b4528', roughness:.8, side:THREE.DoubleSide }), 0, nestY + 0.4, 2.2);
  dMesh(new THREE.TorusGeometry(1.15, 0.05, 6, 24), gold, 0, nestY + 0.8, 2.2).rotation.x = Math.PI / 2;
  const ropeMat = new THREE.LineBasicMaterial({ color:'#3a2a1a', transparent:true, opacity:.75 });
  [1, -1].forEach(s => {
    const base = [1.0, 2.2, 3.4].map(z => new THREE.Vector3(s * (deckHalf(z) - 0.05), DECK.rail, z));
    const top = new THREE.Vector3(s * 0.95, nestY, 2.2), seg = [];
    base.forEach(b => seg.push(b, top));
    for (let k = 1; k < 14; k++){ const t = k / 14; const a = base[0].clone().lerp(top, t), c = base[2].clone().lerp(top, t); seg.push(a, c); }
    const g = new THREE.BufferGeometry().setFromPoints(seg); deckScene.add(new THREE.LineSegments(g, ropeMat));
  });
  /* 깃발 (첫 화면과 같은 빨간 닻 깃발) */
  const fG = new THREE.PlaneGeometry(2.4, 1.5, 12, 4); fG.translate(-1.2, 0, 0); DK3.flagBase = Float32Array.from(fG.attributes.position.array);
  DK3.flag = dMesh(fG, new THREE.MeshStandardMaterial({ map:canvasTex(256, 160, (g, w, h) => { g.fillStyle = '#8a2a1c'; g.fillRect(0, 0, w, h); g.fillStyle = '#f2e8d2'; g.font = `700 92px ${FD}`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('⚓', w / 2, h / 2 + 6); }), side:THREE.DoubleSide, roughness:.8 }), 0, 17.4, 2.2);
  DK3.flag.rotation.y = Math.PI / 2;
  /* 내 해적기, 눈높이에서도 보이게: 선장실 문 위 뒷갑판 난간에 두 장 + 고물(배 뒤) 깃대 */
  const fm = new THREE.MeshStandardMaterial({ map:DK3.flag.material.map, side:THREE.DoubleSide, roughness:.85 }); flagShows.push(fm);
  [-1.6, 1.6].forEach(x => { dMesh(new THREE.BoxGeometry(1.5, 0.05, 0.05), M.brass, x, DECK.qH + 0.88, DECK.qEnd + 0.1);   /* 뒷갑판 난간에 걸어 둔 천 (창문 위) */
    const b = dMesh(new THREE.PlaneGeometry(1.36, 0.82), fm, x, DECK.qH + 0.45, DECK.qEnd + 0.09); b.rotation.z = x > 0 ? 0.02 : -0.02; });
  dMesh(new THREE.CylinderGeometry(0.06, 0.08, 4.4, 8), new THREE.MeshStandardMaterial({ color:'#5a3a22', roughness:.8 }), 0, DECK.qH + 2.2, DECK.stern + 0.5);
  dMesh(new THREE.SphereGeometry(0.11, 10, 8), M.brass, 0, DECK.qH + 4.45, DECK.stern + 0.5);
  const sf = dMesh(new THREE.PlaneGeometry(2.0, 1.25, 8, 2).translate(1.0, 0, 0), fm, 0.06, DECK.qH + 3.7, DECK.stern + 0.5); sf.rotation.y = -Math.PI / 2 + 0.3; DK3.sternFlag = sf;
  /* 기움돛대 · 삼각돛 */
  const bs = dMesh(new THREE.CylinderGeometry(0.12, 0.18, 7.5, 8), mastMat, 0, 2.6, DECK.bow + 3.0); bs.rotation.x = Math.PI / 2 - 0.32;
  const jib = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(0, 14, 10.4), new THREE.Vector3(0, 3.8, DECK.bow + 6.2), new THREE.Vector3(0, 2.0, 11.8)]); jib.computeVertexNormals();
  deckScene.add(new THREE.Mesh(jib, sailMat));

  /* 소품: 해치 · 포 · 통 · 상자 · 밧줄 · 등불 기둥 */
  const hatch = dMesh(new THREE.BoxGeometry(2.0, 0.22, 1.6), M.wood, 0, 0.11, 6.2);
  for (let i = -3; i <= 3; i++) dMesh(new THREE.BoxGeometry(0.05, 0.03, 1.5), M.woodDark, i * 0.27, 0.235, 6.2); void hatch;
  dBox(0, 6.2, 1.0, 0.8);
  const cannonMat = new THREE.MeshStandardMaterial({ color:'#26272a', roughness:.45, metalness:.7 });
  [-0.8, 4.4, 8.2].forEach(z => [1, -1].forEach(s => {
    const x = s * (deckHalf(z) - 0.75), g = new THREE.Group(); g.position.set(x, 0, z); deckScene.add(g);
    dMesh(new THREE.BoxGeometry(0.7, 0.32, 0.9), M.woodRed, 0, 0.26, 0, g);
    [-0.32, 0.32].forEach(zz => [-0.3, 0.3].forEach(xx => { const w = dMesh(new THREE.CylinderGeometry(0.14, 0.14, 0.08, 12), M.woodDark, xx, 0.14, zz, g); w.rotation.z = Math.PI / 2; }));
    const barrel = dMesh(new THREE.CylinderGeometry(0.13, 0.18, 1.4, 12), cannonMat, s * 0.35, 0.55, 0, g); barrel.rotation.z = s * Math.PI / 2;
    dBox(x, z, 0.45, 0.5);
  }));
  const barrelMat = new THREE.MeshStandardMaterial({ color:'#7a5230', roughness:.7 });
  [[-2.6, 12.0], [-2.0, 12.7]].forEach(([x, z]) => {
    dMesh(new THREE.CylinderGeometry(0.34, 0.34, 0.9, 14), barrelMat, x, 0.45, z);
    [0.15, 0.75].forEach(y => dMesh(new THREE.CylinderGeometry(0.355, 0.355, 0.05, 14, 1, true), M.iron, x, y, z)); dBox(x, z, 0.36, 0.36); });
  [[2.9, 6.6, 0.8], [2.4, 7.4, 0.6]].forEach(([x, z, s]) => { dMesh(new THREE.BoxGeometry(s, s, s), M.wood, x, s / 2, z).rotation.y = 0.3; dBox(x, z, s / 2 + 0.05, s / 2 + 0.05); });
  const ropeCoil = dMesh(new THREE.TorusGeometry(0.42, 0.1, 6, 20), new THREE.MeshStandardMaterial({ color:'#c9b08a', roughness:.9 }), 1.6, 0.1, 0.4); ropeCoil.rotation.x = Math.PI / 2;
  /* 등불 기둥 (밤에 밝아요) */
  [[-3.4, 1.2], [3.4, 9.4], [-3.4, 9.4], [3.4, 1.2]].forEach(([x, z]) => {
    const xx = Math.sign(x) * (deckHalf(z) - 0.1);
    dMesh(new THREE.CylinderGeometry(0.04, 0.04, 0.7, 6), M.iron, xx, DECK.rail + 0.35, z);
    const box = dMesh(new THREE.BoxGeometry(0.22, 0.3, 0.22), new THREE.MeshStandardMaterial({ color:'#ffe0a8', emissive:'#ffb050', emissiveIntensity:.6 }), xx, DECK.rail + 0.85, z);
    const glow = new THREE.Sprite(new THREE.SpriteMaterial({ map:glowTex, color:'#ffcf8a', transparent:true, opacity:.4, blending:THREE.AdditiveBlending, depthWrite:false })); glow.scale.set(1.2, 1.2, 1); glow.position.set(xx, DECK.rail + 0.85, z); deckScene.add(glow);
    DK3.lamps.push({ box, glow });
  });

  /* 다음 단계 자리: 해도 탁자 · 망원경 · 망루 사다리 · 낚시터 */
  const chart = new THREE.Group(); chart.position.set(-1.7, 0, -3.5); deckScene.add(chart);
  dMesh(new THREE.BoxGeometry(1.7, 0.1, 1.1), M.woodRed, 0, 0.95, 0, chart);
  [[-0.7, -0.45], [0.7, -0.45], [-0.7, 0.45], [0.7, 0.45]].forEach(([x, z]) => dMesh(new THREE.BoxGeometry(0.1, 0.92, 0.1), M.woodDark, x, 0.46, z, chart));
  const cm = dMesh(new THREE.PlaneGeometry(1.5, 0.95), new THREE.MeshStandardMaterial({ map:mapTex(), roughness:.9 }), 0, 1.006, 0, chart); cm.rotation.x = -Math.PI / 2;
  [[-0.72, -0.44], [0.72, 0.44]].forEach(([x, z]) => dMesh(new THREE.CylinderGeometry(0.03, 0.03, 0.05, 8), M.brass, x, 1.03, z, chart));
  chart.userData.kind = 'chart'; DK3.clickables.push(chart); dBox(-1.7, -3.5, 0.9, 0.6);
  const scope = new THREE.Group(); scope.position.set(0, 0, 13.7); deckScene.add(scope);
  [0, 2.1, 4.2].forEach(a => { const leg = dMesh(new THREE.CylinderGeometry(0.03, 0.03, 1.4, 6), M.woodDark, Math.sin(a) * 0.3, 0.65, Math.cos(a) * 0.3, scope); leg.rotation.set(Math.cos(a) * 0.22, 0, -Math.sin(a) * 0.22); });
  const tube = dMesh(new THREE.CylinderGeometry(0.06, 0.11, 1.1, 14), M.brass, 0, 1.38, 0.1, scope); tube.rotation.x = Math.PI / 2 - 0.12;
  dMesh(new THREE.TorusGeometry(0.11, 0.02, 6, 16), M.woodDark, 0, 1.43, 0.55, scope);
  scope.userData.kind = 'scope'; DK3.clickables.push(scope); dBox(0, 13.7, 0.35, 0.35);
  const ladder = dMesh(new THREE.BoxGeometry(0.2, 2.2, 1.6), new THREE.MeshBasicMaterial({ visible:false }), deckHalf(2.2) - 0.3, 1.6, 2.2);
  ladder.userData.kind = 'nest'; DK3.clickables.push(ladder);
  /* 낚시터: 고물 난간 앞 낚싯대 · 양동이 */
  const rod = dMesh(new THREE.CylinderGeometry(0.02, 0.035, 2.6, 6), M.woodDark, 0.9, DECK.qH + 1.1, DECK.stern + 0.5); rod.rotation.x = -0.75;
  const bucket = dMesh(new THREE.CylinderGeometry(0.22, 0.18, 0.4, 14), new THREE.MeshStandardMaterial({ color:'#6b4528', roughness:.8 }), 1.6, DECK.qH + 0.2, DECK.stern + 0.7);
  void bucket;
  const fishHit = dMesh(new THREE.BoxGeometry(3.2, 1.2, 0.6), new THREE.MeshBasicMaterial({ visible:false }), 0, DECK.qH + 1.0, DECK.stern + 0.4);
  fishHit.userData.kind = 'fish'; DK3.clickables.push(fishHit); dBox(1.6, DECK.stern + 0.7, 0.25, 0.25);
}

/* 바다 · 하늘 · 갈매기 */
function buildDeckWorld(){
  DK3.hemi = new THREE.HemisphereLight('#dff0ff', '#3a2a1a', .8); deckScene.add(DK3.hemi);
  DK3.light = new THREE.DirectionalLight('#fff1d6', 1.1); DK3.light.position.set(-40, 60, 30); deckScene.add(DK3.light);
  deckScene.fog = new THREE.Fog('#bfe0f0', 80, 420);
  DK3.sky = new THREE.Mesh(new THREE.SphereGeometry(450, 32, 16), new THREE.MeshBasicMaterial({ side:THREE.BackSide, fog:false })); deckScene.add(DK3.sky);
  DK3.sun = new THREE.Sprite(new THREE.SpriteMaterial({ map:glowTex, color:'#fff4d6', transparent:true, fog:false, depthWrite:false, blending:THREE.AdditiveBlending })); DK3.sun.scale.set(130, 130, 1); DK3.sun.position.set(-260, 150, 330); deckScene.add(DK3.sun);
  DK3.out = new THREE.Group(); deckScene.add(DK3.out);
  const g = new THREE.PlaneGeometry(240, 240, 64, 64); g.rotateX(-Math.PI / 2);
  DK3.seaBase = Float32Array.from(g.attributes.position.array);
  DK3.sea = new THREE.Mesh(g, new THREE.MeshStandardMaterial({ color:'#ffffff', roughness:.5, flatShading:true })); DK3.sea.position.y = -2.4; DK3.out.add(DK3.sea);
  DK3.far = new THREE.Mesh(new THREE.PlaneGeometry(2000, 2000), new THREE.MeshStandardMaterial({ color:'#1583bf', roughness:.5 })); DK3.far.rotation.x = -Math.PI / 2; DK3.far.position.y = -3.3; DK3.out.add(DK3.far);
  /* 배 둘레 물보라 */
  const foam = new THREE.Mesh(new THREE.PlaneGeometry(14, 38), new THREE.MeshBasicMaterial({ map:glowTex, color:'#ffffff', transparent:true, opacity:.35, depthWrite:false })); foam.rotation.x = -Math.PI / 2; foam.position.set(0, -2.0, 1.5); DK3.out.add(foam); DK3.foam = foam;
  /* 구름 */
  const cloudMat = new THREE.MeshStandardMaterial({ color:'#ffffff', emissive:'#ffffff', emissiveIntensity:.35, roughness:1, flatShading:true, transparent:true, opacity:.92 });
  DK3.clouds = [];
  for (let i = 0; i < 9; i++){
    const c = new THREE.Group();
    for (let k = 0; k < 6; k++){ const b = new THREE.Mesh(new THREE.IcosahedronGeometry(rand(6, 11), 1), cloudMat); b.position.set(k * rand(6, 9), rand(-2, 2), rand(-5, 5)); b.scale.y = .5; c.add(b); }
    const a = rand(0, Math.PI * 2), r = rand(150, 300); c.position.set(Math.cos(a) * r, rand(55, 90), Math.sin(a) * r); deckScene.add(c); DK3.clouds.push(c);
  }
  DK3.cloudMat = cloudMat;
  /* 갈매기: 두 날개를 퍼덕이며 돛대 위를 맴돌아요 */
  const gullMat = new THREE.MeshBasicMaterial({ color:'#f4f4f0', side:THREE.DoubleSide });
  for (let i = 0; i < 4; i++){
    const gg = new THREE.Group();
    const wing = s => { const geo = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(0, 0, 0.15), new THREE.Vector3(s * 0.9, 0.08, 0), new THREE.Vector3(0, 0, -0.2)]); geo.computeVertexNormals(); const m = new THREE.Mesh(geo, gullMat); gg.add(m); return m; };
    gg.userData = { L:wing(1), R:wing(-1), r:rand(9, 16), h:rand(15, 22), sp:rand(.18, .3) * (i % 2 ? 1 : -1), ph:rand(0, 6), cz:rand(-2, 8) };
    deckScene.add(gg); DK3.gulls.push(gg);
  }
}

/* 낮 / 밤 (창밖 버튼과 같아요) */
function deckTime(mode){
  if (!DK3.sky) return;
  const day = mode === 'day';
  DK3.sky.material.map = domeTex[mode] || (domeTex[mode] = skyDomeTex(mode)); DK3.sky.material.needsUpdate = true;
  DK3.sea.material.map = seaTexs[mode] || (seaTexs[mode] = seaTex(mode)); DK3.sea.material.needsUpdate = true;
  DK3.far.material.color.set(day ? '#1583bf' : '#0b2a48');
  deckScene.fog.color.set(day ? '#bfe0f0' : '#0f2444');
  deckScene.background = new THREE.Color(day ? '#9fd0ec' : '#0b1a32');
  DK3.hemi.color.set(day ? '#dff0ff' : '#5a7aa8'); DK3.hemi.groundColor.set(day ? '#3a2a1a' : '#0a0806'); DK3.hemi.intensity = day ? .8 : .32;
  DK3.light.intensity = day ? 1.1 : .25; DK3.light.color.set(day ? '#fff1d6' : '#9fb6e0');
  DK3.sun.material.color.set(day ? '#fff4d6' : '#dfe8f8'); DK3.sun.scale.setScalar(day ? 130 : 60);
  DK3.cloudMat.color.set(day ? '#ffffff' : '#5a6a88'); DK3.cloudMat.emissiveIntensity = day ? .35 : .05;
  DK3.lamps.forEach(L => { if (L.box && L.box.material) L.box.material.emissiveIntensity = L.win ? (day ? .6 : 1.4) : (day ? .5 : 1.6); if (L.glow) L.glow.material.opacity = day ? .25 : .85; });
  DK3.gulls.forEach(g => g.visible = day);
}

/* 다음 단계 자리 안내 */
const josaEun = w => { const ch = Array.from(w).reverse().find(c => c >= '가' && c <= '힣'); return ch && (ch.charCodeAt(0) - 0xAC00) % 28 ? '은' : '는'; };
const soon = what => () => toast(`<strong>${what}</strong>${josaEun(what)} 곧 열려요. 다음 항해에서 만나요!`);
const DECK_SPOTS = {
  door:{ x:0, z:DECK.qEnd + 1.0, face:Math.PI, label:'선장실로 들어가기', use:() => goArea('cabin') },
  chart:{ x:-1.7, z:-2.35, face:Math.PI, label:'항해 지도 펼치기', use:soon('항해 지도') },
  scope:{ x:0, z:12.75, face:0, label:'망원경 들여다보기', use:soon('뱃머리 망원경') },
  nest:{ x:deckHalf(2.2) - 0.85, z:2.2, face:Math.PI / 2, label:'망루 오르기', use:soon('망루') },
  fish:{ x:0, z:DECK.stern + 1.2, face:Math.PI, label:'낚시하기', use:soon('낚시터') }
};

/* 클릭 이동: 장애물 모서리를 잇는 지름길 찾기 (갑판은 넓고 소품이 많아서)
   주갑판 ↔ 선미루는 가까운 계단으로 돌아가요 */
const STAIR_ZONES = [1, -1].map(s => ({ minX:s > 0 ? DECK.stairIn - 0.1 : -DECK.half - 1, maxX:s > 0 ? DECK.half + 1 : -DECK.stairIn + 0.1, minZ:DECK.stairTop - 0.2, maxZ:DECK.stairBot }));
function segHits(ax, az, bx, bz, c, m){
  /* 선분과 (m만큼 넓힌) 상자가 겹치는지: slab 방식 */
  const minX = c.minX - m, maxX = c.maxX + m, minZ = c.minZ - m, maxZ = c.maxZ + m;
  let t0 = 0, t1 = 1; const dx = bx - ax, dz = bz - az;
  for (const [p, d, lo, hi] of [[ax, dx, minX, maxX], [az, dz, minZ, maxZ]]){
    if (Math.abs(d) < 1e-9){ if (p <= lo || p >= hi) return false; }
    else { let u = (lo - p) / d, v = (hi - p) / d; if (u > v) [u, v] = [v, u]; t0 = Math.max(t0, u); t1 = Math.min(t1, v); if (t0 >= t1) return false; }
  }
  return true;
}
/* 장애물 모서리를 잇는 지름길 (갑판 · 다모였섬이 같이 써요)
   blocks: 상자들 · inside(x,z): 걸을 수 있는 곳인지 · extra: 꼭 지나야 할 수 있는 길목 */
function graphPlan(ax, az, tx, tz, blocks, inside, extra = []){
  const m = PLAYER_R + 0.04;
  const free = (x, z) => inside(x, z) && !blocks.some(c => x > c.minX - m && x < c.maxX + m && z > c.minZ - m && z < c.maxZ + m);
  const clear = (a, b) => {
    if (blocks.some(c => segHits(a.x, a.z, b.x, b.z, c, m - 0.02))) return false;
    const n = Math.ceil(Math.hypot(b.x - a.x, b.z - a.z) / 0.8);
    for (let i = 1; i < n; i++){ const x = a.x + (b.x - a.x) * i / n, z = a.z + (b.z - a.z) * i / n; if (!inside(x, z)) return false; }
    return true;
  };
  const A = { x:ax, z:az }, B = { x:tx, z:tz };
  if (clear(A, B)) return [B];
  const pad = m + 0.12, nodes = [A, B, ...extra.filter(e => free(e.x, e.z))];
  blocks.forEach(c => [[c.minX - pad, c.minZ - pad], [c.maxX + pad, c.minZ - pad], [c.minX - pad, c.maxZ + pad], [c.maxX + pad, c.maxZ + pad]].forEach(([x, z]) => { if (free(x, z)) nodes.push({ x, z }); }));
  const n = nodes.length, dist = new Array(n).fill(Infinity), prev = new Array(n).fill(-1), done = new Array(n).fill(false); dist[0] = 0;
  for (let it = 0; it < n; it++){
    let u = -1; for (let i = 0; i < n; i++) if (!done[i] && (u < 0 || dist[i] < dist[u])) u = i;
    if (u < 0 || dist[u] === Infinity) break; if (u === 1) break; done[u] = true;
    for (let v = 0; v < n; v++){ if (done[v] || v === u) continue; const d = dist[u] + Math.hypot(nodes[u].x - nodes[v].x, nodes[u].z - nodes[v].z); if (d < dist[v] && clear(nodes[u], nodes[v])){ dist[v] = d; prev[v] = u; } }
  }
  if (prev[1] < 0) return [B];
  const path = []; for (let v = 1; v > 0; v = prev[v]) path.unshift({ x:nodes[v].x, z:nodes[v].z });
  return path;
}
function deckPlan(ax, az, tx, tz, upper){
  const m = PLAYER_R + 0.04;
  const blocks = upper ? DK3.colliders.filter(c => c.maxZ < DECK.qEnd + 0.3) : DK3.colliders.filter(c => c.minZ > DECK.qEnd - 0.3).concat(STAIR_ZONES);
  const inside = (x, z) => upper ? (z > DECK.stern + m && z < DECK.qEnd - m && Math.abs(x) < deckHalf(z) - m - 0.12)
                                 : (z > DECK.qEnd + m && z < DECK.bow - 0.9 && Math.abs(x) < deckHalf(z) - m - 0.12);
  return graphPlan(ax, az, tx, tz, blocks, inside);
}
function deckRoute(tx, tz){
  const isUp = (x, z) => z < DECK.qEnd - 0.05 || deckHeight(x, z) > 1.3;
  const fromUp = isUp(player.x, player.z), toUp = isUp(tx, tz);
  /* 계단 위에 서 있으면 먼저 가까운 끝으로 */
  const onStair = Math.abs(player.x) > DECK.stairIn && player.z >= DECK.stairTop - 0.1 && player.z <= DECK.stairBot;
  const sx0 = Math.sign(player.x) * (DECK.stairIn + 0.55);
  const bot = s => ({ x:s * (DECK.stairIn + 0.55), z:DECK.stairBot + 0.55 }), top = s => ({ x:s * (DECK.stairIn + 0.55), z:DECK.stairTop - 0.6 });
  if (onStair){ const end = toUp ? top(Math.sign(player.x)) : bot(Math.sign(player.x)); return [{ x:sx0, z:player.z }, end, ...deckPlan(end.x, end.z, tx, tz, toUp)]; }
  if (fromUp === toUp) return deckPlan(player.x, player.z, tx, tz, toUp);
  const s = Math.abs(player.x) > 0.3 ? Math.sign(player.x) : (Math.sign(tx) || 1);
  return toUp ? [...deckPlan(player.x, player.z, bot(s).x, bot(s).z, false), top(s), ...deckPlan(top(s).x, top(s).z, tx, tz, true)]
              : [...deckPlan(player.x, player.z, top(s).x, top(s).z, true), bot(s), ...deckPlan(bot(s).x, bot(s).z, tx, tz, false)];
}

const DECK_AREA = {
  id:'deck', name:'갑판', scene:deckScene, colliders:DK3.colliders, clickables:DK3.clickables, spots:DECK_SPOTS, floors:DK3.floors, exposure:.95,
  clamp(p, m){
    p.z = Math.min(DECK.bow - 0.9, Math.max(DECK.stern + m, p.z));
    const hw = deckHalf(p.z) - m - 0.12; p.x = Math.min(hw, Math.max(-hw, p.x));
  },
  sideOk:(x, z) => Math.abs(x) < deckHalf(z) - 0.5,
  heightAt:deckHeight,
  route:deckRoute,
  camClamp(v, gy){
    /* 선장실 벽 · 선미루 안으로 들어가지 않게 */
    if (gy < 1.3 && v.z < DECK.qEnd + 0.35 && Math.abs(v.x) < DECK.half + 0.5){ v.z = DECK.qEnd + 0.35; v.y = Math.max(v.y, 1.6); }
    const fl = deckHeight(v.x, v.z); v.y = Math.max(v.y, fl + 0.5);
  },
  ambient(dt, time, sway){
    const t = reduceMotion ? 0 : time;
    const p = DK3.sea.geometry.attributes.position, b = DK3.seaBase;
    for (let i = 0; i < p.count; i++) p.array[i * 3 + 1] = waveH(b[i * 3], b[i * 3 + 2], t) * 0.8;
    p.needsUpdate = true; DK3.sea.geometry.computeVertexNormals();
    if (DK3.sea.material.map){ DK3.sea.material.map.offset.x = (t * 0.01) % 1; DK3.sea.material.map.offset.y = (t * 0.03) % 1; }
    /* 배가 흔들리는 대신 바깥 세상이 살짝 기울어요 */
    DK3.out.rotation.z = Math.sin(t * 0.45) * 0.02 * sway; DK3.out.rotation.x = Math.sin(t * 0.33) * 0.012 * sway; DK3.out.position.y = Math.sin(t * 0.6) * 0.3 * sway;
    DK3.foam.material.opacity = .3 + Math.sin(t * 1.3) * .08;
    DK3.sails.forEach((s, i) => { s.scale.z = 1 + Math.sin(t * 1.1 + i) * 0.12 * sway; });
    if (DK3.sternFlag) DK3.sternFlag.rotation.y = -Math.PI / 2 + 0.3 + Math.sin(time * 1.7) * 0.18;
    const fp = DK3.flag.geometry.attributes.position, fb = DK3.flagBase;
    for (let i = 0; i < fp.count; i++){ const x = fb[i * 3], k = -x / 2.4; fp.array[i * 3 + 2] = Math.sin(x * 2.6 + t * 6) * 0.22 * k * (sway || .3); }
    fp.needsUpdate = true;
    DK3.gulls.forEach(g => { const u = g.userData, a = u.ph + t * u.sp; g.position.set(Math.cos(a) * u.r, u.h + Math.sin(t * .7 + u.ph) * 0.8, u.cz + Math.sin(a) * u.r); g.rotation.y = -a + (u.sp > 0 ? 0 : Math.PI); const f = Math.sin(t * 7 + u.ph) * 0.5 * (sway || .2); u.L.rotation.z = f; u.R.rotation.z = -f; });
    DK3.clouds.forEach((c, i) => { c.position.x += dt * (1.2 + i * .1) * (sway || 0); if (c.position.x > 320) c.position.x = -320; });
    islesStep(dt, time); seasStep(dt, time); nestStep(dt); fishStep(dt, time);
  },
  arrive(){ player.x = 0; player.z = DECK.qEnd + 2.3; player.r = 0; cam.yaw = Math.PI; cam.pitch = 0.3; },
  welcome(){ toast('<strong>갑판</strong>이에요. 바닷바람이 시원하네요.<br>뱃머리 망원경 · 해도 탁자 · 망루 · 고물 낚시터를 둘러보세요.', 4200); }
};
AREAS.deck = DECK_AREA;

function buildDeck(){
  buildDeckWorld(); buildDeckShip(); buildIsles(); buildSeas(); buildFishing(); buildDeckRest();
  timeHooks.push(deckTime); deckTime(timeMode);
}
