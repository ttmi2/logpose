/* ============================================================
   LOG POSE · 첫 화면 3D: 푸른 바다 위에 떠 있는 해적선 한 척
   선미(뒤쪽) 창에 불이 켜져 있어요. 그 안이 선장실이에요.
   들어갈 때 카메라가 선미 창으로 날아가요.
   ============================================================ */
const introScene = new THREE.Scene();
const introCam = new THREE.PerspectiveCamera(48, 1, 0.1, 1500);
function introResize(){ introCam.aspect = window.innerWidth / window.innerHeight; introCam.updateProjectionMatrix(); }
window.addEventListener('resize', introResize); introResize();

const IN = { wake:null, foam:null, glints:[], shadows:[], ship:null, sea:null, seaBase:null, far:null, sky:null, sun:null, clouds:[], flag:null, flagBase:null, sails:[], windows:null, hemi:null, light:null, fly:null, t0:0 };

/* 하늘 구 (안쪽 면) */
function skyDomeTex(mode){ return canvasTex(64, 512, (g, w, h) => {
  const day = mode === 'day', gr = g.createLinearGradient(0, 0, 0, h);
  if (day){ gr.addColorStop(0, '#2f6fb8'); gr.addColorStop(.42, '#78b3e2'); gr.addColorStop(.5, '#d6ecf6'); gr.addColorStop(1, '#d6ecf6'); }
  else { gr.addColorStop(0, '#040a16'); gr.addColorStop(.42, '#10234a'); gr.addColorStop(.5, '#2a4472'); gr.addColorStop(1, '#2a4472'); }
  g.fillStyle = gr; g.fillRect(0, 0, w, h);
}); }
const domeTex = {};

/* 바다 무늬: 짙은 파랑 위에 밝은 물결선과 하얀 물마루. 천천히 흘러가요 */
function seaTex(mode){ return canvasTex(512, 512, (g, w, h) => {
  const day = mode === 'day';
  g.fillStyle = day ? '#1583bf' : '#0b2a48'; g.fillRect(0, 0, w, h);
  for (let i = 0; i < 26; i++){ g.fillStyle = day ? `rgba(10,70,130,${rand(.08, .2)})` : `rgba(0,10,30,${rand(.1, .25)})`; g.beginPath(); g.ellipse(rand(0, w), rand(0, h), rand(40, 110), rand(20, 50), rand(0, 3), 0, Math.PI * 2); g.fill(); }
  for (let i = 0; i < 70; i++){
    const x = rand(0, w), y = rand(0, h), l = rand(26, 70);
    g.strokeStyle = day ? `rgba(120,215,245,${rand(.35, .7)})` : `rgba(90,140,200,${rand(.25, .5)})`; g.lineWidth = rand(1.5, 3);
    g.beginPath(); g.moveTo(x, y); g.quadraticCurveTo(x + l / 2, y - rand(4, 8), x + l, y); g.stroke();
    if (Math.random() < .45){ g.strokeStyle = `rgba(255,255,255,${day ? rand(.55, .9) : rand(.25, .45)})`; g.lineWidth = rand(1.5, 2.5); g.beginPath(); g.moveTo(x + l * .3, y - 3); g.quadraticCurveTo(x + l * .5, y - 7, x + l * .7, y - 3); g.stroke(); }
  }
}, [14, 14]); }
const seaTexs = {};
/* 물결 높이: 배 흔들림과 바다 모양이 같은 식을 써요 */
const waveH = (x, z, t) => 0.48 * Math.sin(0.17 * x + t * 1.05) + 0.36 * Math.sin(0.21 * z - t * 0.8) + 0.16 * Math.sin(0.47 * (x + z) + t * 1.7) + 0.08 * Math.sin(0.9 * x - 0.6 * z + t * 2.3);

function sailGeo(w, h, belly){
  const g = new THREE.PlaneGeometry(w, h, 12, 8), p = g.attributes.position;
  for (let i = 0; i < p.count; i++){ const x = p.getX(i) / (w / 2), y = p.getY(i) / (h / 2); p.setZ(i, belly * (1 - x * x) * (1 - 0.35 * y * y)); }
  g.computeVertexNormals(); return g;
}
function emblemTex(){ return canvasTex(512, 512, (g, w, h) => {
  g.fillStyle = '#f2e8d2'; g.fillRect(0, 0, w, h); speckle(g, w, h, 1500, '#8a6a48', .12);
  g.save(); g.translate(w / 2, h / 2 - 10);
  g.strokeStyle = '#8a2a1c'; g.lineWidth = 10; g.beginPath(); g.arc(0, 0, 130, 0, Math.PI * 2); g.stroke();
  g.lineWidth = 3; g.beginPath(); g.arc(0, 0, 104, 0, Math.PI * 2); g.stroke();
  for (let k = 0; k < 4; k++){ g.save(); g.rotate(k * Math.PI / 2); g.beginPath(); g.moveTo(0, -150); g.lineTo(18, 0); g.lineTo(-18, 0); g.closePath(); g.fillStyle = k ? '#8a2a1c' : '#2f6f9a'; g.fill(); g.restore(); }
  g.fillStyle = '#f2e8d2'; g.beginPath(); g.arc(0, 0, 16, 0, Math.PI * 2); g.fill();
  g.restore();
  g.fillStyle = '#8a2a1c'; g.font = `700 54px ${FD}`; g.textAlign = 'center'; g.fillText('그뭔SHIP', w / 2, h - 40);
}); }

function buildShip(){
  const S = new THREE.Group();
  const hullMat = new THREE.MeshStandardMaterial({ color:'#4a2c18', roughness:.7, flatShading:true });
  const trimMat = new THREE.MeshStandardMaterial({ color:'#c9a15e', roughness:.35, metalness:.6 });
  const paint = new THREE.MeshStandardMaterial({ color:'#1f3a56', roughness:.6, flatShading:true });
  /* 선체: 옆모습을 밀어낸 모양. 이물(앞) = +x */
  const sh = new THREE.Shape();
  sh.moveTo(-6.2, 2.6); sh.lineTo(-5.6, 0.2); sh.quadraticCurveTo(-4.6, -1.1, -2.5, -1.2); sh.lineTo(3.6, -1.2);
  sh.quadraticCurveTo(6.2, -0.9, 7.4, 2.2); sh.lineTo(-6.2, 2.6);
  const hullG = new THREE.ExtrudeGeometry(sh, { depth:3.6, bevelEnabled:true, bevelThickness:0.25, bevelSize:0.25, bevelSegments:2, steps:1 }); hullG.translate(0, 0, -1.8);
  S.add(new THREE.Mesh(hullG, hullMat));
  const stripe = new THREE.Mesh(new THREE.BoxGeometry(12.2, 0.5, 4.16), paint); stripe.position.set(0.4, 1.35, 0); S.add(stripe);
  const trim = new THREE.Mesh(new THREE.BoxGeometry(13.2, 0.14, 4.24), trimMat); trim.position.set(0.5, 2.2, 0); S.add(trim);
  const deck = new THREE.Mesh(new THREE.BoxGeometry(12.6, 0.16, 3.7), new THREE.MeshStandardMaterial({ color:'#a07a52', roughness:.8 })); deck.position.set(0.4, 2.42, 0); S.add(deck);
  /* 선미루(뒤쪽 높은 갑판) = 선장실. 뒷면 창 5개에 불이 켜져 있어요 */
  const castle = new THREE.Mesh(new THREE.BoxGeometry(3.2, 2.2, 3.9), hullMat); castle.position.set(-4.7, 3.5, 0); S.add(castle);
  const castleTrim = new THREE.Mesh(new THREE.BoxGeometry(3.4, 0.14, 4.1), trimMat); castleTrim.position.set(-4.7, 4.66, 0); S.add(castleTrim);
  const winMat = new THREE.MeshStandardMaterial({ color:'#ffd58a', emissive:'#ffb050', emissiveIntensity:1.2 });
  IN.windows = winMat;
  for (let k = 0; k < 5; k++){ const wnd = new THREE.Mesh(new THREE.PlaneGeometry(0.5, 0.75), winMat); wnd.position.set(-6.31, 3.45, -1.4 + k * 0.7); wnd.rotation.y = -Math.PI / 2; S.add(wnd); }
  [-1.95, 1.95].forEach(z => { for (let k = 0; k < 2; k++){ const wnd = new THREE.Mesh(new THREE.PlaneGeometry(0.45, 0.6), winMat); wnd.position.set(-5.3 + k * 1.2, 3.5, z * 1.01); wnd.rotation.y = z > 0 ? 0 : Math.PI; S.add(wnd); } });
  const lantern = new THREE.Sprite(new THREE.SpriteMaterial({ map:glowTex, color:'#ffcf7a', transparent:true, opacity:.9, blending:THREE.AdditiveBlending, depthWrite:false })); lantern.scale.set(1.6, 1.6, 1); lantern.position.set(-6.5, 5.2, 0); S.add(lantern);
  const lampPost = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 0.8, 6), trimMat); lampPost.position.set(-6.3, 4.9, 0); S.add(lampPost);
  /* 난간 */
  [-1.85, 1.85].forEach(z => { const rail = new THREE.Mesh(new THREE.BoxGeometry(9.4, 0.08, 0.08), trimMat); rail.position.set(1.6, 3.0, z); S.add(rail);
    for (let x = -2.8; x <= 6.2; x += 0.9){ const post = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.55, 0.07), trimMat); post.position.set(x, 2.75, z); S.add(post); } });
  /* 돛대 · 돛 */
  const mastMat = new THREE.MeshStandardMaterial({ color:'#5a3820', roughness:.7 });
  const sailMat = new THREE.MeshStandardMaterial({ color:'#f2e8d2', roughness:.9, side:THREE.DoubleSide, flatShading:true });
  const emblemMat = new THREE.MeshStandardMaterial({ map:emblemTex(), roughness:.9, side:THREE.DoubleSide, flatShading:true });
  [[1.0, 11.5, [[4.6, 3.6, 7.2, emblemMat], [3.8, 2.6, 10.3, sailMat]]], [4.6, 9.0, [[3.8, 3.0, 6.3, sailMat], [3.0, 2.2, 8.7, sailMat]]], [-3.4, 8.6, [[3.0, 2.6, 6.6, sailMat]]]].forEach(([x, h, sails]) => {
    const m = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.16, h, 10), mastMat); m.position.set(x, 2.4 + h / 2, 0); S.add(m);
    sails.forEach(([w, hh, y, mat]) => {
      const yard = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, w + 0.6, 8), mastMat); yard.rotation.x = Math.PI / 2; yard.position.set(x, y + hh / 2, 0); S.add(yard);
      const sail = new THREE.Mesh(sailGeo(w, hh, 0.55), mat); sail.position.set(x + 0.12, y, 0); sail.rotation.y = Math.PI / 2; S.add(sail); IN.sails.push(sail);
    });
  });
  /* 뱃머리 기움돛대 · 삼각돛 */
  const bow = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.1, 4.2, 8), mastMat); bow.rotation.z = Math.PI / 2 - 0.3; bow.position.set(8.6, 3.0, 0); S.add(bow);
  const jibG = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(4.6, 10.4, 0), new THREE.Vector3(10.4, 3.6, 0), new THREE.Vector3(5.0, 3.4, 0)]); jibG.computeVertexNormals();
  S.add(new THREE.Mesh(jibG, sailMat));
  /* 깃발: 펄럭임 */
  const fG = new THREE.PlaneGeometry(1.8, 1.1, 10, 4); IN.flagBase = Float32Array.from(fG.attributes.position.array);
  const flag = new THREE.Mesh(fG, new THREE.MeshStandardMaterial({ map:canvasTex(256, 160, (g, w, h) => { g.fillStyle = '#8a2a1c'; g.fillRect(0, 0, w, h); g.fillStyle = '#f2e8d2'; g.font = `700 92px ${FD}`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('⚓', w / 2, h / 2 + 6); }), side:THREE.DoubleSide, roughness:.8 }));
  flag.position.set(1.0 - 0.9, 2.4 + 11.5 + 0.2, 0); S.add(flag); IN.flag = flag;
  /* 위에서 보이는 갑판 소품: 해치 · 통 · 밧줄 */
  const hatch = new THREE.Mesh(new THREE.BoxGeometry(1.4, 0.12, 1.2), new THREE.MeshStandardMaterial({ color:'#6b4528', roughness:.7 })); hatch.position.set(2.8, 2.55, 0); S.add(hatch);
  [[-2.2, 1.1], [-2.2, -1.1], [6.0, 0.9]].forEach(([x, z]) => { const b = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.32, 0.7, 12), new THREE.MeshStandardMaterial({ color:'#7a5230', roughness:.7 })); b.position.set(x, 2.85, z); S.add(b); });
  const coil = new THREE.Mesh(new THREE.TorusGeometry(0.4, 0.1, 6, 20), new THREE.MeshStandardMaterial({ color:'#c9b08a', roughness:.9 })); coil.rotation.x = Math.PI / 2; coil.position.set(-0.6, 2.56, 1.1); S.add(coil);
  /* 배 뒤 물보라 자국 · 선체 둘레 거품 (배와 함께 흔들려요) */
  const wakeTex = canvasTex(256, 512, (g, w, h) => {
    g.clearRect(0, 0, w, h);
    for (let i = 0; i < 260; i++){ const y = rand(0, h), spread = (y / h) * w * 0.48 + 10, x = w / 2 + (Math.random() < .5 ? -1 : 1) * spread * rand(.7, 1);
      g.fillStyle = `rgba(255,255,255,${(1 - y / h) * rand(.25, .7)})`; g.beginPath(); g.ellipse(x, y, rand(3, 9), rand(2, 5), 0, 0, Math.PI * 2); g.fill(); }
    const core = g.createLinearGradient(0, 0, 0, h); core.addColorStop(0, 'rgba(255,255,255,.55)'); core.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = core; g.fillRect(w / 2 - 14, 0, 28, h);
  });
  wakeTex.wrapT = THREE.RepeatWrapping;
  IN.wake = new THREE.Mesh(new THREE.PlaneGeometry(16, 34), new THREE.MeshBasicMaterial({ map:wakeTex, transparent:true, depthWrite:false, opacity:.85 }));
  IN.wake.rotation.x = -Math.PI / 2; IN.wake.rotation.z = -Math.PI / 2; IN.wake.position.set(-22.5, 0.65, 0); S.add(IN.wake);
  IN.foam = new THREE.Mesh(new THREE.PlaneGeometry(17, 7), new THREE.MeshBasicMaterial({ map:glowTex, color:'#ffffff', transparent:true, opacity:.5, depthWrite:false }));
  IN.foam.rotation.x = -Math.PI / 2; IN.foam.position.set(0.4, 0.6, 0); S.add(IN.foam);
  S.rotation.y = 0.5;   // 뱃머리가 오른쪽 위를 향해요
  introScene.add(S); IN.ship = S;
}

function buildIntro(){
  IN.hemi = new THREE.HemisphereLight('#dff0ff', '#2a4a5a', .9); introScene.add(IN.hemi);
  IN.light = new THREE.DirectionalLight('#fff1d6', 1.3); IN.light.position.set(40, 60, 30); introScene.add(IN.light);
  introScene.fog = new THREE.Fog('#d6ecf6', 60, 520);
  IN.sky = new THREE.Mesh(new THREE.SphereGeometry(700, 32, 16), new THREE.MeshBasicMaterial({ side:THREE.BackSide, fog:false })); introScene.add(IN.sky);
  IN.sun = new THREE.Sprite(new THREE.SpriteMaterial({ map:glowTex, color:'#fff4d6', transparent:true, fog:false, depthWrite:false, blending:THREE.AdditiveBlending })); IN.sun.scale.set(150, 150, 1); IN.sun.position.set(-320, 140, -420); introScene.add(IN.sun);
  /* 가까운 바다: 낮은 폴리곤 물결 */
  const g = new THREE.PlaneGeometry(300, 300, 84, 84); g.rotateX(-Math.PI / 2);
  IN.seaBase = Float32Array.from(g.attributes.position.array);
  IN.sea = new THREE.Mesh(g, new THREE.MeshStandardMaterial({ color:'#ffffff', roughness:.5, metalness:0, flatShading:true })); introScene.add(IN.sea);
  IN.far = new THREE.Mesh(new THREE.PlaneGeometry(2400, 2400), new THREE.MeshStandardMaterial({ color:'#1583bf', roughness:.5 })); IN.far.rotation.x = -Math.PI / 2; IN.far.position.y = -0.9; introScene.add(IN.far);
  /* 구름 */
  const cloudMat = new THREE.MeshStandardMaterial({ color:'#ffffff', emissive:'#ffffff', emissiveIntensity:.35, roughness:1, flatShading:true, transparent:true, opacity:.92 });
  /* 하늘 시점: 구름은 카메라(높이 78)와 바다 사이를 지나가고, 바다에 그림자를 드리워요 */
  const shadowMat = new THREE.MeshBasicMaterial({ map:glowTex, color:'#0b4a66', transparent:true, opacity:.22, depthWrite:false });
  for (let i = 0; i < 7; i++){
    const c = new THREE.Group();
    for (let k = 0; k < 6; k++){ const b = new THREE.Mesh(new THREE.IcosahedronGeometry(rand(3.5, 6.5), 1), cloudMat); b.position.set(k * rand(3.5, 5.5), rand(-1, 1), rand(-3.5, 3.5)); b.scale.y = .5; c.add(b); }
    c.position.set(rand(-120, 80), rand(30, 46), rand(-70, 60)); introScene.add(c); IN.clouds.push(c);
    const sh = new THREE.Mesh(new THREE.PlaneGeometry(46, 22), shadowMat); sh.rotation.x = -Math.PI / 2; introScene.add(sh); IN.shadows.push(sh);
  }
  /* 햇빛 반짝임 */
  for (let i = 0; i < 46; i++){
    const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map:glowTex, color:'#ffffff', transparent:true, opacity:0, blending:THREE.AdditiveBlending, depthWrite:false }));
    sp.scale.setScalar(rand(0.8, 1.8)); sp.position.set(rand(-90, 60), 0.9, rand(-60, 50)); sp.userData.ph = rand(0, 6); introScene.add(sp); IN.glints.push(sp);
  }
  buildShip();
  introTime(timeMode);
}

/* 낮 / 밤 (선장실 창밖 설정과 같아요) */
function introTime(mode){
  const day = mode === 'day';
  IN.sky.material.map = domeTex[mode] || (domeTex[mode] = skyDomeTex(mode)); IN.sky.material.needsUpdate = true;
  introScene.fog.color.set(day ? '#2f9fd0' : '#0b2a48'); introScene.fog.near = 170; introScene.fog.far = 520;
  IN.sea.material.map = seaTexs[mode] || (seaTexs[mode] = seaTex(mode)); IN.sea.material.needsUpdate = true;
  IN.far.material.color.set(day ? '#1583bf' : '#0b2a48');
  IN.hemi.color.set(day ? '#cfeaff' : '#5a7aa8'); IN.hemi.groundColor.set(day ? '#0a3a55' : '#05101c');
  IN.hemi.intensity = day ? .55 : .3; IN.light.intensity = day ? .95 : .3; IN.light.color.set(day ? '#fff1d6' : '#9fb6e0');
  IN.sun.material.color.set(day ? '#fff4d6' : '#dfe8f8'); IN.sun.scale.setScalar(day ? 150 : 70);
  IN.clouds.forEach(c => c.children.forEach(b => { b.material.color.set(day ? '#ffffff' : '#5a6a88'); b.material.emissiveIntensity = day ? .35 : .05; }));
  IN.glints.forEach(g => { g.material.color.set(day ? '#ffffff' : '#cfe0ff'); });
  IN.shadows.forEach(sh => { sh.visible = day; });
  IN.windows.emissiveIntensity = day ? 0.9 : 1.6;
}

/* 한 프레임 */
const _shipLook = new THREE.Vector3(), _fromPos = new THREE.Vector3(), _fromLook = new THREE.Vector3();
function introStep(dt, time){
  const t = reduceMotion ? 0 : time;
  /* 바다 물결 */
  const p = IN.sea.geometry.attributes.position, b = IN.seaBase;
  for (let i = 0; i < p.count; i++){ const x = b[i * 3], z = b[i * 3 + 2]; p.array[i * 3 + 1] = waveH(x, z, t); }
  p.needsUpdate = true; IN.sea.geometry.computeVertexNormals();
  /* 배: 물결 따라 오르내리고 기울어요 */
  const S = IN.ship;
  S.position.y = waveH(0, 0, t) * 0.7 - 0.55;
  S.rotation.z = (waveH(3, 0, t) - waveH(-3, 0, t)) * 0.06;
  S.rotation.x = (waveH(0, 2, t) - waveH(0, -2, t)) * 0.08;
  /* 깃발 펄럭 */
  const fp = IN.flag.geometry.attributes.position, fb = IN.flagBase;
  for (let i = 0; i < fp.count; i++){ const x = fb[i * 3], k = (0.9 - x) / 1.8; /* 돛대 쪽(+x)은 고정 */ fp.array[i * 3 + 2] = Math.sin(x * 3.2 - t * 6) * 0.18 * k; }
  fp.needsUpdate = true;
  /* 둥실둥실: 천천히 크게 오르내리고, 뱃머리가 살짝 좌우로 */
  S.position.y += Math.sin(t * 0.9) * 0.25;
  S.rotation.y = 0.5 + Math.sin(t * 0.22) * 0.06;
  IN.wake.material.map.offset.y = (t * 0.25) % 1;
  if (IN.sea.material.map){ IN.sea.material.map.offset.x = (t * 0.006) % 1; IN.sea.material.map.offset.y = (t * 0.004) % 1; }
  IN.foam.material.opacity = 0.42 + Math.sin(t * 1.3) * 0.1;
  IN.clouds.forEach((c, i) => {
    c.position.x += dt * (1.4 + i * 0.12); if (c.position.x > 120) c.position.x = -150;
    const sh = IN.shadows[i]; sh.position.set(c.position.x + 10, 0.95, c.position.z + 6);
  });
  IN.glints.forEach(g => { g.material.opacity = Math.max(0, Math.sin(t * 2.4 + g.userData.ph * 3)) * 0.9; });
  /* 카메라: 하늘 높이(78)에서 내려다봐요. 배가 화면 오른쪽 아래(휴대폰은 오른쪽 위)에 오게 */
  const aspect = window.innerWidth / window.innerHeight, H = 78, tilt = 14;
  const halfH = Math.tan(introCam.fov * Math.PI / 360) * H, halfW = halfH * aspect;
  const nx = aspect < 1 ? 0.22 : 0.42, ny = aspect < 1 ? 0.3 : -0.36;
  const drift = reduceMotion ? 0 : 1;
  const L = new THREE.Vector3(-nx * halfW + Math.sin(t * 0.05) * 3 * drift, 0, ny * halfH + Math.cos(t * 0.04) * 2 * drift);
  _shipLook.copy(L);
  if (IN.fly){
    const f = IN.fly; f.t += dt; const k = Math.min(1, f.t / f.dur), e = k < .5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2;
    S.updateMatrixWorld(true);
    const target = S.localToWorld(new THREE.Vector3(-9.6, 3.6, 0)), look = S.localToWorld(new THREE.Vector3(-6.3, 3.45, 0));
    /* 위에서 비스듬히 내려와 선미 창 앞에 멈춰요 */
    const mid = new THREE.Vector3().copy(f.from).lerp(target, e); mid.y += Math.sin(e * Math.PI) * 8;
    introCam.up.set(0, 1, 0).lerp(new THREE.Vector3(0, 0, -1), 1 - e).normalize();
    introCam.position.copy(mid);
    introCam.lookAt(_fromLook.copy(f.fromLook).lerp(look, e));
    if (k >= 1 && !f.done){ f.done = true; f.then(); }
  } else {
    introCam.up.set(0, 0, -1);
    introCam.position.set(L.x, H, L.z + tilt); introCam.lookAt(L);
  }
}
/* 선미 창으로 날아가기 → then() */
function flyIntoCabin(then){
  if (reduceMotion){ then(); return; }
  IN.fly = { t:0, dur:3.0, from:introCam.position.clone(), fromLook:_shipLook.clone(), then, done:false };
}
