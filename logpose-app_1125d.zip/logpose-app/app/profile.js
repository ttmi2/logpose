/* ============================================================
   LOG POSE · 이용자 정보 저장
   지금은 이 브라우저에만 저장해요 (라프텔 로그인이 체험용이라 계정 서버가 없어요).
   나중에 실제 연동이나 서버 저장으로 바꿀 때는 이 파일의 store 만 바꾸면 돼요.
   ============================================================ */
/* 폼 제출이 막힌 화면(대화창 미리보기 · 일부 앱 안 브라우저)에서도 '출항하기' 같은 버튼이 동작하게:
   제출 버튼을 누르면(엔터 포함) 페이지 이동 없이 submit 이벤트만 직접 보내요. 일반 브라우저에서도 똑같이 동작해요. */
document.addEventListener('click', e => {
  const b = e.target && e.target.closest ? e.target.closest('button[type="submit"], input[type="submit"]') : null;
  if (!b || !b.form || b.disabled) return;
  e.preventDefault();
  b.form.dispatchEvent(new Event('submit', { bubbles:true, cancelable:true }));
}, true);
const LPProfile = (() => {
  const KEY = 'logpose.profile', SESSION = 'logpose.in';
  const mem = {};
  const store = {
    get(k){ try { return localStorage.getItem(k); } catch(e){ return mem[k] ?? null; } },
    set(k, v){ try { localStorage.setItem(k, v); } catch(e){ mem[k] = v; } },
    del(k){ try { localStorage.removeItem(k); } catch(e){} delete mem[k]; }
  };
  const session = {
    get(){ try { return sessionStorage.getItem(SESSION) === '1'; } catch(e){ return !!mem[SESSION]; } },
    set(on){ try { on ? sessionStorage.setItem(SESSION, '1') : sessionStorage.removeItem(SESSION); } catch(e){ if (on) mem[SESSION] = 1; else delete mem[SESSION]; } }
  };
  const KINDS = { guest:'비회원', 'laftel-demo':'라프텔 연동 · 체험' };

  function read(){ try { const v = JSON.parse(store.get(KEY) || 'null'); return v && typeof v === 'object' && v.nickname ? v : null; } catch(e){ return null; } }
  function write(p){ store.set(KEY, JSON.stringify(p)); return p; }

  /* 닉네임: 앞뒤 공백 제거, 2~12자, 꺾쇠·따옴표 같은 기호 금지 */
  function checkName(raw){
    /* 이름 뒤에 '선장'이 자동으로 붙으니, 직접 쓴 '선장'은 떼어 내요 (루피선장 → 루피) */
    const n = String(raw || '').replace(/\s+/g, ' ').trim().replace(/\s*선장$/, '');
    if (n.length < 2) return { ok:false, msg:'닉네임은 2자 이상이에요. (뒤의 ‘선장’은 빼고 적어 주세요)' };
    if (n.length > 12) return { ok:false, msg:'닉네임은 12자까지 쓸 수 있어요.' };
    if (/[<>"'`\\]/.test(n)) return { ok:false, msg:'꺾쇠나 따옴표 같은 기호는 쓸 수 없어요.' };
    return { ok:true, name:n };
  }

  /* 배 이름: '○○호' 로 끝나요 (호를 안 붙여도 붙여 줘요) · 호 앞 1~10자 */
  function checkShip(raw){
    let n = String(raw || '').replace(/\s+/g, ' ').trim().replace(/\s*호$/, '');
    if (!n) return { ok:false, msg:'배 이름을 정해 주세요. (예: 써니 → 써니호)' };
    if (n.length > 10) return { ok:false, msg:'배 이름은 ‘호’ 앞까지 10자 안이에요.' };
    if (/[<>"'`\\]/.test(n)) return { ok:false, msg:'꺾쇠나 따옴표 같은 기호는 쓸 수 없어요.' };
    return { ok:true, name:n + '호' };
  }

  return {
    KINDS,
    get:read,
    checkName, checkShip,
    create(nickname, kind, ship){
      const now = new Date().toISOString();
      return write({ v:1, nickname, ship:ship || '', kind:KINDS[kind] ? kind : 'guest', createdAt:now, lastSeen:now, onboarded:false, taste:null, saved:[] });
    },
    update(patch){ const p = read(); if (!p) return null; return write(Object.assign(p, patch)); },
    touch(){ return this.update({ lastSeen:new Date().toISOString() }); },
    clear(){ store.del(KEY); session.set(false); },
    isIn:() => session.get() && !!read(),
    signIn(){ session.set(true); this.touch(); },
    signOut(){ session.set(false); },
    kindLabel:p => KINDS[p && p.kind] || KINDS.guest
  };
})();
