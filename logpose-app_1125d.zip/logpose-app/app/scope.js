/* ============================================================
   LOG POSE · 갑판 2단계: 수평선의 두 섬 + 뱃머리 망원경
   라프텔 중앙 섬(크게, 멀리) · 그 앞 다모였섬(작게, 해적 마을)
   망원경: 둥근 시야로 확대 → ‹ › 로 섬 바꾸기 → 라프텔로 가기 · 다모였섬으로 가기 (둘 다 준비 중)
   섬은 한 작품의 섬이 아니라 항해의 목적지예요. 특정 작품 속 섬을 따라 그리지 않았어요.
   ============================================================ */
const ISLES = [];
/* 같은 입력엔 같은 울퉁불퉁함 (새로고침해도 섬 모양이 그대로) */
const hash3 = (x, y, z) => { const s = Math.sin(x * 12.9898 + y * 78.233 + z * 37.719) * 43758.5453; return s - Math.floor(s); };
function rough(geo, amt, keepBottom){
  const p = geo.attributes.position;
  for (let i = 0; i < p.count; i++){
    const x = p.getX(i), y = p.getY(i), z = p.getZ(i);
    if (keepBottom && y <= keepBottom) continue;
    const k = (hash3(Math.round(x * 4), Math.round(y * 4), Math.round(z * 4)) - .5) * 2 * amt;
    const r = Math.hypot(x, z) || 1; p.setXYZ(i, x + x / r * k, y + k * .35, z + z / r * k);
  }
  geo.computeVertexNormals(); return geo;
}
const flat = c => new THREE.MeshStandardMaterial({ color:c, roughness:.9, flatShading:true });


/* 야자수: 살짝 휜 줄기 + 사방으로 늘어진 잎 + 코코넛 (다모였섬 · 망원경 속 섬이 같이 써요) */
function palmLeafGeo(L){
  const g = new THREE.PlaneGeometry(1.7, L, 2, 10); g.rotateX(-Math.PI / 2); g.translate(0, 0, L / 2);
  const p = g.attributes.position;
  for (let i = 0; i < p.count; i++){
    const x = p.getX(i), z = p.getZ(i), t = z / L;
    const wdt = (1 - t * 0.9) * (0.55 + 0.45 * Math.sin(Math.min(1, t * 1.6) * Math.PI / 2));
    p.setX(i, x * wdt); p.setY(i, t * L * 0.28 - t * t * L * 0.62 - Math.abs(x * wdt) * 0.35);
  }
  g.computeVertexNormals(); return g;
}
const PALM = { trunk:null, ring:null, leaf:null, nut:null, geo:{} };
function makePalm(h = 7, lean = 0.2, leaves = 8){
  if (!PALM.trunk){ PALM.trunk = flat('#9a7a52'); PALM.ring = flat('#7a5c3a'); PALM.leaf = new THREE.MeshStandardMaterial({ color:'#3f8f3a', roughness:.85, flatShading:true, side:THREE.DoubleSide }); PALM.nut = flat('#6b4a2a'); }
  const root = new THREE.Group();
  /* 줄기: 마디 다섯 개가 조금씩 기울며 이어져요 */
  let node = root; const seg = h / 5;
  for (let k = 0; k < 5; k++){
    const s = new THREE.Group(); s.position.y = k ? seg : 0; s.rotation.z = lean / 5 * (k ? 1.4 : 0.6); node.add(s);
    const r0 = 0.42 - k * 0.05, r1 = r0 - 0.05;
    const c = new THREE.Mesh(new THREE.CylinderGeometry(r1, r0, seg, 8), PALM.trunk); c.position.y = seg / 2; s.add(c);
    const ring = new THREE.Mesh(new THREE.CylinderGeometry(r1 + 0.04, r1 + 0.04, 0.12, 8), PALM.ring); ring.position.y = seg - 0.05; s.add(ring);
    node = s;
  }
  const crown = new THREE.Group(); crown.position.y = seg; node.add(crown);
  const L = h * 0.62, geo = PALM.geo[L] || (PALM.geo[L] = palmLeafGeo(L));
  for (let k = 0; k < leaves; k++){
    const piv = new THREE.Group(); piv.rotation.y = k / leaves * Math.PI * 2 + Math.sin(k * 2.3) * 0.25; crown.add(piv);
    const lf = new THREE.Mesh(geo, PALM.leaf); lf.rotation.x = -0.25 + Math.sin(k * 1.7) * 0.15; piv.add(lf);
  }
  for (let k = 0; k < 3; k++){ const a = k / 3 * Math.PI * 2; const n = new THREE.Mesh(new THREE.SphereGeometry(0.26, 8, 6), PALM.nut); n.position.set(Math.cos(a) * 0.32, -0.25, Math.sin(a) * 0.32); crown.add(n); }
  return { root, crown };
}

function buildLaftelIsle(){
  const I = new THREE.Group(); I.position.set(62, -3.0, 250);
  const rock = flat('#8a7663'), rockD = flat('#6a5848'), grass = flat('#4f9a45'), grassD = flat('#3b7a38'), sand = flat('#e8d6a6'), white = flat('#f4f0e6'), red = flat('#b0392a');
  const m = (geo, mat, x, y, z) => { const o = new THREE.Mesh(geo, mat); o.position.set(x, y, z); I.add(o); return o; };
  m(new THREE.CylinderGeometry(58, 64, 2.4, 28), sand, 0, 0.6, 0);                                   // 모래톱
  m(rough(new THREE.CylinderGeometry(44, 54, 18, 16, 3), 3.2, -8.5), rock, 0, 10, 0);                // 절벽 받침
  m(rough(new THREE.CylinderGeometry(40, 44, 5, 16, 1), 2, 0), grass, 0, 20.5, 0);                   // 위 들판
  /* 우뚝 솟은 봉우리 셋 (가운데가 가장 높아요) */
  m(rough(new THREE.ConeGeometry(17, 74, 9, 4), 2.6, 0), rockD, -4, 58, -6);
  m(rough(new THREE.ConeGeometry(9, 26, 8, 2), 1.4, 0), grassD, -4, 82, -6).scale.set(1, 1, 1);
  m(rough(new THREE.ConeGeometry(13, 46, 8, 3), 2.2, 0), rock, 22, 44, 4);
  m(rough(new THREE.ConeGeometry(11, 38, 8, 3), 2.0, 0), rock, -26, 40, 8);
  /* 섬보다 큰 나무: 들판 왼쪽에 우뚝 */
  m(new THREE.CylinderGeometry(3.2, 4.6, 34, 9), flat('#6b4528'), -24, 39, -24);
  [[0, 0, 0, 15], [10, -3, 4, 11], [-10, -2, -3, 11], [3, 6, -8, 10], [-4, 5, 9, 9]].forEach(([x, y, z, r]) => { const c = m(new THREE.IcosahedronGeometry(r, 1), grass, -24 + x, 60 + y, -24 + z); c.scale.y = .72; });
  /* 폭포 두 줄기 (흘러내려요) */
  const fallTex = canvasTex(64, 256, (g, w, h) => { g.fillStyle = 'rgba(230,246,255,.9)'; g.fillRect(0, 0, w, h); for (let i = 0; i < 40; i++){ g.fillStyle = `rgba(150,200,230,${rand(.2, .5)})`; g.fillRect(rand(0, w), rand(0, h), rand(2, 6), rand(20, 60)); } }); fallTex.wrapT = THREE.RepeatWrapping;
  const fallMat = new THREE.MeshBasicMaterial({ map:fallTex, transparent:true, opacity:.85, side:THREE.DoubleSide });
  [[-14, 30], [12, 22]].forEach(([x, w]) => { const f = m(new THREE.PlaneGeometry(w * .22, 20), fallMat, x, 12, -43); f.rotation.y = Math.PI; void f; });
  const mist = new THREE.Sprite(new THREE.SpriteMaterial({ map:glowTex, color:'#ffffff', transparent:true, opacity:.55, depthWrite:false })); mist.scale.set(26, 9, 1); mist.position.set(-2, 2.5, -46); I.add(mist);
  /* 등대: 오른쪽 봉우리 어깨에 */
  const lh = new THREE.Group(); lh.position.set(34, 22, -18); I.add(lh);
  for (let k = 0; k < 4; k++){ const seg = new THREE.Mesh(new THREE.CylinderGeometry(2.0 - k * .3, 2.3 - k * .3, 4, 10), k % 2 ? red : white); seg.position.y = 2 + k * 4; lh.add(seg); }
  const lamp = new THREE.Mesh(new THREE.CylinderGeometry(1.4, 1.4, 2, 8), new THREE.MeshStandardMaterial({ color:'#fff0b0', emissive:'#ffcf6a', emissiveIntensity:.6 })); lamp.position.y = 17; lh.add(lamp);
  const cap = new THREE.Mesh(new THREE.ConeGeometry(1.9, 2.4, 8), red); cap.position.y = 19.2; lh.add(cap);
  const beacon = new THREE.Sprite(new THREE.SpriteMaterial({ map:glowTex, color:'#ffe6a0', transparent:true, opacity:.5, blending:THREE.AdditiveBlending, depthWrite:false, fog:false })); beacon.scale.set(14, 14, 1); beacon.position.y = 17; lh.add(beacon);
  const beam = new THREE.Mesh(new THREE.ConeGeometry(5, 70, 16, 1, true), new THREE.MeshBasicMaterial({ color:'#ffe6a0', transparent:true, opacity:.12, blending:THREE.AdditiveBlending, depthWrite:false, side:THREE.DoubleSide, fog:false }));
  beam.geometry.translate(0, -35, 0); beam.rotation.z = Math.PI / 2; const pivot = new THREE.Group(); pivot.position.y = 17; pivot.add(beam); lh.add(pivot);
  /* 섬 허리를 감싼 뭉게구름 */
  const cl = new THREE.MeshStandardMaterial({ color:'#ffffff', emissive:'#ffffff', emissiveIntensity:.4, roughness:1, flatShading:true, transparent:true, opacity:.9 });
  for (let k = 0; k < 14; k++){ const a = k / 14 * Math.PI * 2 + hash3(k, 1, 2), r = 46 + hash3(k, 3, 4) * 10; const c = new THREE.Mesh(new THREE.IcosahedronGeometry(6 + hash3(k, 5, 6) * 5, 1), cl); c.position.set(Math.cos(a) * r, 30 + hash3(k, 7, 8) * 10, Math.sin(a) * r); c.scale.y = .55; I.add(c); }
  DK3.out.add(I);
  ISLES.push({ id:'laftel', name:'라프텔', kick:'모든 항해의 끝', group:I, look:new THREE.Vector3(62, 45, 250), ax:62, az:250, fov:22, R:66,
    desc:'로그포스가 가리키던 모든 작품이 기다리는 큰 섬이에요. 마음에 든 작품을 실제로 보러 가는 곳이에요.',
    go:'라프텔로 가기', lockNote:'라프텔 주소가 연결되면 이 버튼으로 바로 출항해요.', lamp, beacon, beam:pivot, cloudMat:cl, fall:fallTex });
}

function buildPublicIsle(){
  const I = new THREE.Group(); I.position.set(-40, -2.9, 150);
  const sand = flat('#ecdcae'), grass = flat('#62a94e'), wood = flat('#8a6440'), woodD = flat('#5a3e26');
  const m = (geo, mat, x, y, z, p = I) => { const o = new THREE.Mesh(geo, mat); o.position.set(x, y, z); p.add(o); return o; };
  m(new THREE.CylinderGeometry(16, 18, 2, 20), sand, 0, 0.5, 0);
  m(rough(new THREE.CylinderGeometry(11, 13.5, 3.2, 14, 1), 1.0, -1), grass, -1, 2.6, 1);
  m(rough(new THREE.SphereGeometry(3.2, 10, 6, 0, Math.PI * 2, 0, Math.PI / 2), 0.5, 0), grass, -10, 4, 8);   /* 뒤쪽 작은 언덕 (마을을 가리지 않게) */
  /* 야자나무 */
  [[-8, 4, 0.3], [-5, -7, -0.2], [9, -4, 0.15]].forEach(([x, z, lean]) => {
    const P = makePalm(8, lean * 1.5, 7); P.root.position.set(x, 3.5, z); P.root.rotation.y = x; I.add(P.root);
  });
  /* 해적 마을: 육각 주점 · 시장 천막 · 현상금 게시판 · 광장 분수 · 등불 · 깃발줄 · 섬 깃발 (다모였섬 실제 모습을 줄여서) */
  const V = new THREE.Group(); V.position.set(0, 4.2, 0); V.rotation.y = Math.PI; I.add(V);   /* 앞면이 내 배(망원경) 쪽을 봐요 */
  const roofR = flat('#8a3a24'), stone = flat('#b8ad94'), wallW = flat('#b88a5a');
  /* 주점 럼통: 육각 몸통 + 빨간 지붕 + 굴뚝 */
  const T = new THREE.Group(); T.position.set(-4, 0, -2); V.add(T);
  m(new THREE.CylinderGeometry(3, 3.2, 3.2, 6), wallW, 0, 1.6, 0, T);
  m(new THREE.ConeGeometry(4, 2.6, 6), roofR, 0, 4.5, 0, T);
  m(new THREE.BoxGeometry(0.7, 2, 0.7), stone, 1.4, 5, -0.6, T);
  m(new THREE.BoxGeometry(1.2, 1.8, 0.2), woodD, 0, 0.9, 2.95, T);
  const glowWin = new THREE.MeshStandardMaterial({ color:'#ffd58a', emissive:'#ffb050', emissiveIntensity:.9 });
  [[-1.6, 1.9, 2.55], [1.6, 1.9, 2.55]].forEach(([x, y, z]) => m(new THREE.CircleGeometry(0.4, 12), glowWin, x, y, z, T));
  /* 시장 천막 셋 (줄무늬 차양) */
  const awn = c => new THREE.MeshStandardMaterial({ map:canvasTex(64, 32, (g, w, h) => { for (let i = 0; i < 6; i++){ g.fillStyle = i % 2 ? '#f2e8d2' : c; g.fillRect(i * w / 6, 0, w / 6, h); } }), side:THREE.DoubleSide, roughness:.9 });
  [['#c0392b', 3.5], ['#2f6f9f', 6.3], ['#d9a33a', 9.1]].forEach(([c, x]) => {
    m(new THREE.BoxGeometry(2.2, 1, 1.2), wood, x, 0.5, 4.2, V);
    [-1, 1].forEach(s => m(new THREE.CylinderGeometry(0.07, 0.07, 2.4, 5), woodD, x + s * 1.05, 1.2, 3.7, V));
    const a = m(new THREE.PlaneGeometry(2.6, 1.5), awn(c), x, 2.3, 4.2, V); a.rotation.x = -Math.PI / 2 + 0.45;
    m(new THREE.BoxGeometry(0.4, 0.3, 0.3), flat(c), x - 0.5, 1.15, 4.3, V); });
  /* 현상금 게시판 */
  const bd = canvasTex(128, 64, (g, w, h) => { g.fillStyle = '#6a4628'; g.fillRect(0, 0, w, h); [[8, 6, 30, 40], [44, 10, 24, 32], [74, 4, 30, 42], [106, 12, 16, 26]].forEach(([x, y, pw, ph], i) => { g.fillStyle = i === 2 ? '#f2e2b0' : '#e8d8b0'; g.fillRect(x, y, pw, ph); g.fillStyle = '#8a2a1c'; g.fillRect(x + 3, y + 3, pw - 6, 5); }); });
  m(new THREE.PlaneGeometry(4.2, 2.1), new THREE.MeshStandardMaterial({ map:bd, side:THREE.DoubleSide, roughness:.9 }), 3, 2.2, -6.2, V);
  [-1, 1].forEach(s => m(new THREE.CylinderGeometry(0.1, 0.1, 3.4, 6), woodD, 3 + s * 2.2, 1.7, -6.2, V));
  m(new THREE.BoxGeometry(4.8, 0.25, 0.5), roofR, 3, 3.45, -6.2, V);
  /* 광장 분수 · 등불 넷 */
  m(new THREE.CylinderGeometry(1.4, 1.5, 0.6, 14), stone, 3.2, 0.3, 0.6, V);
  m(new THREE.CylinderGeometry(1.15, 1.15, 0.05, 14), new THREE.MeshStandardMaterial({ color:'#5fb8d6', roughness:.2 }), 3.2, 0.58, 0.6, V);
  m(new THREE.CylinderGeometry(0.15, 0.22, 1.4, 8), stone, 3.2, 1.1, 0.6, V);
  [[0.6, -1.6], [5.8, -1.6], [0.6, 2.8], [5.8, 2.8]].forEach(([x, z]) => { m(new THREE.CylinderGeometry(0.06, 0.06, 2.2, 5), M.iron, x, 1.1, z, V); m(new THREE.BoxGeometry(0.35, 0.4, 0.35), glowWin, x, 2.3, z, V); });
  /* 깃발줄 (광장 위 삼각 깃발) */
  const bunt = []; for (let k = 0; k <= 10; k++){ const t = k / 10; bunt.push(new THREE.Vector3(0.6 + 5.2 * t, 2.6 - Math.sin(t * Math.PI) * 0.5, -1.6 + 4.4 * t)); }
  V.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(bunt), new THREE.LineBasicMaterial({ color:'#3a2616' })));
  bunt.slice(1, -1).forEach((p, k) => { const tri = m(new THREE.ConeGeometry(0.22, 0.45, 3), flat(['#c0392b', '#f2e8d2', '#2f6f9f', '#d9a33a'][k % 4]), p.x, p.y - 0.25, p.z, V); tri.rotation.x = Math.PI; });
  /* 작은 오두막 둘 */
  [[-8.5, 5.5, '#7a5634'], [9, -6.5, '#8a6440']].forEach(([x, z, c]) => { m(new THREE.BoxGeometry(2.4, 1.8, 2.2), flat(c), x, 0.9, z, V); const r = m(new THREE.ConeGeometry(2.1, 1.4, 4), roofR, x, 2.5, z, V); r.rotation.y = Math.PI / 4; });
  /* 섬 깃발: 높은 깃대 위 빨간 닻 깃발 (흔들려요) */
  m(new THREE.CylinderGeometry(.15, .15, 9, 6), woodD, 7.5, 4.5, -2.5, V);
  m(new THREE.SphereGeometry(0.3, 8, 6), M.brass, 7.5, 9.1, -2.5, V);
  const ft = canvasTex(256, 160, (g, w, h) => { g.fillStyle = '#8a2a1c'; g.fillRect(0, 0, w, h); g.fillStyle = '#f2e8d2'; g.font = `700 92px ${FD}`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('⚓', w / 2, h / 2 + 6); });
  const flag = m(new THREE.PlaneGeometry(4.4, 2.75), new THREE.MeshStandardMaterial({ map:ft, side:THREE.DoubleSide, roughness:.8 }), 9.75, 7.5, -2.5, V); flag.rotation.y = -0.5;
  /* 바다로 뻗은 공용 낚시터 잔교 (T자 머리) */
  m(new THREE.BoxGeometry(14, .3, 1.8), wood, -21, 1.6, 4, I);
  m(new THREE.BoxGeometry(2.2, .3, 7), wood, -28.5, 1.6, 4, I);
  for (let x = -16; x >= -28; x -= 3) [-1, 1].forEach(s => m(new THREE.CylinderGeometry(.18, .18, 3.4, 6), woodD, x, 0, 4 + s * 0.85, I));
  /* 작은 선착장 */
  m(new THREE.BoxGeometry(2.4, .3, 10), wood, -4, 1.4, -18);
  [[-5.1, -14], [-2.9, -14], [-5.1, -22], [-2.9, -22]].forEach(([x, z]) => m(new THREE.CylinderGeometry(.22, .22, 3.6, 6), woodD, x, 0, z));
  DK3.out.add(I);
  ISLES.push({ id:'public', name:'다모였섬', kick:'선장님들이 모이는 곳', group:I, look:new THREE.Vector3(-42, 7, 150), ax:-42, az:150, fov:9, R:19, flag,
    desc:'다른 선장님들과 만나 수배서를 붙이고, 유리병을 주고받고, 시장에서 물고기를 파는 섬이에요. 타륜을 돌려 가 볼까요?',
    go:'다모였섬으로 가기', lockNote:'섬을 짓는 중이에요. 곧 열려요!' });
}

/* 낮/밤 · 매 프레임 */
function islesTime(mode){
  const day = mode === 'day', L = ISLES.find(x => x.id === 'laftel'); if (!L) return;
  L.lamp.material.emissiveIntensity = day ? .5 : 2.2; L.beacon.material.opacity = day ? .3 : 1; L.beam.visible = !day;
  L.cloudMat.color.set(day ? '#ffffff' : '#56668a'); L.cloudMat.emissiveIntensity = day ? .4 : .05;
}
function islesStep(dt, t){
  const L = ISLES.find(x => x.id === 'laftel'); if (!L) return;
  L.beam.rotation.y = t * 0.6; L.fall.offset.y = -(t * 0.6) % 1;
  L.beacon.material.opacity = timeMode === 'day' ? .3 : .75 + Math.sin(t * 3) * .25;
  const P = ISLES.find(x => x.id === 'public'); if (P) P.flag.rotation.y = -0.5 + Math.sin(t * 2.4) * 0.12 * (reduceMotion ? 0 : 1);
  scopeStep(dt);
}

/* ---------- 망원경 ---------- */
const SC = { root:$('#scope'), name:$('#scName'), kick:$('#scKick'), desc:$('#scDesc'), idx:$('#scIdx'), go:$('#scGo'), note:$('#scNote'), close:$('#scClose'), prev:$('#scPrev'), next:$('#scNext') };
const scope = { open:false, i:0, look:new THREE.Vector3(), fov:58 };
const BASE_FOV = 58;
const scopeOpen = () => scope.open;

function scopeRender(){
  const I = ISLES[scope.i];
  SC.name.textContent = I.name; SC.kick.textContent = I.kick; SC.desc.textContent = I.desc; SC.idx.textContent = `${scope.i + 1} / ${ISLES.length}`;
  const url = I.id === 'laftel' && typeof LP_EXTRA !== 'undefined' && LP_EXTRA.laftelHome ? LP_EXTRA.laftelHome : '';
  const open = !!url || I.id === 'public';   /* 다모였섬은 열렸어요 → 타륜으로 */
  SC.go.dataset.url = url; SC.go.dataset.sail = I.id === 'public' ? 'isle' : '';
  SC.go.innerHTML = open ? escHTML(I.go) : `${escHTML(I.go)} <small>준비 중</small>`;
  SC.go.classList.toggle('locked', !open); SC.go.setAttribute('aria-disabled', String(!open));
  SC.note.textContent = '';
}
function scopeTo(i){ scope.i = (i + ISLES.length) % ISLES.length; scopeRender(); }
function openScope(){
  if (scope.open || AREA !== DECK_AREA) return;
  scope.open = true; uiOpen = true; keys.clear(); auto = null; $('#toast').hidden = true;
  scope.look.set(0, 2, 60);
  DECK_AREA.view = { pos:new THREE.Vector3(0, 1.62, 14.5), look:scope.look };
  scopeTo(0);
  document.body.classList.add('scope-open');
  SC.root.hidden = false; SC.root.classList.remove('on');
  setTimeout(() => { SC.root.classList.add('on'); try { SC.close.focus({ preventScroll:true }); } catch(e){} }, reduceMotion ? 0 : 450);
}
function closeScope(){
  if (!scope.open) return;
  scope.open = false; SC.root.hidden = true; SC.root.classList.remove('on'); document.body.classList.remove('scope-open');
  DECK_AREA.view = null; uiOpen = false;
  try { renderer.domElement.focus({ preventScroll:true }); } catch(e){}
  if (AREA !== DECK_AREA || reduceMotion){ camera.fov = BASE_FOV; camera.updateProjectionMatrix(); }
}
/* 시선 · 확대를 부드럽게 (갑판 프레임에서 불러요) */
/* 휴대폰(세로 화면)에서도 섬이 옆으로 잘리지 않게 확대를 맞춰요 */
function fovFor(I){
  const d = Math.hypot(I.ax, I.az - 14.5), a = camera.aspect || 1;
  const need = Math.atan(I.R / (d * a));
  return Math.min(50, Math.max(I.fov, 2 * need * 180 / Math.PI));
}
function scopeStep(dt){
  if (AREA !== DECK_AREA) return;
  const want = scope.open ? fovFor(ISLES[scope.i]) : BASE_FOV, k = reduceMotion ? 1 : Math.min(1, dt * (scope.open ? 3.2 : 5));
  if (scope.open) scope.look.lerp(ISLES[scope.i].look, reduceMotion ? 1 : Math.min(1, dt * 2.6));
  const fogFar = scope.open ? 1400 : (nest.open ? 900 : 420); deckScene.fog.far += (fogFar - deckScene.fog.far) * Math.min(1, dt * 3);
  if (Math.abs(camera.fov - want) > 0.02){ camera.fov += (want - camera.fov) * k; camera.updateProjectionMatrix(); }
  else if (camera.fov !== want){ camera.fov = want; camera.updateProjectionMatrix(); }
}

SC.prev.addEventListener('click', () => scopeTo(scope.i - 1));
SC.next.addEventListener('click', () => scopeTo(scope.i + 1));
SC.close.addEventListener('click', () => closeScope());
SC.go.addEventListener('click', () => {
  if (SC.go.dataset.url){ window.location.href = SC.go.dataset.url; return; }
  if (SC.go.dataset.sail){ sailTo(SC.go.dataset.sail); return; }
  SC.note.textContent = ISLES[scope.i].lockNote;
});
/* 휴대폰: 좌우로 밀어서 섬 바꾸기 */
{ let sx = null; SC.root.addEventListener('pointerdown', e => { if (e.target.closest('button')) return; sx = e.clientX; });
  SC.root.addEventListener('pointerup', e => { if (sx === null) return; const d = e.clientX - sx; sx = null; if (Math.abs(d) > 40) scopeTo(scope.i + (d < 0 ? 1 : -1)); }); }
window.addEventListener('keydown', e => {
  if (!scope.open) return;
  if (e.key === 'Escape'){ e.preventDefault(); closeScope(); return; }
  if (e.key === 'ArrowLeft' || e.key === 'ArrowRight'){ if (document.activeElement && document.activeElement.tagName === 'INPUT') return; e.preventDefault(); scopeTo(scope.i + (e.key === 'ArrowRight' ? 1 : -1)); return; }
  if (e.key === 'Tab'){
    const f = [...SC.root.querySelectorAll('button')].filter(b => b.offsetParent !== null);
    if (!f.length) return; const first = f[0], last = f[f.length - 1];
    if (e.shiftKey && document.activeElement === first){ e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && document.activeElement === last){ e.preventDefault(); first.focus(); }
  }
});

function buildIsles(){ buildLaftelIsle(); buildPublicIsle(); timeHooks.push(islesTime); islesTime(timeMode); }
DECK_SPOTS.scope.use = () => openScope();
