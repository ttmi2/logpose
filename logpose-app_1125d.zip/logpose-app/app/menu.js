/* ============================================================
   LOG POSE · 로그포스 메뉴 (단계 6)
   오른쪽 로그포스 버튼 → 옆에서 열리는 패널 (휴대폰은 아래에서 올라오는 시트)
   탭 1 · 저장한 목적지: 책상에서 열기 / 지우기(되돌리기 가능)
   탭 2 · 새 목적지: 다른 목적지 찾기(다시 추천) · 취향 다시 고르기 · 직접 찾기(검색 + 장르)
   ============================================================ */
const LM = { root:$('#lpMenu'), panel:$('#lmPanel'), close:$('#lmClose'), scrim:$('#lmScrim'),
  tabSaved:$('#lmTabSaved'), tabNew:$('#lmTabNew'), saved:$('#lmSaved'), neu:$('#lmNew'), n:$('#lmN'),
  list:$('#lmList'), empty:$('#lmEmpty'), query:$('#lmQuery'), genres:$('#lmGenres'), count:$('#lmCount'), found:$('#lmFound'),
  more:$('#lmMore'), retake:$('#lmRetake'), last:$('#lmLast'), undo:$('#lmUndo'), undoMsg:$('#lmUndoMsg'), undoBtn:$('#lmUndoBtn'),
  badge:$('#lpN'), btn:$('#logposeBtn') };
const menuHooks = [];   /* 저장 목록이 바뀌면 다른 화면도 다시 그려요 (chart.js) */
let lmTab = 'saved', lmGenre = 'all', lmRemoved = null, lmUndoT = 0;

const menuOpen = () => !LM.root.hidden;
const lmBat = s => { const ch = Array.from(String(s)).reverse().find(c => c >= '가' && c <= '힣'); return ch ? (ch.charCodeAt(0) - 0xAC00) % 28 !== 0 : false; };
const fmtDay = iso => { const d = new Date(iso); return isNaN(d) ? '' : `${d.getMonth() + 1}월 ${d.getDate()}일`; };

/* 버튼의 숫자 · 탭 숫자 · 열려 있으면 목록까지 맞춰요 (저장/해제할 때마다 불러요) */
function menuSync(){
  const n = savedList().filter(s => LPData.get(s.id)).length;
  LM.badge.textContent = n > 99 ? '99+' : String(n); LM.badge.hidden = n === 0;
  LM.btn.setAttribute('aria-label', n ? `로그포스 메뉴 열기 · 저장한 목적지 ${n}편` : '로그포스 메뉴 열기');
  LM.n.textContent = n ? String(n) : '';
  if (menuOpen()){ if (lmTab === 'saved') renderSaved(); else renderLmFind(); }
  menuHooks.forEach(f => f());
}

function setTab(tab){
  lmTab = tab;
  const s = tab === 'saved';
  LM.tabSaved.setAttribute('aria-selected', String(s)); LM.tabNew.setAttribute('aria-selected', String(!s));
  LM.tabSaved.tabIndex = s ? 0 : -1; LM.tabNew.tabIndex = s ? -1 : 0;
  LM.saved.hidden = !s; LM.neu.hidden = s;
  if (s) renderSaved(); else { const p = LPProfile.get(); LM.last.hidden = !(p && p.lastRecs && p.lastRecs.length); renderLmFind(); }
}

/* 저장한 목적지 */
function renderSaved(){
  const items = savedList().map(s => ({ s, w:LPData.get(s.id) })).filter(x => x.w);
  LM.empty.hidden = items.length > 0; LM.list.hidden = !items.length;
  LM.list.innerHTML = items.map(({ s, w }) => `
    <li class="lm-item">
      <img src="${coverURL(w)}" alt="">
      <div class="lm-info"><b>${escHTML(w.title)}</b><small><span class="lm-g" style="--gh:${w.genre.hue}">${escHTML(w.genre.name)}</span>${fmtDay(s.at) ? ` · ${fmtDay(s.at)} 저장` : ''}</small></div>
      <div class="lm-btns">
        <button type="button" class="lm-b go" data-open="${w.id}">책상에서 열기</button>
        <button type="button" class="lm-b del" data-del="${w.id}" aria-label="${escHTML(w.title)} 목록에서 지우기">지우기</button>
      </div>
    </li>`).join('');
  LM.list.querySelectorAll('[data-open]').forEach(b => b.addEventListener('click', () => lmPick(b.dataset.open)));
  LM.list.querySelectorAll('[data-del]').forEach(b => b.addEventListener('click', () => removeSaved(b.dataset.del)));
}
function removeSaved(id){
  const list = savedList(), idx = list.findIndex(s => s.id === id); if (idx < 0) return;
  const w = LPData.get(id);
  lmRemoved = { item:list[idx], idx };
  LPProfile.update({ saved:list.filter(s => s.id !== id) });
  LM.undoMsg.textContent = w ? `‘${w.title}’${lmBat(w.title) ? '을' : '를'} 목록에서 지웠어요.` : '목록에서 지웠어요.';
  LM.undo.hidden = false; clearTimeout(lmUndoT); lmUndoT = setTimeout(hideUndo, 6000);
  menuSync();
  const next = LM.list.querySelector('[data-open]'); try { (next || LM.undoBtn).focus({ preventScroll:true }); } catch(e){}
}
function hideUndo(){ LM.undo.hidden = true; lmRemoved = null; clearTimeout(lmUndoT); }
LM.undoBtn.addEventListener('click', () => {
  if (!lmRemoved) return;
  const list = savedList();
  if (!list.some(s => s.id === lmRemoved.item.id)){ list.splice(Math.min(lmRemoved.idx, list.length), 0, lmRemoved.item); LPProfile.update({ saved:list }); }
  hideUndo(); menuSync(); pulseLogpose();
});

/* 직접 찾기 (제목 · 초성 · 인물 이름 + 장르) */
function renderLmFind(){
  const q = LM.query.value.trim();
  LM.genres.innerHTML = [{ id:'all', name:'전체' }, ...LPData.genres()].map(g => `<button type="button" class="rc-tab" data-g="${g.id}" aria-pressed="${lmGenre === g.id}">${escHTML(g.name)}</button>`).join('');
  LM.genres.querySelectorAll('[data-g]').forEach(b => b.addEventListener('click', () => { lmGenre = b.dataset.g; renderLmFind(); }));
  let list = q ? LPData.search(q) : LPData.all();
  if (lmGenre !== 'all') list = list.filter(w => w.genre.id === lmGenre);
  LM.count.textContent = list.length ? `${list.length}편` : (q ? `"${q}"에 맞는 작품이 아직 없어요` : '작품이 없어요');
  LM.found.innerHTML = list.map(w => `<li><button type="button" class="rc-row" data-rec="${w.id}"><img src="${coverURL(w)}" alt=""><span><b>${escHTML(w.title)}${isSaved(w.id) ? ' <i class="lm-star" title="저장한 목적지">✓ 저장됨</i>' : ''}</b><small>${escHTML(w.genre.name)}</small><span class="l">${escHTML(w.line)}</span></span></button></li>`).join('');
  LM.found.querySelectorAll('[data-rec]').forEach(b => b.addEventListener('click', () => lmPick(b.dataset.rec)));
}
LM.query.addEventListener('input', () => renderLmFind());

/* 열고 닫기 */
function openMenu(tab, opts = {}){
  const p = LPProfile.get(); if (!p) return;
  uiOpen = true; keys.clear(); auto = null; $('#toast').hidden = true;
  LM.root.hidden = false; document.body.classList.add('menu-open');
  setTab(tab || (savedList().length ? 'saved' : 'new'));
  pulseLogpose();
  setTimeout(() => {
    try { if (opts.search && lmTab === 'new') LM.query.focus({ preventScroll:true }); else (lmTab === 'saved' ? LM.tabSaved : LM.tabNew).focus({ preventScroll:true }); } catch(e){}
  }, 60);
}
function closeMenu(keepUi){
  if (!menuOpen()) return;
  LM.root.hidden = true; document.body.classList.remove('menu-open'); hideUndo();
  if (!keepUi) uiOpen = false;
}
function lmPick(id){ closeMenu(); openDeskInfo(id, {}); }

LM.close.addEventListener('click', () => { closeMenu(); try { LM.btn.focus({ preventScroll:true }); } catch(e){} });
LM.scrim.addEventListener('click', () => closeMenu());
LM.tabSaved.addEventListener('click', () => setTab('saved'));
LM.tabNew.addEventListener('click', () => setTab('new'));
[LM.tabSaved, LM.tabNew].forEach(t => t.addEventListener('keydown', e => {
  if (e.key === 'ArrowRight' || e.key === 'ArrowLeft'){ e.preventDefault(); const to = lmTab === 'saved' ? 'new' : 'saved'; setTab(to); (to === 'saved' ? LM.tabSaved : LM.tabNew).focus(); }
}));
$('#lmGoNew').addEventListener('click', () => { setTab('new'); LM.tabNew.focus(); });
LM.more.addEventListener('click', () => { closeMenu(); showRecs({ fx:'short' }); });
LM.last.addEventListener('click', () => { const p = LPProfile.get(); const list = recsFromIds(p && p.lastRecs); closeMenu(); if (list.length) showRecs({ fx:'none', list }); else showRecs({ fx:'short' }); });
LM.retake.addEventListener('click', () => {
  const p = LPProfile.get(); if (!p) return;
  const t = p.taste || {};
  LPProfile.update({ tasteDraft:{ seen:(t.seen || []).slice(), none:!!t.none, values:(t.values || []).slice(), genres:(t.genres || []).slice() } });
  closeMenu(); openQuiz();
});
window.addEventListener('keydown', e => {
  if (!menuOpen()) return;
  if (e.key === 'Escape'){ e.preventDefault(); closeMenu(); try { LM.btn.focus({ preventScroll:true }); } catch(err){} return; }
  if (e.key === 'Tab'){   /* 패널 안에서만 돌아요 */
    const f = [...LM.panel.querySelectorAll('button:not([disabled]), input, [tabindex="0"]')].filter(x => x.offsetParent !== null && x.tabIndex >= 0);
    if (!f.length) return;
    const first = f[0], last = f[f.length - 1];
    if (e.shiftKey && document.activeElement === first){ e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && document.activeElement === last){ e.preventDefault(); first.focus(); }
  }
});
menuSync();
