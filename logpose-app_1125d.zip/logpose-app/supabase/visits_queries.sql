-- LOG POSE · 방문자 숫자 보기 (Supabase → SQL Editor 에 하나씩 붙여 넣고 Run, 번역은 끄고)
-- 시간은 모두 한국 시간이에요.

-- 1) 날짜별 방문자 수 (사람 수 = 무작위 방문 번호 개수, 방문 = 사이트를 연 횟수)
select (at at time zone 'Asia/Seoul')::date as 날짜,
       count(distinct visitor) as 방문자,
       count(*) filter (where event = 'visit') as 방문
from public.visits
group by 1 order by 1 desc;

-- 2) 오늘 시간대별 방문자 수 (몇 시에 많이 왔는지)
select extract(hour from at at time zone 'Asia/Seoul') as 시,
       count(distinct visitor) as 방문자
from public.visits
where (at at time zone 'Asia/Seoul')::date = (now() at time zone 'Asia/Seoul')::date
group by 1 order by 1;

-- 3) 어느 공간에 많이 갔는지 (선장실 cabin · 갑판 deck · 다모였섬 isle · 주점 tavern)
select area as 공간, count(distinct visitor) as 방문자, count(*) as 이동
from public.visits where event = 'area'
group by 1 order by 2 desc;

-- 4) 다모였섬 한눈에 보기를 끝까지 본 사람 vs 건너뛴 사람
select event, count(distinct visitor) as 방문자 from public.visits
where event in ('tour_done', 'tour_skip') group by 1;

-- 5) 가이드북을 많이 연 작품 (detail = 작품 id)
select detail as 작품, count(*) as 열기, count(distinct visitor) as 방문자
from public.visits where event = 'guide'
group by 1 order by 2 desc limit 20;

-- 6) PC · 모바일 비율과 어디서 들어왔는지
select device, count(distinct visitor) as 방문자 from public.visits group by 1;
select coalesce(referrer, '(직접 · 알 수 없음)') as 들어온_곳, count(distinct visitor) as 방문자
from public.visits where event = 'visit' group by 1 order by 2 desc;

-- 문의함: 최근 한마디 (한국 시간)
select at at time zone 'Asia/Seoul' as 한국시간, kind, text, device from feedback order by at desc limit 100;
