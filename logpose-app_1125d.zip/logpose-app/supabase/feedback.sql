-- 문의함 표 만들기 (SQL 편집기에 통째로 붙여 넣고 Run · 브라우저 번역은 꺼 주세요)
-- 선장이 게시판 뒷면에 남긴 한마디가 여기 쌓여요. 넣기만 되고 읽기는 막혀 있어서 다른 선장은 못 봐요.
create table if not exists public.feedback (
  id      uuid        primary key default gen_random_uuid(),
  at      timestamptz not null default now(),
  visitor text        not null check (char_length(visitor) between 4 and 40),
  kind    text        not null default '문의' check (kind in ('문의', '버그', '의견')),
  text    text        not null check (char_length(text) between 2 and 120),
  device  text        check (device in ('pc', 'mobile'))
);
create index if not exists feedback_at on public.feedback (at desc);
alter table public.feedback enable row level security;
drop policy if exists "feedback insert anyone" on public.feedback;
create policy "feedback insert anyone" on public.feedback for insert to anon, authenticated
  with check (at > now() - interval '5 minutes' and at < now() + interval '5 minutes');
grant insert on public.feedback to anon, authenticated;

-- 읽기 (팀만): 최근 문의를 한국 시간으로
-- select at at time zone 'Asia/Seoul' as 한국시간, kind, text, device from feedback order by at desc;
