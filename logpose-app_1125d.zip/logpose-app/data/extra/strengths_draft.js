/* 작품별 강점 초안 (tools/draft_strengths.js 가 한 줄 소개의 단어로 자동 생성). 팀 검토 전이에요.
   검토가 끝나면 extra.js 의 strengths 로 옮기거나 이 파일을 고쳐 주세요. */
const LP_STRENGTHS_DRAFT = {
 "kimetsu": [
  "art"
 ],
 "edgerunners": [
  "art"
 ],
 "jujutsu": [
  "art",
  "character"
 ],
 "ancientbride": [
  "world"
 ],
 "mashle": [
  "world"
 ],
 "sao": [
  "world"
 ],
 "slime": [
  "world"
 ],
 "mobpsycho": [
  "art"
 ],
 "violet": [
  "art"
 ],
 "icewall": [
  "character"
 ]
};
