/* ============================================================
   가이드북 — A구역 액션·배틀 (1~2화, 회차 요약 자료로 확인한 범위만)
   장면 시각은 줄거리 순서에 맞춘 대략적인 위치예요.
   ============================================================ */
WORKS.kaiju.guide = {
  season:'1기', eps:2, startAt:[1,0], core:['kaiju','jdf','cleaner'],
  episodes:{
    1:{ title:'괴수가 된 남자', summary:'괴수 사체 청소 일을 하는 32세 카프카가 신입 레노를 만나고, 괴수 습격에서 살아남은 뒤 병원에서 정체 모를 작은 괴수에게 몸을 빼앗겨 괴수가 돼요.' },
    2:{ title:'괴수를 쓰러뜨리는 괴수', summary:'괴수가 된 카프카는 레노와 병원을 빠져나와 사람들을 덮친 괴수를 한 방에 쓰러뜨리고, 3개월 뒤 방위대 입대 시험에 도전해요.' },
  },
  scenes:{
    1:[
      { s:0,    title:'괴수가 일상인 나라', art:'city', chars:[], terms:['kaiju','jdf'], sum:'일본은 거의 매일 괴수의 습격을 받고, 방위대가 괴수를 처리해요.' },
      { s:150,  title:'괴수 청소부 카프카', art:'city', chars:['kafka'], terms:['cleaner'], sum:'카프카는 방위대가 쓰러뜨린 괴수의 사체를 치우는 업체에서 일해요. 한때 방위대를 꿈꿨지만 포기했어요.' },
      { s:330,  title:'신입 레노', art:'city', chars:['kafka','reno'], terms:['cleaner'], sum:'방위대 지망생 레노가 청소 업체에 아르바이트로 들어와요. 처음엔 카프카에게 쌀쌀맞아요.' },
      { s:510,  title:'방위대 대장 미나', art:'battle', chars:['kafka','mina'], terms:['jdf'], sum:'방위대 제3부대 대장 미나가 거대한 괴수를 쓰러뜨려요. 미나는 카프카의 어릴 적 친구예요.' },
      { s:690,  title:'괴수 해체 작업', art:'city', chars:['kafka','reno'], terms:['cleaner'], sum:'카프카와 레노는 괴수 사체를 해체하며 조금씩 가까워져요.' },
      { s:840,  title:'두 번째 습격', art:'street', chars:['kafka','reno'], terms:['kaiju'], sum:'작업 중 또 다른 괴수가 나타나고, 카프카는 레노를 구하려다 크게 다쳐요.' },
      { s:1020, title:'구하러 온 방위대', art:'street', chars:['kafka','reno','mina'], terms:['jdf'], sum:'미나가 이끄는 방위대가 도착해 괴수를 처리하고 두 사람은 목숨을 건져요.' },
      { s:1140, title:'병실에서', art:'night', chars:['kafka','reno'], terms:['jdf'], sum:'레노는 카프카에게 다시 방위대에 도전해 보라고 말해요.' },
      { s:1260, title:'날아든 작은 괴수', art:'night', chars:['kafka'], terms:['kaiju'], sum:'정체 모를 작은 괴수가 카프카의 입으로 들어가고, 카프카의 몸이 괴수로 변해요.' },
      { s:1350, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
    ],
    2:[
      { s:0,    title:'어린 날의 약속', art:'hill', chars:['kafka','mina'], terms:['kaiju'], sum:'어린 카프카와 미나는 함께 괴수를 전부 쓰러뜨리자고 약속했어요.' },
      { s:120,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:210,  title:'출동 준비', art:'office', chars:['mina','hoshina'], terms:['jdf'], sum:'병원 근처에 괴수가 나타났다는 신고에 미나의 제3부대가 출동을 준비해요. 부대장 호시나도 함께해요.' },
      { s:360,  title:'병원 탈출', art:'night', chars:['kafka','reno'], terms:['kaiju'], sum:'괴수 모습이 된 카프카는 병실을 부수고, 레노와 함께 창밖으로 빠져나가요.' },
      { s:570,  title:'다시 사람으로', art:'night', chars:['kafka','reno'], terms:['jdf'], sum:'카프카는 사람 모습으로 돌아오지만 마음대로 조절하지 못해요. 이런 몸으로 방위대에 갈 수 있을지 막막해해요.' },
      { s:780,  title:'위험에 처한 가족', art:'street', chars:['kafka','reno'], terms:['kaiju'], sum:'다른 괴수가 사람들을 덮치자 카프카가 막아서고, 레노는 사람들을 피신시켜요.' },
      { s:960,  title:'한 방', art:'battle', chars:['kafka'], terms:['kaiju'], sum:'카프카는 엄청난 힘으로 괴수를 한 방에 날려 버려요.' },
      { s:1080, title:'괴수 8호', art:'city', chars:['kafka','mina'], terms:['no8'], sum:'방위대는 정체불명의 괴수를 「괴수 8호」로 이름 붙여요. 카프카는 정체를 숨긴 채 자리를 떠요.' },
      { s:1200, title:'3개월 뒤, 입대 시험', art:'training', chars:['kafka','reno','kikoru'], terms:['exam','jdf'], sum:'레노와 카프카는 방위대 1차 시험을 통과하고 2차 시험장에 가요. 그곳에서 당찬 수험생 키코루와 마주쳐요.' },
      { s:1350, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
    ],
  },
  chars:{
    kafka:{ name:'히비노 카프카', short:'카프카', alias:['카프카','히비노'], at:[1,150], pos:[300,230], facts:[
      [[1,150],'32세. 괴수 사체를 치우는 청소 업체에서 일해요.'],
      [[1,150],'어릴 적 방위대원이 되는 게 꿈이었지만 포기했어요.'],
      [[1,1260],'작은 괴수가 몸에 들어온 뒤 괴수로 변할 수 있게 됐어요.'],
      [[2,1080],'방위대는 그의 괴수 모습을 **괴수 8호**라고 불러요.'],
      [[2,1200],'정체를 숨긴 채 방위대 입대 시험에 도전해요.'],
    ], easy:'꿈을 접고 뒷정리를 하던 아저씨가 갑자기 슈퍼 괴력을 얻은 상황이에요.' },
    reno:{ name:'이치카와 레노', short:'레노', alias:['레노','이치카와'], at:[1,330], pos:[460,150], facts:[
      [[1,330],'방위대에 들어가려고 준비하며 청소 업체에서 일하는 청년이에요.'],
      [[1,1140],'카프카에게 다시 방위대에 도전하라고 권해요.'],
      [[2,360],'카프카의 비밀을 아는 사람이에요.'],
    ] },
    mina:{ name:'아시로 미나', short:'미나', alias:['미나','아시로'], at:[1,510], pos:[150,140], facts:[
      [[1,510],'방위대 제3부대 대장이에요. 카프카의 어릴 적 친구예요.'],
      [[2,0],'어린 시절 카프카와 함께 괴수를 쓰러뜨리자고 약속했어요.'],
    ] },
    hoshina:{ name:'호시나 소시로', short:'호시나', alias:['호시나','소시로'], at:[2,210], pos:[110,300], facts:[
      [[2,210],'방위대 제3부대의 부대장이에요. 미나와 함께 출동해요.'],
    ] },
    kikoru:{ name:'시노미야 키코루', short:'키코루', alias:['키코루','시노미야'], at:[2,1200], pos:[470,340], facts:[
      [[2,1200],'방위대 2차 시험장에서 만난 당찬 수험생이에요.'],
    ] },
  },
  rels:[
    ['kafka','reno','friend','청소 업체 선후배',[1,690]],
    ['kafka','mina','friend','어릴 적 친구',[1,510]],
    ['mina','hoshina','peer','제3부대 대장과 부대장',[2,210]],
    ['kafka','kikoru','other','시험장에서 마주친 수험생',[2,1200]],
  ],
  terms:{
    kaiju:{ name:'괴수', alias:['괴수','몬스터'], at:[1,0], facts:[[[1,0],'일본을 거의 매일 습격하는 거대한 생물이에요.']], easy:'태풍처럼 자주 찾아오는 재난이 살아 움직이는 셈이에요.' },
    jdf:{ name:'방위대', alias:['방위대','제3부대'], at:[1,0], facts:[[[1,0],'괴수를 쓰러뜨리는 조직이에요.'],[[1,510],'미나가 제3부대 대장을 맡고 있어요.']], easy:'괴수 전문 소방서 같은 곳이에요.' },
    cleaner:{ name:'괴수 청소 업체', alias:['청소 업체','청소부','해체'], at:[1,150], facts:[[[1,150],'방위대가 쓰러뜨린 괴수 사체를 해체하고 치우는 회사예요.']] },
    no8:{ name:'괴수 8호', alias:['괴수 8호','8호'], at:[2,1080], facts:[[[2,1080],'방위대가 카프카의 괴수 모습에 붙인 이름이에요.']] },
    exam:{ name:'방위대 입대 시험', alias:['시험','입대 시험','2차 시험'], at:[2,1200], facts:[[[2,1200],'카프카와 레노는 1차를 통과하고 2차 시험에 나가요.']] },
  },
  banned:['나루미','괴수 9호','오코노기','카구라기','이하루','이사오'],
};

WORKS.kimetsu.guide = {
  season:'1기', eps:2, startAt:[1,0], core:['oni','sun','basket'],
  episodes:{
    1:{ title:'잔혹', summary:'숯을 팔러 마을에 다녀온 탄지로가 집에 돌아오자 가족은 혈귀에게 습격당해 있고, 유일하게 살아남은 여동생 네즈코는 혈귀가 되어 있어요.' },
    2:{ title:'육성자 우로코다키 사콘지', summary:'탄지로는 네즈코를 업고 사기리산으로 향하다 혈귀와 싸우고, 우로코다키 사콘지를 만나 시험을 받아요.' },
  },
  scenes:{
    1:[
      { s:0,    title:'눈 덮인 산의 남매', art:'forest', chars:['tanjiro','nezuko'], terms:[], sum:'산속에 사는 탄지로는 가족을 위해 숯을 팔러 마을로 내려가요. 여동생 네즈코가 배웅해요.' },
      { s:240,  title:'마을의 숯장수', art:'town', chars:['tanjiro'], terms:[], sum:'탄지로는 마을 사람들에게 숯을 팔고 이런저런 부탁을 들어 주며 늦게까지 머물러요.' },
      { s:420,  title:'하룻밤 묵어 가라', art:'night', chars:['tanjiro','saburo'], terms:['oni'], sum:'날이 저물자 사부로 할아버지가 밤에는 혈귀가 나온다며 탄지로를 자기 집에 재워 줘요.' },
      { s:630,  title:'돌아온 집', art:'forest', chars:['tanjiro'], terms:['oni'], sum:'아침에 집으로 돌아온 탄지로 앞에 처참하게 습격당한 가족이 있어요.' },
      { s:780,  title:'네즈코를 업고', art:'forest', chars:['tanjiro','nezuko'], terms:[], sum:'아직 몸이 따뜻한 네즈코를 업고 탄지로는 의사를 찾아 산을 내려가요.' },
      { s:900,  title:'변해 버린 네즈코', art:'forest', chars:['tanjiro','nezuko'], terms:['oni'], sum:'네즈코가 깨어나 혈귀처럼 탄지로를 공격해요. 그래도 네즈코는 눈물을 흘리며 버텨요.' },
      { s:1020, title:'검사 기유', art:'forest', chars:['tanjiro','nezuko','giyu'], terms:['oni'], sum:'검을 든 기유가 나타나 네즈코를 베려 하고, 탄지로는 동생을 지키려고 맞서요.' },
      { s:1200, title:'오빠를 지키는 네즈코', art:'forest', chars:['tanjiro','nezuko','giyu'], terms:['urokodaki'], sum:'네즈코가 쓰러진 탄지로를 감싸는 모습을 본 기유는 칼을 거두고, 깨어나면 우로코다키 사콘지를 찾아가라는 말을 남겨요.' },
      { s:1350, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
    ],
    2:[
      { s:0,    title:'떠나는 남매', art:'forest', chars:['tanjiro','nezuko'], terms:['sun'], sum:'가족을 묻은 탄지로는 햇빛을 피해야 하는 네즈코를 데리고 길을 떠나요.' },
      { s:120,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:210,  title:'낡은 바구니', art:'town', chars:['tanjiro','nezuko'], terms:['basket','sun'], sum:'탄지로는 낡은 바구니를 사서 네즈코가 햇빛을 피해 들어갈 수 있게 만들어요.' },
      { s:420,  title:'산속 사당', art:'night', chars:['tanjiro','nezuko','temple'], terms:['oni'], sum:'밤길에 들른 사당 안에서 사람을 해친 혈귀를 마주쳐요.' },
      { s:600,  title:'남매의 반격', art:'night', chars:['tanjiro','nezuko','temple'], terms:['oni'], sum:'탄지로가 도끼로 맞서고, 네즈코가 혈귀를 걷어차 머리를 날려 버려요.' },
      { s:780,  title:'덴구 가면의 노인', art:'night', chars:['tanjiro','urokodaki','temple'], terms:['urokodaki','sun'], sum:'덴구 가면을 쓴 우로코다키가 나타나, 망설이는 탄지로를 꾸짖어요. 날이 밝자 혈귀는 햇빛에 사라져요.' },
      { s:960,  title:'사기리산', art:'forest', chars:['tanjiro','nezuko','urokodaki'], terms:['corps'], sum:'우로코다키는 탄지로가 혈귀를 베는 검사가 될 수 있을지 시험하겠다며 산꼭대기에서 내려와 보라고 해요.' },
      { s:1110, title:'함정투성이 하산', art:'forest', chars:['tanjiro'], terms:[], sum:'곳곳에 함정이 깔린 산길을 탄지로는 상처투성이가 되면서도 내려와요.' },
      { s:1260, title:'돌아온 탄지로', art:'forest', chars:['tanjiro','urokodaki'], terms:[], sum:'해가 뜨기 전 탄지로가 무사히 돌아오고, 우로코다키는 그를 받아들여요.' },
      { s:1350, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
    ],
  },
  chars:{
    tanjiro:{ name:'카마도 탄지로', short:'탄지로', alias:['탄지로','카마도'], at:[1,0], pos:[300,220], facts:[
      [[1,0],'산속에서 숯을 구워 파는 집의 장남이에요. 마음이 따뜻하고 냄새를 아주 잘 맡아요.'],
      [[1,630],'혈귀의 습격으로 가족을 잃었어요.'],
      [[1,1200],'혈귀가 된 네즈코를 사람으로 되돌리겠다고 결심해요.'],
      [[2,960],'우로코다키에게 검사가 될 수 있는지 시험을 받아요.'],
    ], easy:'착한 장남이 동생을 지키려고 험한 길에 뛰어든 이야기예요.' },
    nezuko:{ name:'카마도 네즈코', short:'네즈코', alias:['네즈코'], at:[1,0], pos:[140,140], facts:[
      [[1,0],'탄지로의 여동생이에요.'],
      [[1,900],'혈귀가 되었지만, 오빠를 알아보고 지키려 해요.'],
      [[2,210],'햇빛을 피해 바구니 안에 들어가 다녀요.'],
    ] },
    saburo:{ name:'사부로', short:'사부로', alias:['사부로','할아버지'], at:[1,420], pos:[110,330], facts:[
      [[1,420],'마을의 할아버지예요. 밤에는 혈귀가 나온다며 탄지로를 재워 줘요.'],
    ] },
    giyu:{ name:'토미오카 기유', short:'기유', alias:['기유','토미오카'], at:[1,1020], pos:[470,130], facts:[
      [[1,1020],'혈귀를 베는 검사예요. 혈귀가 된 네즈코를 베려 했어요.'],
      [[1,1200],'탄지로에게 우로코다키 사콘지를 찾아가라고 했어요.'],
    ] },
    urokodaki:{ name:'우로코다키 사콘지', short:'우로코다키', alias:['우로코다키','사콘지','덴구'], at:[2,780], pos:[470,320], facts:[
      [[2,780],'덴구 가면을 쓴 노인이에요. 기유가 소개한 사람이에요.'],
      [[2,960],'탄지로가 검사가 될 수 있는지 시험해요.'],
    ] },
    temple:{ name:'사당의 혈귀', short:'사당 혈귀', alias:['사당','사당 혈귀'], at:[2,420], pos:[300,380], facts:[
      [[2,420],'산속 사당에서 사람을 해친 혈귀예요.'],
      [[2,780],'날이 밝자 햇빛을 받고 사라졌어요.'],
    ] },
  },
  rels:[
    ['tanjiro','nezuko','family','오빠와 여동생',[1,0]],
    ['tanjiro','saburo','other','마을에서 재워 준 할아버지',[1,420]],
    ['tanjiro','giyu','other','칼을 맞댄 검사',[1,1020]],
    ['giyu','urokodaki','other','탄지로를 보낸 사람',[2,780]],
    ['tanjiro','urokodaki','peer','스승이 될 사람',[2,1260]],
    ['tanjiro','temple','rival','맞서 싸운 상대',[2,600]],
  ],
  terms:{
    oni:{ name:'혈귀', alias:['혈귀','오니','도깨비'], at:[1,420], facts:[[[1,420],'밤에 나타나 사람을 해치는 존재예요.'],[[1,900],'사람이 혈귀로 변하기도 해요.']], easy:'밤에만 돌아다니는 사람 잡아먹는 괴물이에요.' },
    sun:{ name:'햇빛', alias:['햇빛','해','태양'], at:[2,0], facts:[[[2,0],'혈귀는 햇빛을 피해야 해요.'],[[2,780],'햇빛을 받은 혈귀는 사라져요.']] },
    basket:{ name:'바구니', alias:['바구니','상자'], at:[2,210], generic:true, facts:[[[2,210],'탄지로가 네즈코를 햇빛에서 지키려고 메고 다니는 바구니예요.']] },
    urokodaki:{ name:'우로코다키 사콘지', alias:['우로코다키','사콘지'], at:[1,1200], facts:[[[1,1200],'기유가 탄지로에게 찾아가라고 알려 준 이름이에요.']] },
    corps:{ name:'혈귀를 베는 검사', alias:['검사','귀살대'], at:[2,960], facts:[[[2,960],'우로코다키는 탄지로가 혈귀를 베는 검사가 될 수 있을지 시험해요.']] },
  },
  banned:['무잔','젠이츠','이노스케','사비토','마코모','최종 선별','시노부','렌고쿠','주(柱)','상현','하현'],
};

WORKS.naruto.guide = {
  season:'1기', eps:2, startAt:[1,0], core:['hokage','academy','clone','fox'],
  episodes:{
    1:{ title:'참상! 우즈마키 나루토', summary:'말썽꾸러기 나루토는 졸업 시험에 떨어진 뒤 미즈키에게 속아 금지된 두루마리를 훔치고, 자신 안에 봉인된 구미호의 비밀을 알게 돼요. 이루카의 진심 덕에 나루토는 졸업해요.' },
    2:{ title:'나는 코노하마루다!', summary:'호카게의 손자 코노하마루가 나루토를 졸졸 따라다니고, 나루토는 지름길로 호카게가 될 수는 없다고 알려 줘요.' },
  },
  scenes:{
    1:[
      { s:0,    title:'호카게 바위의 낙서', art:'town', chars:['naruto','iruka'], terms:['hokage'], sum:'나루토가 마을의 역대 호카게 얼굴 바위에 낙서를 하고, 이루카 선생님에게 붙잡혀요.' },
      { s:180,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:270,  title:'라멘 한 그릇', art:'town', chars:['naruto','iruka'], terms:['hokage'], sum:'벌로 바위를 청소한 뒤 이루카가 라멘을 사 줘요. 나루토는 언젠가 호카게가 되겠다고 큰소리쳐요.' },
      { s:450,  title:'졸업 시험 낙방', art:'classroom', chars:['naruto','iruka','mizuki'], terms:['academy','clone'], sum:'닌자 아카데미 졸업 시험에서 나루토는 분신술을 제대로 못 해 떨어져요.' },
      { s:630,  title:'미즈키의 귓속말', art:'night', chars:['naruto','mizuki'], terms:['scroll'], sum:'미즈키 선생님은 비밀 시험이 있다며, 봉인된 두루마리를 가져오면 졸업시켜 주겠다고 꼬드겨요.' },
      { s:780,  title:'숲속 연습', art:'forest', chars:['naruto','hokage3'], terms:['scroll','shadow'], sum:'나루토는 호카게 집에서 두루마리를 들고 나와 숲에서 그림자 분신술을 익혀요. 마을이 발칵 뒤집혀요.' },
      { s:930,  title:'미즈키의 배신', art:'forest', chars:['naruto','iruka','mizuki'], terms:['fox'], sum:'미즈키는 마을 사람들이 숨겨 온 비밀, 나루토 안에 구미호가 봉인돼 있다는 사실을 폭로해요.' },
      { s:1110, title:'이루카의 진심', art:'forest', chars:['naruto','iruka','mizuki'], terms:['fox'], sum:'이루카는 몸을 던져 나루토를 감싸며, 나루토는 구미호가 아니라 자기 제자라고 말해요.' },
      { s:1230, title:'천 명의 나루토', art:'forest', chars:['naruto','iruka','mizuki'], terms:['shadow','headband'], sum:'나루토가 그림자 분신술로 미즈키를 쓰러뜨리고, 이루카는 자기 이마보호대를 나루토에게 씌워 줘요.' },
      { s:1350, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
    ],
    2:[
      { s:0,    title:'증명사진', art:'office', chars:['naruto','hokage3'], terms:['hokage'], sum:'나루토가 얼굴에 분장을 하고 닌자 등록 사진을 찍어 와서 3대 호카게를 곤란하게 해요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'꼬마 자객', art:'office', chars:['naruto','hokage3','konohamaru'], terms:['hokage'], sum:'호카게를 덮치려던 꼬마 코노하마루가 혼자 넘어지고, 나루토를 범인으로 몰아요.' },
      { s:420,  title:'호카게의 손자', art:'town', chars:['naruto','konohamaru'], terms:['hokage'], sum:'코노하마루는 호카게의 손자예요. 사람들이 자기를 손자로만 대하는 게 싫어서, 겁 없이 군 나루토를 따라다녀요.' },
      { s:600,  title:'가정교사 에비스', art:'town', chars:['konohamaru','ebisu'], terms:[], sum:'코노하마루의 가정교사 에비스가 나루토와 어울리면 안 된다며 쫓아와요.' },
      { s:780,  title:'비장의 기술', art:'town', chars:['naruto','konohamaru'], terms:['sexy'], sum:'나루토는 코노하마루에게 자기만의 장난 기술인 섹시 기술을 가르쳐 줘요.' },
      { s:960,  title:'에비스와 대결', art:'forest', chars:['naruto','konohamaru','ebisu'], terms:['shadow','sexy'], sum:'나루토는 그림자 분신술과 섹시 기술로 에비스를 쓰러뜨려요.' },
      { s:1140, title:'지름길은 없어', art:'forest', chars:['naruto','konohamaru'], terms:['hokage'], sum:'나루토는 호카게가 되는 데 지름길은 없다고 말하고, 코노하마루는 나루토의 라이벌이 되겠다고 해요.' },
      { s:1350, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
    ],
  },
  chars:{
    naruto:{ name:'우즈마키 나루토', short:'나루토', alias:['나루토','우즈마키'], at:[1,0], pos:[300,220], facts:[
      [[1,0],'나뭇잎 마을의 말썽꾸러기예요. 호카게가 되는 게 꿈이에요.'],
      [[1,450],'아카데미 졸업 시험에 떨어졌어요.'],
      [[1,780],'그림자 분신술을 익혔어요.'],
      [[1,930],'몸 안에 **구미호**가 봉인돼 있어요.'],
      [[1,1230],'이루카에게 이마보호대를 받고 졸업했어요.'],
    ], easy:'다들 피하던 외톨이가 인정받고 싶어서 큰 꿈을 외치는 이야기예요.' },
    iruka:{ name:'우미노 이루카', short:'이루카', alias:['이루카','우미노'], at:[1,0], pos:[140,130], facts:[
      [[1,0],'닌자 아카데미 선생님이에요. 나루토를 자주 혼내요.'],
      [[1,1110],'나루토를 자기 제자로 인정하고 목숨을 걸고 지켜 줬어요.'],
    ] },
    mizuki:{ name:'미즈키', short:'미즈키', alias:['미즈키'], at:[1,450], pos:[470,130], facts:[
      [[1,450],'닌자 아카데미 선생님이에요.'],
      [[1,930],'나루토를 이용해 봉인된 두루마리를 빼돌리려 했어요.'],
    ] },
    hokage3:{ name:'3대 호카게', short:'3대 호카게', alias:['3대','3대 호카게','할아버지'], at:[1,780], pos:[470,320], facts:[
      [[1,780],'나뭇잎 마을의 지도자예요.'],
      [[2,240],'코노하마루의 할아버지예요.'],
    ] },
    konohamaru:{ name:'코노하마루', short:'코노하마루', alias:['코노하마루'], at:[2,240], pos:[150,330], facts:[
      [[2,240],'3대 호카게의 손자예요.'],
      [[2,420],'손자로만 대접받는 게 싫어서 나루토를 따라다녀요.'],
      [[2,1140],'나루토의 라이벌이 되겠다고 선언해요.'],
    ] },
    ebisu:{ name:'에비스', short:'에비스', alias:['에비스'], at:[2,600], pos:[300,390], facts:[
      [[2,600],'코노하마루의 가정교사예요.'],
    ] },
  },
  rels:[
    ['naruto','iruka','peer','제자와 선생님',[1,0]],
    ['naruto','mizuki','rival','속이고 배신한 선생님',[1,930]],
    ['iruka','mizuki','peer','아카데미 동료 선생님',[1,450]],
    ['hokage3','konohamaru','family','할아버지와 손자',[2,240]],
    ['naruto','konohamaru','rival','형님이자 라이벌',[2,1140]],
    ['konohamaru','ebisu','peer','제자와 가정교사',[2,600]],
  ],
  terms:{
    hokage:{ name:'호카게', alias:['호카게'], at:[1,0], facts:[[[1,0],'나뭇잎 마을에서 가장 강한 닌자이자 마을의 지도자예요.']], easy:'닌자 마을의 대통령 같은 자리예요.' },
    academy:{ name:'닌자 아카데미', alias:['아카데미','졸업 시험'], at:[1,450], facts:[[[1,450],'닌자가 되려는 아이들이 다니는 학교예요. 졸업 시험을 통과해야 닌자가 돼요.']] },
    clone:{ name:'분신술', alias:['분신술'], at:[1,450], facts:[[[1,450],'자기와 똑같은 모습을 만들어 내는 기술이에요. 졸업 시험 과제였어요.']] },
    shadow:{ name:'그림자 분신술', alias:['그림자 분신','다중 그림자 분신'], at:[1,780], facts:[[[1,780],'실체가 있는 분신을 만드는 기술이에요. 나루토가 두루마리를 보고 익혔어요.']] },
    scroll:{ name:'봉인의 두루마리', alias:['두루마리'], at:[1,630], facts:[[[1,630],'금지된 기술이 적힌 두루마리예요.']] },
    fox:{ name:'구미호', alias:['구미호','구미'], at:[1,930], facts:[[[1,930],'예전에 마을을 습격한 꼬리 아홉 달린 여우예요. 나루토 몸 안에 봉인돼 있어요.']] },
    headband:{ name:'이마보호대', alias:['이마보호대','머리띠'], at:[1,1230], generic:true, facts:[[[1,1230],'정식 닌자가 됐다는 표시예요. 이루카가 자기 것을 나루토에게 줬어요.']] },
    sexy:{ name:'섹시 기술', alias:['섹시 기술','섹시 변신'], at:[2,780], facts:[[[2,780],'나루토가 만든 장난스러운 변신 기술이에요.']] },
  },
  banned:['사스케','사쿠라','카카시','오로치마루','자부자','하쿠','가아라','츠나데','지라이야','아카츠키','이타치','미나토','4대 호카게'],
};

WORKS.heroaca.guide = {
  season:'1기', eps:2, startAt:[1,0], core:['quirk','quirkless','hero','ua'],
  episodes:{
    1:{ title:'미도리야 이즈쿠: 오리진', summary:'인구 대부분이 초능력 「개성」을 가진 세상에서 무개성인 이즈쿠는 히어로를 꿈꿔요. 진흙 같은 빌런에게 습격당한 이즈쿠를 동경하던 올마이트가 구해 줘요.' },
    2:{ title:'히어로의 조건', summary:'올마이트의 진짜 모습과 비밀을 알게 된 이즈쿠는 꿈을 접으려다, 빌런에게 잡힌 소꿉친구 바쿠고를 구하러 맨몸으로 뛰어들어요.' },
  },
  scenes:{
    1:[
      { s:0,    title:'개성의 시대', art:'city', chars:['izuku','allmight'], terms:['quirk','hero'], sum:'세계 인구 대부분이 「개성」이라는 초능력을 갖게 됐고, 히어로가 직업이 된 세상이에요. 이즈쿠는 최고의 히어로 올마이트를 동경해요.' },
      { s:180,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:270,  title:'무개성 판정', art:'home', chars:['izuku','inko'], terms:['quirkless'], sum:'어린 이즈쿠는 의사에게 개성이 생기지 않을 거라는 말을 들어요. 그래도 올마이트 영상을 보며 히어로를 꿈꿔요.' },
      { s:480,  title:'교실의 바쿠고', art:'classroom', chars:['izuku','bakugo'], terms:['ua'], sum:'중학교 3학년, 이즈쿠도 명문 히어로 학교 유에이에 가고 싶다는 사실이 알려지자 소꿉친구 바쿠고가 비웃으며 괴롭혀요.' },
      { s:720,  title:'진흙 빌런', art:'street', chars:['izuku','sludge'], terms:['villain'], sum:'하굣길 굴다리에서 진흙 같은 몸의 빌런이 이즈쿠의 몸을 빼앗으려 덮쳐요.' },
      { s:900,  title:'올마이트 등장', art:'street', chars:['izuku','allmight','sludge'], terms:['hero'], sum:'최고의 히어로 올마이트가 나타나 빌런을 한 방에 제압하고 이즈쿠를 구해요.' },
      { s:1080, title:'다리에 매달려', art:'city', chars:['izuku','allmight'], terms:[], sum:'빌런을 병에 담아 떠나려는 올마이트의 다리에 이즈쿠가 매달려 하늘을 날아요.' },
      { s:1230, title:'옥상에서의 질문', art:'city', chars:['izuku','allmight'], terms:['quirkless'], sum:'옥상에 내린 이즈쿠는 개성이 없어도 히어로가 될 수 있느냐고 물어요.' },
      { s:1350, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
    ],
    2:[
      { s:0,    title:'올마이트의 진짜 모습', art:'city', chars:['izuku','allmight'], terms:['hero'], sum:'올마이트가 갑자기 깡마른 모습으로 변해요. 오래전 큰 부상을 입어 힘을 쓸 수 있는 시간이 짧다고 털어놔요.' },
      { s:210,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:300,  title:'현실적인 꿈', art:'city', chars:['izuku','allmight'], terms:['quirkless'], sum:'올마이트는 개성 없이 히어로는 어렵다며 경찰 같은 다른 길도 있다고 말해요. 이즈쿠는 고개를 떨궈요.' },
      { s:540,  title:'붙잡힌 바쿠고', art:'fire', chars:['bakugo','sludge'], terms:['villain'], sum:'놓쳐 버린 진흙 빌런이 이번엔 바쿠고를 붙잡아요. 현장의 히어로들은 선뜻 나서지 못해요.' },
      { s:780,  title:'몸이 먼저', art:'fire', chars:['izuku','bakugo','sludge'], terms:[], sum:'구경하던 이즈쿠가 생각보다 먼저 몸이 움직여 바쿠고를 구하러 뛰어들어요.' },
      { s:960,  title:'다시 나타난 올마이트', art:'battle', chars:['izuku','bakugo','allmight','sludge'], terms:['hero'], sum:'이즈쿠의 모습을 본 올마이트가 한계를 넘어 다시 나서고, 한 방으로 빌런을 날려 버려요.' },
      { s:1140, title:'꾸중과 칭찬', art:'street', chars:['izuku','bakugo'], terms:[], sum:'이즈쿠는 무모했다고 혼나고, 바쿠고는 도움 받은 게 못마땅해요.' },
      { s:1230, title:'너는 히어로가 될 수 있어', art:'street', chars:['izuku','allmight'], terms:['hero'], sum:'올마이트가 이즈쿠를 찾아와 너는 히어로가 될 수 있다고 말하고, 이즈쿠는 눈물을 쏟아요.' },
      { s:1350, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
    ],
  },
  chars:{
    izuku:{ name:'미도리야 이즈쿠', short:'이즈쿠', alias:['이즈쿠','미도리야','데쿠'], at:[1,0], pos:[300,220], facts:[
      [[1,0],'히어로를 동경하는 중학생이에요.'],
      [[1,270],'개성이 없는 **무개성**이에요.'],
      [[1,480],'히어로 학교 유에이에 가고 싶어 해요.'],
      [[2,780],'바쿠고를 구하려고 맨몸으로 빌런에게 뛰어들었어요.'],
    ], easy:'능력 없는 평범한 애가 그래도 영웅이 되고 싶다고 버티는 이야기예요.' },
    inko:{ name:'미도리야 인코', short:'엄마', alias:['엄마','인코'], at:[1,270], pos:[110,320], facts:[
      [[1,270],'이즈쿠의 엄마예요.'],
    ] },
    bakugo:{ name:'바쿠고 카츠키', short:'바쿠고', alias:['바쿠고','카츠키','캇짱'], at:[1,480], pos:[470,130], facts:[
      [[1,480],'이즈쿠의 소꿉친구예요. 폭발을 일으키는 강한 개성을 가졌고, 이즈쿠를 무시해요.'],
      [[2,540],'진흙 빌런에게 붙잡혔다가 구출됐어요.'],
    ] },
    sludge:{ name:'진흙 빌런', short:'진흙 빌런', alias:['진흙 빌런','슬러지','빌런'], at:[1,720], pos:[470,330], facts:[
      [[1,720],'흐물흐물한 진흙 같은 몸으로 사람 몸을 빼앗으려는 빌런이에요.'],
    ] },
    allmight:{ name:'올마이트', short:'올마이트', alias:['올마이트','올 마이트'], at:[1,0], pos:[140,130], facts:[
      [[1,0],'모두가 인정하는 최고의 히어로예요.'],
      [[2,0],'예전에 큰 부상을 입어, 힘을 낼 수 있는 시간이 짧아요. 평소엔 깡마른 모습이에요.'],
      [[2,1230],'이즈쿠에게 히어로가 될 수 있다고 말했어요.'],
    ] },
  },
  rels:[
    ['izuku','inko','family','아들과 엄마',[1,270]],
    ['izuku','bakugo','rival','소꿉친구지만 괴롭히는 사이',[1,480]],
    ['izuku','allmight','other','동경하는 영웅',[1,0]],
    ['allmight','sludge','rival','쫓는 히어로와 빌런',[1,900]],
  ],
  terms:{
    quirk:{ name:'개성', alias:['개성','초능력'], at:[1,0], facts:[[[1,0],'사람마다 하나씩 갖게 된 초능력이에요. 인구 대부분이 개성을 가졌어요.']], easy:'사람마다 타고나는 특수 능력이에요.' },
    quirkless:{ name:'무개성', alias:['무개성','개성이 없'], at:[1,270], facts:[[[1,270],'개성이 생기지 않은 사람이에요. 이즈쿠가 무개성이에요.']] },
    hero:{ name:'히어로', alias:['히어로','영웅'], at:[1,0], facts:[[[1,0],'개성으로 사람들을 구하고 빌런을 잡는 직업이에요.']] },
    villain:{ name:'빌런', alias:['빌런','악당'], at:[1,720], facts:[[[1,720],'개성을 나쁜 일에 쓰는 범죄자예요.']] },
    ua:{ name:'유에이 고교', alias:['유에이','UA','웅영'], at:[1,480], facts:[[[1,480],'최고의 히어로를 많이 배출한 명문 히어로 학교예요.']] },
  },
  banned:['원 포 올','One For All','우라라카','이이다','토도로키','올 포 원','아이자와','시가라키','입학시험'],
};

WORKS.revengers.guide = {
  season:'1기', eps:2, startAt:[1,0], core:['toman','leap','handshake'],
  episodes:{
    1:{ title:'Reborn', summary:'2017년, 별 볼 일 없는 26세 타케미치는 중학생 시절 여자친구 히나가 폭력 조직 다툼에 휘말려 죽었다는 뉴스를 봐요. 다음 날 선로에 떨어진 순간 12년 전으로 돌아가요.' },
    2:{ title:'Resist', summary:'악수가 타임리프의 열쇠라는 걸 알게 된 타케미치는 다시 과거로 가서, 불량배 키요마사가 여는 싸움판에 맞서기로 해요.' },
  },
  scenes:{
    1:[
      { s:0,    title:'인생 밑바닥', art:'city', chars:['takemichi'], terms:[], sum:'26세 타케미치는 아르바이트에서 연하 점장에게 무시당하며 하루하루 버티듯 살아요.' },
      { s:150,  title:'뉴스 속 이름', art:'night', chars:['takemichi','hina'], terms:['toman'], sum:'뉴스에서 중학생 시절 여자친구 히나와 남동생이 도쿄 만지회라는 조직의 다툼에 휘말려 죽었다는 소식이 나와요.' },
      { s:330,  title:'선로 위로', art:'night', chars:['takemichi'], terms:['leap'], sum:'퇴근길 역에서 누군가에게 떠밀려 선로로 떨어진 타케미치는 눈앞이 하얘져요.' },
      { s:420,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:510,  title:'12년 전 교복', art:'street', chars:['takemichi','friends'], terms:['leap'], sum:'눈을 뜨니 2005년, 불량 중학생 시절이에요. 어린 친구들과 함께 있어요.' },
      { s:720,  title:'얻어맞은 하루', art:'alley', chars:['takemichi','friends'], terms:[], sum:'타케미치 무리는 시부야의 2학년 선배들에게 상대도 안 되게 얻어맞아요.' },
      { s:930,  title:'괴롭힘당하던 소년', art:'night', chars:['takemichi','naoto'], terms:[], sum:'밤길에서 괴롭힘당하던 소년을 구해 주는데, 그 아이는 히나의 남동생 나오토예요.' },
      { s:1080, title:'미래를 말하다', art:'night', chars:['takemichi','naoto'], terms:['toman'], sum:'타케미치는 나오토에게 12년 뒤 누나와 함께 죽게 된다고 털어놓아요.' },
      { s:1200, title:'악수, 그리고 현재', art:'city', chars:['takemichi','naoto'], terms:['handshake','leap'], sum:'두 사람이 악수하자 타케미치는 현재로 돌아와요. 과거에 경고를 들은 나오토는 살아 있고, 형사가 되어 있어요.' },
      { s:1350, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
    ],
    2:[
      { s:0,    title:'형사 나오토의 설명', art:'office', chars:['takemichi','naoto'], terms:['toman'], sum:'나오토는 도쿄 만지회에 대해 설명하지만, 지친 타케미치는 머리에 잘 들어오지 않아요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'다시 악수', art:'office', chars:['takemichi','naoto'], terms:['handshake','leap','mikey'], sum:'악수가 시간 이동의 열쇠라고 본 나오토는, 누나를 구하려면 조직의 사노 만지로를 막아야 한다고 말해요. 다시 악수한 타케미치는 12년 전으로 가요.' },
      { s:420,  title:'싸움판 한가운데', art:'gym', chars:['takemichi','kiyomasa'], terms:['fight'], sum:'눈을 떠 보니 키요마사가 여는 싸움판 한복판이고, 타케미치는 실컷 두들겨 맞아요.' },
      { s:630,  title:'금기의 이름', art:'alley', chars:['takemichi','kiyomasa'], terms:['mikey'], sum:'조직의 우두머리를 만나고 싶다는 말에 키요마사는 야구 배트를 휘두르며 그 이름을 함부로 꺼내지 말라고 위협해요.' },
      { s:840,  title:'히나와의 재회', art:'home', chars:['takemichi','hina'], terms:[], sum:'타케미치는 히나의 집을 찾아가요. 상처를 본 히나는 자기가 남자였다면 지켜 줬을 거라 말하고, 타케미치는 히나를 지키겠다고 약속해요.' },
      { s:1080, title:'다음 희생양', art:'gym', chars:['takemichi','takuya','kiyomasa'], terms:['fight'], sum:'몸이 약한 친구 타쿠야가 싸움판에 끌려 나가자, 타케미치가 나타나 싸움을 멈춰 세워요.' },
      { s:1260, title:'맞서다', art:'gym', chars:['takemichi','kiyomasa'], terms:[], sum:'타케미치는 키요마사 앞으로 걸어가 정면으로 싸움을 걸어요.' },
      { s:1350, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
    ],
  },
  chars:{
    takemichi:{ name:'하나가키 타케미치', short:'타케미치', alias:['타케미치','하나가키','타케밋치'], at:[1,0], pos:[300,220], facts:[
      [[1,0],'26세. 아르바이트로 근근이 사는 청년이에요.'],
      [[1,510],'12년 전, 불량 중학생이던 시절로 돌아갔어요.'],
      [[1,1200],'나오토와 악수하면 현재와 과거를 오갈 수 있어요.'],
      [[2,840],'히나를 지키겠다고 약속했어요.'],
    ], easy:'인생 망한 어른이 과거로 돌아가 첫사랑을 구하려는 이야기예요.' },
    hina:{ name:'타치바나 히나타', short:'히나', alias:['히나','히나타','타치바나'], at:[1,150], pos:[140,130], facts:[
      [[1,150],'타케미치가 중학생 때 사귄 여자친구예요. 2017년 뉴스에서 사망 소식이 전해졌어요.'],
      [[2,840],'과거의 히나는 다친 타케미치를 걱정해 줘요.'],
    ] },
    friends:{ name:'타케미치의 친구들', short:'친구들', alias:['친구들'], at:[1,510], pos:[120,330], facts:[
      [[1,510],'중학생 시절 함께 몰려다니던 불량 친구들이에요.'],
    ] },
    naoto:{ name:'타치바나 나오토', short:'나오토', alias:['나오토'], at:[1,930], pos:[470,130], facts:[
      [[1,930],'히나의 남동생이에요.'],
      [[1,1200],'타케미치의 경고 덕분에 살아남아 현재는 형사예요.'],
      [[2,240],'누나를 구하려면 사노 만지로를 막아야 한다고 말해요.'],
    ] },
    kiyomasa:{ name:'키요마사', short:'키요마사', alias:['키요마사'], at:[2,420], pos:[470,330], facts:[
      [[2,420],'도쿄 만지회 소속 불량배예요. 중학생들을 붙잡아 싸움판을 열어요.'],
    ] },
    takuya:{ name:'타쿠야', short:'타쿠야', alias:['타쿠야'], at:[2,1080], pos:[300,390], facts:[
      [[2,1080],'타케미치의 친구예요. 몸이 약한 편이에요.'],
    ] },
  },
  rels:[
    ['takemichi','hina','friend','중학생 시절 여자친구',[1,150]],
    ['hina','naoto','family','누나와 남동생',[1,930]],
    ['takemichi','naoto','peer','시간을 넘는 협력자',[1,1200]],
    ['takemichi','friends','friend','중학교 친구들',[1,510]],
    ['takemichi','kiyomasa','rival','괴롭히는 선배',[2,420]],
    ['takemichi','takuya','friend','친구',[2,1080]],
  ],
  terms:{
    toman:{ name:'도쿄 만지회', alias:['도쿄 만지회','도만','만지회'], at:[1,150], facts:[[[1,150],'뉴스에 나온 폭력 조직이에요. 히나의 죽음과 얽혀 있어요.'],[[2,420],'키요마사도 이 조직 소속이에요.']] },
    leap:{ name:'타임리프', alias:['타임리프','과거로','시간 이동'], at:[1,330], facts:[[[1,330],'선로에 떨어진 순간 타케미치는 12년 전으로 돌아갔어요.']] },
    handshake:{ name:'악수', alias:['악수'], at:[1,1200], facts:[[[1,1200],'나오토와 악수하자 타케미치가 현재로 돌아왔어요.'],[[2,240],'다시 악수해 과거로 갔어요. 악수가 시간 이동의 열쇠예요.']] },
    mikey:{ name:'사노 만지로', alias:['사노','만지로','마이키'], at:[2,240], facts:[[[2,240],'나오토가 막아야 한다고 말한 도쿄 만지회의 인물이에요.']] },
    fight:{ name:'싸움판', alias:['싸움판','결투'], at:[2,420], facts:[[[2,420],'키요마사가 중학생들을 싸우게 하고 돈을 거는 판이에요.']] },
  },
  banned:['드라켄','류구지','키사키','바지','카즈토라','치후유','하카이','핼러윈','블러디'],
};

WORKS.edgerunners.guide = {
  season:'시즌 1', eps:2, startAt:[1,0], core:['cyberware','sandevistan','arasaka','ripper'],
  episodes:{
    1:{ title:'Let You Down', summary:'2076년 나이트시티. 엄마 글로리아의 바람으로 아라사카 아카데미에 다니는 데이비드는, 총격전에 휘말린 엄마를 잃고 엄마가 남긴 군용 임플란트 「산데비스탄」을 몸에 넣기로 해요.' },
    2:{ title:'Like a Boy', summary:'산데비스탄을 이식한 데이비드는 학교에서 쫓겨나고, 거리에서 만난 수상한 소녀 루시와 손을 잡아요.' },
  },
  scenes:{
    1:[
      { s:0,    title:'나이트시티', art:'city', chars:[], terms:['cyberware'], sum:'몸을 기계로 바꾸는 사이버웨어가 흔한 도시예요. 사이버웨어에 정신을 잃고 폭주한 사람을 진압 부대가 처리해요.' },
      { s:180,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:270,  title:'아라사카 아카데미', art:'classroom', chars:['david'], terms:['arasaka'], sum:'데이비드는 비싼 학비를 내며 대기업 아라사카가 세운 학교에 다니지만, 형편이 넉넉하지 않아 늘 겉돌아요.' },
      { s:420,  title:'불법 개조', art:'classroom', chars:['david','gloria'], terms:[], sum:'유료 업데이트를 피하려고 장비를 몰래 개조했다가 학교 시스템을 망가뜨리고, 엄마 글로리아가 뒷수습을 해요.' },
      { s:600,  title:'말다툼', art:'street', chars:['david','gloria'], terms:[], sum:'돌아오는 차 안에서 두 사람은 학교 문제로 크게 다퉈요.' },
      { s:720,  title:'총격전', art:'fire', chars:['david','gloria'], terms:[], sum:'갱단과 기업 간부의 차량 사이에서 벌어진 총격전에 휘말려 글로리아가 크게 다쳐요.' },
      { s:870,  title:'병원에서 알게 된 것', art:'night', chars:['david','gloria'], terms:['sandevistan'], sum:'데이비드는 엄마 치료비로 저축을 다 써 버리고, 엄마가 군용 임플란트 산데비스탄을 몰래 가지고 있었다는 걸 알게 돼요.' },
      { s:1020, title:'모욕', art:'classroom', chars:['david','katsuo'], terms:[], sum:'같은 반 카츠오가 데이비드를 때리고 엄마를 모욕해요.' },
      { s:1140, title:'홀로 남다', art:'night', chars:['david','gloria'], terms:[], sum:'글로리아가 끝내 세상을 떠나요.' },
      { s:1230, title:'리퍼닥을 찾아서', art:'darkroom', chars:['david','doc'], terms:['ripper','sandevistan'], sum:'돈도 갈 곳도 없는 데이비드는 불법 시술사 닥을 찾아가 산데비스탄을 몸에 넣어 달라고 부탁해요.' },
      { s:1350, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
    ],
    2:[
      { s:0,    title:'이식', art:'darkroom', chars:['david','doc'], terms:['sandevistan','ripper'], sum:'닥이 산데비스탄을 이식해 주자, 데이비드는 한순간 세상이 느려지는 감각을 얻어요.' },
      { s:180,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:270,  title:'복수', art:'classroom', chars:['david','katsuo'], terms:['sandevistan'], sum:'학교로 돌아간 데이비드는 카메라가 보는 앞에서 카츠오를 때려눕히고 퇴학당해요.' },
      { s:480,  title:'지켜보는 간부', art:'office', chars:['tanaka'], terms:['arasaka'], sum:'카츠오의 아버지인 아라사카 간부는 부작용 없이 산데비스탄을 쓰는 데이비드에게 흥미를 보여요.' },
      { s:630,  title:'루시', art:'street', chars:['david','lucy'], terms:[], sum:'거리를 떠돌던 데이비드는 신비로운 소녀 루시를 만나고, 루시는 함께 일하자고 해요.' },
      { s:840,  title:'지하철 소매치기', art:'city', chars:['david','lucy'], terms:['sandevistan'], sum:'두 사람은 밤새 지하철에서 소매치기를 하고, 데이비드는 산데비스탄을 너무 많이 써서 쓰러져요.' },
      { s:1020, title:'경고', art:'darkroom', chars:['david','doc'], terms:['ripper'], sum:'닥은 면역 억제제를 주며 산데비스탄 사용을 줄이라고 경고해요.' },
      { s:1140, title:'달의 꿈', art:'night', chars:['david','lucy'], terms:[], sum:'루시는 자기 집에서 달에 가고 싶다는 꿈을 이야기하며 가상의 달 표면을 보여 줘요.' },
      { s:1260, title:'루시의 속셈', art:'night', chars:['lucy','david'], terms:['edgerunner'], sum:'사실 루시는 데이비드를 용병 무리에게 넘기려고 시간을 끌고 있었어요.' },
      { s:1350, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
    ],
  },
  chars:{
    david:{ name:'데이비드 마르티네스', short:'데이비드', alias:['데이비드','마르티네스'], at:[1,270], pos:[300,220], facts:[
      [[1,270],'아라사카 아카데미에 다니는 학생이에요. 집안 형편이 어려워요.'],
      [[1,1140],'엄마를 잃고 혼자가 됐어요.'],
      [[2,0],'몸에 산데비스탄을 이식했어요.'],
      [[2,270],'학교에서 퇴학당했어요.'],
    ], easy:'가진 것 없는 소년이 위험한 기계 몸으로 거친 도시에 뛰어드는 이야기예요.' },
    gloria:{ name:'글로리아 마르티네스', short:'글로리아', alias:['글로리아','엄마'], at:[1,420], pos:[140,130], facts:[
      [[1,420],'데이비드의 엄마예요. 아들이 성공하길 바라며 학비를 대요.'],
      [[1,870],'군용 임플란트 산데비스탄을 몰래 갖고 있었어요.'],
    ] },
    katsuo:{ name:'카츠오', short:'카츠오', alias:['카츠오'], at:[1,1020], pos:[470,130], facts:[
      [[1,1020],'데이비드를 괴롭히는 같은 반 학생이에요.'],
      [[2,480],'아버지가 아라사카 간부예요.'],
    ] },
    doc:{ name:'닥', short:'닥', alias:['닥','리퍼닥'], at:[1,1230], pos:[120,330], facts:[
      [[1,1230],'몸에 사이버웨어를 넣어 주는 불법 시술사예요.'],
      [[2,1020],'데이비드에게 산데비스탄을 너무 많이 쓰지 말라고 경고해요.'],
    ] },
    tanaka:{ name:'카츠오의 아버지', short:'다나카 간부', alias:['다나카','간부'], at:[2,480], pos:[470,330], facts:[
      [[2,480],'아라사카의 간부예요. 데이비드에게 흥미를 보여요.'],
    ] },
    lucy:{ name:'루시', short:'루시', alias:['루시'], at:[2,630], pos:[300,390], facts:[
      [[2,630],'거리에서 만난 수수께끼 같은 소녀예요.'],
      [[2,1140],'달에 가는 게 꿈이라고 말해요.'],
      [[2,1260],'데이비드를 용병 무리에게 넘기려 하고 있었어요.'],
    ] },
  },
  rels:[
    ['david','gloria','family','아들과 엄마',[1,420]],
    ['david','katsuo','rival','괴롭히는 동급생',[1,1020]],
    ['david','doc','other','시술해 준 리퍼닥',[1,1230]],
    ['katsuo','tanaka','family','아들과 아버지',[2,480]],
    ['david','lucy','other','함께 일하게 된 소녀',[2,630]],
  ],
  terms:{
    cyberware:{ name:'사이버웨어', alias:['사이버웨어','임플란트','사이버사이코'], at:[1,0], facts:[[[1,0],'몸에 이식하는 기계 장치예요. 너무 많이 쓰면 정신이 무너져 폭주할 수 있어요.']], easy:'몸에 끼우는 기계 업그레이드 부품이에요.' },
    arasaka:{ name:'아라사카', alias:['아라사카','아라사카 아카데미'], at:[1,270], facts:[[[1,270],'나이트시티를 주무르는 거대 기업이에요. 데이비드가 다니는 학교도 이 회사가 세웠어요.']] },
    sandevistan:{ name:'산데비스탄', alias:['산데비스탄','산데'], at:[1,870], facts:[[[1,870],'글로리아가 갖고 있던 군용 임플란트예요.'],[[2,0],'쓰는 순간 주변이 느려진 것처럼 엄청 빨리 움직일 수 있어요.'],[[2,840],'많이 쓰면 몸에 큰 무리가 가요.']] },
    ripper:{ name:'리퍼닥', alias:['리퍼닥','시술사'], at:[1,1230], facts:[[[1,1230],'사이버웨어를 몸에 넣어 주는 시술사예요. 닥은 불법으로 일해요.']] },
    edgerunner:{ name:'용병 무리', alias:['용병','엣지러너'], at:[2,1260], facts:[[[2,1260],'돈을 받고 위험한 일을 하는 무리예요. 루시는 이들과 엮여 있어요.']] },
  },
  banned:['메인','레베카','키위','도리오','팔코','필라','아담 스매셔','스매셔','사이버사이코시스'],
};

WORKS.sakamoto.guide = {
  season:'1기', eps:2, startAt:[1,0], core:['store','nokill','mindread'],
  episodes:{
    1:{ title:'전설의 킬러', summary:'전설의 킬러였던 사카모토는 사랑에 빠져 은퇴한 뒤 동네 가게 주인이 됐어요. 그를 데려가거나 없애라는 명령을 받은 옛 후배 신이 찾아와요.' },
    2:{ title:'VS 손희·바쵸', summary:'가게 점원이 된 신은 사카모토가 아내와 한 약속을 알게 되고, 두 사람은 차이나타운에서 만난 소녀 루를 지키려 킬러들과 싸워요.' },
  },
  scenes:{
    1:[
      { s:0,    title:'전설의 킬러', art:'night', chars:['sakamoto'], terms:[], sum:'모든 악당이 두려워하던 최강의 킬러 사카모토가 있었어요.' },
      { s:150,  title:'은퇴의 이유', art:'town', chars:['sakamoto','aoi'], terms:['nokill'], sum:'편의점 점원 아오이에게 첫눈에 반한 사카모토는 킬러 일을 그만두고 결혼해요.' },
      { s:300,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:390,  title:'동네 가게 아저씨', art:'town', chars:['sakamoto','aoi','hana'], terms:['store'], sum:'몇 년 뒤, 몸이 푸근해진 사카모토는 아내 아오이, 딸 하나와 함께 동네 가게를 꾸려요.' },
      { s:570,  title:'찾아온 신', art:'town', chars:['sakamoto','shin'], terms:['mindread'], sum:'옛 후배 아사쿠라 신이 조직 보스의 명령으로 사카모토를 데려가거나 없애려고 찾아와요. 신은 남의 속마음을 읽을 수 있어요.' },
      { s:780,  title:'녹슬지 않은 실력', art:'town', chars:['sakamoto','shin'], terms:['nokill'], sum:'신이 덤벼들지만 사카모토는 가게 물건만으로 가볍게 제압하고, 신을 살려 둔 채 가족과 함께 밥을 먹여요.' },
      { s:990,  title:'보스에게 맞선 신', art:'night', chars:['shin','boss'], terms:[], sum:'신은 일을 거절하겠다고 보스에게 말하지만, 보스는 신까지 처리하려 해요.' },
      { s:1140, title:'뒤따라온 사카모토', art:'night', chars:['sakamoto','shin','boss'], terms:['nokill'], sum:'몰래 신을 따라온 사카모토가 나타나 신과 함께 조직을 쓰러뜨려요.' },
      { s:1260, title:'새 점원', art:'town', chars:['sakamoto','shin'], terms:['store'], sum:'사카모토는 신을 자기 가게 점원으로 들여요.' },
      { s:1350, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
    ],
    2:[
      { s:0,    title:'유능한 점원 신', art:'town', chars:['shin'], terms:['mindread','store'], sum:'신은 손님의 속마음을 읽어 필요한 물건을 척척 찾아 주는 점원이 돼요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'아오이의 조건', art:'town', chars:['shin','aoi'], terms:['nokill'], sum:'신은 아오이가 사카모토의 킬러 생활을 강하게 반대하고, 다시 그 세계로 돌아가면 떠나겠다고 했다는 걸 알게 돼요.' },
      { s:420,  title:'차이나타운의 소녀', art:'street', chars:['sakamoto','shin','lu'], terms:[], sum:'고기만두를 사러 간 차이나타운에서 깡패들과 싸우던 소녀 루를 구해 함께 달아나요.' },
      { s:600,  title:'루의 사정', art:'street', chars:['sakamoto','shin','lu'], terms:['treasure'], sum:'루는 보물창고 열쇠를 노린 다른 조직에게 몰살당한 마피아 일가의 유일한 생존자예요.' },
      { s:750,  title:'만두와 맞바꾼 약속', art:'street', chars:['sakamoto','lu'], terms:['store'], sum:'사카모토는 가게에서 고기만두를 만들어 주는 조건으로 루를 돕기로 해요.' },
      { s:870,  title:'킬러 둘', art:'battle', chars:['sakamoto','shin','sonhee','bacho'], terms:[], sum:'상대 조직이 고용한 킬러 손희와 바쵸가 습격해 와요.' },
      { s:1020, title:'읽어 버린 약속', art:'battle', chars:['sakamoto','shin','sonhee','bacho'], terms:['nokill','mindread'], sum:'싸우던 중 신은 사카모토의 속마음에서 아오이에게 다시는 사람을 죽이지 않겠다고 한 약속을 읽어요. 사카모토는 약속을 지키며 킬러들을 쓰러뜨려요.' },
      { s:1170, title:'보물창고', art:'night', chars:['lu'], terms:['treasure'], sum:'보물창고 안에는 루가 어른이 되면 함께 마시려던 아버지의 술 한 병이 있었어요.' },
      { s:1260, title:'10억 엔의 현상금', art:'night', chars:['lu','sakamoto'], terms:['bounty','store'], sum:'루는 가게의 만두 담당이 되고, 살인청부업자 연맹은 사카모토에게 10억 엔의 현상금을 걸어요.' },
      { s:1350, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
    ],
  },
  chars:{
    sakamoto:{ name:'사카모토 타로', short:'사카모토', alias:['사카모토','타로'], at:[1,0], pos:[300,220], facts:[
      [[1,0],'모든 악당이 두려워하던 전설의 킬러였어요.'],
      [[1,150],'아오이와 결혼하며 킬러 일을 그만뒀어요.'],
      [[1,390],'지금은 살이 찐 동네 가게 주인이에요. 실력은 그대로예요.'],
      [[2,1020],'아내에게 다시는 사람을 죽이지 않겠다고 약속했어요.'],
      [[2,1260],'10억 엔의 현상금이 걸렸어요.'],
    ], easy:'은퇴한 액션 영화 주인공이 동네 마트 사장님이 된 느낌이에요.' },
    aoi:{ name:'사카모토 아오이', short:'아오이', alias:['아오이'], at:[1,150], pos:[140,130], facts:[
      [[1,150],'사카모토의 아내예요. 예전엔 편의점 점원이었어요.'],
      [[2,240],'남편이 킬러로 돌아가는 걸 강하게 반대해요.'],
    ] },
    hana:{ name:'사카모토 하나', short:'하나', alias:['하나'], at:[1,390], pos:[110,300], facts:[
      [[1,390],'사카모토와 아오이의 딸이에요.'],
    ] },
    shin:{ name:'아사쿠라 신', short:'신', alias:['신','아사쿠라'], at:[1,570], pos:[470,130], facts:[
      [[1,570],'사카모토의 옛 후배 킬러예요. 다른 사람의 속마음을 읽을 수 있어요.'],
      [[1,1260],'사카모토 가게의 점원이 됐어요.'],
    ] },
    boss:{ name:'조직 보스', short:'보스', alias:['보스'], at:[1,570], pos:[470,330], facts:[
      [[1,570],'신에게 사카모토를 데려오거나 없애라고 시킨 조직의 우두머리예요.'],
    ] },
    lu:{ name:'루 샤오탕', short:'루', alias:['루','샤오탕'], at:[2,420], pos:[300,390], facts:[
      [[2,420],'차이나타운에서 만난 소녀예요.'],
      [[2,600],'몰살당한 마피아 일가의 유일한 생존자예요.'],
      [[2,1260],'사카모토 가게에서 고기만두를 만들게 됐어요.'],
    ] },
    sonhee:{ name:'손희', short:'손희', alias:['손희'], at:[2,870], pos:[540,250], facts:[[[2,870],'상대 조직이 고용한 킬러예요.']] },
    bacho:{ name:'바쵸', short:'바쵸', alias:['바쵸'], at:[2,870], pos:[540,400], facts:[[[2,870],'손희와 함께 습격한 킬러예요.']] },
  },
  rels:[
    ['sakamoto','aoi','family','부부',[1,150]],
    ['sakamoto','hana','family','아빠와 딸',[1,390]],
    ['aoi','hana','family','엄마와 딸',[1,390]],
    ['sakamoto','shin','peer','옛 선후배에서 사장과 점원으로',[1,1260]],
    ['shin','boss','rival','명령을 거절한 상대',[1,990]],
    ['sakamoto','lu','peer','사장과 만두 담당',[2,1260]],
    ['sonhee','bacho','peer','함께 온 킬러',[2,870]],
    ['sakamoto','sonhee','rival','맞서 싸운 상대',[2,870]],
  ],
  terms:{
    store:{ name:'사카모토 상점', alias:['가게','상점','편의점'], at:[1,390], facts:[[[1,390],'사카모토 가족이 운영하는 동네 가게예요.'],[[1,1260],'신이 점원으로 일하게 됐어요.']] },
    nokill:{ name:'살인 금지 약속', alias:['약속','죽이지'], at:[1,150], facts:[[[1,150],'사카모토는 결혼하면서 킬러 일을 그만뒀어요.'],[[2,1020],'아내에게 다시는 사람을 죽이지 않겠다고 약속했어요.']] },
    mindread:{ name:'독심술', alias:['독심술','속마음','마음을 읽'], at:[1,570], facts:[[[1,570],'신은 다른 사람의 속마음을 읽을 수 있어요.']], easy:'상대 머릿속 생각이 자막처럼 들리는 능력이에요.' },
    treasure:{ name:'보물창고', alias:['보물창고','열쇠'], at:[2,600], facts:[[[2,600],'루의 일가가 지키던 창고예요. 다른 조직이 이 열쇠를 노렸어요.'],[[2,1170],'안에는 아버지가 남긴 술 한 병이 있었어요.']] },
    bounty:{ name:'현상금', alias:['현상금','10억'], at:[2,1260], facts:[[[2,1260],'살인청부업자 연맹이 사카모토에게 10억 엔을 걸었어요.']] },
  },
  banned:['나구모','슬러','ORDER','오더','JCC','세바','헤이스케','오사라기','카라사와'],
};

WORKS.onepunch.guide = {
  season:'1기', eps:2, startAt:[1,0], core:['kaijin','hobby','onepunch'],
  episodes:{
    1:{ title:'최강의 남자', summary:'취미로 히어로를 하는 대머리 남자 사이타마는 어떤 괴인도 주먹 한 방에 쓰러뜨려요. 너무 강해져서 싸움이 시시해진 게 고민이에요.' },
    2:{ title:'고고한 사이보그', summary:'모기 괴인을 쫓던 사이보그 제노스가 위기에 빠지자 사이타마가 한 방에 끝내고, 제노스는 사이타마의 제자가 되겠다고 해요.' },
  },
  scenes:{
    1:[
      { s:0,    title:'파괴된 도시', art:'fire', chars:['vaccine'], terms:['kaijin'], sum:'괴인 백신맨이 도시를 쑥대밭으로 만들고 소녀를 해치려 해요.' },
      { s:150,  title:'한 방', art:'city', chars:['saitama','vaccine'], terms:['onepunch','hobby'], sum:'대머리에 망토를 두른 사이타마가 나타나 백신맨을 주먹 한 방에 날려 버려요. 사이타마는 취미로 히어로를 하고 있어요.' },
      { s:300,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:390,  title:'3년 전', art:'street', chars:['saitama','crab'], terms:['kaijin'], sum:'3년 전 취업 준비생이던 사이타마는 게 괴인에게서 소년을 구한 일을 계기로 히어로가 되기로 해요.' },
      { s:600,  title:'너무 강해진 남자', art:'training', chars:['saitama'], terms:['hobby'], sum:'혹독한 단련 끝에 머리카락까지 빠질 만큼 강해졌지만, 상대가 다 한 방에 끝나 싸움이 지루해졌어요.' },
      { s:780,  title:'거대 괴인 형제', art:'city', chars:['saitama','brothers'], terms:['kaijin','onepunch'], sum:'거대한 괴인 형제가 나타나지만 이번에도 한 방이에요.' },
      { s:960,  title:'꿈속의 강적', art:'night', chars:['saitama'], terms:['underground'], sum:'사이타마는 땅속 종족이 쳐들어와 자신과 호각으로 싸우는 꿈을 꾸며 오랜만에 설레요.' },
      { s:1110, title:'진짜 침공', art:'city', chars:['saitama','underking'], terms:['underground','onepunch'], sum:'잠에서 깨 보니 정말 땅속 종족이 쳐들어왔지만, 사이타마는 그 우두머리도 한 방에 쓰러뜨려요.' },
      { s:1260, title:'시시한 결말', art:'city', chars:['saitama'], terms:['underground'], sum:'남은 땅속 종족은 물러가고, 사이타마는 다시 허무해져요.' },
      { s:1350, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
    ],
    2:[
      { s:0,    title:'피를 빠는 괴인', art:'city', chars:['mosquito'], terms:['kaijin'], sum:'모기 떼를 부리는 괴인 모기 소녀가 도시 사람들의 피를 빨아들여요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'사이보그 제노스', art:'battle', chars:['genos','mosquito'], terms:['cyborg'], sum:'몸을 기계로 바꾼 사이보그 제노스가 모기 소녀를 쫓아 맞서 싸워요.' },
      { s:480,  title:'최후의 수단', art:'battle', chars:['genos','mosquito'], terms:['cyborg'], sum:'모기 소녀에게 몰린 제노스는 스스로를 폭발시키는 마지막 수단까지 생각해요.' },
      { s:660,  title:'모기 잡으러 온 남자', art:'battle', chars:['saitama','genos','mosquito'], terms:['onepunch'], sum:'모기에 물린 게 짜증나 쫓아온 사이타마가 손바닥 한 번으로 모기 소녀를 끝내요.' },
      { s:870,  title:'제노스의 과거', art:'night', chars:['genos','saitama'], terms:['cyborg'], sum:'제노스는 폭주한 사이보그에게 고향과 가족을 잃고 복수를 위해 몸을 기계로 바꿨다고 털어놔요.' },
      { s:1080, title:'제자로 받아 주세요', art:'home', chars:['genos','saitama'], terms:['hobby'], sum:'제노스는 사이타마의 강함의 비밀을 알고 싶다며 제자로 받아 달라고 조르고, 사이타마는 마지못해 받아들여요.' },
      { s:1350, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
    ],
  },
  chars:{
    saitama:{ name:'사이타마', short:'사이타마', alias:['사이타마','대머리','망토'], at:[1,150], pos:[300,220], facts:[
      [[1,150],'취미로 히어로를 하는 대머리 남자예요. 어떤 적도 주먹 한 방에 쓰러뜨려요.'],
      [[1,390],'3년 전 소년을 구한 일을 계기로 히어로가 되기로 했어요.'],
      [[1,600],'너무 강해져서 싸움이 시시한 게 고민이에요.'],
      [[2,1080],'제노스를 제자로 받아들였어요.'],
    ], easy:'게임을 만렙 찍어 버려서 재미가 없어진 사람 같아요.' },
    vaccine:{ name:'백신맨', short:'백신맨', alias:['백신맨'], at:[1,0], pos:[140,120], facts:[[[1,0],'도시를 파괴하던 괴인이에요. 사이타마의 한 방에 쓰러졌어요.']] },
    crab:{ name:'게 괴인', short:'게 괴인', alias:['게 괴인','게'], at:[1,390], pos:[110,300], facts:[[[1,390],'3년 전 사이타마가 처음 맞선 괴인이에요.']] },
    brothers:{ name:'거대 괴인 형제', short:'괴인 형제', alias:['형제','거대 괴인'], at:[1,780], pos:[470,120], facts:[[[1,780],'거대한 몸집의 괴인 형제예요.']] },
    underking:{ name:'땅속 종족의 왕', short:'지저왕', alias:['지저왕','땅속 왕'], at:[1,1110], pos:[470,320], facts:[[[1,1110],'땅속에서 쳐들어온 종족의 우두머리예요.']] },
    mosquito:{ name:'모기 소녀', short:'모기 소녀', alias:['모기 소녀','모기'], at:[2,0], pos:[540,220], facts:[[[2,0],'모기 떼로 사람들의 피를 빨아들이는 괴인이에요.']] },
    genos:{ name:'제노스', short:'제노스', alias:['제노스'], at:[2,240], pos:[300,390], facts:[
      [[2,240],'온몸을 기계로 바꾼 사이보그예요.'],
      [[2,870],'폭주한 사이보그에게 고향과 가족을 잃었어요. 복수를 다짐하고 있어요.'],
      [[2,1080],'사이타마의 제자가 됐어요.'],
    ] },
  },
  rels:[
    ['saitama','vaccine','rival','한 방에 쓰러뜨린 괴인',[1,150]],
    ['saitama','crab','rival','히어로가 된 계기',[1,390]],
    ['saitama','brothers','rival','한 방에 쓰러뜨린 괴인',[1,780]],
    ['saitama','underking','rival','한 방에 쓰러뜨린 괴인',[1,1110]],
    ['genos','mosquito','rival','쫓던 괴인',[2,240]],
    ['saitama','genos','peer','스승과 제자',[2,1080]],
  ],
  terms:{
    kaijin:{ name:'괴인', alias:['괴인','괴물'], at:[1,0], facts:[[[1,0],'사람을 해치는 괴물들이에요. 히어로가 맞서 싸워요.']] },
    hobby:{ name:'취미 히어로', alias:['취미','히어로'], at:[1,150], facts:[[[1,150],'사이타마는 누구에게 속하지 않고 취미로 히어로를 해요.']], easy:'돈 안 받고 동호회처럼 히어로를 하는 거예요.' },
    onepunch:{ name:'한 방', alias:['한 방','원펀치','펀치'], at:[1,150], facts:[[[1,150],'사이타마는 어떤 상대도 주먹 한 방에 끝내요.']] },
    underground:{ name:'땅속 종족', alias:['땅속 종족','지저인','지저족'], at:[1,960], facts:[[[1,960],'사이타마의 꿈에 나온 강적이에요.'],[[1,1110],'실제로 쳐들어왔지만 금세 물러갔어요.']] },
    cyborg:{ name:'사이보그', alias:['사이보그','기계 몸'], at:[2,240], facts:[[[2,240],'몸을 기계로 바꾼 사람이에요. 제노스가 사이보그예요.']] },
  },
  banned:['킹','타츠마키','뱅','실버팽','가로우','보로스','협회 랭킹','S급','진화의 집','아머드 고릴라','쿠세노'],
};

WORKS.windbreaker.guide = {
  season:'1기', eps:2, startAt:[1,0], core:['furin','bofurin','town'],
  episodes:{
    1:{ title:'사쿠라, 후린에 오다', summary:'싸움으로 자기를 증명하려는 외톨이 사쿠라가 마을에 와서 코토하를 불량배에게서 구하고, 마을을 지키는 후린 고교 학생들 「보후린」을 알게 돼요.' },
    2:{ title:'꿈속의 히어로', summary:'입학식 날 사쿠라는 동급생 니레이를 만나고, 후린 고교 교실에서 개성 강한 반 친구들과 위험한 스기시타를 마주해요.' },
  },
  scenes:{
    1:[
      { s:0,    title:'외톨이 소년', art:'void', chars:['sakura'], terms:[], sum:'겉모습 때문에 따돌림받아 온 사쿠라는 싸움으로 자기 가치를 증명하려 해요.' },
      { s:180,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:270,  title:'코토하를 구하다', art:'street', chars:['sakura','kotoha'], terms:['town'], sum:'마을에 온 사쿠라는 코토하에게 시비를 걸던 불량배들을 쓰러뜨려요.' },
      { s:450,  title:'오므라이스', art:'home', chars:['sakura','kotoha'], terms:['town'], sum:'코토하는 자기 카페에서 오므라이스를 대접하며, 예전 이 마을이 불량배들의 세력 다툼으로 거칠었다고 이야기해요.' },
      { s:660,  title:'인질', art:'street', chars:['sakura','kotoha'], terms:[], sum:'불량배들이 패거리를 데리고 돌아와 코토하를 붙잡아요. 사쿠라가 구해 내지만 칼과 배트에 다쳐 몰려요.' },
      { s:870,  title:'후린 고교 학생들', art:'street', chars:['sakura','hiiragi'], terms:['furin'], sum:'후린 고교 학생들이 나타나 함께 불량배들을 처리해요.' },
      { s:1020, title:'보후린', art:'town', chars:['sakura','kotoha','hiiragi'], terms:['bofurin','furin'], sum:'코토하는 2년 전 후린 학생들이 마을을 안전하게 만들었고, 주민들이 그들을 「보후린」이라 부르며 반긴다고 알려 줘요. 사쿠라도 후린 고교 학생이 될 참이에요.' },
      { s:1200, title:'어색한 칭찬', art:'town', chars:['sakura','kotoha'], terms:['bofurin'], sum:'마을 사람들의 칭찬에 사쿠라는 어쩔 줄 몰라하지만, 결국 후린 학생들을 노린 불량배를 막아서요.' },
      { s:1350, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
    ],
    2:[
      { s:0,    title:'할머니를 업고', art:'town', chars:['sakura','kotoha'], terms:['town'], sum:'입학식 날 아침, 사쿠라가 할머니를 업고 카페에 들어오고 코토하가 아침을 챙겨 줘요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'니레이', art:'home', chars:['sakura','kotoha','nirei'], terms:['furin'], sum:'같은 신입생 니레이가 넘어지듯 들어와 사쿠라와 티격태격해요.' },
      { s:420,  title:'선물 공세', art:'town', chars:['sakura'], terms:['town'], sum:'마을 가게들이 사쿠라에게 음식을 계속 건네서 양손이 봉지로 가득 차요.' },
      { s:570,  title:'맞고 있던 니레이', art:'alley', chars:['sakura','nirei'], terms:[], sum:'불량배들에게 맞고 있던 니레이를 사쿠라가 구해요.' },
      { s:750,  title:'강해지고 싶어서', art:'alley', chars:['sakura','nirei'], terms:['furin'], sum:'니레이는 중학교 때 괴롭힘을 당했고, 강해지고 싶어서 후린에 왔다고 털어놔요. 그리고 사쿠라에 대한 걸 수첩에 적기 시작해요.' },
      { s:930,  title:'같은 반', art:'classroom', chars:['sakura','nirei','suo'], terms:['furin'], sum:'두 사람은 같은 반이 되고, 스오가 사쿠라의 싸움을 칭찬하며 반 분위기가 사쿠라 쪽으로 기울어요.' },
      { s:1080, title:'개성 강한 반 친구들', art:'classroom', chars:['sakura','suo','kiryu','tsugeura'], terms:[], sum:'키류, 츠게우라 같은 반 친구들도 저마다 존재감을 드러내요.' },
      { s:1230, title:'스기시타', art:'classroom', chars:['sakura','sugishita'], terms:[], sum:'반에서 가장 위험한 스기시타가 책상을 던지며 사쿠라를 노려보고, 두 사람 사이에 싸움의 기운이 감돌아요.' },
      { s:1350, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
    ],
  },
  chars:{
    sakura:{ name:'사쿠라 하루카', short:'사쿠라', alias:['사쿠라','하루카'], at:[1,0], pos:[300,220], facts:[
      [[1,0],'외모 때문에 따돌림받아 온 외톨이예요. 싸움으로 자기를 증명하려 해요.'],
      [[1,1020],'후린 고교에 입학하러 이 마을에 왔어요.'],
      [[2,570],'괴롭힘당하던 니레이를 구해 줬어요.'],
    ], easy:'혼자가 익숙한 싸움꾼이 처음으로 동료와 마을을 얻는 이야기예요.' },
    kotoha:{ name:'타치바나 코토하', short:'코토하', alias:['코토하','타치바나'], at:[1,270], pos:[140,130], facts:[
      [[1,270],'마을에서 카페를 하는 소녀예요.'],
      [[1,450],'사쿠라에게 오므라이스를 대접하고 마을 이야기를 들려줘요.'],
    ] },
    hiiragi:{ name:'히이라기', short:'히이라기', alias:['히이라기'], at:[1,870], pos:[110,320], facts:[
      [[1,870],'불량배와 싸우는 사쿠라를 도우러 온 후린 고교 학생이에요.'],
    ] },
    nirei:{ name:'니레이 아키히코', short:'니레이', alias:['니레이','아키히코'], at:[2,240], pos:[470,130], facts:[
      [[2,240],'사쿠라와 같은 후린 고교 신입생이에요.'],
      [[2,750],'강해지고 싶어서 후린에 왔어요. 수첩에 이것저것 기록해요.'],
    ] },
    suo:{ name:'스오 하야토', short:'스오', alias:['스오','하야토'], at:[2,930], pos:[470,320], facts:[[[2,930],'같은 반 친구예요. 사쿠라의 싸움을 칭찬했어요.']] },
    kiryu:{ name:'키류 미츠키', short:'키류', alias:['키류','미츠키'], at:[2,1080], pos:[300,400], facts:[[[2,1080],'같은 반 친구예요.']] },
    tsugeura:{ name:'츠게우라 타이가', short:'츠게우라', alias:['츠게우라','타이가'], at:[2,1080], pos:[540,240], facts:[[[2,1080],'같은 반 친구예요.']] },
    sugishita:{ name:'스기시타 쿄타로', short:'스기시타', alias:['스기시타','쿄타로'], at:[2,1230], pos:[540,400], facts:[[[2,1230],'반에서 가장 위험하다고 알려진 학생이에요. 사쿠라를 노려봐요.']] },
  },
  rels:[
    ['sakura','kotoha','friend','구해 준 사이',[1,270]],
    ['sakura','hiiragi','peer','후린 선배',[1,870]],
    ['sakura','nirei','friend','첫 친구',[2,750]],
    ['sakura','suo','peer','같은 반',[2,930]],
    ['sakura','kiryu','peer','같은 반',[2,1080]],
    ['sakura','tsugeura','peer','같은 반',[2,1080]],
    ['sakura','sugishita','rival','신경전',[2,1230]],
  ],
  terms:{
    town:{ name:'마을', alias:['마을','동네'], at:[1,270], generic:true, facts:[[[1,450],'예전엔 불량배들의 세력 다툼으로 거칠었던 마을이에요.']] },
    furin:{ name:'후린 고교', alias:['후린','후린 고교'], at:[1,870], facts:[[[1,870],'싸움 실력으로 유명한 고등학교예요.'],[[1,1020],'2년 전 이 학교 학생들이 마을을 안전하게 만들었어요.']] },
    bofurin:{ name:'보후린', alias:['보후린','방풍','윈드 브레이커'], at:[1,1020], facts:[[[1,1020],'마을을 지키는 후린 고교 학생들을 주민들이 부르는 이름이에요.']], easy:'동네를 지키는 자율 방범대 같은 학생들이에요.' },
  },
  banned:['우메미야','시시토레','타카라다','KEEL','킬','코가네이'],
};

WORKS.jujutsu.guide = {
  season:'1기', eps:2, startAt:[1,0], core:['curse','sorcerer','finger','sukuna'],
  episodes:{
    1:{ title:'료멘 스쿠나', summary:'운동 신경이 남다른 고등학생 유지는 할아버지를 떠나보낸 날 학교에서 「저주」의 습격을 받고, 친구들을 구하려고 저주받은 손가락을 삼켜요.' },
    2:{ title:'나를 위해', summary:'손가락을 삼킨 유지 몸에 최강의 저주 스쿠나가 깃들고, 주술사 고죠는 유지에게 손가락을 모두 모으라는 조건으로 사형 집행을 미뤄요.' },
  },
  scenes:{
    1:[
      { s:0,    title:'괴력의 고등학생', art:'classroom', chars:['yuji'], terms:[], sum:'유지는 운동 신경이 엄청나지만 오컬트 연구회에서 놀며 지내요.' },
      { s:180,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:270,  title:'할아버지의 유언', art:'home', chars:['yuji','grandpa'], terms:[], sum:'병원에서 할아버지는 유지에게 남을 도우라는 말을 남기고 세상을 떠나요.' },
      { s:450,  title:'메구미 등장', art:'classroom', chars:['yuji','megumi'], terms:['finger','sorcerer'], sum:'학교에 숨겨진 위험한 물건을 회수하러 온 주술사 메구미가 유지를 찾아와요.' },
      { s:630,  title:'봉인을 푼 선배들', art:'night', chars:['seniors'], terms:['finger','curse'], sum:'오컬트 연구회 선배들이 밤에 학교에서 그 물건의 봉인을 풀어 버려요.' },
      { s:780,  title:'몰려든 저주', art:'night', chars:['yuji','megumi','seniors'], terms:['curse'], sum:'봉인이 풀리자 사람을 해치는 저주들이 몰려들고, 유지는 선배들을 구하러 학교로 뛰어들어요.' },
      { s:990,  title:'맨몸의 싸움', art:'night', chars:['yuji','megumi'], terms:['curse','sorcerer'], sum:'주술을 모르는 유지는 맨몸으로 저주와 싸우고, 메구미도 크게 다쳐요.' },
      { s:1170, title:'손가락을 삼키다', art:'night', chars:['yuji','megumi'], terms:['finger','sukuna'], sum:'힘을 얻으려고 유지는 저주받은 손가락을 삼켜 버리고, 몸에 이상한 문양이 떠올라요.' },
      { s:1350, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
    ],
    2:[
      { s:0,    title:'깨어난 스쿠나', art:'night', chars:['sukuna','megumi'], terms:['sukuna'], sum:'유지의 몸을 차지한 저주의 왕 스쿠나가 날뛰려 해요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'되찾은 몸', art:'night', chars:['yuji','megumi'], terms:['sukuna'], sum:'유지는 의지로 스쿠나를 눌러 다시 자기 몸을 되찾아요.' },
      { s:390,  title:'고죠 사토루', art:'night', chars:['gojo','yuji','megumi'], terms:['sorcerer','sukuna'], sum:'눈을 가린 주술사 고죠가 나타나 유지가 스쿠나를 통제할 수 있는지 시험해요.' },
      { s:600,  title:'사형 판결', art:'office', chars:['gojo','yuji'], terms:['finger','sukuna'], sum:'스쿠나를 품은 유지는 원래 처형 대상이지만, 고죠는 손가락을 전부 먹게 한 뒤 처형하자며 집행을 미뤄요.' },
      { s:810,  title:'할아버지 장례', art:'grave', chars:['yuji','gojo'], terms:[], sum:'유지는 할아버지 장례를 치르며, 어떻게 죽을지는 스스로 고르겠다고 마음먹어요.' },
      { s:990,  title:'도쿄 주술 고전', art:'town', chars:['yuji','gojo'], terms:['school'], sum:'유지는 고죠를 따라 주술사를 키우는 학교, 도쿄 주술고등전문학교로 가요.' },
      { s:1140, title:'교장과의 면접', art:'office', chars:['yuji','yaga'], terms:['school'], sum:'저주 인형을 만드는 교장 야가가 왜 주술사가 되려 하느냐고 묻고, 유지는 자기 답을 찾아 입학을 허락받아요.' },
      { s:1350, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
    ],
  },
  chars:{
    yuji:{ name:'이타도리 유지', short:'유지', alias:['유지','이타도리'], at:[1,0], pos:[300,220], facts:[
      [[1,0],'운동 신경이 엄청난 고등학생이에요. 오컬트 연구회 소속이에요.'],
      [[1,270],'할아버지에게 남을 도우라는 유언을 들었어요.'],
      [[1,1170],'저주받은 손가락을 삼켰어요.'],
      [[2,600],'손가락을 모두 먹은 뒤 처형된다는 조건으로 살아 있어요.'],
    ], easy:'착한 체육 만렙 고등학생이 몸속에 최강 악당을 품게 된 상황이에요.' },
    grandpa:{ name:'이타도리 와스케', short:'할아버지', alias:['할아버지'], at:[1,270], pos:[110,330], facts:[[[1,270],'유지의 할아버지예요. 남을 도우라는 말을 남기고 세상을 떠났어요.']] },
    megumi:{ name:'후시구로 메구미', short:'메구미', alias:['메구미','후시구로'], at:[1,450], pos:[470,130], facts:[
      [[1,450],'위험한 물건을 회수하러 온 주술사예요. 유지와 비슷한 또래예요.'],
    ] },
    seniors:{ name:'오컬트 연구회 선배들', short:'선배들', alias:['선배','선배들'], at:[1,630], pos:[140,130], facts:[[[1,630],'유지와 같은 오컬트 연구회 선배예요. 봉인을 풀어 버렸어요.']] },
    sukuna:{ name:'료멘 스쿠나', short:'스쿠나', alias:['스쿠나','료멘'], at:[2,0], pos:[300,400], facts:[
      [[2,0],'유지의 몸에 깃든 저주의 왕이에요.'],
      [[2,240],'유지가 의지로 눌러 몸을 되찾았어요.'],
    ] },
    gojo:{ name:'고죠 사토루', short:'고죠', alias:['고죠','사토루'], at:[2,390], pos:[470,320], facts:[
      [[2,390],'눈을 가린 주술사예요. 메구미의 선생님이에요.'],
      [[2,600],'유지의 처형을 미루자고 했어요.'],
    ] },
    yaga:{ name:'야가 마사미치', short:'야가', alias:['야가','교장'], at:[2,1140], pos:[540,230], facts:[[[2,1140],'도쿄 주술고등전문학교의 교장이에요. 저주 인형을 만들어요.']] },
  },
  rels:[
    ['yuji','grandpa','family','손자와 할아버지',[1,270]],
    ['yuji','seniors','friend','오컬트 연구회',[1,630]],
    ['yuji','megumi','friend','함께 싸운 사이',[1,990]],
    ['yuji','sukuna','other','몸을 나눠 쓰는 사이',[2,0]],
    ['gojo','megumi','peer','선생님과 학생',[2,390]],
    ['gojo','yuji','peer','선생님과 학생',[2,990]],
    ['yuji','yaga','other','입학 면접',[2,1140]],
  ],
  terms:{
    curse:{ name:'저주', alias:['저주','주령'], at:[1,630], facts:[[[1,630],'사람의 부정적인 감정에서 태어나 사람을 해치는 존재예요.']], easy:'사람들의 나쁜 감정이 뭉쳐 생긴 괴물이에요.' },
    sorcerer:{ name:'주술사', alias:['주술사','주술'], at:[1,450], facts:[[[1,450],'저주를 물리치는 사람들이에요. 메구미가 주술사예요.']] },
    finger:{ name:'저주받은 손가락', alias:['손가락','특급 주물'], at:[1,450], facts:[[[1,450],'학교에 숨겨져 있던 위험한 물건이에요.'],[[1,630],'봉인이 풀리면 저주들이 몰려들어요.'],[[2,600],'스쿠나의 손가락이에요. 유지는 이걸 모두 먹어야 해요.']] },
    sukuna:{ name:'료멘 스쿠나', alias:['스쿠나'], at:[1,1170], facts:[[[1,1170],'손가락의 주인인 저주의 왕이에요.']] },
    school:{ name:'도쿄 주술고등전문학교', alias:['주술 고전','고전','주술고등전문학교'], at:[2,990], facts:[[[2,990],'주술사를 키우는 학교예요.']] },
  },
  banned:['노바라','쿠기사키','마히토','게토','스쿠나 손가락 20','시부야','영역 전개','토도','죠고','하나미'],
};

WORKS.chainsaw.guide = {
  season:'1기', eps:2, startAt:[1,0], core:['devil','hunter','publicsafety','chainsaw'],
  episodes:{
    1:{ title:'개와 전기톱', summary:'아버지가 남긴 빚을 갚으려 악마를 사냥하는 소년 덴지는 전기톱 악마 포치타와 하루하루 버티다가, 야쿠자의 배신으로 죽음 직전에 포치타와 하나가 돼요.' },
    2:{ title:'도쿄 도착', summary:'마키마를 따라 도쿄로 간 덴지는 공안 소속 데빌 헌터가 되고, 선배 아키와 충돌한 뒤 새 파트너 파워를 만나요.' },
  },
  scenes:{
    1:[
      { s:0,    title:'빚쟁이 소년', art:'forest', chars:['denji','pochita'], terms:['devil','hunter'], sum:'덴지는 죽은 아버지의 빚을 갚으려 야쿠자 밑에서 악마를 사냥해요. 곁에는 전기톱 악마 포치타가 있어요.' },
      { s:180,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:270,  title:'밑바닥 생활', art:'home', chars:['denji','pochita'], terms:[], sum:'장기까지 팔아 가며 빚을 갚는 덴지는 잼 바른 빵 한 쪽이 소원일 만큼 가난해요.' },
      { s:480,  title:'포치타와의 약속', art:'night', chars:['denji','pochita'], terms:['chainsaw'], sum:'덴지는 어릴 적 다친 포치타를 구해 준 뒤 서로 의지하며 살아왔어요.' },
      { s:660,  title:'평범한 꿈', art:'night', chars:['denji'], terms:[], sum:'덴지는 언젠가 평범하게 먹고 자는 삶을 살고 싶어 해요.' },
      { s:810,  title:'배신', art:'darkroom', chars:['denji','pochita','zombie'], terms:['devil'], sum:'야쿠자들이 좀비의 악마와 손잡고 덴지를 함정에 빠뜨려 목숨을 빼앗아요.' },
      { s:990,  title:'전기톱 소년', art:'darkroom', chars:['denji','pochita','zombie'], terms:['chainsaw'], sum:'포치타가 덴지의 심장이 되어 주고, 되살아난 덴지는 몸에서 전기톱이 튀어나오는 모습으로 좀비들을 쓸어 버려요.' },
      { s:1200, title:'마키마', art:'night', chars:['denji','makima'], terms:['publicsafety'], sum:'모든 게 끝난 자리에 공안 소속의 여성 마키마가 나타나, 덴지에게 자기 밑에서 살라고 제안해요.' },
      { s:1350, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
    ],
    2:[
      { s:0,    title:'마키마의 개', art:'street', chars:['denji','makima'], terms:['publicsafety'], sum:'마키마는 덴지를 자기 「개」로 거두겠다고 하고, 덴지는 따뜻한 밥에 마음이 흔들려요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'우동 한 그릇', art:'town', chars:['denji','makima','pochita'], terms:['chainsaw'], sum:'함께 우동을 먹으며 덴지는 포치타가 이제 자기 심장으로 살아 있다는 걸 알게 돼요.' },
      { s:420,  title:'공안 데빌 헌터', art:'office', chars:['denji','makima','aki'], terms:['publicsafety','hunter'], sum:'도쿄의 공안 본부에서 마키마는 덴지를 선배 아키의 팀에 배치해요.' },
      { s:600,  title:'골목의 신고식', art:'alley', chars:['denji','aki'], terms:[], sum:'아키는 덴지를 골목으로 데려가 때리며 그만두라고 하지만, 덴지는 지지 않고 반격해요.' },
      { s:780,  title:'아키의 집', art:'home', chars:['denji','aki'], terms:[], sum:'덴지는 아키의 집에서 함께 살게 되고, 아키는 도망칠 생각은 하지 말라고 경고해요.' },
      { s:960,  title:'새 목표', art:'city', chars:['denji','aki'], terms:['devil'], sum:'첫 임무를 치른 덴지는 마키마와 얽힌 엉뚱한 목표를 세우며 의욕을 불태워요.' },
      { s:1140, title:'파워', art:'city', chars:['denji','power','makima'], terms:['fiend'], sum:'마키마는 덴지에게 새 파트너 파워를 붙여 줘요. 파워는 악마가 사람의 몸을 차지한 마인이에요.' },
      { s:1260, title:'피의 망치', art:'battle', chars:['power','denji'], terms:['devil','fiend'], sum:'순찰 중 피 냄새를 맡은 파워가 지붕에서 뛰어내려 피로 만든 망치로 악마를 짓뭉개요.' },
      { s:1350, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
    ],
  },
  chars:{
    denji:{ name:'덴지', short:'덴지', alias:['덴지','체인소 맨'], at:[1,0], pos:[300,220], facts:[
      [[1,0],'아버지의 빚을 갚으려 악마를 사냥하는 소년이에요.'],
      [[1,990],'포치타가 심장이 되어, 몸에서 전기톱을 꺼낼 수 있게 됐어요.'],
      [[2,420],'공안 소속 데빌 헌터가 됐어요.'],
    ], easy:'평범하게 밥 먹고 자는 게 소원인 소년이 괴물 사냥꾼이 된 이야기예요.' },
    pochita:{ name:'포치타', short:'포치타', alias:['포치타'], at:[1,0], pos:[140,130], facts:[
      [[1,0],'덴지와 함께 사는 강아지 같은 전기톱 악마예요.'],
      [[1,990],'덴지의 심장이 되었어요.'],
    ] },
    zombie:{ name:'좀비의 악마', short:'좀비의 악마', alias:['좀비','좀비의 악마'], at:[1,810], pos:[120,330], facts:[[[1,810],'야쿠자와 손잡고 덴지를 노린 악마예요.']] },
    makima:{ name:'마키마', short:'마키마', alias:['마키마'], at:[1,1200], pos:[470,130], facts:[
      [[1,1200],'공안 소속의 여성이에요. 덴지에게 자기 밑에서 살라고 했어요.'],
      [[2,420],'덴지를 데빌 헌터로 배치했어요.'],
    ] },
    aki:{ name:'하야카와 아키', short:'아키', alias:['아키','하야카와'], at:[2,420], pos:[470,330], facts:[
      [[2,420],'공안 데빌 헌터예요. 덴지의 선배예요.'],
      [[2,780],'덴지와 함께 살게 됐어요.'],
    ] },
    power:{ name:'파워', short:'파워', alias:['파워'], at:[2,1140], pos:[300,400], facts:[
      [[2,1140],'덴지의 새 파트너예요. 악마가 사람 몸을 차지한 마인이에요.'],
      [[2,1260],'피로 무기를 만들어 싸워요.'],
    ] },
  },
  rels:[
    ['denji','pochita','family','서로의 전부였던 단짝',[1,0]],
    ['denji','zombie','rival','덴지를 노린 악마',[1,810]],
    ['denji','makima','other','거둬 준 상사',[1,1200]],
    ['denji','aki','peer','선배와 후배',[2,420]],
    ['makima','aki','peer','상사와 부하',[2,420]],
    ['denji','power','peer','파트너',[2,1140]],
  ],
  terms:{
    devil:{ name:'악마', alias:['악마','데빌'], at:[1,0], facts:[[[1,0],'사람을 해치는 존재예요. 이름마다 다른 힘을 가져요.']] },
    hunter:{ name:'데빌 헌터', alias:['데빌 헌터','헌터'], at:[1,0], facts:[[[1,0],'악마를 사냥하는 사람이에요.'],[[2,420],'덴지는 공안 소속 데빌 헌터가 됐어요.']] },
    chainsaw:{ name:'전기톱', alias:['전기톱','체인소'], at:[1,480], facts:[[[1,480],'포치타는 머리에 전기톱이 달린 악마예요.'],[[1,990],'덴지는 몸에서 전기톱을 꺼내 싸워요.']] },
    publicsafety:{ name:'공안', alias:['공안','공안 데빌 헌터'], at:[1,1200], facts:[[[1,1200],'마키마가 속한 국가 조직이에요.'],[[2,420],'도쿄에 본부가 있어요.']] },
    fiend:{ name:'마인', alias:['마인'], at:[2,1140], facts:[[[2,1140],'악마가 사람의 시체를 차지한 존재예요. 파워가 마인이에요.']] },
  },
  banned:['히메노','코베니','레제','총의 악마','지배','아라이','사무라이 소드','에터니티','박쥐의 악마'],
};

WORKS.hunter.guide = {
  season:'1기', eps:2, startAt:[1,0], core:['hunter','exam'],
  episodes:{
    1:{ title:'출발 × 과 × 친구', summary:'고래섬 소년 곤은 죽은 줄 알았던 아버지가 전설적인 헌터라는 걸 알고, 헌터 시험을 보러 섬을 떠나요. 배 위에서 쿠라피카와 레오리오를 만나요.' },
    2:{ title:'시험 × 의 × 시험', summary:'시험장으로 가는 길에 곤 일행은 수수께끼 퀴즈를 내는 노파와, 변신하는 마수 키리코 가족의 시험을 차례로 통과해요.' },
  },
  scenes:{
    1:[
      { s:0,    title:'고래섬의 소년', art:'forest', chars:['gon'], terms:[], sum:'고래섬에서 이모 미토와 사는 소년 곤은 숲과 동물에 익숙한 야생아예요.' },
      { s:150,  title:'카이트', art:'forest', chars:['gon','kite'], terms:['hunter'], sum:'어린 곤이 위험한 짐승에게 습격당했을 때, 헌터 카이트가 구해 줘요. 카이트는 곤의 아버지 진의 제자였어요.' },
      { s:330,  title:'아버지는 헌터', art:'home', chars:['gon','mito'], terms:['hunter'], sum:'곤은 아버지 진이 살아 있고, 대단한 헌터라는 걸 알게 돼요. 아버지를 찾기 위해 자기도 헌터가 되기로 해요.' },
      { s:450,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:540,  title:'떠나는 날', art:'boat', chars:['gon','mito'], terms:['exam'], sum:'12살이 된 곤은 미토의 허락을 받고 헌터 시험을 보러 배에 올라요.' },
      { s:720,  title:'두 동행', art:'boat', chars:['gon','kurapika','leorio'], terms:['exam'], sum:'배 안에는 침착한 쿠라피카와 돈 이야기를 하는 레오리오도 타고 있어요.' },
      { s:900,  title:'폭풍', art:'boat', chars:['gon','kurapika','leorio','captain'], terms:[], sum:'거센 폭풍에 다른 수험생들은 뱃멀미로 쓰러지고, 곤과 두 사람만 멀쩡히 남아요.' },
      { s:1050, title:'헌터가 되려는 이유', art:'boat', chars:['gon','kurapika','leorio','captain'], terms:['hunter'], sum:'선장이 헌터가 되려는 이유를 묻자, 쿠라피카는 멸족한 일족의 원수를 갚으려 하고 레오리오는 돈 때문이라고 말해요.' },
      { s:1200, title:'선장의 인정', art:'boat', chars:['gon','kurapika','leorio','captain'], terms:['exam'], sum:'폭풍 속에서 서로를 구한 세 사람을 선장은 인정하고, 시험장 근처 항구로 데려다줘요.' },
      { s:1350, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
    ],
    2:[
      { s:0,    title:'항구에서', art:'town', chars:['gon','kurapika','leorio'], terms:['exam'], sum:'선장의 힌트대로 세 사람은 시험장으로 안내해 줄 사람들을 찾아 산길로 가요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'노파의 퀴즈', art:'town', chars:['gon','kurapika','leorio','granny'], terms:['quiz'], sum:'노파가 둘 중 하나를 고르라는 곤란한 질문을 내고, 틀리면 이 길로는 갈 수 없다고 해요.' },
      { s:450,  title:'정답은 침묵', art:'town', chars:['gon','kurapika','leorio','granny'], terms:['quiz'], sum:'정답은 대답하지 않는 것이었어요. 세 사람은 진짜 길로 들어서요.' },
      { s:630,  title:'외딴 오두막', art:'forest', chars:['gon','kurapika','leorio'], terms:[], sum:'오두막에 다다르자 부상당한 남자와 그를 습격한 괴물이 있어요.' },
      { s:810,  title:'뒤바뀐 사람', art:'forest', chars:['gon','kurapika','leorio'], terms:[], sum:'곤은 날카로운 감각으로 괴물을 쫓고, 쿠라피카는 바꿔치기된 사람을 알아채요. 레오리오는 다친 사람을 정성껏 돌봐요.' },
      { s:1020, title:'키리코의 시험', art:'forest', chars:['gon','kurapika','leorio','kiriko'], terms:['kiriko','exam'], sum:'모든 게 사람으로 변신하는 마수 키리코 가족이 꾸민 시험이었어요. 세 사람 모두 합격해요.' },
      { s:1200, title:'시험장으로', art:'city', chars:['gon','kurapika','leorio','kiriko'], terms:['exam'], sum:'키리코가 세 사람을 시험장이 있는 도시까지 데려다주고 들어가는 암호도 알려 줘요.' },
      { s:1350, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
    ],
  },
  chars:{
    gon:{ name:'곤 프릭스', short:'곤', alias:['곤','프릭스'], at:[1,0], pos:[300,220], facts:[
      [[1,0],'고래섬에서 이모 미토와 사는 소년이에요. 감각이 아주 뛰어나요.'],
      [[1,330],'아버지 진을 찾으려고 헌터가 되기로 했어요.'],
      [[1,540],'12살에 헌터 시험을 보러 섬을 떠났어요.'],
    ], easy:'아빠를 찾으러 모험을 떠난 순수한 야생 소년이에요.' },
    mito:{ name:'미토', short:'미토', alias:['미토','이모'], at:[1,0], pos:[110,330], facts:[[[1,0],'곤을 키운 이모예요.']] },
    kite:{ name:'카이트', short:'카이트', alias:['카이트'], at:[1,150], pos:[140,130], facts:[[[1,150],'어린 곤을 구해 준 헌터예요. 곤의 아버지 진의 제자예요.']] },
    kurapika:{ name:'쿠라피카', short:'쿠라피카', alias:['쿠라피카'], at:[1,720], pos:[470,130], facts:[
      [[1,720],'침착하고 똑똑한 수험생이에요.'],
      [[1,1050],'멸족한 자기 일족의 원수를 갚으려고 헌터가 되려 해요.'],
    ] },
    leorio:{ name:'레오리오', short:'레오리오', alias:['레오리오'], at:[1,720], pos:[470,330], facts:[
      [[1,720],'돈 때문에 헌터가 되려 한다고 말하는 수험생이에요.'],
      [[2,810],'다친 사람을 정성껏 돌봤어요.'],
    ] },
    captain:{ name:'선장', short:'선장', alias:['선장'], at:[1,900], pos:[540,230], facts:[[[1,900],'수험생을 태운 배의 선장이에요. 세 사람을 시험장 근처로 데려다줬어요.']] },
    granny:{ name:'퀴즈 노파', short:'노파', alias:['노파','할머니'], at:[2,240], pos:[300,400], facts:[[[2,240],'시험장으로 가는 길목에서 퀴즈를 내는 노파예요.']] },
    kiriko:{ name:'키리코 가족', short:'키리코', alias:['키리코'], at:[2,1020], pos:[120,220], facts:[[[2,1020],'사람으로 변신할 수 있는 마수 가족이에요. 수험생을 시험장까지 안내해요.']] },
  },
  rels:[
    ['gon','mito','family','조카와 이모',[1,0]],
    ['gon','kite','other','생명의 은인',[1,150]],
    ['gon','kurapika','friend','함께 가는 동료',[1,1200]],
    ['gon','leorio','friend','함께 가는 동료',[1,1200]],
    ['kurapika','leorio','friend','티격태격 동료',[1,1200]],
    ['gon','captain','other','태워 준 선장',[1,900]],
  ],
  terms:{
    hunter:{ name:'헌터', alias:['헌터'], at:[1,150], facts:[[[1,150],'보물·괴물·미지의 땅 같은 것을 찾아다니는 특별한 자격을 가진 사람이에요.'],[[1,330],'곤의 아버지 진도 헌터예요.']], easy:'국가 공인 모험가 자격증 소지자예요.' },
    exam:{ name:'헌터 시험', alias:['헌터 시험','시험장','시험'], at:[1,540], facts:[[[1,540],'헌터가 되려면 통과해야 하는 시험이에요. 시험장에 가는 것부터 어려워요.']] },
    quiz:{ name:'노파의 퀴즈', alias:['퀴즈','질문'], at:[2,240], facts:[[[2,450],'정답은 대답하지 않는 것이었어요.']] },
    kiriko:{ name:'키리코', alias:['키리코','마수'], at:[2,1020], facts:[[[2,1020],'사람으로 변신하는 마수예요. 수험생을 시험해요.']] },
  },
  banned:['킬루아','히소카','일루미','네테로','유명 여단','환영여단','넨','그리드 아일랜드','개미','키메라'],
};
