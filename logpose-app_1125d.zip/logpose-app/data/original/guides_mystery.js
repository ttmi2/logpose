/* ============================================================
   가이드북 — D구역 SF·미스터리·스릴러 (1~2화, 회차 요약 자료로 확인한 범위만)
   장면 시각은 줄거리 순서에 맞춘 대략적인 위치예요.
   ============================================================ */
WORKS.parasyte.guide = {
  season:'1기', eps:2, startAt:[1,0], core:['parasite','migi','heart'],
  episodes:{
    1:{ title:'변신', summary:'평범한 고교생 신이치의 오른손에 정체 모를 생물이 깃들어요. 뇌를 빼앗으려다 실패하고 오른팔에 자리 잡은 그 생물과, 신이치는 원치 않는 동거를 시작해요.' },
    2:{ title:'육체의 악마', summary:'오른손 생물은 스스로를 「오른쪽이」라고 불러요. 세계 곳곳에서 끔찍한 사건이 이어지는 가운데, 신이치는 처음으로 사람의 몸을 차지한 다른 기생생물과 마주쳐요.' },
  },
  scenes:{
    1:[
      { s:0,    title:'하늘에서 온 것', art:'night', chars:[], terms:['parasite'], sum:'어느 밤, 정체 모를 작은 생물들이 세상 곳곳에 떨어져 사람의 머릿속을 노려요.' },
      { s:150,  title:'이어폰 덕분에', art:'home', chars:['shinichi'], terms:['parasite'], sum:'잠든 신이치의 귀로 들어가려던 생물은 이어폰에 막히고, 대신 오른팔을 파고들어요.' },
      { s:330,  title:'이상한 오른손', art:'classroom', chars:['shinichi','satomi'], terms:[], sum:'다음 날 신이치의 오른손이 제멋대로 움직여, 등굣길에 반 친구 사토미의 몸을 더듬어 버려요.' },
      { s:510,  title:'차를 멈춘 손', art:'street', chars:['shinichi'], terms:[], sum:'달려오는 차에서 아이를 구하려던 순간, 오른손이 저절로 튀어나가 차를 멈춰 세워요.' },
      { s:690,  title:'오른손이 말을 하다', art:'home', chars:['shinichi','migi'], terms:['parasite'], sum:'겁에 질린 신이치가 칼로 손을 찌르려 하자, 오른손이 모습을 바꾸며 칼날을 부러뜨리고 말을 걸어요.' },
      { s:870,  title:'비밀', art:'home', chars:['shinichi','migi','parents'], terms:[], sum:'신이치는 이 생물과 함께 살 수밖에 없게 되고, 부모님에게 들키지 않으려 애써요.' },
      { s:1050, title:'배우는 생물', art:'home', chars:['shinichi','migi'], terms:['parasite'], sum:'오른손 생물은 밤새 책과 사전을 읽으며 엄청난 속도로 인간을 배워요.' },
      { s:1200, title:'개의 몸을 한 동족', art:'street', chars:['shinichi','migi'], terms:['heart'], sum:'오른손이 신이치를 데려간 곳에는 같은 종류의 생물이 깃든 개가 있어요. 그것을 죽이려면 숙주의 심장을 부숴야 한다는 걸 알게 돼요.' },
      { s:1350, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
    ],
    2:[
      { s:0,    title:'이름은 오른쪽이', art:'home', chars:['shinichi','migi'], terms:['migi'], sum:'이름을 묻는 신이치에게, 생물은 오른손에 있으니 「오른쪽이」라고 부르라고 해요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'결승 골', art:'gym', chars:['shinichi','satomi'], terms:[], sum:'체육 시간 농구 경기에서 신이치가 결승 골을 넣어 사토미를 놀라게 하고, 지난번 일을 사과해요.' },
      { s:390,  title:'질투', art:'classroom', chars:['shinichi','migi','nagai'], terms:['migi'], sum:'질투한 반 친구 나가이가 싸움을 걸고, 오른쪽이가 억지로 신이치의 주먹을 휘둘러요.' },
      { s:540,  title:'다진 고기 살인 사건', art:'classroom', chars:['shinichi','yuko'], terms:['mince'], sum:'친구 유코가 세계 곳곳에서 일어나는 끔찍한 「다진 고기 살인 사건」 이야기를 해요.' },
      { s:690,  title:'살기 위해 먹는다', art:'home', chars:['shinichi','migi'], terms:['parasite','mince'], sum:'오른쪽이는 동족들이 살아남기 위해 사람을 먹는 거라고 담담하게 설명해요.' },
      { s:840,  title:'골목의 남자', art:'alley', chars:['shinichi','migi','mrb'], terms:['parasite'], sum:'오른쪽이가 근처의 동족을 감지하고, 신이치는 사람의 몸을 차지한 그 남자를 골목으로 유인해요.' },
      { s:990,  title:'함께 가자는 제안', art:'alley', chars:['migi','mrb'], terms:['parasite','heart'], sum:'남자는 오래 살아남으려면 자기와 함께하자고 오른쪽이에게 제안하지만, 오른쪽이는 그를 쓰러뜨리고 신이치 곁에 남아요.' },
      { s:1140, title:'놀이터의 고양이', art:'field', chars:['shinichi','satomi'], terms:[], sum:'다음 날 사토미와 팬케이크를 먹고 돌아가던 길, 불량배들이 모래에 묻힌 고양이에게 돌을 던지는 걸 보고 신이치가 막아서요.' },
      { s:1290, title:'달라진 얼굴', art:'field', chars:['shinichi','satomi'], terms:[], sum:'평소와 다른 신이치의 모습에 사토미는 깜짝 놀라요.' },
    ],
  },
  chars:{
    shinichi:{ name:'이즈미 신이치', short:'신이치', alias:['신이치','이즈미'], at:[1,150], pos:[300,230], facts:[
      [[1,150],'평범하고 착한 고등학생이에요.'],
      [[1,690],'오른팔에 기생생물이 자리 잡았어요.'],
      [[2,1290],'가끔 평소와 다른 모습을 보여 주변을 놀라게 해요.'],
    ], easy:'몸 한쪽을 외계 생물과 나눠 쓰게 된, 평범한 고등학생이에요.' },
    migi:{ name:'오른쪽이', short:'오른쪽이', alias:['오른쪽이','오른손'], at:[1,690], pos:[460,140], facts:[
      [[1,690],'신이치의 오른팔에 자리 잡은 기생생물이에요. 말을 하고 모양을 바꿔요.'],
      [[1,1050],'아주 빠르게 배워요.'],
      [[2,0],'오른손에 있어서 「오른쪽이」라는 이름을 스스로 붙여요.'],
      [[2,990],'동족의 제안을 거절하고 신이치 곁에 남아요.'],
    ], easy:'감정은 없지만 무척 똑똑하고 솔직한 동거인이에요.' },
    satomi:{ name:'무라노 사토미', short:'사토미', alias:['사토미','무라노'], at:[1,330], pos:[140,120], facts:[
      [[1,330],'신이치의 반 친구예요.'],
      [[2,240],'신이치의 사과를 받아 줘요.'],
    ] },
    parents:{ name:'신이치의 부모님', short:'부모님', alias:['부모님','엄마','아빠'], at:[1,870], pos:[120,380], facts:[
      [[1,870],'신이치는 오른손의 비밀을 부모님에게 숨겨요.'],
    ] },
    nagai:{ name:'나가이', short:'나가이', alias:['나가이'], at:[2,390], pos:[300,410], facts:[
      [[2,390],'질투해서 신이치에게 싸움을 건 반 친구예요.'],
    ] },
    yuko:{ name:'유코', short:'유코', alias:['유코'], at:[2,540], pos:[470,360], facts:[
      [[2,540],'신이치와 사토미의 친구예요. 세계의 끔찍한 사건 이야기를 꺼내요.'],
    ] },
    mrb:{ name:'기생생물 남자', short:'그 남자', alias:['그 남자'], at:[2,840], pos:[540,240], facts:[
      [[2,840],'사람의 몸을 차지한 기생생물이에요.'],
      [[2,990],'오른쪽이에게 함께하자고 제안해요.'],
    ] },
  },
  rels:[
    ['shinichi','migi','other','한 몸을 나눠 쓰는 사이',[1,690]],
    ['shinichi','satomi','friend','반 친구',[1,330]],
    ['shinichi','parents','family','가족',[1,870]],
    ['shinichi','nagai','rival','싸움을 건 반 친구',[2,390]],
    ['satomi','yuko','friend','친구',[2,540]],
    ['migi','mrb','rival','같은 종족이지만 다른 길을 고른 사이',[2,990]],
  ],
  terms:{
    parasite:{ name:'기생생물', alias:['기생생물','동족'], at:[1,0], facts:[[[1,0],'어디선가 나타나 사람의 머리를 노리는 작은 생물이에요.'],[[1,150],'뇌를 빼앗지 못하면 다른 부위에 자리 잡기도 해요.'],[[2,690],'살아남기 위해 사람을 먹어요.']], easy:'사람의 머리를 차지하고 그 사람인 척 사는 무서운 생물이에요.' },
    heart:{ name:'숙주의 심장', alias:['심장'], at:[1,1200], facts:[[[1,1200],'기생생물을 쓰러뜨리려면 몸을 빌려준 숙주의 심장을 부숴야 해요.']] },
    migi:{ name:'오른쪽이라는 이름', alias:['이름'], at:[2,0], facts:[[[2,0],'오른손에 있어서 붙인 이름이에요.']] },
    mince:{ name:'다진 고기 살인 사건', alias:['다진 고기','살인 사건'], at:[2,540], facts:[[[2,540],'세계 곳곳에서 일어나는 끔찍한 사건이에요.']] },
  },
  banned:['타미야','시마다','고토','카나','미키','A라고'],
};

WORKS.ghoul.guide = {
  season:'1기', eps:2, startAt:[1,0], core:['ghoul','kagune','anteiku'],
  episodes:{
    1:{ title:'비극', summary:'책을 좋아하는 대학생 카네키는 단골 카페에서 만난 리제와 데이트를 해요. 그날 밤 리제는 정체를 드러내고 그를 덮치고, 살아남은 카네키는 리제의 장기를 이식받은 뒤 사람의 음식을 먹을 수 없게 돼요.' },
    2:{ title:'부화', summary:'카네키는 굶주림 속에서도 사람으로 남으려 버티지만, 다른 구울 니시키가 친구 히데를 노리고 나타나요. 친구를 지키려던 카네키 안에서 리제의 힘이 깨어나요.' },
  },
  scenes:{
    1:[
      { s:0,    title:'구울이 사는 도시', art:'city', chars:[], terms:['ghoul'], sum:'도쿄에는 사람을 먹어야만 살 수 있는 「구울」이 사람인 척 섞여 살아요. 20구에서는 사건이 끊이지 않아요.' },
      { s:150,  title:'카페 안테이크', art:'party', chars:['kaneki','hide','touka'], terms:['anteiku','ghoul'], sum:'카네키와 친구 히데는 단골 카페 안테이크에서 구울이 정말 사람 사이에 섞여 있을지 이야기해요. 히데는 점원 토우카에게 말을 걸어요.' },
      { s:330,  title:'책을 읽는 그녀', art:'party', chars:['kaneki','rize'], terms:['anteiku'], sum:'카네키는 카페에서 늘 책을 읽는 리제에게 마음이 있어요. 좋아하는 작가가 같다는 걸 알고 데이트 약속을 잡아요.' },
      { s:510,  title:'첫 데이트', art:'street', chars:['kaneki','rize'], terms:[], sum:'두 사람은 작가 타카츠키 센 이야기로 가까워지고, 카네키는 부모님을 잃은 이야기까지 털어놓아요.' },
      { s:690,  title:'어두운 골목', art:'alley', chars:['kaneki','rize'], terms:['kagune','ghoul'], sum:'집에 바래다주던 어두운 길에서 리제가 정체를 드러내요. 등에서 촉수 같은 무기가 뻗어 나와 카네키를 덮쳐요.' },
      { s:840,  title:'떨어진 철골', art:'night', chars:['kaneki','rize'], terms:[], sum:'공사장으로 내던져진 카네키가 잡아먹히려는 순간, 위에서 철골이 떨어져 리제를 덮쳐요.' },
      { s:960,  title:'수술', art:'darkroom', chars:['kaneki','kanou'], terms:[], sum:'의사 카노는 죽어 가는 카네키에게 리제의 장기를 이식하는 긴급 수술을 해요.' },
      { s:1080, title:'변해 버린 입맛', art:'home', chars:['kaneki'], terms:['ghoul'], sum:'퇴원한 카네키는 사람의 음식이 끔찍한 맛으로 느껴지고, 한쪽 눈이 붉게 변하는 걸 발견해요.' },
      { s:1200, title:'골목의 냄새', art:'alley', chars:['kaneki','nishiki'], terms:['ghoul'], sum:'참을 수 없는 허기에 골목으로 끌려간 카네키는 구울들과 마주치고, 구울 니시키는 자기 구역에 들어왔다며 그를 노려요.' },
      { s:1320, title:'토우카의 등장', art:'alley', chars:['kaneki','touka','nishiki'], terms:['ghoul'], sum:'안테이크 점원 토우카가 나타나 니시키를 물리쳐요. 사람으로 남겠다는 카네키에게 토우카는 억지로 고기를 먹여요.' },
    ],
    2:[
      { s:0,    title:'버티는 카네키', art:'home', chars:['kaneki'], terms:['ghoul'], sum:'카네키는 사람으로 남겠다며 아무것도 먹지 않고 버티지만, 몸은 점점 한계에 다다라요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'안테이크의 점장', art:'party', chars:['kaneki','yoshimura','touka'], terms:['anteiku','ghoul'], sum:'안테이크의 점장 요시무라는 카네키를 따뜻하게 맞아 줘요. 안테이크는 구울들을 돕는 곳이었어요.' },
      { s:420,  title:'커피 한 잔', art:'party', chars:['kaneki','yoshimura'], terms:['anteiku'], sum:'요시무라는 구울도 커피만은 마실 수 있다며 허기를 달래는 법을 알려 주고, 먹을 것이 든 꾸러미를 건네요.' },
      { s:600,  title:'사람인 척', art:'classroom', chars:['kaneki','hide'], terms:[], sum:'카네키는 꾸러미에 손대지 않고 학교에 나가 히데를 만나요. 평소처럼 보이고 싶어요.' },
      { s:750,  title:'히데 곁의 선배', art:'classroom', chars:['kaneki','hide','nishiki'], terms:['ghoul'], sum:'히데가 어울리는 선배가 골목에서 마주쳤던 구울 니시키라는 걸 알고 카네키는 얼어붙어요.' },
      { s:930,  title:'습격', art:'alley', chars:['kaneki','hide','nishiki'], terms:['kagune'], sum:'니시키는 히데를 쓰러뜨리고 카네키를 일방적으로 몰아붙여요.' },
      { s:1080, title:'깨어난 힘', art:'battle', chars:['kaneki','nishiki','rize'], terms:['kagune'], sum:'한계에 몰린 카네키의 머릿속에서 리제가 속삭이고, 카네키의 몸에서도 카구네가 터져 나와 니시키를 쓰러뜨려요.' },
      { s:1230, title:'멈춰 세운 토우카', art:'night', chars:['kaneki','touka','hide'], terms:['kagune'], sum:'허기에 이성을 잃고 쓰러진 히데에게 다가가던 카네키를, 뒤늦게 도착한 토우카가 막아서요. 카네키는 정신을 잃어요.' },
      { s:1350, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
    ],
  },
  chars:{
    kaneki:{ name:'카네키 켄', short:'카네키', alias:['카네키','켄'], at:[1,150], pos:[300,230], facts:[
      [[1,150],'책을 좋아하는 조용한 대학생이에요.'],
      [[1,510],'부모님을 일찍 여의었어요.'],
      [[1,960],'리제의 장기를 이식받았어요.'],
      [[1,1080],'사람의 음식을 먹을 수 없게 되고 한쪽 눈이 붉게 변해요.'],
      [[2,1080],'몸에서 카구네가 나와요.'],
    ], easy:'하루아침에 반은 사람, 반은 구울이 되어 버린 평범한 대학생이에요.' },
    hide:{ name:'나가치카 히데요시', short:'히데', alias:['히데','나가치카'], at:[1,150], pos:[150,120], facts:[
      [[1,150],'카네키의 오랜 친구예요. 밝고 넉살 좋아요.'],
      [[2,930],'니시키에게 습격당해 다쳐요.'],
    ] },
    touka:{ name:'키리시마 토우카', short:'토우카', alias:['토우카','키리시마'], at:[1,150], pos:[470,130], facts:[
      [[1,150],'카페 안테이크의 점원이에요.'],
      [[1,1320],'구울이에요. 니시키를 물리치고 카네키에게 억지로 고기를 먹여요.'],
      [[2,1230],'이성을 잃은 카네키를 막아서요.'],
    ] },
    rize:{ name:'카미시로 리제', short:'리제', alias:['리제','카미시로'], at:[1,330], pos:[130,350], facts:[
      [[1,330],'카페에서 늘 책을 읽던 여성이에요.'],
      [[1,690],'정체는 사람을 먹는 구울이에요. 카네키를 덮쳐요.'],
      [[1,840],'떨어진 철골에 깔려요.'],
      [[2,1080],'카네키의 머릿속에서 속삭여요.'],
    ] },
    kanou:{ name:'카노', short:'카노', alias:['카노','의사'], at:[1,960], pos:[60,240], facts:[
      [[1,960],'카네키에게 리제의 장기를 이식한 의사예요.'],
    ] },
    nishiki:{ name:'니시오 니시키', short:'니시키', alias:['니시키','니시오'], at:[1,1200], pos:[480,340], facts:[
      [[1,1200],'자기 구역을 지키는 거친 구울이에요.'],
      [[2,750],'히데가 어울리는 같은 대학 선배예요.'],
      [[2,930],'히데와 카네키를 습격해요.'],
    ] },
    yoshimura:{ name:'요시무라', short:'요시무라', alias:['요시무라','점장'], at:[2,240], pos:[300,410], facts:[
      [[2,240],'카페 안테이크의 점장이에요. 카네키를 따뜻하게 맞아 줘요.'],
      [[2,420],'구울도 커피는 마실 수 있다고 알려 줘요.'],
    ] },
  },
  rels:[
    ['kaneki','hide','friend','오랜 친구',[1,150]],
    ['kaneki','rize','other','데이트 상대이자 그를 덮친 구울',[1,690]],
    ['kanou','kaneki','other','수술한 의사와 환자',[1,960]],
    ['touka','nishiki','rival','맞붙은 구울',[1,1320]],
    ['yoshimura','touka','peer','안테이크 점장과 점원',[2,240]],
    ['yoshimura','kaneki','other','카네키를 돕는 점장',[2,240]],
    ['nishiki','hide','other','같은 대학 선배',[2,750]],
  ],
  terms:{
    ghoul:{ name:'구울', alias:['구울'], at:[1,0], facts:[[[1,0],'사람을 먹어야만 살 수 있는 존재예요. 겉모습은 사람과 똑같아요.'],[[1,1080],'사람의 음식은 끔찍한 맛으로 느껴져요.'],[[2,420],'커피는 마실 수 있어요.']], easy:'사람처럼 생겼지만 사람만 먹을 수 있는 존재예요.' },
    anteiku:{ name:'안테이크', alias:['안테이크','카페'], at:[1,150], facts:[[[1,150],'카네키와 히데의 단골 카페예요.'],[[2,240],'사실은 구울들을 돕는 곳이에요.']] },
    kagune:{ name:'카구네', alias:['카구네','촉수'], at:[1,690], facts:[[[1,690],'구울의 몸에서 뻗어 나오는 촉수 같은 무기예요.']], easy:'구울이 몸에서 꺼내는 비밀 무기예요.' },
  },
  banned:['아오기리','제이슨','야모리','아리마','츠키야마','후에구치','히나미'],
};

WORKS.conan.guide = {
  season:'1기', eps:2, startAt:[1,0], core:['detective','blackorg','shrink'],
  episodes:{
    1:{ title:'롤러코스터 살인 사건', summary:'고교생 명탐정 신이치는 소꿉친구 란과 놀이공원에 갔다가 롤러코스터 살인 사건을 해결해요. 그 뒤 수상한 검은 옷의 남자들을 뒤쫓다 습격당하고, 정체 모를 독약을 먹게 돼요.' },
    2:{ title:'사장 따님 유괴 사건', summary:'아이 몸이 되어 버린 신이치는 「에도가와 코난」이라는 이름으로 란의 집에서 지내게 돼요. 탐정인 란의 아버지 코고로가 맡은 유괴 사건을, 코난이 몰래 해결로 이끌어요.' },
  },
  scenes:{
    1:[
      { s:0,    title:'저택의 밀실', art:'darkroom', chars:['shinichi','megure'], terms:['detective'], sum:'파티가 열린 저택에서 은행장이 밀실에서 총에 맞은 채 발견돼요. 경찰도 증거를 못 찾던 그때 고교생 탐정 신이치가 나타나요.' },
      { s:150,  title:'휠체어의 범인', art:'darkroom', chars:['shinichi','megure'], terms:['detective'], sum:'신이치는 창문과 밧줄을 이용한 트릭을 밝히고, 휠체어를 탄 저택 주인이 사실 걸을 수 있다는 걸 증명해 범인으로 지목해요.' },
      { s:330,  title:'란과의 약속', art:'street', chars:['shinichi','ran'], terms:[], sum:'등굣길, 축구부를 그만두고 탐정이 되겠다는 신이치에게 란은 가라테 대회에서 우승하면 놀이공원에 데려가기로 한 약속을 상기시켜요.' },
      { s:480,  title:'트로피컬 랜드', art:'party', chars:['shinichi','ran'], terms:['detective'], sum:'두 사람은 놀이공원에 가요. 줄을 서는 동안에도 신이치는 앞사람을 보고 추리를 늘어놓아요.' },
      { s:630,  title:'롤러코스터의 비극', art:'party', chars:['shinichi','ran'], terms:[], sum:'롤러코스터가 어두운 터널을 빠져나오는 순간 한 남자가 목숨을 잃어요. 같은 열차에 검은 옷의 남자 두 명도 타고 있었어요.' },
      { s:810,  title:'진실은 하나', art:'party', chars:['shinichi','megure','ran'], terms:['detective'], sum:'신이치는 터널 안의 단서와 범인의 끊어진 목걸이를 근거로 범인이 피해자의 옛 연인이라는 걸 밝혀내요.' },
      { s:990,  title:'검은 옷의 남자들', art:'party', chars:['shinichi','ran'], terms:['blackorg'], sum:'수상한 두 남자를 뒤쫓기로 한 신이치는 란을 두고 혼자 달려가요. 란은 멀어지는 그의 뒷모습을 바라봐요.' },
      { s:1140, title:'몰래 본 거래', art:'night', chars:['shinichi','vodka'], terms:['blackorg'], sum:'보드카라 불리는 남자가 한 회사 임원과 비밀 거래를 하고, 신이치는 숨어서 그 장면을 지켜봐요.' },
      { s:1260, title:'뒤에서 날아온 일격', art:'night', chars:['shinichi','gin','vodka'], terms:['blackorg','poison'], sum:'뒤에서 다가온 진이 신이치를 쓰러뜨리고, 흔적이 남지 않는다는 개발 중인 독약을 먹여요. 쓰러진 신이치의 몸에 이상한 변화가 일어나요.' },
    ],
    2:[
      { s:0,    title:'작아진 몸', art:'night', chars:['shinichi'], terms:['shrink'], sum:'눈을 뜬 신이치의 몸은 초등학생 크기로 작아져 있어요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'아가사 박사', art:'home', chars:['shinichi','agasa'], terms:['shrink','blackorg'], sum:'이웃 아가사 박사는 신이치임을 믿어 주고, 그 남자들이 알면 주변 사람까지 위험해지니 정체를 숨기라고 해요.' },
      { s:390,  title:'에도가와 코난', art:'home', chars:['shinichi','ran','agasa'], terms:['conanname'], sum:'갑자기 찾아온 란이 누구냐고 묻자, 책장을 본 그는 좋아하는 추리 작가들의 이름을 따 「에도가와 코난」이라고 대답해요.' },
      { s:540,  title:'탐정 사무소로', art:'office', chars:['shinichi','ran','kogoro'], terms:['conanname','blackorg'], sum:'아가사의 부탁으로 코난은 탐정인 란의 아버지 코고로의 집에서 지내게 돼요. 그 남자들의 정보를 얻기 위해서예요.' },
      { s:690,  title:'유괴 의뢰', art:'office', chars:['kogoro','shinichi','ran'], terms:['kidnap'], sum:'그날 밤 코고로에게 한 회사 사장의 딸이 유괴됐다는 의뢰가 들어와요.' },
      { s:840,  title:'수상한 집사', art:'home', chars:['shinichi','kogoro'], terms:['kidnap'], sum:'코난의 귀띔으로 코고로는 유괴를 목격했다는 집사를 의심하게 돼요.' },
      { s:990,  title:'두 번째 전화', art:'home', chars:['kogoro','shinichi'], terms:['kidnap'], sum:'그런데 딸이 또다시 유괴됐다는 전화가 걸려 와요. 처음 유괴와는 다른 진짜 범인이 끼어든 거예요.' },
      { s:1140, title:'단서를 따라', art:'city', chars:['shinichi'], terms:['kidnap'], sum:'코난은 전화 속 소리를 단서로 은신처를 찾아내고, 아이 몸으로도 아이를 구해 내요. 범인은 체포돼요.' },
      { s:1260, title:'유괴의 진짜 이유', art:'home', chars:['kogoro','ran','shinichi'], terms:['kidnap'], sum:'첫 유괴는 일만 하는 아버지와 시간을 보내고 싶었던 딸이 집사에게 부탁한 연극이었어요. 사건을 해결했다며 기분이 좋아진 코고로는 코난이 함께 지내도 좋다고 해요.' },
    ],
  },
  chars:{
    shinichi:{ name:'쿠도 신이치', short:'신이치', alias:['신이치','쿠도','남도일','코난'], at:[1,0], pos:[300,230], facts:[
      [[1,0],'경찰도 도움을 청하는 고교생 명탐정이에요.'],
      [[1,330],'축구부를 그만두고 탐정 일에 빠져 있어요.'],
      [[1,1260],'검은 옷의 남자들에게 독약을 먹어요.'],
      [[2,0],'몸이 아이처럼 작아져요.'],
      [[2,390],'「에도가와 코난」이라는 이름으로 지내요.'],
    ], easy:'몸은 아이, 머리는 명탐정이에요.' },
    megure:{ name:'메구레 경부', short:'메구레', alias:['메구레','경부'], at:[1,0], pos:[110,240], facts:[
      [[1,0],'신이치와 자주 사건을 함께하는 경찰이에요.'],
    ] },
    ran:{ name:'모리 란', short:'란', alias:['란','모리 란','유미란'], at:[1,330], pos:[470,140], facts:[
      [[1,330],'신이치의 소꿉친구예요. 가라테 실력자예요.'],
      [[2,390],'아이가 된 신이치를 알아보지 못하고 「코난」으로 맞이해요.'],
    ] },
    gin:{ name:'진', short:'진', alias:['진'], at:[1,1140], pos:[140,90], facts:[
      [[1,1140],'롤러코스터에 함께 탔던 검은 옷의 남자예요.'],
      [[1,1260],'신이치를 쓰러뜨리고 독약을 먹여요.'],
    ] },
    vodka:{ name:'보드카', short:'보드카', alias:['보드카'], at:[1,1140], pos:[60,150], facts:[
      [[1,1140],'진과 함께 다니는 검은 옷의 남자예요.'],
      [[1,1140],'비밀 거래를 해요.'],
    ] },
    agasa:{ name:'아가사 박사', short:'아가사', alias:['아가사','박사','브라운 박사'], at:[2,240], pos:[130,380], facts:[
      [[2,240],'신이치네 이웃에 사는 발명가예요. 신이치의 정체를 아는 사람이에요.'],
    ] },
    kogoro:{ name:'모리 코고로', short:'코고로', alias:['코고로','모리 탐정','유명한'], at:[2,540], pos:[470,360], facts:[
      [[2,540],'란의 아버지예요. 사립 탐정이지만 실력은 별로예요.'],
      [[2,1260],'코난이 함께 지내도 좋다고 해요.'],
    ] },
  },
  rels:[
    ['shinichi','ran','friend','소꿉친구',[1,330]],
    ['shinichi','megure','peer','함께 사건을 푸는 사이',[1,0]],
    ['gin','vodka','peer','검은 옷의 2인조',[1,1140]],
    ['gin','shinichi','rival','독약을 먹인 남자',[1,1260]],
    ['agasa','shinichi','friend','정체를 아는 이웃',[2,240]],
    ['kogoro','ran','family','아버지와 딸',[2,540]],
    ['kogoro','shinichi','other','함께 사는 탐정과 꼬마',[2,540]],
  ],
  terms:{
    detective:{ name:'고교생 탐정', alias:['탐정','추리'], at:[1,0], facts:[[[1,0],'신이치는 경찰도 의지하는 고교생 탐정이에요.']] },
    blackorg:{ name:'검은 옷의 남자들', alias:['검은 옷','검은 조직','그 남자들'], at:[1,990], facts:[[[1,990],'롤러코스터에 탔던 수상한 두 남자예요.'],[[1,1140],'몰래 거래를 하는 위험한 무리예요.']], easy:'정체를 알 수 없는 범죄자들이에요.' },
    poison:{ name:'개발 중인 독약', alias:['독약','약'], at:[1,1260], facts:[[[1,1260],'흔적이 남지 않는다는 독약이에요. 진이 신이치에게 먹였어요.']] },
    shrink:{ name:'작아진 몸', alias:['작아진','아이 몸'], at:[2,0], facts:[[[2,0],'독약을 먹은 신이치는 죽지 않고 초등학생 크기로 작아졌어요.'],[[2,240],'정체가 알려지면 주변 사람도 위험해져요.']] },
    conanname:{ name:'에도가와 코난', alias:['에도가와 코난','코난'], at:[2,390], facts:[[[2,390],'신이치가 책장의 추리 작가 이름에서 따서 지어낸 가명이에요.']] },
    kidnap:{ name:'사장 딸 유괴 사건', alias:['유괴','유괴 사건'], at:[2,690], facts:[[[2,690],'코고로가 맡은 사건이에요.'],[[2,990],'처음 유괴 뒤에 진짜 범인이 끼어들었어요.']] },
  },
  banned:['하이바라','마취총','괴도 키드','핫토리','APTX','소년 탐정단'],
};

WORKS.mobpsycho.guide = {
  season:'1기', eps:2, startAt:[1,0], core:['esper','spirit','reigen'],
  episodes:{
    1:{ title:'자칭 영능력자 레이겐 아라타카 ~그리고 모브~', summary:'가짜 영능력자 레이겐은 무서운 악령 앞에서 소금만 뿌리다, 결국 아르바이트생 중학생 모브를 불러요. 엄청난 초능력자인 모브는 악령을 손쉽게 없애고, 터널 퇴마 의뢰도 해결해요.' },
    2:{ title:'청춘의 고민 ~텔레파시 동호회 등장~', summary:'폐부 위기의 텔레파시 동호회가 모브를 끌어들이려 하고, 모브와 레이겐은 여고에 숨어들어 유령을 퇴치해요. 모브는 고민 끝에 뜻밖의 동아리에 들어가요.' },
  },
  scenes:{
    1:[
      { s:0,    title:'영능 상담소', art:'office', chars:['reigen'], terms:['reigen'], sum:'레이겐은 「영능력자」 간판을 걸고 상담소를 운영하지만, 사실 영능력은 없어요.' },
      { s:120,  title:'소금 공격', art:'darkroom', chars:['reigen'], terms:['spirit'], sum:'진짜 악령이 나타나자 레이겐은 식탁 소금을 뿌려 보지만 악령을 더 화나게 할 뿐이에요.' },
      { s:270,  title:'모브 호출', art:'darkroom', chars:['reigen','mob'], terms:['esper','spirit'], sum:'레이겐이 부르자 아르바이트생 중학생 모브가 와서, 손 하나 대지 않고 악령을 단숨에 없애요.' },
      { s:420,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:510,  title:'평범한 중학생', art:'classroom', chars:['mob'], terms:['esper'], sum:'모브는 감정을 거의 드러내지 않는 평범한 중학생이에요. 초능력은 사람에게 함부로 쓰면 안 된다고 생각해요.' },
      { s:690,  title:'스승과 제자', art:'office', chars:['mob','reigen'], terms:['reigen'], sum:'모브는 레이겐을 스승으로 믿고 따라요. 레이겐은 그럴듯한 말로 모브를 이끌어요.' },
      { s:840,  title:'터널 의뢰', art:'night', chars:['mob','reigen'], terms:['spirit'], sum:'악령이 들끓는다는 터널을 정리해 달라는 의뢰가 들어오고, 레이겐은 이번에도 모브에게 기대요.' },
      { s:1020, title:'폭주족 유령의 경고', art:'night', chars:['mob','reigen','biker'], terms:['spirit'], sum:'세상을 떠난 폭주족 두목의 유령이 터널 안쪽에 더 강한 괴물이 있다고 경고해요.' },
      { s:1170, title:'터널의 괴물', art:'battle', chars:['mob'], terms:['esper','spirit'], sum:'모브가 터널 깊은 곳의 괴물을 쓰러뜨리고, 갇혀 있던 영혼들은 저세상으로 떠나요.' },
      { s:1350, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
    ],
    2:[
      { s:0,    title:'폐부 위기', art:'classroom', chars:['kurata'], terms:['telepathy'], sum:'부원이 모자라 없어질 위기에 놓인 텔레파시 동호회의 부장 쿠라타가 새 부원을 찾아요.' },
      { s:120,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:210,  title:'모브 스카우트', art:'classroom', chars:['kurata','mob'], terms:['telepathy','esper'], sum:'쿠라타는 모브를 동호회에 끌어들이려 하고, 전화 너머 레이겐과 말다툼까지 벌여요.' },
      { s:390,  title:'여고 의뢰', art:'office', chars:['reigen','mob'], terms:['spirit'], sum:'여학교에 유령이 나온다는 의뢰가 들어와요. 두 사람은 여장을 하고 학교에 숨어들어요.' },
      { s:570,  title:'붙잡힌 레이겐', art:'classroom', chars:['reigen'], terms:[], sum:'레이겐은 학교 경비에게 붙잡혀 버려요.' },
      { s:720,  title:'안내해 준 학생들', art:'classroom', chars:['mob'], terms:['spirit'], sum:'모브는 학생 두 명의 안내를 받아 유령이 있는 곳을 찾아가요.' },
      { s:870,  title:'남학생 유령', art:'battle', chars:['mob'], terms:['spirit','esper'], sum:'모브는 학교에 머물던 남학생 유령과 마주하고 그를 퇴치해요.' },
      { s:1020, title:'동아리 고민', art:'classroom', chars:['mob','kurata'], terms:['telepathy'], sum:'다음 날 모브는 텔레파시 동호회 가입을 고민해요. 그런데 학생회는 동호회 방을 육체개조부에 넘기겠다고 해요.' },
      { s:1200, title:'육체개조부', art:'gym', chars:['mob'], terms:['bodyclub'], sum:'고민 끝에 모브는 근육을 단련하는 육체개조부에 들어가기로 해요.' },
      { s:1350, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
    ],
  },
  chars:{
    mob:{ name:'카게야마 시게오', short:'모브', alias:['모브','시게오','카게야마'], at:[1,270], pos:[300,230], facts:[
      [[1,270],'엄청난 초능력을 가진 중학생이에요. 레이겐 상담소에서 아르바이트를 해요.'],
      [[1,510],'감정을 잘 드러내지 않아요. 초능력을 사람에게 함부로 쓰지 않아요.'],
      [[2,1200],'육체개조부에 들어가요.'],
    ], easy:'세계 최강급 초능력이 있지만, 바라는 건 평범한 청춘인 중학생이에요.' },
    reigen:{ name:'레이겐 아라타카', short:'레이겐', alias:['레이겐','스승'], at:[1,0], pos:[470,140], facts:[
      [[1,0],'「영능력자」를 자처하지만 영능력은 없어요.'],
      [[1,270],'곤란할 땐 모브를 불러 해결해요.'],
      [[1,690],'말솜씨가 뛰어나요.'],
    ], easy:'능력은 가짜지만 말발과 처세는 진짜인 어른이에요.' },
    biker:{ name:'폭주족 두목 유령', short:'폭주족 유령', alias:['폭주족 유령'], at:[1,1020], pos:[150,380], facts:[
      [[1,1020],'터널에 갇혀 있던 유령이에요. 더 강한 괴물이 있다고 경고해요.'],
    ] },
    kurata:{ name:'쿠라타', short:'쿠라타', alias:['쿠라타','부장'], at:[2,0], pos:[140,120], facts:[
      [[2,0],'텔레파시 동호회 부장이에요. 폐부를 막으려 애써요.'],
      [[2,210],'모브를 끌어들이려 해요.'],
    ] },
  },
  rels:[
    ['reigen','mob','other','스승과 제자, 상담소 사장과 아르바이트생',[1,270]],
    ['mob','biker','other','터널에서 만난 유령',[1,1020]],
    ['kurata','mob','other','동호회에 끌어들이려는 선배',[2,210]],
    ['kurata','reigen','rival','전화로 말다툼한 사이',[2,210]],
  ],
  terms:{
    reigen:{ name:'영능 상담소', alias:['상담소','영능력자'], at:[1,0], facts:[[[1,0],'레이겐이 운영하는 상담소예요. 퇴마 의뢰를 받아요.']] },
    spirit:{ name:'악령', alias:['악령','유령','영혼'], at:[1,120], facts:[[[1,120],'사람을 괴롭히는 나쁜 영혼이에요.'],[[1,1170],'갇혀 있던 영혼들은 해방되면 저세상으로 떠나요.']] },
    esper:{ name:'초능력', alias:['초능력','초능력자'], at:[1,270], facts:[[[1,270],'모브는 손대지 않고 악령을 없앨 만큼 강한 초능력자예요.']], easy:'마음만 먹으면 무엇이든 움직이는 힘이에요.' },
    telepathy:{ name:'텔레파시 동호회', alias:['텔레파시 동호회','동호회'], at:[2,0], facts:[[[2,0],'부원이 모자라 폐부 위기에 놓인 동호회예요.']] },
    bodyclub:{ name:'육체개조부', alias:['육체개조부'], at:[2,1020], facts:[[[2,1020],'몸을 단련하는 동아리예요.'],[[2,1200],'모브가 들어가기로 해요.']] },
  },
  banned:['에쿠보','테루키','하나자와','리츠','츠보미','쇼'],
};

WORKS.beastars.guide = {
  season:'1기', eps:2, startAt:[1,0], core:['carnivore','cherryton','drama'],
  episodes:{
    1:{ title:'달과 짐승', summary:'육식동물과 초식동물이 함께 다니는 체리턴 학원에서 알파카 템이 누군가에게 잡아먹혀요. 학교가 술렁이는 가운데, 연극부의 회색늑대 레고시는 작은 토끼 하루에게 마음이 끌려요.' },
    2:{ title:'학원의 정점', summary:'레고시는 자신 안의 육식 본능과 싸우고, 하루가 원예부의 유일한 부원이라는 걸 알게 돼요. 장미를 구하러 간 원예부에서 하루는 레고시를 당황하게 만들어요.' },
  },
  scenes:{
    1:[
      { s:0,    title:'한밤의 사건', art:'night', chars:['tem'], terms:['cherryton','carnivore'], sum:'늦은 밤, 체리턴 학원에서 알파카 템이 정체 모를 육식동물에게 잡아먹혀요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'흔들리는 학교', art:'classroom', chars:['legoshi'], terms:['carnivore','herbivore'], sum:'사건 뒤 학교에는 초식동물과 육식동물 사이의 긴장이 흘러요.' },
      { s:420,  title:'연극부', art:'darkroom', chars:['legoshi','louis'], terms:['drama'], sum:'연극부는 템을 추모하며 연습을 이어 가요. 무대 담당인 회색늑대 레고시와 연극부의 스타인 붉은사슴 루이가 있어요.' },
      { s:600,  title:'갈등 달래기', art:'darkroom', chars:['legoshi','louis'], terms:['drama','carnivore'], sum:'레고시는 루이와 함께 부원들 사이의 갈등을 달래려 애써요.' },
      { s:780,  title:'괴롭힘당하는 토끼', art:'classroom', chars:['haru'], terms:['herbivore'], sum:'작은 흰 토끼 하루는 같은 반 학생들에게 따돌림을 당해요.' },
      { s:930,  title:'늦은 밤 연습', art:'night', chars:['louis','legoshi'], terms:['drama'], sum:'루이는 템의 대역을 맡은 부원을 위해 늦게까지 남아 연습을 시켜 주고, 레고시는 극장 밖을 지켜요.' },
      { s:1110, title:'달빛 아래', art:'night', chars:['legoshi','haru'], terms:['carnivore'], sum:'어둠 속에서 하루와 마주친 레고시는 자신도 모르게 그녀에게 끌려요.' },
      { s:1350, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
    ],
    2:[
      { s:0,    title:'본능', art:'night', chars:['legoshi','haru'], terms:['carnivore'], sum:'레고시는 하루를 먹고 싶다는 본능에 휩싸여 그녀의 팔을 다치게 해요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'빠져나간 하루', art:'night', chars:['legoshi','haru','louis'], terms:['drama'], sum:'루이가 어두운 극장에서 다쳤다는 소식에 레고시가 정신을 차린 사이, 하루는 빠져나가요.' },
      { s:420,  title:'식당의 소동', art:'classroom', chars:['louis'], terms:['carnivore','herbivore'], sum:'다음 날, 루이는 식당에서 벌어진 싸움을 말리고, 다친 다리를 숨긴 채 연습을 이어 가요.' },
      { s:600,  title:'장미 심부름', art:'darkroom', chars:['legoshi','louis'], terms:['drama'], sum:'연극부는 무대 소품으로 쓸 장미를 구해 오라고 레고시에게 부탁해요.' },
      { s:780,  title:'원예부의 유일한 부원', art:'flowers', chars:['legoshi','haru'], terms:['garden'], sum:'원예부를 찾아간 레고시는 하루가 그곳의 유일한 부원이라는 걸 알게 돼요.' },
      { s:960,  title:'들킬까 봐', art:'flowers', chars:['legoshi','haru'], terms:['garden'], sum:'레고시는 자신이 그날 밤의 늑대라는 걸 하루가 알아챌까 두려워하면서도 원예 일을 도와요.' },
      { s:1140, title:'하루의 보답', art:'flowers', chars:['legoshi','haru'], terms:['garden'], sum:'하루는 도와준 보답이라며 레고시를 크게 당황하게 만드는 행동을 하고, 레고시는 겁에 질려요.' },
      { s:1350, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
    ],
  },
  chars:{
    legoshi:{ name:'레고시', short:'레고시', alias:['레고시'], at:[1,240], pos:[300,230], facts:[
      [[1,240],'체리턴 학원의 회색늑대예요. 덩치는 크지만 조용해요.'],
      [[1,420],'연극부 무대 담당이에요.'],
      [[2,0],'자신 안의 육식 본능과 싸워요.'],
    ], easy:'세상에서 가장 무섭게 생긴, 세상에서 가장 소심한 늑대예요.' },
    tem:{ name:'템', short:'템', alias:['템'], at:[1,0], pos:[110,80], facts:[
      [[1,0],'연극부 부원이었던 알파카예요. 누군가에게 잡아먹혔어요.'],
    ] },
    louis:{ name:'루이', short:'루이', alias:['루이'], at:[1,420], pos:[470,130], facts:[
      [[1,420],'연극부의 스타인 붉은사슴이에요. 자존심이 강해요.'],
      [[2,420],'다친 다리를 숨기고 연습해요.'],
    ] },
    haru:{ name:'하루', short:'하루', alias:['하루'], at:[1,780], pos:[470,340], facts:[
      [[1,780],'작은 흰 토끼예요. 반에서 따돌림을 당해요.'],
      [[2,0],'레고시에게 팔을 다쳐요. 상대가 누군지는 몰라요.'],
      [[2,780],'원예부의 유일한 부원이에요.'],
    ] },
  },
  rels:[
    ['legoshi','louis','peer','연극부 동료',[1,420]],
    ['louis','tem','peer','연극부 동료',[1,420]],
    ['legoshi','haru','other','레고시가 끌리는 상대',[1,1110]],
  ],
  terms:{
    cherryton:{ name:'체리턴 학원', alias:['체리턴','학원'], at:[1,0], facts:[[[1,0],'육식동물과 초식동물이 함께 다니는 기숙 학교예요.']] },
    carnivore:{ name:'육식동물', alias:['육식','육식동물'], at:[1,0], facts:[[[1,0],'고기를 먹는 동물이에요. 이 세계에서는 다른 동물을 먹는 게 금지돼 있어요.'],[[2,0],'본능을 누르고 살아가요.']], easy:'원래는 사냥꾼이지만, 법과 예의로 본능을 참고 사는 동물들이에요.' },
    herbivore:{ name:'초식동물', alias:['초식','초식동물'], at:[1,240], facts:[[[1,240],'풀을 먹는 동물이에요. 사건 뒤 육식동물을 더 경계해요.']] },
    drama:{ name:'연극부', alias:['연극부','연극'], at:[1,420], facts:[[[1,420],'템이 있던 동아리예요. 템을 추모하며 공연을 준비해요.']] },
    garden:{ name:'원예부', alias:['원예부','장미'], at:[2,780], facts:[[[2,780],'하루 혼자 지키는 동아리예요.']] },
  },
  banned:['리즈','주노','고우힌','빌이','시시구미'],
};

WORKS.neverland.guide = {
  season:'1기', eps:2, startAt:[1,0], core:['house','mom','escape'],
  episodes:{
    1:{ title:'121045', summary:'고아원 그레이스 필드 하우스에서 「엄마」와 행복하게 사는 아이들. 입양을 떠난 코니가 두고 간 인형을 돌려주러 간 엠마와 노먼은, 아이들이 사실 괴물의 먹이로 길러지고 있다는 끔찍한 진실을 목격해요.' },
    2:{ title:'131045', summary:'엠마와 노먼은 아무렇지 않은 척하며 탈출 방법을 찾고, 엄마가 아이들의 위치를 알고 있다는 걸 깨달아요. 레이가 계획에 합류하고, 하우스에는 새 보모가 찾아와요.' },
  },
  scenes:{
    1:[
      { s:0,    title:'하우스의 아침', art:'home', chars:['emma'], terms:['house'], sum:'엠마는 아침 일찍 동생들을 깨우고 신발 끈을 묶어 주며 하루를 시작해요.' },
      { s:150,  title:'엄마', art:'home', chars:['emma','isabella'], terms:['mom'], sum:'아이들은 다정한 보모 이자벨라를 「엄마」라고 부르며 따라요.' },
      { s:300,  title:'만점 셋', art:'classroom', chars:['emma','norman','ray'], terms:['test'], sum:'매일 치르는 시험에서 엠마, 노먼, 레이만 만점을 받아요.' },
      { s:450,  title:'술래잡기', art:'forest', chars:['emma','norman'], terms:[], sum:'술래잡기에서 노먼은 머리를 써서 엠마까지 잡아내요. 「너는 너무 착한 게 약점이야.」' },
      { s:630,  title:'숲 끝의 울타리', art:'forest', chars:['emma','norman'], terms:['house'], sum:'숲 끝 울타리에서 아이들은 바깥세상과 입양 이야기를 나눠요. 울타리 너머는 가면 안 되는 곳이에요.' },
      { s:780,  title:'코니의 입양', art:'home', chars:['conny','isabella','emma'], terms:['mom'], sum:'어린 코니가 입양이 정해져, 아이들과 눈물로 작별하고 엄마의 손을 잡고 떠나요.' },
      { s:930,  title:'두고 간 인형', art:'home', chars:['emma','norman'], terms:[], sum:'코니가 아끼던 토끼 인형을 두고 간 걸 발견한 엠마와 노먼은 인형을 돌려주러 문 쪽으로 가요.' },
      { s:1080, title:'트럭 안의 코니', art:'darkroom', chars:['emma','norman','conny'], terms:[], sum:'문 너머 통로에 선 트럭 안에서 두 사람은 숨이 멎은 코니를 발견해요.' },
      { s:1200, title:'괴물들', art:'darkroom', chars:['emma','norman','isabella'], terms:['monster','mom'], sum:'트럭 밑에 숨은 두 사람은 괴물들이 아이들을 「상품」이라 부르는 걸 들어요. 그리고 엄마가 그들과 함께 일한다는 걸 알게 돼요.' },
      { s:1320, title:'토끼 인형', art:'night', chars:['emma','norman','isabella'], terms:['escape'], sum:'밤, 노먼은 탈출 계획을 세우자고 해요. 한편 엄마는 통로에 남은 토끼 인형을 손에 들고 있어요.' },
    ],
    2:[
      { s:0,    title:'아무 일 없던 척', art:'home', chars:['emma','norman'], terms:['mom'], sum:'다음 날 아침, 엠마와 노먼은 아무렇지 않은 척해요. 엄마가 인형을 보고 무엇을 알아챘는지는 알 수 없어요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'한 명도 남기지 않고', art:'forest', chars:['emma','norman'], terms:['escape'], sum:'엠마는 모든 아이를 데리고 나가고 싶어 해요. 두 사람은 숲에서 탈출로를 찾아요.' },
      { s:420,  title:'거대한 벽', art:'wall', chars:['emma','norman'], terms:['escape'], sum:'울타리 너머에서 두 사람은 문지기 건물은 너무 위험하다고 판단하고, 그 뒤로 넘기 어려운 거대한 벽을 발견해요.' },
      { s:600,  title:'사라진 아이', art:'forest', chars:['isabella'], terms:['tracker'], sum:'놀이 시간이 끝나고 한 아이가 보이지 않자, 엄마는 회중시계 같은 것을 보고 곧장 그 아이를 찾아내요.' },
      { s:780,  title:'위치를 아는 엄마', art:'forest', chars:['emma','norman'], terms:['tracker'], sum:'엠마와 노먼은 엄마가 아이들의 위치를 알 수 있는 장치를 가지고 있다는 걸 깨달아요.' },
      { s:900,  title:'엄마의 질문', art:'home', chars:['isabella','emma'], terms:['mom'], sum:'그날 밤 엄마는 엠마에게 문 근처에 갔었냐고 물어요. 엠마는 태연하게 거짓말을 하고, 저녁 종이 대화를 끊어요.' },
      { s:1020, title:'시트로 만든 밧줄', art:'night', chars:['emma','norman'], terms:['escape'], sum:'밤에 두 사람은 창고에서 침대 시트를 꺼내 밧줄을 만들어요.' },
      { s:1140, title:'레이 합류', art:'forest', chars:['emma','norman','ray'], terms:['escape'], sum:'레이는 이미 둘의 이야기를 엿들었어요. 모두를 데리고 나가는 건 무리라고 하면서도, 결국 돕기로 해요.' },
      { s:1290, title:'새 식구', art:'home', chars:['isabella'], terms:['mom'], sum:'하우스에 새로 어린 동생이 오고, 엄마를 도울 새 보모도 함께 와요.' },
    ],
  },
  chars:{
    emma:{ name:'엠마', short:'엠마', alias:['엠마'], at:[1,0], pos:[300,230], facts:[
      [[1,0],'운동 신경이 좋고 동생들을 잘 챙기는 11살 소녀예요.'],
      [[1,300],'시험에서 늘 만점을 받아요.'],
      [[2,240],'아이들 모두를 데리고 탈출하고 싶어 해요.'],
    ], easy:'겁나는 상황에서도 「다 같이」를 포기하지 않는 아이예요.' },
    isabella:{ name:'이자벨라', short:'엄마', alias:['엄마','이자벨라'], at:[1,150], pos:[300,60], facts:[
      [[1,150],'아이들을 돌보는 다정한 보모예요. 아이들은 「엄마」라고 불러요.'],
      [[1,1200],'괴물들과 함께 일한다는 사실이 드러나요.'],
      [[2,600],'아이들의 위치를 아는 장치를 가지고 있어요.'],
    ] },
    norman:{ name:'노먼', short:'노먼', alias:['노먼'], at:[1,300], pos:[470,150], facts:[
      [[1,300],'머리가 아주 좋은 11살 소년이에요.'],
      [[1,1320],'탈출 계획을 세우자고 해요.'],
    ] },
    ray:{ name:'레이', short:'레이', alias:['레이'], at:[1,300], pos:[140,150], facts:[
      [[1,300],'엠마, 노먼과 함께 늘 만점을 받는 11살 소년이에요.'],
      [[2,1140],'탈출 계획에 합류해요.'],
    ] },
    conny:{ name:'코니', short:'코니', alias:['코니'], at:[1,780], pos:[140,370], facts:[
      [[1,780],'입양이 정해져 하우스를 떠난 어린 동생이에요. 토끼 인형을 아꼈어요.'],
    ] },
  },
  rels:[
    ['emma','norman','friend','함께 진실을 본 친구',[1,300]],
    ['emma','ray','friend','함께 자란 친구',[1,300]],
    ['norman','ray','friend','함께 자란 친구',[1,300]],
    ['isabella','emma','family','엄마와 아이',[1,150]],
    ['emma','conny','family','하우스의 언니와 동생',[1,780]],
  ],
  terms:{
    house:{ name:'그레이스 필드 하우스', alias:['하우스','고아원'], at:[1,0], facts:[[[1,0],'아이들이 함께 사는 고아원이에요.'],[[1,630],'숲 끝에 넘어가면 안 되는 울타리가 있어요.']] },
    mom:{ name:'엄마', alias:['엄마'], at:[1,150], facts:[[[1,150],'아이들이 보모 이자벨라를 부르는 말이에요.']] },
    test:{ name:'매일의 시험', alias:['시험'], at:[1,300], facts:[[[1,300],'아이들은 매일 시험을 치러요. 엠마, 노먼, 레이는 늘 만점이에요.']] },
    monster:{ name:'괴물', alias:['괴물','상품'], at:[1,1200], facts:[[[1,1200],'아이들을 「상품」이라 부르며 데려가는 존재예요.']], easy:'아이들을 노리는 무서운 존재예요. 하우스는 사실 그들을 위한 농장이었어요.' },
    escape:{ name:'탈출 계획', alias:['탈출','계획'], at:[1,1320], facts:[[[1,1320],'노먼이 제안한 계획이에요.'],[[2,420],'숲 너머에는 거대한 벽이 있어요.']] },
    tracker:{ name:'위치 추적', alias:['추적','회중시계','장치'], at:[2,600], facts:[[[2,600],'엄마는 아이들의 위치를 알려 주는 장치를 가지고 있어요.']] },
  },
  banned:['크로네','레우비스','길다','무지카','소냐'],
};

WORKS.hikaru.guide = {
  season:'1기', eps:2, startAt:[1,0], core:['notHikaru','village','mountain'],
  episodes:{
    1:{ title:'바꿔치기', summary:'산에서 실종됐다 돌아온 단짝 히카루. 요시키는 그가 진짜 히카루가 아니라는 걸 알아채고, 그 「무언가」는 자신이 히카루를 대신하고 있다고 털어놓으며 비밀을 지켜 달라고 부탁해요.' },
    2:{ title:'의심', summary:'마을에서 한 노인이 숨진 채 발견되고 소문이 돌아요. 요시키는 「히카루」가 가진 힘을 조금씩 알게 되고, 마을 밖에서 수상한 사람이 찾아와 산의 존재를 쫓기 시작해요.' },
  },
  scenes:{
    1:[
      { s:0,    title:'산속의 수색', art:'forest', chars:['yoshiki','hikaru'], terms:['mountain'], sum:'폭우가 쏟아지는 산에서 요시키는 실종된 단짝 히카루를 찾아 헤매요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'여섯 달 뒤', art:'town', chars:['yoshiki','hikaru'], terms:['village'], sum:'여름, 시골 마을. 돌아온 히카루와 요시키는 편의점 앞에서 아이스크림을 먹어요. 히카루는 사라졌던 며칠을 기억하지 못해요.' },
      { s:390,  title:'너, 히카루 아니지', art:'town', chars:['yoshiki','hikaru'], terms:['notHikaru'], sum:'요시키가 너는 히카루가 아니라고 말하자, 히카루의 얼굴이 녹아내리듯 일그러져요.' },
      { s:540,  title:'비밀로 해 줘', art:'town', chars:['yoshiki','hikaru'], terms:['notHikaru'], sum:'「그것」은 진짜 히카루는 죽었고, 자신은 그의 기억을 가지고 있다고 털어놓아요. 비밀을 지켜 달라며 요시키를 죽이고 싶지 않다고 해요.' },
      { s:720,  title:'마지막 날의 꿈', art:'hill', chars:['yoshiki'], terms:['village'], sum:'요시키는 사라지기 전날 히카루가 마을을 떠나 도시로 가라고 했던 기억을 꿈꿔요.' },
      { s:870,  title:'학교', art:'classroom', chars:['yoshiki','hikaru'], terms:['notHikaru'], sum:'학교에서 수업 시간에 영화를 보던 히카루는, 직접 겪는 건 특별하다며 눈물을 흘려요.' },
      { s:1020, title:'히카루를 보고 무너진 노인', art:'street', chars:['yoshiki','hikaru','matsuura'], terms:['notHikaru'], sum:'둘이 마을을 돌아다니던 중, 마츠우라 할머니가 히카루를 보자마자 공포에 질려 무너져 내려요.' },
      { s:1170, title:'해 질 녘의 고백', art:'hill', chars:['yoshiki','hikaru'], terms:['notHikaru'], sum:'요시키는 진짜 히카루가 죽었다는 걸 받아들여요. 「그것」은 히카루를 죽이지 않았다며 요시키가 좋다고 말하고, 요시키는 울며 떠나지 말라고 해요.' },
      { s:1320, title:'불려 온 사람', art:'night', chars:['tanaka'], terms:['village'], sum:'그날 밤 마츠우라 할머니가 숨진 채 발견되고, 불안해진 마을 사람들은 바깥의 수상한 남자 타나카에게 연락해요.' },
    ],
    2:[
      { s:0,    title:'경찰차', art:'street', chars:['yoshiki','hikaru'], terms:['village'], sum:'자전거를 타고 가던 두 사람 옆으로 경찰차가 지나가요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'교실의 소문', art:'classroom', chars:['yoshiki'], terms:['village'], sum:'학교에서는 노인의 죽음을 두고 소문이 돌아요. 요시키는 할머니가 히카루를 보고 겁에 질렸던 걸 떠올리며 의심을 키워요.' },
      { s:390,  title:'숲길이 무서운 친구', art:'forest', chars:['yoshiki','hikaru','yuta'], terms:['mountain'], sum:'저주받았다고 믿는 친구 유타가 숲길을 함께 지나 달라고 부탁하고, 히카루가 나서서 함께 가요.' },
      { s:570,  title:'마을 사람들과 타나카', art:'home', chars:['tanaka'], terms:['village'], sum:'타나카는 겁에 질린 마을 사람들을 만나지만, 가볍게 구는 태도에 사람들은 화를 내요.' },
      { s:720,  title:'목이 긴 것', art:'forest', chars:['yoshiki','hikaru'], terms:['notHikaru'], sum:'돌아오는 길, 요시키를 향해 목이 긴 무언가가 다가오자 히카루가 막아서서 그것을 먹어 치워요.' },
      { s:870,  title:'아사코', art:'forest', chars:['yoshiki','hikaru','asako'], terms:['notHikaru'], sum:'소리를 듣고 온 아사코는 히카루에게서 무언가를 느낀 듯한 말을 해요.' },
      { s:1020, title:'가슴의 구멍', art:'classroom', chars:['yoshiki','hikaru'], terms:['notHikaru'], sum:'히카루는 자기 가슴에 난 틈에 요시키의 손을 넣게 해요. 요시키는 빨려 들어갈 뻔하다가 빠져나와요.' },
      { s:1170, title:'산에서 찾은 가방', art:'home', chars:['tanaka'], terms:['mountain'], sum:'타나카는 산에서 히카루의 가방을 찾았다며, 산의 존재가 마을로 내려와 섞여 있을지 모른다고 의심해요.' },
      { s:1290, title:'마트의 경고', art:'street', chars:['yoshiki','rie'], terms:['mountain'], sum:'마트에서 만난 주부 쿠레바야시는 요시키에게 산의 나쁜 기운이 히카루 안에 있다며 엮이지 말라고 경고해요.' },
    ],
  },
  chars:{
    yoshiki:{ name:'츠지나카 요시키', short:'요시키', alias:['요시키','츠지나카'], at:[1,0], pos:[300,230], facts:[
      [[1,0],'시골 마을에 사는 고등학생이에요. 히카루의 단짝이에요.'],
      [[1,390],'돌아온 히카루가 진짜가 아니라는 걸 알아채요.'],
      [[1,1170],'진짜 히카루의 죽음을 받아들이면서도 「그것」 곁에 있기로 해요.'],
    ], easy:'가장 친한 친구를 잃었는데, 친구의 얼굴을 한 무언가가 곁에 남은 소년이에요.' },
    hikaru:{ name:'히카루', short:'히카루', alias:['히카루','인도 히카루'], at:[1,0], pos:[470,140], facts:[
      [[1,0],'산에서 실종된 요시키의 단짝이에요.'],
      [[1,240],'여섯 달 뒤 돌아와 요시키 곁에 있어요.'],
      [[1,540],'진짜 히카루는 죽었고, 지금은 그의 기억을 가진 「무언가」가 그 모습으로 살아요.'],
      [[2,720],'다른 괴이를 먹어 치울 수 있어요.'],
    ] },
    matsuura:{ name:'마츠우라 할머니', short:'마츠우라', alias:['마츠우라','할머니'], at:[1,1020], pos:[130,120], facts:[
      [[1,1020],'히카루를 보고 공포에 질린 마을 노인이에요.'],
      [[1,1320],'그날 밤 숨진 채 발견돼요.'],
    ] },
    tanaka:{ name:'타나카', short:'타나카', alias:['타나카'], at:[1,1320], pos:[480,350], facts:[
      [[1,1320],'마을 사람들이 부른 바깥의 수상한 남자예요. 괴이를 쫓아요.'],
      [[2,1170],'산의 존재가 마을에 섞여 있다고 의심해요.'],
    ] },
    yuta:{ name:'유타', short:'유타', alias:['유타'], at:[2,390], pos:[130,350], facts:[
      [[2,390],'저주받았다고 믿는 같은 학교 친구예요.'],
    ] },
    asako:{ name:'아사코', short:'아사코', alias:['아사코'], at:[2,870], pos:[300,410], facts:[
      [[2,870],'히카루에게서 무언가를 느끼는 듯한 학생이에요.'],
    ] },
    rie:{ name:'쿠레바야시', short:'쿠레바야시', alias:['쿠레바야시','리에'], at:[2,1290], pos:[540,240], facts:[
      [[2,1290],'기운을 느끼는 감각이 있는 주부예요. 요시키에게 경고해요.'],
    ] },
  },
  rels:[
    ['yoshiki','hikaru','friend','단짝, 그리고 비밀을 나눈 사이',[1,540]],
    ['matsuura','hikaru','other','히카루를 보고 겁에 질린 노인',[1,1020]],
    ['tanaka','hikaru','rival','산의 존재를 쫓는 사람',[2,1170]],
    ['yoshiki','yuta','peer','같은 학교 친구',[2,390]],
    ['rie','yoshiki','other','경고를 건넨 사람',[2,1290]],
  ],
  terms:{
    mountain:{ name:'산', alias:['산','산의 존재'], at:[1,0], facts:[[[1,0],'히카루가 실종됐던 마을 뒷산이에요.'],[[2,1170],'무언가가 산에서 내려왔을지도 몰라요.']] },
    village:{ name:'시골 마을', alias:['마을'], at:[1,240], facts:[[[1,240],'요시키와 히카루가 사는 작은 시골 마을이에요. 서로의 사정을 다 아는 곳이에요.']] },
    notHikaru:{ name:'히카루가 아닌 것', alias:['그것','무언가'], at:[1,390], facts:[[[1,390],'히카루의 모습과 기억을 가진 정체 모를 존재예요.'],[[1,540],'요시키에게 비밀을 지켜 달라고 해요.']], easy:'친구의 모습을 하고 있지만 사람이 아닌 무언가예요.' },
  },
  banned:['노우누키','쿠비타치'],
};
