/* ============================================================
   가이드북 — E구역 로맨스·드라마·청춘 (1~2화, 회차 요약 자료로 확인한 범위만)
   장면 시각은 줄거리 순서에 맞춘 대략적인 위치예요.
   ============================================================ */
WORKS.april.guide = {
  season:'1기', eps:2, startAt:[1,0], core:['monotone','piano','violin'],
  episodes:{
    1:{ title:'모노톤 컬러풀', summary:'어머니를 잃은 뒤 피아노를 칠 수 없게 된 전 천재 피아니스트 코세이. 소꿉친구 츠바키의 부탁으로 나간 더블데이트 자리에서, 공원에서 멜로디언을 불던 바이올리니스트 카오리를 만나요.' },
    2:{ title:'친구 A', summary:'카오리의 바이올린 콩쿠르를 보러 간 코세이는 악보를 벗어난 자유로운 연주에 사로잡혀요. 카오리는 코세이에게 료타 대신 곁에 있어 달라고 부탁해요.' },
  },
  scenes:{
    1:[
      { s:0,    title:'흑백의 세상', art:'town', chars:['kosei'], terms:['monotone'], sum:'중학생 코세이에게 세상은 온통 흑백이에요. 2년 전 어머니가 세상을 떠난 뒤부터예요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'소꿉친구들', art:'street', chars:['kosei','tsubaki','ryota'], terms:[], sum:'소프트볼부 츠바키, 축구부 료타는 코세이의 소꿉친구예요. 츠바키는 사랑을 하면 세상이 알록달록해진다고 말해요.' },
      { s:420,  title:'더블데이트', art:'street', chars:['kosei','tsubaki'], terms:[], sum:'츠바키는 료타를 좋아한다는 여학생과의 약속에 코세이도 함께 가자고 해요.' },
      { s:570,  title:'피아노를 친 이유', art:'home', chars:['kosei','saki'], terms:['piano'], sum:'코세이는 어머니의 꿈을 이루려고 피아노를 쳤고, 지금은 그것밖에 남은 게 없어서 붙잡고 있을 뿐이라고 털어놓아요.' },
      { s:720,  title:'공원의 멜로디언', art:'flowers', chars:['kosei','kaori'], terms:[], sum:'다음 날 먼저 공원에 간 코세이는, 아이들과 멜로디언을 불며 비둘기를 부르는 소녀를 봐요.' },
      { s:870,  title:'최악의 첫인상', art:'flowers', chars:['kosei','kaori'], terms:[], sum:'뜻밖의 사고로 코세이는 소녀에게 단단히 미움을 사요.' },
      { s:1020, title:'료타의 데이트 상대', art:'street', chars:['kosei','kaori','ryota','tsubaki'], terms:['violin'], sum:'알고 보니 그 소녀가 료타의 데이트 상대 카오리예요. 카오리는 곧 콩쿠르에 나가는 바이올리니스트예요.' },
      { s:1200, title:'멈춘 연주', art:'darkroom', chars:['kosei','saki'], terms:['piano'], sum:'회상 속에서, 코세이는 어머니를 잃은 슬픔에 짓눌려 「월광 소나타」를 연주하다 그대로 멈춰 버렸어요.' },
    ],
    2:[
      { s:0,    title:'콩쿠르 홀', art:'darkroom', chars:['kosei','kaori','tsubaki','ryota'], terms:['violin'], sum:'네 사람은 중학생 바이올린 콩쿠르에 10분 전에 아슬아슬하게 도착해요. 몇몇 관객은 코세이를 알아봐요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'같은 곡, 다른 연주', art:'darkroom', chars:['kosei'], terms:['competition'], sum:'예선에서는 모두 피아노 반주자와 함께 같은 과제곡을 연주해요. 다들 악보대로 정확하게 연주해요.' },
      { s:420,  title:'네 번째 참가자', art:'darkroom', chars:['kaori','kosei'], terms:['violin'], sum:'네 번째로 나온 카오리는 악보를 벗어난 자유롭고 강렬한 연주로 관객을 사로잡아요.' },
      { s:660,  title:'색이 돌아온 순간', art:'darkroom', chars:['kosei','kaori'], terms:['monotone'], sum:'흑백이던 코세이의 눈에 카오리의 연주가 색을 입혀요.' },
      { s:840,  title:'친구 A', art:'street', chars:['kosei','kaori','ryota'], terms:[], sum:'연주가 끝나고 카오리가 료타에게 달려가는 모습을 보며, 코세이는 자신이 영화 속 「친구 A」 같다고 느껴요.' },
      { s:1020, title:'복잡한 마음', art:'night', chars:['kosei','tsubaki'], terms:[], sum:'코세이는 카오리에게 끌리는 마음과 거리감 사이에서 복잡해져요.' },
      { s:1170, title:'대신 와 줄래?', art:'street', chars:['kosei','kaori'], terms:[], sum:'다음 날 료타가 축구 연습이 있자, 카오리는 코세이에게 그동안 료타 대신 곁에 있어 달라고 해요.' },
      { s:1290, title:'크로이처 소나타', art:'darkroom', chars:['kaori'], terms:['competition','violin'], sum:'콩쿠르 1차 무대에서 카오리는 베토벤 「크로이처 소나타」 1악장을 원곡과 전혀 다른 방식으로 연주해요.' },
    ],
  },
  chars:{
    kosei:{ name:'아리마 코세이', short:'코세이', alias:['코세이','아리마'], at:[1,0], pos:[300,230], facts:[
      [[1,0],'한때 천재 피아니스트로 불린 중학생이에요.'],
      [[1,570],'어머니의 꿈을 이루려고 피아노를 쳤어요.'],
      [[1,1200],'어머니를 잃은 뒤 연주 중에 멈춰 버린 적이 있어요.'],
      [[2,840],'카오리 곁에서 자신을 「친구 A」 같다고 느껴요.'],
    ], easy:'피아노를 사랑했지만 소리를 잃어버린 소년이에요.' },
    tsubaki:{ name:'사와베 츠바키', short:'츠바키', alias:['츠바키','사와베'], at:[1,240], pos:[150,120], facts:[
      [[1,240],'코세이의 소꿉친구예요. 소프트볼부예요.'],
      [[1,420],'코세이를 더블데이트에 데려가요.'],
    ] },
    ryota:{ name:'와타리 료타', short:'료타', alias:['료타','와타리'], at:[1,240], pos:[470,120], facts:[
      [[1,240],'코세이의 소꿉친구예요. 축구부에 인기가 많아요.'],
    ] },
    saki:{ name:'아리마 사키', short:'사키', alias:['사키','어머니','엄마'], at:[1,570], pos:[120,370], facts:[
      [[1,570],'코세이의 어머니예요. 2년 전 세상을 떠났어요.'],
    ] },
    kaori:{ name:'미야조노 카오리', short:'카오리', alias:['카오리','미야조노'], at:[1,720], pos:[470,350], facts:[
      [[1,720],'공원에서 아이들과 멜로디언을 불던 소녀예요.'],
      [[1,1020],'료타의 데이트 상대이자 바이올리니스트예요.'],
      [[2,420],'악보를 벗어난 자유로운 연주를 해요.'],
    ], easy:'제멋대로지만 눈부시게 빛나는 바이올리니스트예요.' },
  },
  rels:[
    ['kosei','tsubaki','friend','소꿉친구',[1,240]],
    ['kosei','ryota','friend','소꿉친구',[1,240]],
    ['kosei','saki','family','아들과 어머니',[1,570]],
    ['kaori','ryota','other','데이트 상대',[1,1020]],
    ['kosei','kaori','other','함께 다니게 된 「친구 A」',[2,1170]],
  ],
  terms:{
    monotone:{ name:'흑백의 세상', alias:['흑백','모노톤'], at:[1,0], facts:[[[1,0],'어머니를 잃은 뒤 코세이의 눈에 보이는 세상이에요.'],[[2,660],'카오리의 연주가 그 세상에 색을 입혀요.']], easy:'마음이 멈춰 버려 모든 게 회색으로 보이는 상태예요.' },
    piano:{ name:'피아노', alias:['피아노','월광 소나타'], at:[1,570], facts:[[[1,570],'코세이가 어머니의 꿈을 위해 치던 악기예요.'],[[1,1200],'연주 도중 멈춘 뒤로 제대로 치지 못해요.']] },
    violin:{ name:'바이올린', alias:['바이올린'], at:[1,1020], facts:[[[1,1020],'카오리가 연주하는 악기예요.']] },
    competition:{ name:'바이올린 콩쿠르', alias:['콩쿠르','예선','크로이처'], at:[2,240], facts:[[[2,240],'중학생 바이올리니스트들이 실력을 겨루는 대회예요.']] },
  },
  banned:['이가와','아이자와','세토 히로코','나기'],
};

WORKS.alya.guide = {
  season:'1기', eps:2, startAt:[1,0], core:['russian','council','yukisecret'],
  episodes:{
    1:{ title:'아랴 양은 러시아어로 부끄러워해', summary:'옆자리의 미소녀 아랴는 쿠제가 못 알아들을 거라 믿고 러시아어로 속마음을 흘려요. 하지만 쿠제는 사실 러시아어를 다 알아들어요.' },
    2:{ title:'소꿉친구라고 하기엔', summary:'학생회 유키가 쿠제를 학생회에 끌어들이려 하고, 쿠제와 유키 사이의 숨겨진 관계가 드러나요. 아랴는 두 사람을 신경 쓰며 쿠제와 옷 쇼핑에 나서요.' },
  },
  scenes:{
    1:[
      { s:0,    title:'고고한 옆자리', art:'classroom', chars:['alya','kuze'], terms:[], sum:'러시아계 미소녀 아랴는 성적도 외모도 뛰어나 「고고한 공주님」이라 불려요. 옆자리 쿠제에게는 늘 차갑게 굴어요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'러시아어 한마디', art:'classroom', chars:['alya','kuze'], terms:['russian'], sum:'아랴는 쿠제가 못 알아들을 거라 생각하고 러시아어로 수줍은 속마음을 흘려요.' },
      { s:390,  title:'사실은 다 들려', art:'classroom', chars:['kuze'], terms:['russian'], sum:'쿠제는 어릴 적 러시아 소녀와 이야기하려고 러시아어를 배워 다 알아들어요. 하지만 모르는 척해요.' },
      { s:540,  title:'학생회', art:'office', chars:['alya','maria','yuki'], terms:['council'], sum:'아랴는 언니 마리야, 그리고 라이벌 스오 유키와 함께 학생회에서 활동해요. 유키는 쿠제의 소꿉친구예요.' },
      { s:720,  title:'젖은 양말', art:'classroom', chars:['alya','kuze'], terms:[], sum:'어느 아침, 양말이 젖은 아랴는 쿠제에게 갈아 신는 걸 도와 달라고 해요.' },
      { s:870,  title:'대참사', art:'classroom', chars:['alya','kuze'], terms:[], sum:'쿠제의 손이 미끄러지는 사고가 나고, 아랴는 그를 걷어차고 도망쳐요.' },
      { s:1020, title:'쫓고 쫓기는', art:'street', chars:['alya','kuze'], terms:[], sum:'쿠제는 숨이 찰 때까지 아랴를 쫓아가 사과하고, 아랴도 자기 잘못도 있었다며 진정할 시간이 필요했다고 해요.' },
      { s:1200, title:'다시 러시아어로', art:'classroom', chars:['alya','kuze'], terms:['russian'], sum:'아랴는 또다시 러시아어로 쿠제를 놀리고, 쿠제는 속으로 괴로워해요.' },
      { s:1350, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
    ],
    2:[
      { s:0,    title:'학생회장과의 만남', art:'office', chars:['yuki','kuze','kenzaki'], terms:['council'], sum:'유키는 쿠제를 학생회에 들이려는 계획으로 학생회장 켄자키에게 쿠제를 소개해요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'아랴의 목표', art:'office', chars:['kuze','alya'], terms:['council'], sum:'쿠제는 아랴가 내년 학생회장 선거에 나갈 생각이라는 걸 알게 돼요.' },
      { s:420,  title:'집에서 기다린 사람', art:'home', chars:['kuze','yuki'], terms:['yukisecret'], sum:'집에 돌아온 쿠제 앞에 유키가 있어요. 사실 유키는 성이 다른 쿠제의 친여동생이에요. 사람들을 놀리는 게 재밌어서 비밀로 하고 있어요.' },
      { s:600,  title:'미행', art:'street', chars:['kuze','yuki','alya'], terms:[], sum:'둘이 쇼핑을 하던 중 아랴가 몰래 뒤따라오고 있다는 걸 알아채요.' },
      { s:750,  title:'지옥의 라멘', art:'party', chars:['yuki','alya','kuze'], terms:['russian'], sum:'유키는 아랴를 엄청나게 매운 라멘집에 데려가요. 아랴는 고집스럽게 다 먹고, 러시아어로 쿠제가 부회장으로 자신을 도와주면 좋겠다고 중얼거려요.' },
      { s:930,  title:'옷 쇼핑', art:'town', chars:['alya','kuze'], terms:[], sum:'유키가 자리를 뜨자 아랴는 쿠제를 데리고 옷을 고르러 가요. 칭찬이 좋아 점점 과감한 옷을 입어 봐요.' },
      { s:1110, title:'돌아온 유키', art:'town', chars:['alya','yuki','kuze'], terms:[], sum:'아주 짧은 치마를 입고 나온 순간 유키가 돌아와, 아랴는 얼어붙어요.' },
      { s:1230, title:'같은 역', art:'city', chars:['alya','kuze','yuki'], terms:['yukisecret'], sum:'멍하니 기차를 타고 가던 아랴는, 쿠제와 유키가 같은 역에서 내리는 걸 보고 정신이 번쩍 들어요.' },
      { s:1350, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
    ],
  },
  chars:{
    alya:{ name:'쿠조 알리사 미하일로브나', short:'아랴', alias:['아랴','알리사','쿠조'], at:[1,0], pos:[470,140], facts:[
      [[1,0],'러시아계 미소녀예요. 성적도 외모도 뛰어나요.'],
      [[1,240],'쿠제가 못 알아듣는다고 믿고 러시아어로 속마음을 흘려요.'],
      [[2,240],'내년 학생회장 선거에 나갈 생각이에요.'],
    ], easy:'겉으론 새침하지만 러시아어로는 솔직한, 숨김 서툰 공주님이에요.' },
    kuze:{ name:'쿠제 마사치카', short:'쿠제', alias:['쿠제','마사치카'], at:[1,0], pos:[300,230], facts:[
      [[1,0],'아랴의 옆자리에 앉은, 의욕 없어 보이는 남학생이에요.'],
      [[1,390],'어릴 적 배운 러시아어를 다 알아들어요. 그래도 모르는 척해요.'],
      [[2,420],'유키의 친오빠예요.'],
    ] },
    maria:{ name:'쿠조 마리야', short:'마리야', alias:['마리야','마샤'], at:[1,540], pos:[140,110], facts:[
      [[1,540],'아랴의 언니예요. 학생회에서 함께 활동해요.'],
    ] },
    yuki:{ name:'스오 유키', short:'유키', alias:['유키','스오'], at:[1,540], pos:[150,350], facts:[
      [[1,540],'학생회 일원이자 쿠제의 소꿉친구로 알려져 있어요. 아랴의 라이벌이에요.'],
      [[2,0],'쿠제를 학생회에 끌어들이려 해요.'],
      [[2,420],'사실은 쿠제의 친여동생이에요.'],
    ] },
    kenzaki:{ name:'켄자키 토야', short:'켄자키', alias:['켄자키','학생회장'], at:[2,0], pos:[480,370], facts:[
      [[2,0],'지금의 학생회장이에요.'],
    ] },
  },
  rels:[
    ['alya','kuze','other','옆자리 친구',[1,0]],
    ['alya','maria','family','자매',[1,540]],
    ['alya','yuki','rival','학생회의 라이벌',[1,540]],
    ['kuze','yuki','friend','소꿉친구로 알려진 사이',[1,540]],
    ['kuze','yuki','family','사실은 남매',[2,420]],
    ['kenzaki','yuki','peer','학생회 동료',[2,0]],
  ],
  terms:{
    russian:{ name:'러시아어', alias:['러시아어'], at:[1,240], facts:[[[1,240],'아랴가 몰래 속마음을 흘릴 때 쓰는 말이에요.'],[[1,390],'쿠제는 다 알아들어요.']], easy:'아랴에겐 비밀 일기장 같은 언어인데, 쿠제에겐 다 들려요.' },
    council:{ name:'학생회', alias:['학생회','학생회장','부회장'], at:[1,540], facts:[[[1,540],'아랴, 마리야, 유키가 활동하는 곳이에요.'],[[2,240],'아랴는 내년 학생회장에 도전하려 해요.']] },
    yukisecret:{ name:'유키의 비밀', alias:['남매','여동생'], at:[2,420], facts:[[[2,420],'유키는 성이 다른 쿠제의 친여동생이에요. 학교에선 비밀이에요.']] },
  },
  banned:['아야노','타니야마','미야마에'],
};

WORKS.bisquedoll.guide = {
  season:'1기', eps:2, startAt:[1,0], core:['hina','cosplay','shizuku'],
  episodes:{
    1:{ title:'나와 정반대 세계에 사는 사람', summary:'히나 인형 옷을 만드는 고죠는 취미를 들킬까 봐 사람을 피하는 고교생이에요. 학교 재봉실에서 반의 인기녀 마린에게 들키지만, 마린은 그의 솜씨를 칭찬하며 코스프레 의상을 만들어 달라고 해요.' },
    2:{ title:'빨리 해 볼래?', summary:'마린이 원하는 캐릭터는 성인 게임 속 「시즈쿠 쿠로에」예요. 고죠는 처음으로 사람이 입을 옷을 만들기 위해 마린의 치수를 재고, 자료 조사에 들어가요.' },
  },
  scenes:{
    1:[
      { s:0,    title:'히나 인형', art:'home', chars:['gojo','grandpa'], terms:['hina'], sum:'고죠는 할아버지의 히나 인형 공방에서 자라, 인형의 얼굴과 옷을 만드는 장인을 꿈꿔요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'숨기는 취미', art:'classroom', chars:['gojo'], terms:['hina'], sum:'어릴 적 취미를 놀림받은 뒤로, 고죠는 학교에서 아무와도 어울리지 않아요.' },
      { s:390,  title:'반의 인기녀', art:'classroom', chars:['gojo','marin'], terms:[], sum:'청소 당번 날, 반의 인기녀 마린이 고죠에게 거리낌 없이 말을 걸어요. 좋아하는 건 솔직하게 좋다고 하는 사람이에요.' },
      { s:570,  title:'고장 난 재봉틀', art:'home', chars:['gojo','grandpa'], terms:[], sum:'집 재봉틀이 고장 나자, 고죠는 새것이 올 때까지 학교 재봉실을 쓰기로 해요.' },
      { s:720,  title:'재봉실에서', art:'classroom', chars:['gojo','marin'], terms:['hina'], sum:'재봉실에서 인형 옷을 만들던 고죠 앞에 마린이 나타나요. 마린은 놀리기는커녕 솜씨를 칭찬해요.' },
      { s:900,  title:'마린의 의상', art:'classroom', chars:['gojo','marin'], terms:['cosplay'], sum:'마린은 직접 만들던 코스프레 의상을 보여 주고, 고죠는 무심코 날카롭게 평가해 버려요.' },
      { s:1080, title:'만들어 줄래?', art:'classroom', chars:['gojo','marin'], terms:['cosplay','shizuku'], sum:'마린은 아주 소중한 캐릭터 「시즈쿠 쿠로에」의 의상을 만들어 달라고 부탁해요.' },
      { s:1230, title:'최선을 다할게요', art:'classroom', chars:['gojo','marin'], terms:['cosplay'], sum:'사람이 입을 옷은 만들어 본 적 없지만, 고죠는 최선을 다하겠다고 약속하고 마린은 크게 기뻐해요.' },
      { s:1350, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
    ],
    2:[
      { s:0,    title:'시즈쿠의 정체', art:'classroom', chars:['marin','gojo'], terms:['shizuku'], sum:'마린이 코스프레하고 싶은 시즈쿠는 성인 게임 속 캐릭터예요. 고죠는 당황해요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'좋아하는 데 이유는 없어', art:'classroom', chars:['marin','gojo'], terms:['cosplay'], sum:'마린은 좋아하는 데 성별이나 장르는 상관없다고 말하고, 고죠도 고개를 끄덕여요.' },
      { s:420,  title:'코스프레 교본', art:'home', chars:['gojo'], terms:['cosplay'], sum:'마린이 건넨 코스프레 의상 만들기 책을 보며 고죠는 공부를 시작해요.' },
      { s:600,  title:'공방에 온 마린', art:'home', chars:['marin','gojo'], terms:['measure'], sum:'다음 날 마린이 치수를 재러 고죠네 공방에 찾아와요. 옷 안에 수영복을 입고 왔어요.' },
      { s:780,  title:'채촌', art:'home', chars:['gojo','marin'], terms:['measure'], sum:'고죠는 얼굴이 새빨개지면서도 장인답게 침착하게 모든 치수를 꼼꼼히 재요.' },
      { s:1020, title:'자료 조사', art:'home', chars:['marin','gojo'], terms:['shizuku'], sum:'고죠가 참고할 자료를 부탁하자, 마린은 시즈쿠가 나오는 게임 두 편을 건네요.' },
      { s:1200, title:'밤샘 연구', art:'home', chars:['gojo','grandpa'], terms:['shizuku'], sum:'그날 밤 고죠는 의상 연구를 위해 게임을 하고, 할아버지는 기겁해요.' },
      { s:1350, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
    ],
  },
  chars:{
    gojo:{ name:'고죠 와카나', short:'고죠', alias:['고죠','와카나'], at:[1,0], pos:[300,230], facts:[
      [[1,0],'히나 인형 장인을 꿈꾸는 고교생이에요.'],
      [[1,240],'취미를 들킬까 봐 사람과 어울리지 않아요.'],
      [[1,1230],'마린의 코스프레 의상을 만들기로 해요.'],
    ], easy:'손재주는 장인급인데 자신감은 바닥인 수줍은 소년이에요.' },
    grandpa:{ name:'고죠의 할아버지', short:'할아버지', alias:['할아버지'], at:[1,0], pos:[120,380], facts:[
      [[1,0],'히나 인형 공방을 하는 고죠의 할아버지예요.'],
    ] },
    marin:{ name:'키타가와 마린', short:'마린', alias:['마린','키타가와'], at:[1,390], pos:[470,140], facts:[
      [[1,390],'반의 인기녀예요. 좋아하는 건 솔직하게 좋다고 해요.'],
      [[1,900],'코스프레를 좋아해 직접 의상을 만들기도 해요.'],
      [[2,0],'시즈쿠 쿠로에를 코스프레하고 싶어 해요.'],
    ], easy:'좋아하는 것 앞에선 한없이 진심인 밝은 갸루예요.' },
  },
  rels:[
    ['gojo','grandpa','family','손자와 할아버지',[1,0]],
    ['gojo','marin','friend','의상을 만들어 주기로 한 사이',[1,1230]],
  ],
  terms:{
    hina:{ name:'히나 인형', alias:['히나 인형','인형'], at:[1,0], facts:[[[1,0],'일본의 전통 인형이에요. 고죠는 얼굴과 옷을 만드는 장인을 꿈꿔요.']] },
    cosplay:{ name:'코스프레', alias:['코스프레','의상'], at:[1,900], facts:[[[1,900],'좋아하는 캐릭터의 옷과 모습을 따라 하는 취미예요. 마린이 좋아해요.']], easy:'좋아하는 캐릭터가 직접 되어 보는 놀이예요.' },
    shizuku:{ name:'시즈쿠 쿠로에', alias:['시즈쿠'], at:[1,1080], facts:[[[1,1080],'마린에게 아주 소중한 캐릭터예요.'],[[2,0],'성인 게임 속 캐릭터예요.']] },
    measure:{ name:'채촌', alias:['치수','채촌'], at:[2,600], facts:[[[2,600],'옷을 만들기 위해 몸의 치수를 재는 일이에요.']] },
  },
  banned:['쥬쥬','시노','이누이','아마네'],
};

WORKS.raise.guide = {
  season:'1기', eps:2, startAt:[1,0], core:['yakuza','engagement','plan'],
  episodes:{
    1:{ title:'패배자는 설 자리가 없어', summary:'오사카 야쿠자 조직 두목의 손녀 요시노는 할아버지 뜻에 따라 도쿄로 가서 다른 조직의 손자 키리시마와 약혼해요. 키리시마의 진짜 얼굴을 본 요시노는 그를 반하게 만든 뒤 무너뜨리겠다고 결심해요.' },
    2:{ title:'두 번째 화', summary:'요시노는 사라진 조직원의 딸을 찾는 일에 키리시마와 함께 휘말려요. 두 사람은 위험한 클럽에서 한바탕 소동을 벌여요.' },
  },
  scenes:{
    1:[
      { s:0,    title:'오사카의 아가씨', art:'city', chars:['yoshino'], terms:['yakuza'], sum:'오사카 야쿠자 조직 두목의 손녀 요시노는 콧대가 높아 학교에선 아무도 다가오지 않아요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'약혼 통보', art:'home', chars:['yoshino','grandpa'], terms:['engagement'], sum:'할아버지는 요시노에게 도쿄로 가서 오랜 친구의 손자와 약혼하라고 해요. 요시노는 마지못해 받아들여요.' },
      { s:420,  title:'도쿄의 학교', art:'classroom', chars:['yoshino','kirishima'], terms:['engagement'], sum:'도쿄의 학교에서 요시노는 키리시마의 약혼녀라는 이유로 반 친구들의 미움을 받아요.' },
      { s:600,  title:'키리시마의 정체', art:'night', chars:['yoshino','kirishima'], terms:['yakuza'], sum:'겉보기엔 평범해 보이던 키리시마는 사실 문신을 하고 폭력을 서슴지 않는 야쿠자의 얼굴을 가지고 있어요.' },
      { s:780,  title:'선을 넘은 말', art:'night', chars:['yoshino','kirishima'], terms:[], sum:'키리시마는 요시노에게 조직을 위해 몸을 팔아 돈을 벌라고 해요. 요시노는 경악해요.' },
      { s:960,  title:'할아버지의 조언', art:'home', chars:['yoshino','grandpa'], terms:['plan'], sum:'전화를 건 요시노에게 할아버지는 키리시마를 반하게 만든 뒤 그 마음으로 그를 무너뜨리라고 해요.' },
      { s:1110, title:'사라진 2주', art:'city', chars:['yoshino'], terms:['plan'], sum:'요시노는 2주 동안 자취를 감춰요.' },
      { s:1230, title:'돌아온 요시노', art:'classroom', chars:['yoshino','kirishima'], terms:['plan'], sum:'돌아온 요시노는 장기를 팔아 마련했다며 거액을 내밀어요. 그 기세에 키리시마는 요시노에게 반해 버려요.' },
      { s:1350, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
    ],
    2:[
      { s:0,    title:'숨겨진 추적기', art:'classroom', chars:['yoshino','kirishima'], terms:[], sum:'요시노는 키리시마가 자기 전자사전에 위치 추적기를 숨겨 뒀다는 걸 알게 돼요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'사라진 딸', art:'office', chars:['kirishima','shiori'], terms:['yakuza'], sum:'산하 조직 간부의 스무 살 딸 시오리가 행방불명되고, 요시노는 안전을 위해 키리시마 곁에 붙어 지내야 해요.' },
      { s:420,  title:'조직의 사정', art:'office', chars:['kirishima','yoshino'], terms:['yakuza'], sum:'두 조직의 영역 다툼과 키리시마의 과거 이야기가 조금씩 드러나요.' },
      { s:600,  title:'드라이어 쇼핑', art:'town', chars:['yoshino','shiori'], terms:[], sum:'새 헤어드라이어를 사러 나간 요시노는 다른 조직 구역의 클럽으로 들어가는 시오리를 발견해요.' },
      { s:780,  title:'집안의 이름으로', art:'night', chars:['yoshino'], terms:['yakuza'], sum:'그 클럽은 소메이 가문 산하 조직의 가게예요. 요시노는 집안의 이름을 대고 안으로 들어가요.' },
      { s:960,  title:'불법 도박', art:'night', chars:['yoshino','shiori'], terms:[], sum:'시오리는 불법 도박판에서 속임수를 쓰다 걸려, 나라 밖으로 도망치려던 참이었어요.' },
      { s:1110, title:'난투', art:'battle', chars:['kirishima','yoshino'], terms:[], sum:'키리시마가 나타나 위협적으로 굴다 싸움이 벌어지고, 요시노도 헤어드라이어를 휘둘러 가세해요.' },
      { s:1260, title:'아무 일 없었던 듯', art:'classroom', chars:['yoshino','kirishima'], terms:[], sum:'다음 날 교실, 붕대를 감은 키리시마와 요시노는 아무 일 없었던 것처럼 수다를 떨어요.' },
      { s:1350, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
    ],
  },
  chars:{
    yoshino:{ name:'소메이 요시노', short:'요시노', alias:['요시노','소메이'], at:[1,0], pos:[300,230], facts:[
      [[1,0],'오사카 야쿠자 조직 두목의 손녀예요. 콧대 높고 당찬 고교생이에요.'],
      [[1,240],'할아버지 뜻에 따라 도쿄에서 약혼 생활을 시작해요.'],
      [[1,960],'키리시마를 반하게 만든 뒤 무너뜨리려 해요.'],
    ], easy:'절대 지고는 못 사는 오사카 아가씨예요.' },
    grandpa:{ name:'요시노의 할아버지', short:'할아버지', alias:['할아버지'], at:[1,240], pos:[120,110], facts:[
      [[1,240],'오사카 야쿠자 조직의 두목이에요. 요시노의 약혼을 정했어요.'],
    ] },
    kirishima:{ name:'키리시마 미야마', short:'키리시마', alias:['키리시마','미야마'], at:[1,420], pos:[470,140], facts:[
      [[1,420],'요시노의 약혼자예요. 같은 학교에 다녀요.'],
      [[1,600],'사실은 야쿠자의 얼굴을 가진 위험한 사람이에요.'],
      [[1,1230],'요시노에게 반해 버려요.'],
    ] },
    shiori:{ name:'아카자 시오리', short:'시오리', alias:['시오리'], at:[2,240], pos:[470,360], facts:[
      [[2,240],'산하 조직 간부의 딸이에요. 행방불명됐어요.'],
      [[2,960],'불법 도박에서 속임수를 쓰다 걸렸어요.'],
    ] },
  },
  rels:[
    ['yoshino','grandpa','family','손녀와 할아버지',[1,240]],
    ['yoshino','kirishima','other','정략 약혼자',[1,420]],
    ['kirishima','shiori','other','찾아야 하는 산하 조직 사람',[2,240]],
  ],
  terms:{
    yakuza:{ name:'야쿠자', alias:['야쿠자','조직'], at:[1,0], facts:[[[1,0],'일본의 폭력 조직이에요. 요시노는 오사카 조직 두목의 손녀예요.']] },
    engagement:{ name:'정략 약혼', alias:['약혼','약혼녀'], at:[1,240], facts:[[[1,240],'두 조직 집안이 정한 요시노와 키리시마의 약혼이에요.']] },
    plan:{ name:'반하게 해서 무너뜨리기', alias:['계획','작전'], at:[1,960], facts:[[[1,960],'할아버지가 알려 준 작전이에요. 키리시마를 반하게 만든 뒤 무너뜨려요.']], easy:'사랑을 무기로 쓰는 위험한 연애 전쟁이에요.' },
  },
  banned:['오미'],
};

WORKS.kiminitodoke.guide = {
  season:'1기', eps:2, startAt:[1,0], core:['sadako','courage','rumor'],
  episodes:{
    1:{ title:'첫 마음', summary:'음침해 보인다는 이유로 「사다코」라 불리는 사와코. 반의 인기남 카제하야만은 그녀를 평범하게 대해 줘요. 담력 시험에서 유령 역을 맡은 사와코는 처음으로 반 친구들과 가까워져요.' },
    2:{ title:'자리 바꾸기', summary:'자리 바꾸기에서 카제하야와 야노, 요시다가 사와코 곁에 앉아요. 그런데 사와코가 나쁜 소문을 퍼뜨렸다는 말이 돌고, 사와코는 친구들을 위해 거리를 두려 해요.' },
  },
  scenes:{
    1:[
      { s:0,    title:'벚꽃 아래의 만남', art:'flowers', chars:['sawako','kazehaya'], terms:[], sum:'입학식 날, 사와코는 벚나무 아래에서 카제하야를 만나 학교 가는 길을 알려 줬어요. 처음으로 마음이 설렌 순간이에요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'「사다코」', art:'classroom', chars:['sawako','kazehaya'], terms:['sadako'], sum:'반 친구들은 공포 영화 주인공 이름을 따 사와코를 「사다코」라 부르며 무서워해요. 카제하야만 그녀를 성으로 불러요.' },
      { s:390,  title:'담력 시험 계획', art:'classroom', chars:['kazehaya','yano','yoshida'], terms:['courage'], sum:'카제하야가 반 담력 시험을 열자고 하고, 야노와 요시다는 사와코가 귀신 역을 하면 멋지겠다고 해요.' },
      { s:540,  title:'카제하야의 친절', art:'classroom', chars:['sawako','kazehaya'], terms:[], sum:'아무도 안 하려는 꽃 돌보기 당번을 사와코가 맡고, 카제하야는 그녀의 이름이 예쁘다고 말해 줘요.' },
      { s:690,  title:'귀신 역을 하겠어요', art:'classroom', chars:['sawako','yano','yoshida'], terms:['courage'], sum:'사와코는 귀신 역을 하고 싶다고 나서요. 진짜 영능력은 없다는 말에 야노와 요시다가 웃음을 터뜨리며 가까워져요.' },
      { s:870,  title:'집에서 연습', art:'home', chars:['sawako'], terms:['courage'], sum:'집에서 귀신 연기를 연습하는 사와코를 보고 아빠는 걱정하지만, 엄마는 딸이 즐거워한다는 걸 알아봐요.' },
      { s:1020, title:'담력 시험', art:'forest', chars:['sawako','kazehaya','yano','yoshida'], terms:['courage'], sum:'귀신 분장을 한 사와코가 모두를 놀래 주고, 카제하야와 밤에 이야기를 나눠요. 야노와 요시다는 음료를 건네며 수고했다고 해요.' },
      { s:1170, title:'방학 전날', art:'classroom', chars:['sawako','kazehaya'], terms:[], sum:'남학생들이 카제하야를 사와코와 엮으며 놀리자 카제하야는 무례하다고 말해요. 사와코는 그의 평판이 걱정돼요.' },
      { s:1290, title:'첫눈에', art:'classroom', chars:['sawako','kazehaya'], terms:[], sum:'방학 첫날 학교에서 울던 사와코에게 카제하야가 반 친구들의 선물을 들고 와요. 그리고 입학식 날 첫눈에 반했다고 털어놓아요.' },
    ],
    2:[
      { s:0,    title:'자리 바꾸기', art:'classroom', chars:['sawako','kazehaya'], terms:['sadako'], sum:'제비뽑기로 자리를 바꾸는 날, 사와코 옆자리가 걸린 남학생이 무서워하자 카제하야가 자리를 바꿔 줘요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'주변 자리', art:'classroom', chars:['yano','yoshida','ryu','sawako'], terms:[], sum:'야노와 요시다도 사와코 근처에 앉고, 요시다의 소꿉친구 류가 뒷자리에 앉아요.' },
      { s:390,  title:'함께 먹는 점심', art:'classroom', chars:['sawako','yano','yoshida','kurumi'], terms:[], sum:'야노와 요시다는 사와코와 점심을 먹으며 반 이야기를 해요. 카제하야를 좋아하는 여학생도 많고, 쿠루미도 그중 하나예요.' },
      { s:540,  title:'도와주는 반 친구들', art:'classroom', chars:['sawako','kazehaya'], terms:[], sum:'반 친구들이 의자를 가져다주며 말을 걸어 주자 사와코는 기뻐서 울어요. 사와코가 공부를 잘 가르쳐 준다는 것도 알려져요.' },
      { s:720,  title:'두 개의 소문', art:'classroom', chars:['yano','yoshida'], terms:['rumor'], sum:'요시다가 중학교 때 불량했고 야노는 남자를 잘 갈아치운다는 소문이 돌아요. 그 소문을 사와코가 퍼뜨렸다는 말도 함께요.' },
      { s:870,  title:'거리 두기', art:'classroom', chars:['sawako','yano','yoshida'], terms:['rumor'], sum:'자기 때문에 둘의 평판이 나빠질까 봐, 사와코는 선생님에게 둘은 친구가 아니라고 말해 버려요. 이를 들은 두 사람은 상처받아요.' },
      { s:1020, title:'카제하야의 조언', art:'classroom', chars:['sawako','kazehaya','ryu','yoshida'], terms:['rumor'], sum:'류는 요시다에게 직접 물어보라고 하고, 카제하야는 사와코에게 피하지 말고 솔직하게 이야기하라고 해요.' },
      { s:1170, title:'화장실 앞', art:'classroom', chars:['sawako','yano','yoshida'], terms:['rumor'], sum:'소문을 퍼뜨린 여학생들 앞에서 사와코는 야노와 요시다를 좋아하니 그럴 리 없다고 말해요. 두 사람이 나서서 그들을 쫓아내요.' },
      { s:1290, title:'친구', art:'classroom', chars:['sawako','yano','yoshida','kazehaya'], terms:[], sum:'세 사람은 끌어안고 함께 울어요. 요시다는 다시는 사와코를 혼자 두지 않겠다고 해요.' },
    ],
  },
  chars:{
    sawako:{ name:'쿠로누마 사와코', short:'사와코', alias:['사와코','쿠로누마'], at:[1,0], pos:[300,230], facts:[
      [[1,0],'수줍고 순수한 고교생이에요.'],
      [[1,240],'음침해 보인다는 오해로 「사다코」라 불려요.'],
      [[2,540],'공부를 잘 가르쳐 줘요.'],
    ], easy:'오해받기 쉽지만 누구보다 착하고 성실한 소녀예요.' },
    kazehaya:{ name:'카제하야 쇼타', short:'카제하야', alias:['카제하야','쇼타'], at:[1,0], pos:[470,140], facts:[
      [[1,0],'반의 인기남이에요. 누구에게나 다정해요.'],
      [[1,240],'사와코를 평범하게 대해 주는 유일한 사람이에요.'],
      [[1,1290],'입학식 날 사와코에게 첫눈에 반했다고 털어놓아요.'],
    ] },
    yano:{ name:'야노 아야네', short:'야노', alias:['야노','아야네'], at:[1,390], pos:[130,120], facts:[
      [[1,390],'어른스러운 분위기의 반 친구예요.'],
      [[2,720],'근거 없는 소문에 휘말려요.'],
    ] },
    yoshida:{ name:'요시다 치즈루', short:'요시다', alias:['요시다','치즈루'], at:[1,390], pos:[130,340], facts:[
      [[1,390],'털털하고 의리 있는 반 친구예요.'],
      [[2,1290],'사와코를 다시는 혼자 두지 않겠다고 해요.'],
    ] },
    ryu:{ name:'사나다 류', short:'류', alias:['류','사나다'], at:[2,240], pos:[300,420], facts:[
      [[2,240],'요시다의 소꿉친구예요. 말수가 적어요.'],
    ] },
    kurumi:{ name:'쿠루미', short:'쿠루미', alias:['쿠루미'], at:[2,390], pos:[480,370], facts:[
      [[2,390],'카제하야를 좋아하는 여학생이에요.'],
    ] },
  },
  rels:[
    ['sawako','kazehaya','other','설레는 상대',[1,0]],
    ['sawako','yano','friend','친구',[1,690]],
    ['sawako','yoshida','friend','친구',[1,690]],
    ['yano','yoshida','friend','단짝',[1,390]],
    ['yoshida','ryu','friend','소꿉친구',[2,240]],
    ['kurumi','kazehaya','other','카제하야를 좋아해요',[2,390]],
  ],
  terms:{
    sadako:{ name:'사다코', alias:['사다코'], at:[1,240], facts:[[[1,240],'공포 영화 속 귀신 이름이에요. 반 친구들이 사와코를 이렇게 불러요.']] },
    courage:{ name:'담력 시험', alias:['담력 시험','귀신 역'], at:[1,390], facts:[[[1,390],'밤에 무서운 길을 걷는 반 행사예요.'],[[1,690],'사와코가 귀신 역을 맡아요.']] },
    rumor:{ name:'나쁜 소문', alias:['소문'], at:[2,720], facts:[[[2,720],'야노와 요시다에 대한 나쁜 소문이에요. 사와코가 퍼뜨렸다는 말도 돌아요.']] },
  },
  banned:['쿠루미가 소문','켄토','우메'],
};

WORKS.silentvoice.guide = {
  season:'영화', unit:'부', eps:2, startAt:[1,0], core:['notebook','sign','amends'],
  episodes:{
    1:{ title:'다시 만나러 가다', summary:'영화 앞부분이에요. 초등학생 쇼야는 청각장애가 있는 전학생 쇼코를 괴롭히다 반에서 혼자가 돼요. 몇 년 뒤 외톨이 고등학생이 된 쇼야는 쇼코를 다시 찾아가 그때 그 노트를 돌려줘요.' },
    2:{ title:'목소리의 형태', summary:'영화 뒷부분이에요. 다시 모인 옛 친구들 사이에서 과거가 터져 나오고 관계가 무너져요. 그러다 큰 사고를 겪은 뒤, 쇼야와 쇼코는 다리 위에서 마음을 털어놓아요.' },
  },
  scenes:{
    1:[
      { s:0,    title:'전학생', art:'classroom', chars:['shoya','shoko'], terms:['notebook'], sum:'초등학생 쇼야의 반에 청각장애가 있는 전학생 쇼코가 와요. 쇼코는 필담 노트로 친구들과 이야기하려 해요.' },
      { s:150,  title:'괴롭힘', art:'classroom', chars:['shoya','shoko','ueno'], terms:['notebook'], sum:'쇼야와 몇몇 친구들은 쇼코를 놀리고 괴롭혀요.' },
      { s:300,  title:'혼자 남은 쇼야', art:'classroom', chars:['shoya'], terms:[], sum:'괴롭힘이 문제가 되자 친구들은 모든 잘못을 쇼야에게 돌리고, 이번엔 쇼야가 따돌림을 당해요.' },
      { s:450,  title:'전학', art:'classroom', chars:['shoya','shoko'], terms:['notebook'], sum:'쇼코와 크게 다툰 뒤 쇼코는 전학을 가고, 쇼야는 그녀의 노트를 간직해요.' },
      { s:600,  title:'외톨이 고등학생', art:'city', chars:['shoya'], terms:['amends'], sum:'고등학생이 된 쇼야는 아무와도 눈을 마주치지 못해요. 삶을 정리하려 마음먹은 그는, 그 전에 상처 준 사람들에게 사과하기로 해요.' },
      { s:750,  title:'수화 센터', art:'office', chars:['shoya','shoko'], terms:['sign','notebook'], sum:'쇼야는 배운 수화로 쇼코에게 다가가 노트를 돌려줘요.' },
      { s:900,  title:'첫 친구', art:'street', chars:['shoya','tomohiro'], terms:[], sum:'쇼야에게 도움을 받은 적 있는 외톨이 나가츠카가 쇼야의 친구가 돼요.' },
      { s:1020, title:'잉어 먹이', art:'boat', chars:['shoya','shoko','yuzuru'], terms:[], sum:'다리 위에서 쇼코와 잉어에게 먹이를 주는 쇼야를, 쇼코의 동생 유즈루가 경계해요.' },
      { s:1140, title:'강물 속 노트', art:'boat', chars:['shoya','yuzuru'], terms:['notebook'], sum:'쇼야가 강에 떨어진 노트를 건지러 뛰어들자, 유즈루는 사진을 찍어 인터넷에 올려 쇼야를 곤란하게 해요.' },
      { s:1260, title:'유즈루와의 화해', art:'home', chars:['shoya','yuzuru'], terms:[], sum:'집을 나온 유즈루를 쇼야가 재워 주고, 두 사람은 화해해요.' },
      { s:1350, title:'옛 친구', art:'classroom', chars:['shoya','shoko','miyoko'], terms:['amends'], sum:'쇼야는 쇼코에게 친절했던 옛 반 친구 사하라를 찾아 두 사람을 다시 이어 줘요.' },
    ],
    2:[
      { s:0,    title:'다시 나타난 얼굴들', art:'classroom', chars:['shoya','ueno','kawai'], terms:[], sum:'함께 쇼코를 괴롭혔던 우에노, 그리고 같은 학교에 다니는 옛 반장 카와이가 다시 쇼야의 삶에 나타나요.' },
      { s:150,  title:'달? 좋아해?', art:'street', chars:['shoko','shoya'], terms:['sign'], sum:'쇼코는 선물을 건네며 목소리로 마음을 고백하지만, 쇼야는 다른 말로 잘못 알아듣고 쇼코는 속상해 달려가요.' },
      { s:330,  title:'놀이공원', art:'party', chars:['shoya','shoko','tomohiro','miyoko','kawai','ueno'], terms:[], sum:'쇼야는 친구들을 모아 놀이공원에 가고, 우에노도 따라와요.' },
      { s:480,  title:'우에노와 쇼코', art:'party', chars:['ueno','shoko'], terms:[], sum:'우에노는 쇼야의 불행이 쇼코 때문이라며 쇼코를 몰아붙여요.' },
      { s:630,  title:'무너진 관계', art:'classroom', chars:['shoya','kawai','tomohiro'], terms:[], sum:'카와이가 자기는 잘못 없다며 쇼야의 과거를 모두에게 폭로하고, 쇼야는 화를 내며 친구들과 연을 끊어 버려요.' },
      { s:780,  title:'할머니의 죽음', art:'grave', chars:['shoko','yuzuru','shoya'], terms:[], sum:'쇼코 자매의 할머니가 세상을 떠나고, 쇼야는 자매를 위로하려 시골 여행에 데려가요.' },
      { s:930,  title:'불꽃놀이', art:'night', chars:['shoya','shoko'], terms:[], sum:'불꽃놀이 날 숙제가 있다며 먼저 집에 간 쇼코를 따라간 쇼야는, 위험한 순간의 쇼코를 붙잡아 끌어올리다 강으로 떨어져요.' },
      { s:1080, title:'의식 불명', art:'darkroom', chars:['shoya','shoko'], terms:[], sum:'친구들이 쇼야를 구하지만 쇼야는 깨어나지 못해요. 쇼코는 친구들에게 다시 다가가려 애써요.' },
      { s:1200, title:'다리 위에서', art:'boat', chars:['shoya','shoko'], terms:['sign','amends'], sum:'깨어난 쇼야는 다리에서 울고 있는 쇼코를 만나 사과하고, 앞으로 살아가는 걸 도와 달라고 해요. 쇼코는 고개를 끄덕여요.' },
      { s:1320, title:'학교 축제', art:'party', chars:['shoya','tomohiro','miyoko','shoko'], terms:['amends'], sum:'학교 축제에서 친구들과 다시 마주한 쇼야는, 사람들의 얼굴과 목소리를 똑바로 마주하며 눈물을 흘려요.' },
    ],
  },
  chars:{
    shoya:{ name:'이시다 쇼야', short:'쇼야', alias:['쇼야','이시다'], at:[1,0], pos:[300,230], facts:[
      [[1,0],'초등학생 시절 전학생 쇼코를 괴롭혔어요.'],
      [[1,300],'친구들에게 모든 책임을 떠안고 따돌림을 당해요.'],
      [[1,600],'고등학생이 되어 쇼코에게 사과하러 가요.'],
      [[2,1200],'살아가겠다고 마음을 바꿔요.'],
    ], easy:'가해자였다가 외톨이가 된 소년이 용서를 배우는 이야기예요.' },
    shoko:{ name:'니시미야 쇼코', short:'쇼코', alias:['쇼코','니시미야'], at:[1,0], pos:[470,140], facts:[
      [[1,0],'청각장애가 있는 전학생이에요. 필담 노트로 이야기해요.'],
      [[1,750],'쇼야를 다시 만나요.'],
      [[2,150],'쇼야에게 마음을 고백해요.'],
    ], easy:'늘 웃지만 마음속 상처를 혼자 끌어안는 소녀예요.' },
    ueno:{ name:'우에노 나오카', short:'우에노', alias:['우에노','나오카'], at:[1,150], pos:[130,110], facts:[
      [[1,150],'초등학생 때 쇼야와 함께 쇼코를 괴롭혔어요.'],
      [[2,480],'쇼코를 몰아붙여요.'],
    ] },
    tomohiro:{ name:'나가츠카 토모히로', short:'나가츠카', alias:['나가츠카','토모히로'], at:[1,900], pos:[130,340], facts:[
      [[1,900],'쇼야의 고등학교 친구예요. 예전에 쇼야에게 도움을 받았어요.'],
    ] },
    yuzuru:{ name:'니시미야 유즈루', short:'유즈루', alias:['유즈루'], at:[1,1020], pos:[540,250], facts:[
      [[1,1020],'쇼코의 동생이에요. 쇼야를 경계해요.'],
      [[1,1260],'쇼야와 화해해요.'],
    ] },
    miyoko:{ name:'사하라 미요코', short:'사하라', alias:['사하라','미요코'], at:[1,1350], pos:[300,410], facts:[
      [[1,1350],'초등학생 때 쇼코에게 친절했던 반 친구예요.'],
    ] },
    kawai:{ name:'카와이 미키', short:'카와이', alias:['카와이','미키'], at:[2,0], pos:[470,370], facts:[
      [[2,0],'초등학교 때 반장이었어요. 지금은 쇼야와 같은 고등학교에 다녀요.'],
      [[2,630],'쇼야의 과거를 모두에게 폭로해요.'],
    ] },
  },
  rels:[
    ['shoya','shoko','other','가해자였다가 다시 마주한 사이',[1,750]],
    ['shoya','ueno','peer','초등학교 동창',[1,150]],
    ['shoya','tomohiro','friend','고등학교 친구',[1,900]],
    ['shoko','yuzuru','family','자매',[1,1020]],
    ['shoko','miyoko','friend','다시 이어진 친구',[1,1350]],
    ['shoya','kawai','peer','초등학교 동창',[2,0]],
  ],
  terms:{
    notebook:{ name:'필담 노트', alias:['노트','필담'], at:[1,0], facts:[[[1,0],'쇼코가 친구들과 글로 이야기하려고 가지고 다니던 노트예요.'],[[1,450],'쇼야가 간직하고 있었어요.']] },
    amends:{ name:'사과', alias:['사과','속죄'], at:[1,600], facts:[[[1,600],'쇼야가 상처 준 사람들에게 하려는 일이에요.']], easy:'늦었지만 잘못을 마주하려는 마음이에요.' },
    sign:{ name:'수화', alias:['수화'], at:[1,750], facts:[[[1,750],'쇼야가 쇼코와 이야기하려고 배운 말이에요.']] },
  },
  banned:['마시바','타케우치'],
};

WORKS.firefly.guide = {
  season:'1기', eps:2, startAt:[1,0], core:['meiji','assassin','proposal'],
  episodes:{
    1:{ title:'첫 화', summary:'메이지 시대, 몸이 약한 명문가 아가씨 사토코는 납치되어 죽을 위기에 놓여요. 자신을 죽이러 온 암살자 신페이에게 사토코는 살기 위해 청혼을 해요.' },
    2:{ title:'두 번째 화', summary:'청혼을 진심으로 받아들인 신페이는 사토코에게 집착하기 시작해요. 사토코는 그의 마음을 이용해 자신을 노리는 적들에 맞서기로 해요.' },
  },
  scenes:{
    1:[
      { s:0,    title:'메이지 시대의 아가씨', art:'home', chars:['satoko'], terms:['meiji'], sum:'메이지 시대, 부유한 명문가의 딸 사토코는 심장이 약해 거의 집 안에서만 지내요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'아버지의 바람', art:'home', chars:['satoko','jubei'], terms:['marriage'], sum:'아버지 쥬베는 딸을 아끼며, 결혼을 해야 수명을 늘릴 치료도 받을 수 있다고 생각해요. 사토코는 아버지에게 보답하려면 결혼해야 한다고 느껴요.' },
      { s:420,  title:'날 선 동생', art:'home', chars:['satoko','miwako'], terms:[], sum:'이복동생 미와코는 아버지의 사랑을 독차지하는 사토코를 미워해요. 두 사람 사이에 날 선 대화가 오가요.' },
      { s:600,  title:'외출', art:'town', chars:['satoko','kotaro'], terms:[], sum:'사토코는 호위 코타로와 함께 외출해요.' },
      { s:750,  title:'납치', art:'darkroom', chars:['satoko'], terms:['assassin'], sum:'사토코는 그녀를 죽이라는 의뢰를 받은 무리에게 납치돼요. 밝던 분위기가 한순간에 어두워져요.' },
      { s:930,  title:'암살자 신페이', art:'darkroom', chars:['satoko','shinpei'], terms:['assassin'], sum:'사토코를 죽이러 온 암살자 신페이가 나타나요. 다른 사람이 그녀에게 손대는 건 막으면서도 목숨을 노려요.' },
      { s:1110, title:'청혼', art:'darkroom', chars:['satoko','shinpei'], terms:['proposal'], sum:'살아남기 위해 사토코는 신페이에게 반했다며 결혼하자고 해요. 신페이는 처음엔 속셈이라고 의심해요.' },
      { s:1260, title:'피를 닦아 주고', art:'night', chars:['satoko','shinpei'], terms:['proposal'], sum:'사토코가 그의 입가의 피를 닦아 주고 입을 맞추자, 신페이의 태도가 완전히 바뀌어요. 그는 사토코에게 깊이 빠져들어요.' },
    ],
    2:[
      { s:0,    title:'약혼자가 된 암살자', art:'home', chars:['satoko','shinpei'], terms:['proposal'], sum:'신페이는 정말 결혼할 거라 믿고 사토코를 살려 뒀어요. 사토코는 그와 함께 지내게 돼요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'신페이의 꿈', art:'home', chars:['shinpei','satoko'], terms:[], sum:'신페이는 매일 사토코의 머리를 감겨 주는 미래를 꿈꿔요. 자신은 지옥에 갈 테니 따라와 달라고도 해요.' },
      { s:450,  title:'당신이 청혼했잖아', art:'home', chars:['shinpei','satoko'], terms:['proposal'], sum:'사토코가 망설이면, 신페이는 먼저 청혼한 건 그녀라며 선택을 몰아붙여요.' },
      { s:660,  title:'노리는 자들', art:'town', chars:['satoko'], terms:['assassin'], sum:'사토코를 노리는 적들은 아직 남아 있어요. 그녀 혼자서는 자신을 지킬 수 없어요.' },
      { s:870,  title:'사토코의 선택', art:'town', chars:['satoko','shinpei'], terms:['assassin'], sum:'사토코는 목숨까지 걸 만큼 자신에게 빠진 신페이의 마음을 이용해 적들에게 맞서기로 해요.' },
      { s:1080, title:'군중 앞의 춤', art:'party', chars:['satoko'], terms:[], sum:'사토코는 많은 사람 앞에서 춤을 추며 사람들의 시선을 끌어요. 신페이의 마음은 불안하게 흔들려요.' },
      { s:1260, title:'다음 수', art:'night', chars:['satoko','shinpei'], terms:[], sum:'사토코는 더 어려운 일에 나설 준비를 해요.' },
    ],
  },
  chars:{
    satoko:{ name:'키리가야 사토코', short:'사토코', alias:['사토코','키리가야'], at:[1,0], pos:[300,230], facts:[
      [[1,0],'메이지 시대 명문가의 딸이에요. 심장이 약해요.'],
      [[1,1110],'살아남기 위해 암살자에게 청혼해요.'],
      [[2,870],'신페이의 마음을 이용해 적에게 맞서기로 해요.'],
    ], easy:'몸은 약하지만 머리와 배짱은 누구보다 센 아가씨예요.' },
    jubei:{ name:'키리가야 쥬베', short:'쥬베', alias:['쥬베','아버지'], at:[1,240], pos:[120,110], facts:[
      [[1,240],'사토코의 아버지예요. 딸이 결혼해 치료를 받길 바라요.'],
    ] },
    miwako:{ name:'미와코', short:'미와코', alias:['미와코'], at:[1,420], pos:[130,350], facts:[
      [[1,420],'사토코의 이복동생이에요. 사토코를 미워해요.'],
    ] },
    kotaro:{ name:'오가와 코타로', short:'코타로', alias:['코타로'], at:[1,600], pos:[470,380], facts:[
      [[1,600],'사토코의 호위예요.'],
    ] },
    shinpei:{ name:'고토 신페이', short:'신페이', alias:['신페이','고토'], at:[1,930], pos:[480,140], facts:[
      [[1,930],'사토코를 죽이러 온 실력 있는 암살자예요.'],
      [[1,1260],'사토코에게 깊이 빠져들어요.'],
      [[2,0],'사토코의 약혼자가 됐다고 믿어요.'],
    ], easy:'사랑에 빠진 순간부터 가장 위험한 아군이 된 암살자예요.' },
  },
  rels:[
    ['satoko','jubei','family','딸과 아버지',[1,240]],
    ['satoko','miwako','family','이복 자매',[1,420]],
    ['satoko','kotaro','other','아가씨와 호위',[1,600]],
    ['satoko','shinpei','other','목숨을 건 약혼',[1,1110]],
  ],
  terms:{
    meiji:{ name:'메이지 시대', alias:['메이지'], at:[1,0], facts:[[[1,0],'일본이 근대화되던 19세기 후반의 시대예요.']] },
    marriage:{ name:'결혼', alias:['결혼','혼담'], at:[1,240], facts:[[[1,240],'사토코는 아버지에게 보답하려면 결혼해야 한다고 느껴요.']] },
    assassin:{ name:'암살 의뢰', alias:['암살','암살자','의뢰'], at:[1,750], facts:[[[1,750],'누군가가 사토코를 죽여 달라고 의뢰했어요.']] },
    proposal:{ name:'목숨을 건 청혼', alias:['청혼','약혼'], at:[1,1110], facts:[[[1,1110],'사토코가 살아남으려고 신페이에게 한 청혼이에요.'],[[1,1260],'신페이는 이를 진심으로 받아들여요.']], easy:'살려고 한 거짓말이 진짜 약속이 되어 버린 거예요.' },
  },
  banned:[],
};

WORKS.blueperiod.guide = {
  season:'1기', eps:2, startAt:[1,0], core:['painting','geidai','artclub'],
  episodes:{
    1:{ title:'그림 그리는 즐거움에 눈뜨다', summary:'공부도 잘하고 친구도 많지만 늘 공허했던 고교생 야토라. 미술실에서 본 선배 모리의 그림, 그리고 처음으로 직접 그린 「파란 시부야」가 그의 마음을 움직여요. 야토라는 미대 입시에 도전하기로 해요.' },
    2:{ title:'두 번째 화', summary:'미술부에 들어간 야토라는 방학 동안 데생 30장을 그려 와요. 미대 진학을 걱정하는 어머니를 설득하기 위해 야토라는 자기 그림으로 진심을 전해요.' },
  },
  scenes:{
    1:[
      { s:0,    title:'뭐든 잘하는 소년', art:'city', chars:['yatora','friends'], terms:[], sum:'고교 2학년 야토라는 성적도 좋고 친구도 많지만, 밤새 친구들과 놀아도 어딘가 공허해요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'미술실의 그림', art:'classroom', chars:['yatora','mori'], terms:['painting'], sum:'미술실에 두고 온 물건을 찾으러 간 야토라는 선배 모리의 그림을 보고 마음이 크게 흔들려요.' },
      { s:420,  title:'미술부 유카', art:'classroom', chars:['yatora','yuka'], terms:['artclub'], sum:'미술부원 유카와 처음 부딪치지만, 두 사람은 조금씩 가까워져요.' },
      { s:600,  title:'미술 선생님', art:'classroom', chars:['yatora','saeki'], terms:['painting'], sum:'미술 선생님 사에키는 야토라의 관심을 알아보고 그림 이야기를 들려줘요.' },
      { s:780,  title:'파란 시부야', art:'city', chars:['yatora','friends'], terms:['painting'], sum:'야토라는 새벽의 시부야가 파랗게 보였던 느낌을 그림으로 그려요. 처음으로 친구들과 진짜 이어진 기분이 들어요.' },
      { s:960,  title:'현실의 벽', art:'home', chars:['yatora'], terms:['geidai'], sum:'집안 사정상 사립은 어렵고, 국립인 도쿄예술대학 회화과는 일본에서 가장 들어가기 어려운 곳이에요. 그림으로 먹고살 수 있을지도 불안해요.' },
      { s:1110, title:'모리의 말', art:'classroom', chars:['yatora','mori'], terms:['painting'], sum:'모리는 재능보다 경험과 앎이 중요하다고 말해 줘요.' },
      { s:1260, title:'결심', art:'classroom', chars:['yatora','saeki'], terms:['geidai'], sum:'야토라가 미대에 가겠다고 하자, 사에키는 험한 길이지만 좋아하는 일에 노력하는 사람은 강하다고 응원해요.' },
    ],
    2:[
      { s:0,    title:'미술부 입부', art:'classroom', chars:['yatora','saeki'], terms:['artclub'], sum:'야토라는 미술부에 들어가 기초부터 배우기 시작해요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'데생 30장', art:'home', chars:['yatora'], terms:['sketch'], sum:'다른 부원들이 과제 양에 투덜대는 동안, 야토라는 방학 동안 데생을 30장이나 그려 와요.' },
      { s:420,  title:'연필 요령', art:'classroom', chars:['yatora','saeki'], terms:['sketch'], sum:'사에키는 연필 쓰는 요령을 알려 주며 야토라를 이끌어요. 칭찬을 들어도 야토라는 아직 부족하다고만 생각해요.' },
      { s:600,  title:'선배의 조언', art:'classroom', chars:['yatora','mori','yuka'], terms:['artclub'], sum:'모리 선배는 야토라의 그림을 다정하게 고쳐 주고, 유카도 미술부에서 자주 마주쳐요.' },
      { s:780,  title:'어머니의 걱정', art:'home', chars:['yatora','mother'], terms:['geidai'], sum:'어머니는 무엇 하나 오래 해 본 적 없고 형편도 넉넉하지 않은데 미대라니 걱정이 커요.' },
      { s:960,  title:'그림으로 전하는 말', art:'home', chars:['yatora','mother'], terms:['painting'], sum:'야토라는 어머니를 그린 그림을 건네며, 그림을 그리면서 세상이 다르게 보이기 시작했다고 말해요.' },
      { s:1140, title:'어머니의 마음', art:'home', chars:['mother','yatora'], terms:['geidai'], sum:'어머니는 아들이 얼마나 진지한지 조금씩 알게 되고, 마음을 열어요.' },
      { s:1290, title:'다음 걸음', art:'city', chars:['yatora','yuka'], terms:['geidai'], sum:'야토라는 미대 입시를 향해 다음 걸음을 내디뎌요.' },
    ],
  },
  chars:{
    yatora:{ name:'야구치 야토라', short:'야토라', alias:['야토라','야구치'], at:[1,0], pos:[300,230], facts:[
      [[1,0],'성적도 좋고 친구도 많은 고교 2학년이에요. 그런데 늘 공허해요.'],
      [[1,780],'처음으로 그림을 그리며 즐거움을 느껴요.'],
      [[1,1260],'도쿄예술대학을 목표로 해요.'],
      [[2,240],'방학 동안 데생 30장을 그려요.'],
    ], easy:'요령은 좋지만 처음으로 「진심」을 찾은 소년이에요.' },
    friends:{ name:'야토라의 친구들', short:'친구들', alias:['친구들'], at:[1,0], pos:[110,380], facts:[
      [[1,0],'야토라와 함께 노는 친구들이에요. 야토라를 천재라고 생각해요.'],
    ] },
    mori:{ name:'모리 마루', short:'모리', alias:['모리','모리 선배'], at:[1,240], pos:[470,130], facts:[
      [[1,240],'미술부 3학년 선배예요. 그녀의 그림이 야토라를 흔들어요.'],
      [[1,1110],'경험과 앎이 재능만큼 중요하다고 말해요.'],
    ] },
    yuka:{ name:'아유카와 류지', short:'유카', alias:['유카','류지','아유카와'], at:[1,420], pos:[140,120], facts:[
      [[1,420],'야토라와 같은 학년의 미술부원이에요. 「유카」라고 불러 주길 원해요.'],
    ] },
    saeki:{ name:'사에키 선생님', short:'사에키', alias:['사에키','선생님'], at:[1,600], pos:[480,340], facts:[
      [[1,600],'미술 선생님이에요. 야토라를 응원해요.'],
    ] },
    mother:{ name:'야토라의 어머니', short:'어머니', alias:['어머니','엄마'], at:[2,780], pos:[300,410], facts:[
      [[2,780],'야토라의 미대 진학을 걱정해요.'],
      [[2,1140],'아들의 진심을 알아 가요.'],
    ] },
  },
  rels:[
    ['yatora','friends','friend','함께 노는 친구들',[1,0]],
    ['yatora','mori','other','마음을 흔든 선배',[1,240]],
    ['yatora','yuka','peer','미술부 동기',[1,420]],
    ['saeki','yatora','other','선생님과 제자',[1,600]],
    ['yatora','mother','family','아들과 어머니',[2,780]],
  ],
  terms:{
    painting:{ name:'그림', alias:['그림','파란 시부야'], at:[1,240], facts:[[[1,240],'모리의 그림이 야토라를 처음 움직였어요.'],[[1,780],'야토라는 파랗게 보였던 새벽 시부야를 그렸어요.']], easy:'말로는 못 하던 마음을 꺼내는 언어예요.' },
    artclub:{ name:'미술부', alias:['미술부'], at:[1,420], facts:[[[1,420],'유카와 모리가 있는 동아리예요.'],[[2,0],'야토라가 들어가요.']] },
    geidai:{ name:'도쿄예술대학', alias:['예대','미대','도쿄예대'], at:[1,960], facts:[[[1,960],'국립 미술대학이에요. 회화과는 일본에서 가장 들어가기 어려운 곳 중 하나예요.']] },
    sketch:{ name:'데생', alias:['데생','스케치'], at:[2,240], facts:[[[2,240],'연필로 대상을 관찰해 그리는 기초 연습이에요.']] },
  },
  banned:['타카하시 세카이','하시다','오바 마키'],
};

WORKS.boss.guide = {
  season:'1기', eps:2, startAt:[1,0], core:['newjob','boss','proposal'],
  episodes:{
    1:{ title:'첫 화', summary:'이전 회사 상사에게 시달리다 이직한 모모세는 새 상사가 무서울까 봐 잔뜩 긴장해요. 그런데 새 상사 시로사키는 허당이지만 다정하고 유능한 사람이에요.' },
    2:{ title:'업어 줄까요?', summary:'모모세와 시로사키는 광고 준비를 위해 새로 단장한 놀이공원을 직접 체험해요. 돌아오는 길, 멈춰 선 깜깜한 전철 안에서 모모세는 이직을 결심한 날을 이야기해요.' },
  },
  scenes:{
    1:[
      { s:0,    title:'새 직장, 새 상사', art:'office', chars:['momose'], terms:['newjob'], sum:'이직한 모모세는 새 상사도 무리한 요구를 할까 봐 불안해해요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'시로사키 과장', art:'office', chars:['momose','shirosaki'], terms:['boss'], sum:'동료들의 환영을 받은 뒤 새 상사 시로사키가 도착해요. 모모세는 겁을 먹어요.' },
      { s:420,  title:'배탈', art:'office', chars:['momose','shirosaki'], terms:[], sum:'긴장한 모모세가 배가 아프자, 시로사키는 직접 약을 사다 줘요. 알고 보니 엉뚱한 약이라 모모세는 웃음이 터져요.' },
      { s:600,  title:'허당이지만 유능한', art:'office', chars:['shirosaki','momose'], terms:['boss'], sum:'시로사키는 덜렁대 보여도 일은 잘해요. 모모세가 전 상사에게 시달렸다는 걸 눈치채지만, 모모세는 아니라고 둘러대요.' },
      { s:780,  title:'한잔', art:'night', chars:['shirosaki','momose'], terms:[], sum:'그날 저녁, 모모세가 긴장한 걸 본 시로사키가 한잔하러 가자고 하고, 모모세는 그 배려에 감동해요.' },
      { s:960,  title:'한 번도 통과 못 한 기획', art:'office', chars:['shirosaki','momose'], terms:['proposal'], sum:'시로사키는 모모세가 낸 기획안이 한 번도 통과된 적 없다는 말을 우연히 듣게 돼요.' },
      { s:1110, title:'기획안 부탁', art:'office', chars:['shirosaki','momose'], terms:['proposal'], sum:'며칠 뒤 시로사키는 모모세에게 기획안을 맡기고, 끝까지 자신감을 북돋아 줘요.' },
      { s:1260, title:'통과', art:'office', chars:['momose','shirosaki'], terms:['proposal'], sum:'모모세의 기획안이 통과되고, 모모세는 뛸 듯이 기뻐해요.' },
    ],
    2:[
      { s:0,    title:'놀이공원 광고', art:'office', chars:['shirosaki','momose'], terms:['proposal'], sum:'새로 단장한 놀이공원 광고를 맡게 되자, 시로사키는 직접 즐겨 봐야 좋은 광고가 나온다고 해요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'회전목마', art:'party', chars:['shirosaki','momose'], terms:[], sum:'두 사람은 회전목마를 타며 놀이공원을 둘러봐요.' },
      { s:450,  title:'롤러코스터', art:'party', chars:['shirosaki','momose'], terms:[], sum:'롤러코스터까지 타며 조사는 순조롭게 진행돼요.' },
      { s:690,  title:'즐거운 하루', art:'party', chars:['momose','shirosaki'], terms:['boss'], sum:'모모세는 일하면서도 즐거울 수 있다는 걸 느껴요.' },
      { s:900,  title:'멈춘 전철', art:'night', chars:['momose','shirosaki'], terms:[], sum:'돌아오는 전철이 정전으로 멈추고, 칸 안이 칠흑처럼 깜깜해져요.' },
      { s:1080, title:'어둠 속 이야기', art:'night', chars:['momose','shirosaki'], terms:['newjob'], sum:'어둠 속에서 모모세는 이직을 결심했던 날의 이야기를 시로사키에게 털어놓아요.' },
      { s:1260, title:'다정한 상사', art:'night', chars:['shirosaki','momose'], terms:['boss'], sum:'시로사키는 모모세의 이야기를 묵묵히 들어 줘요.' },
    ],
  },
  chars:{
    momose:{ name:'모모세 켄타로', short:'모모세', alias:['모모세','켄타로'], at:[1,0], pos:[300,230], facts:[
      [[1,0],'이직한 26살 회사원이에요. 소심하고 쉽게 긴장해요.'],
      [[1,600],'전 직장 상사에게 시달렸어요.'],
      [[1,1260],'처음으로 기획안이 통과돼요.'],
    ], easy:'상처받은 마음을 조심조심 회복해 가는 신입 사원이에요.' },
    shirosaki:{ name:'시로사키 유세이', short:'시로사키', alias:['시로사키','과장'], at:[1,240], pos:[470,140], facts:[
      [[1,240],'모모세의 새 상사예요.'],
      [[1,600],'덜렁대 보여도 일은 잘하고 부하를 잘 챙겨요.'],
    ], easy:'허당인데 미워할 수 없는, 다정한 상사예요.' },
  },
  rels:[
    ['shirosaki','momose','peer','상사와 부하',[1,240]],
  ],
  terms:{
    newjob:{ name:'이직', alias:['이직','전 직장'], at:[1,0], facts:[[[1,0],'모모세는 힘든 직장을 떠나 새 회사로 옮겼어요.']] },
    boss:{ name:'새 상사', alias:['상사','과장님'], at:[1,240], facts:[[[1,240],'모모세의 새 상사 시로사키예요.']] },
    proposal:{ name:'기획안', alias:['기획','기획안','광고'], at:[1,960], facts:[[[1,960],'모모세의 기획안은 예전 회사에서 한 번도 통과된 적이 없어요.'],[[1,1260],'시로사키의 도움으로 처음 통과돼요.']] },
  },
  banned:[],
};

WORKS.signal.guide = {
  season:'1기', eps:2, startAt:[1,0], core:['deaf','sign','world'],
  episodes:{
    1:{ title:'유키의 세계', summary:'청각장애가 있는 대학생 유키는 전철에서 곤란할 때 도와준 선배 이츠오미에게 마음이 끌려요. 다시 만난 이츠오미는 유키의 세계를 보고 싶다고 말해요.' },
    2:{ title:'좋아하는 마음으로', summary:'이츠오미와 자주 마주치며 유키의 마음은 커져 가요. 이것이 동경인지 사랑인지 고민하던 유키는, 결국 사랑이라고 마음을 정해요.' },
  },
  scenes:{
    1:[
      { s:0,    title:'소리 없는 세계', art:'city', chars:['yuki'], terms:['deaf'], sum:'19살 대학생 유키는 소리가 들리지 않는 세계에 살아요. 사람들의 입 모양을 읽어 대화를 따라가요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'전철의 외국인', art:'city', chars:['yuki'], terms:['deaf'], sum:'집에 가는 전철에서 외국인 관광객이 길을 묻지만, 유키는 자기 사정을 설명하기 어려워 곤란해해요.' },
      { s:390,  title:'키 큰 선배', art:'city', chars:['yuki','itsuomi'], terms:['lipread'], sum:'같은 대학의 키 큰 학생이 나서서 관광객을 돕고, 유키가 입 모양을 읽을 수 있게 천천히 말해 준 뒤 머리를 툭 쓰다듬고 내려요.' },
      { s:570,  title:'친구 린', art:'classroom', chars:['yuki','rin'], terms:[], sum:'유키는 친구 린에게 그 사람 이야기를 해요. 린은 그가 이츠오미이고, 사촌과 함께 작은 바에서 일한다고 알려 줘요.' },
      { s:720,  title:'바에서', art:'party', chars:['yuki','rin','itsuomi','oushi'], terms:['world'], sum:'두 사람은 바에 찾아가요. 이츠오미는 일본어, 영어, 독일어를 하는 여행가예요. 린은 이츠오미의 사촌 오우시의 연락처를 받아요.' },
      { s:900,  title:'소외감', art:'party', chars:['yuki','rin','oushi'], terms:['deaf'], sum:'린이 유키의 장애를 대신 설명하는 순간, 유키는 소외감을 느껴요. 이츠오미에게 연락처를 물을 용기도 나지 않아요.' },
      { s:1050, title:'함께 걷는 밤길', art:'night', chars:['yuki','itsuomi'], terms:['sign'], sum:'이츠오미가 유키를 집까지 바래다줘요. 오토바이가 지나가자 그는 유키를 끌어당겨 손을 잡아요. 용기를 낸 유키가 연락처를 묻고, 이츠오미는 「응」이라는 수화를 알려 달라고 해요.' },
      { s:1230, title:'넓은 세상', art:'home', chars:['yuki','itsuomi'], terms:['world'], sum:'문자로 세상이 넓다고 생각하냐는 유키의 물음에, 이츠오미는 넓다고 답하며 유키의 세계를 보고 싶다고 해요.' },
    ],
    2:[
      { s:0,    title:'좋아하는 걸까', art:'home', chars:['yuki'], terms:[], sum:'유키는 이츠오미를 향한 마음이 사랑인지 동경인지 헷갈려요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'자꾸 마주치는 선배', art:'classroom', chars:['yuki','itsuomi'], terms:['sign'], sum:'이츠오미와 자주 마주치고, 그는 「좋은 아침」 같은 수화를 하나씩 배워 와요.' },
      { s:420,  title:'머리 쓰다듬기', art:'classroom', chars:['yuki','itsuomi'], terms:[], sum:'이츠오미는 유키를 귀엽다고 하고, 머리를 쓰다듬는 인사를 해요. 유키의 마음은 커져 가요.' },
      { s:600,  title:'소꿉친구 오우시', art:'street', chars:['yuki','oushi'], terms:['sign'], sum:'유키의 소꿉친구 오우시는 퉁명스럽게 굴고, 두 사람은 날 선 수화로 대화를 나눠요.' },
      { s:780,  title:'린의 조언', art:'classroom', chars:['yuki','rin'], terms:[], sum:'린은 사랑인지 동경인지 모르겠다면 스스로 하나를 골라 정해 버리라고 조언해요.' },
      { s:960,  title:'유키의 학창 시절', art:'classroom', chars:['yuki'], terms:['deaf'], sum:'유키는 유치원부터 고등학교까지 반 친구가 서너 명뿐인 작은 청각장애 학교에서 자랐어요. 더 넓은 세상을 원해 대학에 왔어요.' },
      { s:1140, title:'정했어', art:'home', chars:['yuki','itsuomi'], terms:['world'], sum:'유키는 이츠오미를 좋아한다고, 사랑이라고 마음을 정해요.' },
    ],
  },
  chars:{
    yuki:{ name:'이토세 유키', short:'유키', alias:['유키','이토세'], at:[1,0], pos:[300,230], facts:[
      [[1,0],'청각장애가 있는 19살 대학생이에요. 입 모양을 읽어 대화해요.'],
      [[2,960],'작은 청각장애 학교에서 자라, 더 넓은 세상을 원해 대학에 왔어요.'],
      [[2,1140],'이츠오미를 좋아한다고 마음을 정해요.'],
    ], easy:'조용하지만 마음속엔 반짝이는 세계를 가진 소녀예요.' },
    itsuomi:{ name:'나기 이츠오미', short:'이츠오미', alias:['이츠오미','나기'], at:[1,390], pos:[470,140], facts:[
      [[1,390],'같은 대학의 키 큰 선배예요.'],
      [[1,720],'여러 나라 말을 하는 여행가예요.'],
      [[1,1230],'유키의 세계를 보고 싶다고 해요.'],
      [[2,240],'수화를 하나씩 배워요.'],
    ] },
    rin:{ name:'린', short:'린', alias:['린'], at:[1,570], pos:[130,120], facts:[
      [[1,570],'유키의 밝은 친구예요.'],
      [[1,720],'오우시를 좋아해요.'],
    ] },
    oushi:{ name:'오우시', short:'오우시', alias:['오우시'], at:[1,720], pos:[480,360], facts:[
      [[1,720],'이츠오미의 사촌이에요. 함께 바에서 일해요.'],
      [[2,600],'유키의 소꿉친구예요. 유키를 지나치게 걱정해요.'],
    ] },
  },
  rels:[
    ['yuki','itsuomi','other','유키가 좋아하는 선배',[1,1050]],
    ['yuki','rin','friend','친구',[1,570]],
    ['rin','oushi','other','린이 좋아하는 사람',[1,720]],
    ['yuki','oushi','friend','소꿉친구',[2,600]],
    ['itsuomi','oushi','family','사촌',[1,720]],
  ],
  terms:{
    deaf:{ name:'청각장애', alias:['청각장애','소리'], at:[1,0], facts:[[[1,0],'유키는 소리를 듣지 못해요.']] },
    lipread:{ name:'입 모양 읽기', alias:['입 모양','독순'], at:[1,390], facts:[[[1,390],'유키는 상대의 입 모양을 읽어 말을 이해해요. 천천히 말하면 더 잘 읽을 수 있어요.']] },
    world:{ name:'유키의 세계', alias:['세계','넓은 세상'], at:[1,720], facts:[[[1,720],'이츠오미는 여러 나라를 다니는 여행가예요.'],[[1,1230],'이츠오미는 유키의 세계를 보고 싶어 해요.']] },
    sign:{ name:'수화', alias:['수화'], at:[1,1050], facts:[[[1,1050],'손으로 하는 말이에요. 이츠오미가 배우기 시작해요.']], easy:'눈으로 듣고 손으로 말하는 언어예요.' },
  },
  banned:['에마'],
};

WORKS.skiploafer.guide = {
  season:'1기', eps:2, startAt:[1,0], core:['tokyo','plan','classofficer'],
  episodes:{
    1:{ title:'첫 화', summary:'시골 바닷가 마을에서 도쿄의 명문 고교에 수석 입학한 미츠미. 완벽한 첫날을 꿈꾸지만 출근길 전철에서 길을 잃고, 같은 반 소스케와 함께 입학식장으로 달려가요.' },
    2:{ title:'두 번째 화', summary:'새 교실에서 미츠미는 반 친구들과 어울리려 애쓰지만 생각보다 쉽지 않아요. 노래방 모임에서 친구가 조금씩 생기고, 소스케의 웃음 뒤에 숨은 무언가가 살짝 보여요.' },
  },
  scenes:{
    1:[
      { s:0,    title:'새 교복', art:'home', chars:['mitsumi','fumi'], terms:[], sum:'미츠미는 고향 친구 후미에게 전화로 새 교복을 자랑해요. 고교 첫날이에요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'도쿄 생활', art:'city', chars:['mitsumi','nao'], terms:['tokyo'], sum:'시골에서 올라온 미츠미는 도쿄에서 나오 고모와 함께 살아요.' },
      { s:390,  title:'인생 계획', art:'home', chars:['mitsumi'], terms:['plan'], sum:'미츠미는 완벽한 하루를 장담하며, 관료가 되어 고향을 돕겠다는 장래 계획을 늘어놓아요.' },
      { s:540,  title:'만원 전철', art:'city', chars:['mitsumi'], terms:['tokyo'], sum:'출근길 만원 전철에서 벽에 끼인 미츠미는 내릴 역을 놓쳐 버려요.' },
      { s:690,  title:'소스케', art:'city', chars:['mitsumi','sosuke'], terms:[], sum:'도와주려는 소스케에게 입학식에 늦을까 봐 날카롭게 굴지만, 두 사람은 함께 학교로 달려가요.' },
      { s:870,  title:'신입생 대표', art:'classroom', chars:['mitsumi','sosuke'], terms:['plan'], sum:'콜록대며 도착한 미츠미는 원고를 가방에 두고 왔지만, 외워 둔 신입생 대표 연설을 해내요.' },
      { s:1020, title:'대참사', art:'classroom', chars:['mitsumi'], terms:[], sum:'연설이 끝난 뒤 긴장이 풀린 미츠미는 그만 선생님 앞에서 토해 버려요.' },
      { s:1170, title:'첫 친구들', art:'classroom', chars:['mitsumi','sosuke','mika'], terms:[], sum:'소스케는 미츠미의 친구가 되고, 같은 반 미카도 인사를 건네요.' },
      { s:1290, title:'첫날은 연습', art:'home', chars:['mitsumi','sosuke'], terms:['plan'], sum:'미츠미는 오늘의 실수는 첫날이라 안 친다며 다시 완벽을 다짐해요. 소스케는 내일은 늦지 말아야겠다고 생각해요.' },
    ],
    2:[
      { s:0,    title:'자기소개', art:'classroom', chars:['mitsumi'], terms:[], sum:'반 친구들이 차례로 자기소개를 하고, 미츠미는 「전투 개시!」라며 비장하게 일어서요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'반장 선거', art:'classroom', chars:['mitsumi','sosuke'], terms:['classofficer'], sum:'미츠미와 소스케는 함께 학급 위원에 자원해요. 소스케는 꿈은 없지만 미츠미 밑에서 일하는 건 좋다고 해요.' },
      { s:420,  title:'미카의 경고', art:'classroom', chars:['mika','mitsumi'], terms:[], sum:'미카는 소스케가 누구에게나 다정한 사람이니 진지하게 받아들이지 말라고 하고, 미츠미는 조금 거리를 둬요.' },
      { s:600,  title:'유즈키', art:'classroom', chars:['yuzuki','mitsumi'], terms:[], sum:'지켜보던 유즈키가 미츠미에게 다가와, 소스케에게 접근하려고 너를 이용하는 거 괜찮냐고 물어요.' },
      { s:780,  title:'후미의 전화', art:'home', chars:['mitsumi','fumi'], terms:[], sum:'교실이 생각보다 어렵다고 느끼던 미츠미는 후미의 전화에 다시 힘을 얻어요.' },
      { s:930,  title:'노래방', art:'party', chars:['mitsumi','sosuke','mika','yuzuki'], terms:[], sum:'반 친구들과 노래방에 가요. 미츠미는 어린이 프로그램 주제가를 부르고, 유즈키와 연락처를 교환해요.' },
      { s:1110, title:'연극부 선배', art:'street', chars:['kanechika','sosuke','mitsumi'], terms:[], sum:'연극부 2학년 카네치카가 다가와 소스케에게 어디서 본 적 있지 않냐고 묻자, 소스케는 눈에 띄게 불편해해요.' },
      { s:1260, title:'웃음 뒤의 그림자', art:'night', chars:['sosuke','mitsumi'], terms:[], sum:'소스케는 아직 정하지 않은 일은 고민하지 않는다고 말하지만, 미츠미는 그 웃음 뒤에 쓸쓸함이 있다는 걸 느껴요.' },
    ],
  },
  chars:{
    mitsumi:{ name:'이와쿠라 미츠미', short:'미츠미', alias:['미츠미','이와쿠라'], at:[1,0], pos:[300,230], facts:[
      [[1,0],'시골 바닷가 마을에서 온 15살 고교생이에요.'],
      [[1,390],'관료가 되어 고향을 돕겠다는 계획이 있어요.'],
      [[1,870],'수석 입학생으로 신입생 대표 연설을 해요.'],
      [[2,240],'학급 위원이 돼요.'],
    ], easy:'계획은 완벽한데 실전은 늘 엉뚱한, 사랑스러운 시골 소녀예요.' },
    fumi:{ name:'후미', short:'후미', alias:['후미'], at:[1,0], pos:[120,380], facts:[
      [[1,0],'미츠미의 고향 친구예요.'],
    ] },
    nao:{ name:'나오', short:'나오', alias:['나오','고모'], at:[1,240], pos:[130,120], facts:[
      [[1,240],'미츠미가 도쿄에서 함께 사는 가족이에요.'],
    ] },
    sosuke:{ name:'시마 소스케', short:'소스케', alias:['소스케','시마'], at:[1,690], pos:[470,140], facts:[
      [[1,690],'전철에서 만난 같은 반 남학생이에요. 느긋하고 다정해요.'],
      [[2,240],'함께 학급 위원이 돼요.'],
      [[2,1110],'자신을 알아보는 듯한 선배 앞에서 불편해해요.'],
    ] },
    mika:{ name:'에가시라 미카', short:'미카', alias:['미카'], at:[1,1170], pos:[480,360], facts:[
      [[1,1170],'같은 반 친구예요.'],
      [[2,420],'소스케를 진지하게 받아들이지 말라고 해요.'],
    ] },
    yuzuki:{ name:'무라시게 유즈키', short:'유즈키', alias:['유즈키'], at:[2,600], pos:[540,240], facts:[
      [[2,600],'눈치 빠른 같은 반 친구예요.'],
    ] },
    kanechika:{ name:'카네치카', short:'카네치카', alias:['카네치카'], at:[2,1110], pos:[300,410], facts:[
      [[2,1110],'연극부 2학년 선배예요. 각본도 써요.'],
    ] },
  },
  rels:[
    ['mitsumi','fumi','friend','고향 친구',[1,0]],
    ['mitsumi','nao','family','도쿄에서 함께 사는 가족',[1,240]],
    ['mitsumi','sosuke','friend','첫날 만난 친구',[1,1170]],
    ['mitsumi','mika','peer','같은 반',[1,1170]],
    ['mitsumi','yuzuki','friend','연락처를 교환한 친구',[2,930]],
    ['kanechika','sosuke','other','어디서 본 듯한 선배',[2,1110]],
  ],
  terms:{
    tokyo:{ name:'도쿄 생활', alias:['도쿄'], at:[1,240], facts:[[[1,240],'시골에서 온 미츠미에게 도쿄는 모든 게 낯설어요.']] },
    plan:{ name:'미츠미의 인생 계획', alias:['계획','관료'], at:[1,390], facts:[[[1,390],'좋은 대학을 나와 관료가 되어 고향을 돕겠다는 계획이에요.']], easy:'작은 마을을 위해 큰 꿈을 꾸는 거예요.' },
    classofficer:{ name:'학급 위원', alias:['학급 위원','반장'], at:[2,240], facts:[[[2,240],'미츠미와 소스케가 함께 맡아요.']] },
  },
  banned:['츠무기','마코토','히카루'],
};

WORKS.icewall.guide = {
  season:'1기', eps:2, startAt:[1,0], core:['wall','meiten','giraffe'],
  episodes:{
    1:{ title:'첫 화', summary:'중학교 때 상처받은 뒤 마음에 벽을 쌓은 코유키는 고등학교에서 「얼음 여왕」이라 불려요. 그런 그녀에게 미나토가 자꾸 다가오고, 친구 미키의 지인 요타와도 엮이게 돼요.' },
    2:{ title:'열쇠공', summary:'헌팅에 곤란해하던 코유키를 요타가 구해 주고, 코유키는 요타에게 조금씩 마음을 열어요. 그런 두 사람을 본 미나토는 둘의 관계가 신경 쓰이기 시작해요.' },
  },
  scenes:{
    1:[
      { s:0,    title:'중학교의 기억', art:'classroom', chars:['koyuki'], terms:[], sum:'중학생 시절 코유키는 놀림과 괴롭힘을 당했고, 무엇을 해도 어색하게만 느꼈어요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'얼음 여왕', art:'classroom', chars:['koyuki'], terms:['wall','meiten'], sum:'메이텐 고교에 온 코유키는 사람을 피하며 지내, 다가가기 어려운 사람으로 통해요.' },
      { s:420,  title:'친구 미키', art:'classroom', chars:['koyuki','miki'], terms:[], sum:'인기 많은 미키는 그런 코유키의 친구예요.' },
      { s:600,  title:'계단의 미나토', art:'classroom', chars:['koyuki','minato'], terms:['wall'], sum:'유리창에 비친 자기 얼굴에 장난스러운 표정을 짓던 코유키를 본 미나토가, 계단에서 그녀에게 말을 걸어요.' },
      { s:780,  title:'인사하는 미나토', art:'street', chars:['minato','koyuki'], terms:[], sum:'미나토는 친구들을 두고 지나가는 코유키에게 일부러 인사하러 와요. 코유키는 당황해요.' },
      { s:930,  title:'두고 간 노트', art:'home', chars:['koyuki','miki'], terms:[], sum:'함께 공부하던 날 미키가 노트를 두고 가자, 코유키는 그걸 전해 주러 나가요.' },
      { s:1080, title:'키 큰 남학생', art:'street', chars:['koyuki','yota'], terms:['giraffe'], sum:'노트를 전하러 간 곳에서 코유키는 아주 키가 큰 남학생 요타와 마주쳐요. 속으로 「기린 씨」라고 불러요.' },
      { s:1230, title:'따라오는 남자들', art:'night', chars:['koyuki','yota'], terms:[], sum:'미키를 만나러 가던 코유키를 수상한 남자 둘이 따라와요. 길 건너 요타를 발견한 코유키가 손을 흔들고, 요타가 와서 남자들을 노려봐요.' },
    ],
    2:[
      { s:0,    title:'연결 고리', art:'classroom', chars:['minato'], terms:[], sum:'미나토는 스스로를 사람들 사이를 이어 주는 역할이라고 생각해요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'구해 준 요타', art:'night', chars:['koyuki','yota'], terms:['giraffe'], sum:'헌팅에 곤란해하던 코유키를 요타가 얼떨결에 구해 줘요.' },
      { s:420,  title:'미키의 옛 친구', art:'street', chars:['yota','koyuki','miki'], terms:[], sum:'요타는 미키의 중학교 시절부터의 친구로, 꾸미지 않은 미키의 모습을 알아요.' },
      { s:600,  title:'공부방 가는 길', art:'street', chars:['koyuki','yota'], terms:['wall'], sum:'두 사람은 공부방을 쓰러 동네 시민회관까지 함께 걸어요. 무슨 말을 할지 걱정하던 코유키는 미키라는 공통점 덕분에 자연스럽게 웃어요.' },
      { s:780,  title:'신경 쓰이는 미나토', art:'classroom', chars:['minato','koyuki','yota'], terms:[], sum:'늘 혼자인 코유키를 신경 쓰던 미나토는, 코유키와 요타가 함께 있는 걸 보고 두 사람 사이가 궁금해져요.' },
      { s:960,  title:'차인 미나토', art:'classroom', chars:['minato'], terms:[], sum:'미나토는 사귀던 여자아이에게 「나를 좋아한 적 없잖아」라는 말과 함께 차여요. 그런데 크게 상처받은 기색은 없어요.' },
      { s:1110, title:'시끄러운 반', art:'classroom', chars:['koyuki','yota'], terms:['meiten'], sum:'코유키는 시끌벅적하기로 소문난 요타네 반에 가는 게 긴장돼요.' },
      { s:1260, title:'가위바위보', art:'city', chars:['koyuki','miki'], terms:[], sum:'전철에서 미키와 코유키는 자리를 걸고 가위바위보를 해요. 자리를 양보하려다 오해를 살까 봐 둘은 허둥지둥 옆 칸으로 도망쳐요.' },
    ],
  },
  chars:{
    koyuki:{ name:'히카와 코유키', short:'코유키', alias:['코유키','히카와'], at:[1,0], pos:[300,230], facts:[
      [[1,0],'중학교 때 괴롭힘을 당했어요.'],
      [[1,240],'고등학교에선 마음에 벽을 쌓고 사람을 피해요.'],
      [[2,600],'요타 앞에서는 조금씩 웃어요.'],
    ], easy:'차가워 보이지만 사실은 상처받기 싫은 겁쟁이예요.' },
    miki:{ name:'아즈미 미키', short:'미키', alias:['미키','아즈미'], at:[1,420], pos:[130,120], facts:[
      [[1,420],'인기 많은 코유키의 친구예요.'],
      [[2,420],'요타와는 중학교 때부터 아는 사이예요.'],
    ] },
    minato:{ name:'아마미야 미나토', short:'미나토', alias:['미나토','아마미야'], at:[1,600], pos:[470,140], facts:[
      [[1,600],'코유키에게 자꾸 말을 거는 남학생이에요.'],
      [[2,0],'사람들 사이를 이어 주는 역할이라고 생각해요.'],
      [[2,780],'코유키와 요타의 관계가 궁금해져요.'],
    ] },
    yota:{ name:'히노 요타', short:'요타', alias:['요타','히노','기린 씨'], at:[1,1080], pos:[480,360], facts:[
      [[1,1080],'키가 아주 큰 남학생이에요.'],
      [[1,1230],'코유키를 따라오던 남자들을 막아 줘요.'],
      [[2,420],'미키의 중학교 시절 친구예요.'],
    ] },
  },
  rels:[
    ['koyuki','miki','friend','친구',[1,420]],
    ['minato','koyuki','other','자꾸 다가오는 남학생',[1,600]],
    ['koyuki','yota','friend','마음을 열기 시작한 상대',[2,600]],
    ['miki','yota','friend','중학교 때부터 아는 사이',[2,420]],
  ],
  terms:{
    wall:{ name:'마음의 벽', alias:['벽','얼음 여왕','성벽'], at:[1,240], facts:[[[1,240],'상처받지 않으려고 코유키가 쌓은 마음의 벽이에요.']], easy:'다가오는 사람을 먼저 밀어내는 자기 보호막이에요.' },
    meiten:{ name:'메이텐 고교', alias:['메이텐'], at:[1,240], facts:[[[1,240],'코유키와 친구들이 다니는 고등학교예요.']] },
    giraffe:{ name:'기린 씨', alias:['기린'], at:[1,1080], facts:[[[1,1080],'코유키가 키 큰 요타에게 속으로 붙인 별명이에요.']] },
  },
  banned:[],
};

WORKS.ouran.guide = {
  season:'1기', eps:2, startAt:[1,0], core:['hostclub','debt','secret'],
  episodes:{
    1:{ title:'오늘부터 넌 호스트다!', summary:'부잣집 자제들이 다니는 오란 학원의 장학생 하루히는 조용히 공부할 곳을 찾다 호스트부에 들어가 800만 엔짜리 꽃병을 깨 버려요. 빚을 갚기 위해 하루히는 남장을 한 채 호스트로 일하게 돼요.' },
    2:{ title:'고교생 호스트의 일!', summary:'단골손님 카나코의 약혼자 문제로 호스트부가 둘을 이어 주기로 해요. 댄스 파티에서 작전은 성공하지만, 마지막에 뜻밖의 사고가 벌어져요.' },
  },
  scenes:{
    1:[
      { s:0,    title:'오란 학원', art:'classroom', chars:['haruhi'], terms:['ouran'], sum:'부유층 자제들이 다니는 오란 학원에, 서민 출신 장학생 하루히가 있어요. 짧은 머리 때문에 남자로 오해받아요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'제3음악실', art:'party', chars:['haruhi','tamaki','kyoya','hikaru','kaoru','honey','mori'], terms:['hostclub'], sum:'조용히 공부할 곳을 찾던 하루히가 빈 음악실 문을 열자, 화려한 미남들의 호스트부가 맞아 줘요.' },
      { s:420,  title:'800만 엔 꽃병', art:'party', chars:['haruhi','kyoya'], terms:['debt'], sum:'뒷걸음질 치던 하루히가 경매에 내놓을 800만 엔짜리 꽃병을 깨 버려요.' },
      { s:570,  title:'잡일꾼에서 호스트로', art:'party', chars:['haruhi','tamaki'], terms:['debt','hostclub'], sum:'빚을 갚으려 잡일을 하던 하루히가 여학생들을 자연스럽게 즐겁게 해 주자, 부원들은 그녀를 견습 호스트로 승격시켜요. 손님 100명을 모으면 빚을 없애 주기로 해요.' },
      { s:780,  title:'들킨 비밀', art:'party', chars:['haruhi','tamaki','hikaru','kaoru'], terms:['secret'], sum:'부원들은 하루히가 여자라는 걸 알게 되지만, 비밀을 지켜 주기로 해요.' },
      { s:960,  title:'질투하는 손님', art:'classroom', chars:['haruhi','ayanokoji'], terms:['hostclub'], sum:'타마키의 단골손님 아야노코지는 하루히를 질투해 가방을 연못에 던져 버려요.' },
      { s:1140, title:'출입 금지', art:'party', chars:['tamaki','ayanokoji','haruhi'], terms:['hostclub'], sum:'일이 드러나자 타마키는 아야노코지에게 호스트부 출입을 금지해요.' },
      { s:1290, title:'목표 상향', art:'party', chars:['haruhi','tamaki','kyoya'], terms:['debt'], sum:'그런데 소동을 이유로 하루히의 목표는 손님 1,000명으로 늘어나 버려요.' },
    ],
    2:[
      { s:0,    title:'단골손님 카나코', art:'party', chars:['kanako','haruhi'], terms:['hostclub'], sum:'호스트를 자주 바꾸는 단골손님 카나코가 이번엔 하루히를 지명해요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'약혼자 토오루', art:'classroom', chars:['kanako','toru'], terms:[], sum:'카나코에게는 유학을 앞둔 약혼자 토오루가 있어요. 두 사람은 서로 엇갈리고 있어요.' },
      { s:420,  title:'호스트부의 작전', art:'party', chars:['tamaki','kyoya','haruhi'], terms:['hostclub'], sum:'호스트부는 다가오는 댄스 파티에서 두 사람을 다시 이어 주기로 해요.' },
      { s:600,  title:'여장한 하루히', art:'party', chars:['haruhi','toru'], terms:['secret'], sum:'여학생 차림을 한 하루히가 토오루에게 다가가 마음이 있는 척해요. 토오루는 이미 마음에 둔 사람이 있다고 말해요.' },
      { s:780,  title:'달려간 카나코', art:'party', chars:['kanako','toru'], terms:[], sum:'그 모습을 본 카나코가 울며 달려가고, 토오루가 뒤쫓아가요.' },
      { s:960,  title:'다시 확인한 마음', art:'night', chars:['kanako','toru'], terms:[], sum:'두 사람은 서로의 마음을 다시 확인해요.' },
      { s:1110, title:'파티의 여왕', art:'party', chars:['kanako','haruhi'], terms:['hostclub'], sum:'파티의 여왕으로 뽑힌 카나코는 하루히에게서 볼에 입맞춤을 받기로 해요.' },
      { s:1260, title:'예상 못 한 사고', art:'party', chars:['tamaki','haruhi','kanako'], terms:[], sum:'하루히의 첫 키스일까 봐 타마키가 막으려 달려들다 넘어지고, 하루히와 카나코의 입술이 닿아 버려요.' },
    ],
  },
  chars:{
    haruhi:{ name:'후지오카 하루히', short:'하루히', alias:['하루히','후지오카'], at:[1,0], pos:[300,230], facts:[
      [[1,0],'서민 출신 장학생이에요. 남자로 오해받아요.'],
      [[1,420],'800만 엔짜리 꽃병을 깨요.'],
      [[1,570],'빚을 갚으려 견습 호스트가 돼요.'],
    ], easy:'꾸밈없고 무심한데 그래서 더 인기 있는 남장 호스트예요.' },
    tamaki:{ name:'스오우 타마키', short:'타마키', alias:['타마키','스오우'], at:[1,240], pos:[470,130], facts:[
      [[1,240],'호스트부 부장이에요. 과장되고 다정해요.'],
      [[2,1260],'하루히를 지키려다 오히려 사고를 쳐요.'],
    ] },
    kyoya:{ name:'오오토리 쿄야', short:'쿄야', alias:['쿄야','오오토리'], at:[1,240], pos:[130,110], facts:[
      [[1,240],'호스트부의 살림을 맡는 부부장이에요. 계산이 빨라요.'],
    ] },
    hikaru:{ name:'히타치인 히카루', short:'히카루', alias:['히카루'], at:[1,240], pos:[60,240], facts:[
      [[1,240],'호스트부의 쌍둥이 중 한 명이에요.'],
    ] },
    kaoru:{ name:'히타치인 카오루', short:'카오루', alias:['카오루'], at:[1,240], pos:[120,330], facts:[
      [[1,240],'호스트부의 쌍둥이 중 한 명이에요.'],
    ] },
    honey:{ name:'하니', short:'하니', alias:['하니'], at:[1,240], pos:[540,240], facts:[
      [[1,240],'귀여운 외모의 3학년 호스트예요.'],
    ] },
    mori:{ name:'모리', short:'모리', alias:['모리'], at:[1,240], pos:[530,360], facts:[
      [[1,240],'말수 적은 3학년 호스트예요. 하니와 늘 함께예요.'],
    ] },
    ayanokoji:{ name:'아야노코지', short:'아야노코지', alias:['아야노코지'], at:[1,960], pos:[300,60], facts:[
      [[1,960],'타마키의 단골손님이에요. 하루히를 질투해요.'],
    ] },
    kanako:{ name:'카스가자키 카나코', short:'카나코', alias:['카나코'], at:[2,0], pos:[230,410], facts:[
      [[2,0],'호스트부 단골손님이에요.'],
      [[2,960],'약혼자와 마음을 다시 확인해요.'],
    ] },
    toru:{ name:'스즈시마 토오루', short:'토오루', alias:['토오루'], at:[2,240], pos:[380,410], facts:[
      [[2,240],'카나코의 약혼자예요. 유학을 앞두고 있어요.'],
    ] },
  },
  rels:[
    ['tamaki','haruhi','peer','호스트부 부장과 부원',[1,240]],
    ['tamaki','kyoya','peer','부장과 부부장',[1,240]],
    ['hikaru','kaoru','family','쌍둥이',[1,240]],
    ['honey','mori','friend','늘 함께인 사이',[1,240]],
    ['ayanokoji','haruhi','rival','질투한 손님',[1,960]],
    ['kanako','toru','other','약혼자',[2,240]],
  ],
  terms:{
    ouran:{ name:'오란 학원', alias:['오란','학원'], at:[1,0], facts:[[[1,0],'부유층 자제들이 다니는 사립 학교예요.']] },
    hostclub:{ name:'호스트부', alias:['호스트부','호스트'], at:[1,240], facts:[[[1,240],'미남 부원들이 여학생 손님을 즐겁게 해 주는 동아리예요.']], easy:'부잣집 도련님들의 「다과 접대 동아리」예요.' },
    debt:{ name:'800만 엔 빚', alias:['빚','꽃병'], at:[1,420], facts:[[[1,420],'하루히가 깬 꽃병값이에요.'],[[1,570],'손님 100명을 모으면 없애 주기로 했어요.'],[[1,1290],'목표가 1,000명으로 늘어나요.']] },
    secret:{ name:'하루히의 비밀', alias:['비밀','여자'], at:[1,780], facts:[[[1,780],'하루히가 여자라는 사실이에요. 부원들만 알아요.']] },
  },
  banned:['렌게','네코자와','쿠라노스케'],
};

WORKS.kaguya.guide = {
  season:'1기', eps:2, startAt:[1,0], core:['council','confess','battle'],
  episodes:{
    1:{ title:'영화에 초대받고 싶어', summary:'명문 슈치인 학원 학생회장 시로가네와 부회장 카구야는 서로 좋아하지만, 먼저 고백하면 지는 거라 믿어요. 두 사람은 상대가 먼저 고백하게 만들려고 두뇌전을 펼쳐요.' },
    2:{ title:'연락처를 교환하고 싶어', summary:'새 스마트폰을 산 시로가네와 카구야는 서로 먼저 연락처를 묻게 만들려 해요. 여름 여행지를 두고도 신경전이 이어지고, 한 남학생이 시로가네에게 연애 상담을 해 와요.' },
  },
  scenes:{
    1:[
      { s:0,    title:'슈치인 학원 학생회', art:'office', chars:['shirogane','kaguya'], terms:['council'], sum:'명문 슈치인 학원의 학생회장 시로가네와 부회장 카구야는 누가 봐도 잘 어울리는 한 쌍이에요.' },
      { s:120,  title:'먼저 고백하면 진다', art:'office', chars:['shirogane','kaguya'], terms:['confess','battle'], sum:'두 사람은 서로 좋아하지만, 연애는 먼저 고백하는 쪽이 지는 거라고 믿어요. 그래서 상대가 고백하게 만들려 머리를 굴려요.' },
      { s:240,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:330,  title:'영화표 두 장', art:'office', chars:['chika','shirogane','kaguya'], terms:['battle'], sum:'서기 후지와라가 영화표를 시로가네에게 주려 하고, 시로가네는 카구야를 초대할지 고민해요.' },
      { s:510,  title:'카구야의 설계', art:'office', chars:['kaguya','chika'], terms:['battle'], sum:'사실 그 표가 후지와라 손에 들어가게 꾸민 건 카구야였어요. 시로가네가 자신을 초대하게 만들려고요.' },
      { s:720,  title:'연애편지', art:'office', chars:['kaguya','shirogane'], terms:['confess'], sum:'카구야가 연애편지를 받자, 시로가네는 고백도 안 한 상대에게 가지 말라고 붙잡고 싶어 해요.' },
      { s:960,  title:'도시락', art:'office', chars:['shirogane','chika'], terms:[], sum:'시로가네가 직접 싼 도시락을 후지와라와 나눠 먹어요.' },
      { s:1140, title:'질투', art:'office', chars:['kaguya','shirogane','chika'], terms:['battle'], sum:'두 사람이 서로 먹여 주는 모습을 본 카구야는 화가 나고 질투가 치밀어요.' },
      { s:1350, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
    ],
    2:[
      { s:0,    title:'새 스마트폰', art:'office', chars:['shirogane','kaguya'], terms:['battle'], sum:'시로가네는 새 스마트폰을 사고, 카구야가 먼저 메신저 연락처를 묻게 만들려 해요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'같은 작전', art:'office', chars:['kaguya','shirogane'], terms:['battle'], sum:'몰래 그 상황을 꾸민 카구야도 똑같이 시로가네가 먼저 묻게 하려 해요.' },
      { s:510,  title:'여름 여행', art:'office', chars:['chika','shirogane','kaguya'], terms:['council'], sum:'후지와라가 학생회 여름 여행을 제안해요.' },
      { s:720,  title:'산이냐 바다냐', art:'office', chars:['shirogane','kaguya','chika'], terms:['battle'], sum:'시로가네와 카구야는 산과 바다 중 어디로 갈지를 두고 또다시 신경전을 벌여요.' },
      { s:960,  title:'숨기고 싶은 것', art:'office', chars:['shirogane'], terms:[], sum:'시로가네에게도 남들에게 들키고 싶지 않은 것이 있어요.' },
      { s:1140, title:'연애 상담', art:'office', chars:['shirogane','kaguya'], terms:['confess'], sum:'한 남학생이 시로가네에게 반 친구 카시와기에게 고백해도 될지 상담하러 오고, 카구야는 몰래 엿들어요.' },
      { s:1350, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
    ],
  },
  chars:{
    shirogane:{ name:'시로가네 미유키', short:'시로가네', alias:['시로가네','미유키','회장'], at:[1,0], pos:[300,230], facts:[
      [[1,0],'슈치인 학원 학생회장이에요. 학년 1등이에요.'],
      [[1,120],'카구야를 좋아하지만 먼저 고백하면 진다고 믿어요.'],
      [[1,960],'직접 도시락을 싸 와요.'],
    ], easy:'완벽해 보이지만 사실은 노력파에 허당인 회장이에요.' },
    kaguya:{ name:'시노미야 카구야', short:'카구야', alias:['카구야','시노미야','부회장'], at:[1,0], pos:[470,140], facts:[
      [[1,0],'학생회 부회장이에요. 대재벌 집안의 딸이에요.'],
      [[1,120],'시로가네를 좋아하지만 먼저 고백하면 진다고 믿어요.'],
      [[1,510],'영화표 상황을 몰래 꾸몄어요.'],
    ], easy:'자존심이 하늘을 찌르는 천재 아가씨예요.' },
    chika:{ name:'후지와라 치카', short:'후지와라', alias:['후지와라','치카','서기'], at:[1,330], pos:[300,410], facts:[
      [[1,330],'학생회 서기예요. 천진난만해서 두 사람의 작전을 자주 망쳐요.'],
      [[2,510],'학생회 여름 여행을 제안해요.'],
    ] },
  },
  rels:[
    ['shirogane','kaguya','rival','서로 좋아하지만 먼저 고백하긴 싫은 사이',[1,120]],
    ['shirogane','chika','peer','학생회 동료',[1,330]],
    ['kaguya','chika','peer','학생회 동료',[1,330]],
  ],
  terms:{
    council:{ name:'슈치인 학원 학생회', alias:['학생회','슈치인'], at:[1,0], facts:[[[1,0],'명문 슈치인 학원의 학생회예요. 시로가네가 회장, 카구야가 부회장이에요.']] },
    confess:{ name:'고백', alias:['고백','연애편지'], at:[1,120], facts:[[[1,120],'두 사람은 먼저 고백하는 쪽이 지는 거라고 믿어요.']] },
    battle:{ name:'연애 두뇌전', alias:['두뇌전','작전'], at:[1,120], facts:[[[1,120],'상대가 먼저 고백하게 만들려는 두 사람의 머리싸움이에요.']], easy:'누가 먼저 「좋아해」라고 말하나 내기하는 거예요.' },
  },
  banned:['이시가미','이노','하야사카','츠바메','미코'],
};

WORKS.clannad.guide = {
  season:'1기', eps:2, startAt:[1,0], core:['dramaclub','bakery','hill'],
  episodes:{
    1:{ title:'벚꽃 흩날리는 언덕길에서', summary:'학교생활에 흥미를 잃은 토모야는 등굣길 언덕에서 혼잣말을 하는 소녀 나기사를 만나요. 나기사는 없어진 연극부를 다시 하고 싶어 하고, 토모야는 그녀의 집인 빵집에 들르게 돼요.' },
    2:{ title:'첫걸음', summary:'토모야는 연극부 부활을 꿈꾸는 나기사를 도와 포스터를 붙여요. 그 과정에서 개성 강한 학생들과 마주치고, 토모야가 농구를 그만둔 이유가 드러나요.' },
  },
  scenes:{
    1:[
      { s:0,    title:'언덕길의 소녀', art:'hill', chars:['tomoya','nagisa'], terms:['hill'], sum:'벚꽃이 흩날리는 언덕길에서 토모야는 혼잣말을 하며 망설이는 소녀 나기사를 만나요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'시큰둥한 일상', art:'classroom', chars:['tomoya'], terms:[], sum:'토모야는 학교생활에 흥미를 잃고 시큰둥하게 지내요.' },
      { s:420,  title:'다시 만난 나기사', art:'classroom', chars:['tomoya','nagisa'], terms:[], sum:'점심시간에 나기사를 다시 만난 토모야는, 그녀가 마지막 학년을 다시 다니고 있다는 걸 알게 돼요.' },
      { s:600,  title:'연극부', art:'classroom', chars:['nagisa','tomoya'], terms:['dramaclub'], sum:'나기사는 연극부에 들어가고 싶었지만, 연극부는 이미 없어진 뒤예요.' },
      { s:780,  title:'방과 후', art:'street', chars:['tomoya','nagisa'], terms:[], sum:'방과 후 토모야는 나기사와 함께 걸으며 이야기를 나눠요.' },
      { s:960,  title:'후루카와 빵집', art:'town', chars:['tomoya','nagisa','akio','sanae'], terms:['bakery'], sum:'나기사의 집은 빵집이에요. 토모야는 나기사의 부모님을 만나요.' },
      { s:1140, title:'유쾌한 부모님', art:'town', chars:['akio','sanae','tomoya'], terms:['bakery'], sum:'나기사의 부모님은 유쾌하고 따뜻한 사람들이에요.' },
      { s:1260, title:'저녁 초대', art:'home', chars:['tomoya','nagisa','sanae'], terms:['bakery'], sum:'토모야는 나기사의 가족과 함께 저녁을 먹자는 초대를 받아요.' },
      { s:1350, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
    ],
    2:[
      { s:0,    title:'연극부를 다시', art:'classroom', chars:['nagisa','tomoya'], terms:['dramaclub'], sum:'나기사는 연극부를 다시 만들고 싶다고 털어놓아요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'포스터 만들기', art:'classroom', chars:['tomoya','nagisa'], terms:['dramaclub'], sum:'토모야는 부원 모집 포스터를 함께 만들어요.' },
      { s:420,  title:'학교 곳곳에', art:'classroom', chars:['tomoya','nagisa'], terms:['dramaclub'], sum:'두 사람은 학교 곳곳에 포스터를 붙여요.' },
      { s:600,  title:'도서실의 천재', art:'classroom', chars:['tomoya','kotomi'], terms:[], sum:'토모야는 머리는 천재적이지만 어딘가 엉뚱한 학생 코토미를 만나요.' },
      { s:780,  title:'1학년 후코', art:'classroom', chars:['tomoya','fuko'], terms:[], sum:'불가사리 모양 조각을 든 1학년 후코와도 마주쳐요.' },
      { s:960,  title:'농구 이야기', art:'gym', chars:['nagisa','tomoya'], terms:[], sum:'토모야가 예전에 농구를 했다는 걸 안 나기사는, 내일 같이 농구를 하자고 해요.' },
      { s:1140, title:'그만둔 이유', art:'home', chars:['tomoya'], terms:['shoulder'], sum:'토모야는 아버지와의 다툼으로 팔을 다쳐, 더 이상 농구를 할 수 없게 됐다는 사실이 드러나요.' },
      { s:1350, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
    ],
  },
  chars:{
    tomoya:{ name:'오카자키 토모야', short:'토모야', alias:['토모야','오카자키'], at:[1,0], pos:[300,230], facts:[
      [[1,0],'학교생활에 흥미를 잃은 고교 3학년이에요.'],
      [[2,960],'예전에 농구를 했어요.'],
      [[2,1140],'아버지와의 다툼으로 팔을 다쳐 농구를 그만뒀어요.'],
    ], easy:'세상에 시큰둥한 척하지만 사실은 다정한 불량 학생이에요.' },
    nagisa:{ name:'후루카와 나기사', short:'나기사', alias:['나기사','후루카와'], at:[1,0], pos:[470,140], facts:[
      [[1,0],'언덕길에서 혼잣말을 하던 소녀예요.'],
      [[1,420],'마지막 학년을 다시 다니고 있어요.'],
      [[2,0],'연극부를 다시 만들고 싶어 해요.'],
    ], easy:'소심하지만 한 걸음씩 꿈을 향해 나아가는 소녀예요.' },
    akio:{ name:'후루카와 아키오', short:'아키오', alias:['아키오'], at:[1,960], pos:[130,110], facts:[
      [[1,960],'나기사의 아버지예요. 빵집을 해요.'],
    ] },
    sanae:{ name:'후루카와 사나에', short:'사나에', alias:['사나에'], at:[1,960], pos:[130,340], facts:[
      [[1,960],'나기사의 어머니예요. 빵을 굽지만 그 빵은 조금 독특해요.'],
    ] },
    kotomi:{ name:'이치노세 코토미', short:'코토미', alias:['코토미'], at:[2,600], pos:[480,360], facts:[
      [[2,600],'천재적이지만 엉뚱한 학생이에요.'],
    ] },
    fuko:{ name:'이부키 후코', short:'후코', alias:['후코'], at:[2,780], pos:[300,410], facts:[
      [[2,780],'조각을 들고 다니는 1학년이에요.'],
    ] },
  },
  rels:[
    ['tomoya','nagisa','friend','연극부 부활을 돕는 사이',[1,600]],
    ['nagisa','akio','family','딸과 아버지',[1,960]],
    ['nagisa','sanae','family','딸과 어머니',[1,960]],
    ['akio','sanae','family','부부',[1,960]],
    ['tomoya','kotomi','other','학교에서 만난 학생',[2,600]],
    ['tomoya','fuko','other','학교에서 만난 1학년',[2,780]],
  ],
  terms:{
    hill:{ name:'언덕길', alias:['언덕','언덕길'], at:[1,0], facts:[[[1,0],'학교로 이어지는 벚꽃 언덕길이에요. 두 사람이 처음 만난 곳이에요.']] },
    dramaclub:{ name:'연극부', alias:['연극부','포스터'], at:[1,600], facts:[[[1,600],'나기사가 들어가고 싶었던 동아리예요. 지금은 없어졌어요.'],[[2,0],'나기사는 다시 만들고 싶어 해요.']] },
    bakery:{ name:'후루카와 빵집', alias:['빵집'], at:[1,960], facts:[[[1,960],'나기사네 가족이 하는 빵집이에요.']] },
    shoulder:{ name:'다친 팔', alias:['팔','농구'], at:[2,1140], facts:[[[2,1140],'토모야는 팔을 다쳐 농구를 그만뒀어요.']] },
  },
  banned:['스노하라','후지바야시','사카가미','우시오'],
};

WORKS.bluebox.guide = {
  season:'1기', eps:2, startAt:[1,0], core:['badminton','basketball','nationals'],
  episodes:{
    1:{ title:'치나츠 선배', summary:'배드민턴부 1학년 타이키는 아침 연습 때 마주치는 농구부 선배 치나츠를 짝사랑해요. 치나츠의 가족이 해외로 떠난다는 소식을 들은 다음 날, 타이키는 치나츠가 자기 집에서 함께 살게 됐다는 걸 알게 돼요.' },
    2:{ title:'인터하이에 가야 해', summary:'한집에 살게 된 두 사람. 타이키는 치나츠와 같은 높이에 서기 위해 인터하이를 목표로 해요. 그런데 새 학기, 치나츠가 배드민턴부 선배와 이야기하는 모습을 보게 돼요.' },
  },
  scenes:{
    1:[
      { s:0,    title:'아침 체육관', art:'gym', chars:['taiki','chinatsu'], terms:['badminton','basketball'], sum:'배드민턴부 타이키는 아침 일찍 체육관에 가요. 거기엔 늘 먼저 와 있는 농구부 선배 치나츠가 있어요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'친구들에게 고백', art:'classroom', chars:['taiki','kyo','hina'], terms:[], sum:'타이키는 친구 쿄와 히나에게 치나츠 선배를 좋아한다고 털어놓아요. 둘은 무리라면서도 말 걸 요령을 알려 줘요.' },
      { s:420,  title:'목도리', art:'street', chars:['taiki','chinatsu'], terms:[], sum:'추운 아침, 타이키는 치나츠에게 목도리를 빌려주고, 치나츠는 그를 이름으로 부르기 시작해요.' },
      { s:600,  title:'선배의 아쉬움', art:'gym', chars:['taiki','chinatsu'], terms:['nationals','basketball'], sum:'치나츠는 전국 대회에 가지 못해 아쉬웠던 이야기를 하고, 타이키는 배드민턴을 더 잘하고 싶어져요.' },
      { s:780,  title:'이사 소식', art:'home', chars:['taiki','mother'], terms:[], sum:'타이키는 치나츠 엄마와 친한 친구인 자기 엄마에게서, 치나츠네 가족이 해외로 이사한다는 소식을 들어요.' },
      { s:960,  title:'체육관으로', art:'gym', chars:['taiki','chinatsu'], terms:[], sum:'타이키는 응원 인사라도 하려 체육관으로 달려가요. 그런데 치나츠는 아는 사람 집에서 지내며 일본에 남는다고 해요.' },
      { s:1140, title:'다음 날 아침', art:'home', chars:['taiki','chinatsu','mother'], terms:['together'], sum:'다음 날 아침, 타이키는 치나츠가 지내게 된 곳이 바로 자기 집이라는 걸 알고 깜짝 놀라요.' },
      { s:1350, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
    ],
    2:[
      { s:0,    title:'한 지붕 아래', art:'home', chars:['taiki','chinatsu'], terms:['together'], sum:'치나츠는 타이키네 집에 자리를 잡고, 타이키는 갑작스러운 생활에 적응하려 애써요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'비밀로 해', art:'classroom', chars:['kyo','taiki'], terms:['together'], sum:'들뜬 타이키를 본 쿄는 함께 산다는 건 비밀로 하라고 조언해요.' },
      { s:420,  title:'인터하이 목표', art:'gym', chars:['taiki','kyo'], terms:['nationals'], sum:'타이키는 치나츠와 같은 높이에 서고 싶어 인터하이에 나가겠다고 해요. 쿄는 깜짝 놀라요.' },
      { s:600,  title:'행운의 팔찌', art:'home', chars:['chinatsu','taiki'], terms:['nationals'], sum:'그 이야기를 들은 치나츠는 타이키에게 행운의 팔찌를 건네며 자기 것도 보여 줘요.' },
      { s:780,  title:'눈치 빠른 히나', art:'gym', chars:['hina','taiki'], terms:[], sum:'체육관에서 연습하는 타이키를 본 히나는 치나츠 때문이라고 짐작하고 놀려요.' },
      { s:960,  title:'거리 두기', art:'home', chars:['taiki','chinatsu'], terms:['together'], sum:'들킬까 겁난 타이키는 치나츠에게 같이 있는 걸 사람들이 보면 소문날 거라며 거리를 둬요. 치나츠는 타이키와 히나가 서로 좋아하는 줄 알았다며 어리둥절해해요.' },
      { s:1140, title:'새 학기', art:'gym', chars:['taiki'], terms:['nationals'], sum:'새 학년이 시작되고, 타이키는 목표를 향해 열심히 연습해요.' },
      { s:1260, title:'선배와 치나츠', art:'street', chars:['taiki','hina','chinatsu','haryu'], terms:['badminton'], sum:'방과 후 다가오는 치나츠를 보던 타이키와 히나는, 그녀가 배드민턴부 선배 하류와 이야기하는 걸 보고 충격을 받아요.' },
    ],
  },
  chars:{
    taiki:{ name:'이노마타 타이키', short:'타이키', alias:['타이키','이노마타'], at:[1,0], pos:[300,230], facts:[
      [[1,0],'배드민턴부 1학년이에요. 아침마다 연습해요.'],
      [[1,240],'농구부 치나츠 선배를 좋아해요.'],
      [[2,420],'인터하이 출전을 목표로 해요.'],
    ], easy:'짝사랑 상대와 한집에 살게 된, 성실한 운동부 소년이에요.' },
    chinatsu:{ name:'카노 치나츠', short:'치나츠', alias:['치나츠','카노'], at:[1,0], pos:[470,140], facts:[
      [[1,0],'농구부 2학년 에이스예요. 아침 연습을 빠지지 않아요.'],
      [[1,600],'전국 대회에 가지 못해 아쉬웠던 적이 있어요.'],
      [[1,1140],'가족이 해외로 떠나고, 타이키네 집에서 지내게 돼요.'],
    ] },
    kyo:{ name:'카사하라 쿄', short:'쿄', alias:['쿄','카사하라'], at:[1,240], pos:[130,120], facts:[
      [[1,240],'타이키의 친구예요.'],
      [[2,240],'함께 산다는 건 비밀로 하라고 조언해요.'],
    ] },
    hina:{ name:'쵸노 히나', short:'히나', alias:['히나','쵸노'], at:[1,240], pos:[130,340], facts:[
      [[1,240],'타이키의 소꿉친구예요. 리듬체조부예요.'],
      [[2,780],'타이키의 마음을 눈치채고 놀려요.'],
    ] },
    mother:{ name:'타이키의 엄마', short:'엄마', alias:['엄마'], at:[1,780], pos:[110,240], facts:[
      [[1,780],'치나츠 엄마와 친한 친구예요.'],
    ] },
    haryu:{ name:'하류 켄고', short:'하류', alias:['하류','켄고'], at:[2,1260], pos:[480,370], facts:[
      [[2,1260],'타이키의 배드민턴부 선배예요.'],
    ] },
  },
  rels:[
    ['taiki','chinatsu','other','짝사랑하는 선배이자 한집 식구',[1,1140]],
    ['taiki','kyo','friend','친구',[1,240]],
    ['taiki','hina','friend','소꿉친구',[1,240]],
    ['taiki','mother','family','아들과 엄마',[1,780]],
    ['taiki','haryu','peer','배드민턴부 선후배',[2,1260]],
  ],
  terms:{
    badminton:{ name:'배드민턴부', alias:['배드민턴'], at:[1,0], facts:[[[1,0],'타이키가 속한 운동부예요.']] },
    basketball:{ name:'여자 농구부', alias:['농구','농구부'], at:[1,0], facts:[[[1,0],'치나츠가 속한 운동부예요.']] },
    nationals:{ name:'전국 대회', alias:['전국 대회','인터하이'], at:[1,600], facts:[[[1,600],'고교 운동부의 최고 무대예요. 치나츠는 아깝게 가지 못했어요.'],[[2,420],'타이키의 목표예요.']], easy:'고등학생 운동부의 「꿈의 무대」예요.' },
    together:{ name:'한집살이', alias:['한집','같이 산다'], at:[1,1140], facts:[[[1,1140],'치나츠는 타이키네 집에서 지내요.'],[[2,240],'학교에서는 비밀이에요.']] },
  },
  banned:['유메카','아야메'],
};

WORKS.kaoru.guide = {
  season:'1기', eps:2, startAt:[1,0], core:['chidori','kikyo','bakery'],
  episodes:{
    1:{ title:'첫 화', summary:'거친 남고 치도리 고교의 린타로는 무서운 외모와 달리 다정한 소년이에요. 가족이 하는 케이크 가게에서, 바로 옆 명문 여고 키쿄 학원의 카오루코를 만나요.' },
    2:{ title:'두 번째 화', summary:'카오루코가 치도리 교문 앞에서 린타로를 기다리고, 두 학교의 시선이 쏠려요. 린타로는 카오루코를 밀어내려 하지만, 결국 진심으로 사과하러 키쿄 교문 앞으로 가요.' },
  },
  scenes:{
    1:[
      { s:0,    title:'두 학교', art:'city', chars:[], terms:['kikyo','chidori'], sum:'품격 있는 명문 여고 키쿄 학원과, 바로 옆 담장 너머의 남고 치도리 고교. 두 학교는 사이가 나빠요.' },
      { s:150,  title:'창가의 린타로', art:'classroom', chars:['rintaro'], terms:['chidori'], sum:'치도리 고교의 린타로는 교실 창가에 앉아 하늘 대신 벽을 바라봐요.' },
      { s:300,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:390,  title:'무서운 외모', art:'street', chars:['rintaro'], terms:['chidori'], sum:'불량배들이 싸움을 걸어오지만, 린타로의 무서운 인상에 그대로 달아나요. 사실 린타로와 친구들은 불량하지 않아요.' },
      { s:570,  title:'가족의 케이크 가게', art:'town', chars:['rintaro'], terms:['bakery'], sum:'방과 후 린타로는 학교에 숨긴 채 가족이 하는 케이크 가게에서 일해요.' },
      { s:720,  title:'케이크를 먹는 소녀', art:'town', chars:['rintaro','kaoruko'], terms:['bakery','kikyo'], sum:'키쿄 학원 학생 카오루코가 가게에서 케이크를 잔뜩 먹다 린타로와 눈이 마주치자 도망쳐요. 린타로는 자기가 겁을 준 줄 알고 사과해요.' },
      { s:900,  title:'무섭지 않아요', art:'town', chars:['rintaro','kaoruko'], terms:['bakery'], sum:'다시 온 카오루코는 많이 먹는 게 부끄러웠을 뿐, 한 번도 린타로가 무섭다고 생각한 적 없다고 말해요.' },
      { s:1080, title:'두고 간 케이크', art:'street', chars:['rintaro','kaoruko'], terms:[], sum:'카오루코가 두고 간 케이크를 전하러 간 린타로는, 동네 남자들에게 시달리는 그녀를 발견해요. 카오루코는 린타로를 감싸고, 린타로는 그녀를 지키다 다쳐요.' },
      { s:1230, title:'창문 너머', art:'classroom', chars:['rintaro','kaoruko'], terms:['kikyo','chidori'], sum:'카오루코는 다음에 또 케이크를 먹자고 해요. 그리고 두 학교의 창문 너머로 서로를 발견하자, 린타로는 얼굴이 빨개져 커튼을 닫아요.' },
    ],
    2:[
      { s:0,    title:'솔직한 사람', art:'town', chars:['rintaro','kaoruko'], terms:[], sum:'린타로는 이렇게 솔직하고 직접적인 사람이 있을 줄 몰랐다며 카오루코를 떠올려요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'우사미의 불만', art:'classroom', chars:['usami','rintaro'], terms:['kikyo','chidori'], sum:'린타로의 단짝 우사미는 키쿄 학생들의 적대적인 시선에 불만을 터뜨려요.' },
      { s:420,  title:'교문 앞의 카오루코', art:'street', chars:['kaoruko','rintaro','usami'], terms:['chidori'], sum:'카오루코가 치도리 교문 앞에서 린타로를 기다려요. 두 학교의 사이를 신경 쓰지 않는 모습에 우사미는 날을 세워요.' },
      { s:600,  title:'노래방', art:'party', chars:['rintaro','usami'], terms:[], sum:'고민하는 린타로를 눈치챈 친구들은 노래방에 데려가 곁을 지켜 줘요.' },
      { s:780,  title:'가게에서', art:'town', chars:['rintaro','kaoruko'], terms:['bakery'], sum:'가게에 온 카오루코에게 왜 학교에 왔냐고 묻자, 그녀는 린타로를 보고 싶어서였고 만나서 기뻤다고 해요.' },
      { s:960,  title:'밀어내기', art:'town', chars:['rintaro','kaoruko','mother'], terms:['kikyo'], sum:'키쿄 학생이니 결국 자기를 떠날 거라 생각한 린타로는 그만 가 달라고 해요. 어머니는 사람들이 린타로에게 했던 걸 그가 똑같이 하고 있다고 일깨워요.' },
      { s:1140, title:'키쿄 교문 앞', art:'street', chars:['rintaro','kaoruko'], terms:['kikyo'], sum:'린타로는 사과하려고 키쿄 학원 교문 앞에서 카오루코를 기다려요. 카오루코도 자기가 너무 말을 많이 했나 걱정했다고 털어놓아요.' },
      { s:1290, title:'아침 햇살', art:'flowers', chars:['rintaro','kaoruko'], terms:[], sum:'아침 햇살 아래 두 사람은 오해를 풀고, 서로를 향한 마음을 확인해요.' },
    ],
  },
  chars:{
    rintaro:{ name:'츠무기 린타로', short:'린타로', alias:['린타로','츠무기'], at:[1,150], pos:[300,230], facts:[
      [[1,150],'치도리 고교 학생이에요. 키가 크고 인상이 무서워요.'],
      [[1,570],'가족이 하는 케이크 가게에서 일해요. 학교엔 비밀이에요.'],
      [[2,960],'키쿄 학생은 자기를 떠날 거라 생각해 카오루코를 밀어내려 해요.'],
    ], easy:'무서운 얼굴에 마음은 솜사탕인 소년이에요.' },
    kaoruko:{ name:'와구리 카오루코', short:'카오루코', alias:['카오루코','와구리'], at:[1,720], pos:[470,140], facts:[
      [[1,720],'명문 여고 키쿄 학원 학생이에요. 케이크를 아주 좋아해요.'],
      [[1,900],'린타로가 무섭다고 생각한 적 없다고 해요.'],
      [[2,420],'두 학교의 사이를 신경 쓰지 않고 린타로를 찾아가요.'],
    ], easy:'작고 다정하지만 하고 싶은 말은 꼭 하는 소녀예요.' },
    usami:{ name:'우사미', short:'우사미', alias:['우사미'], at:[2,240], pos:[130,120], facts:[
      [[2,240],'린타로의 빨간 머리 단짝이에요. 키쿄 학생들에게 불만이 많아요.'],
    ] },
    mother:{ name:'린타로의 어머니', short:'어머니', alias:['어머니','엄마'], at:[2,960], pos:[130,360], facts:[
      [[2,960],'린타로에게 카오루코를 밀어내지 말라고 일깨워요.'],
    ] },
  },
  rels:[
    ['rintaro','kaoruko','other','케이크 가게에서 만난 사이',[1,900]],
    ['rintaro','usami','friend','단짝',[2,240]],
    ['rintaro','mother','family','아들과 어머니',[2,960]],
  ],
  terms:{
    kikyo:{ name:'키쿄 학원', alias:['키쿄'], at:[1,0], facts:[[[1,0],'품격 있는 명문 여고예요.'],[[2,240],'치도리 학생들을 차갑게 대해요.']] },
    chidori:{ name:'치도리 고교', alias:['치도리'], at:[1,0], facts:[[[1,0],'키쿄 학원 바로 옆의 남고예요. 거칠다는 평판이 있어요.']] },
    bakery:{ name:'케이크 가게', alias:['가게','케이크'], at:[1,570], facts:[[[1,570],'린타로 가족이 하는 가게예요. 카오루코의 단골집이에요.']], easy:'두 사람을 이어 준 달콤한 장소예요.' },
  },
  banned:['호시나','스바루','나츠사와','요리코'],
};
