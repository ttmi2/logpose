/* ============================================================
   가이드북 — F구역 코미디·일상·힐링 (1~2화, 회차 요약 자료로 확인한 범위만)
   장면 시각은 줄거리 순서에 맞춘 대략적인 위치예요.
   ============================================================ */
WORKS.natsume.guide = {
  season:'1기', eps:2, startAt:[1,0], core:['yokai','book','name'],
  episodes:{
    1:{ title:'고양이와 우인장', summary:'요괴를 볼 수 있는 소년 나츠메는 쫓기다 들어간 사당에서 봉인된 요괴를 풀어 줘요. 할머니 레이코가 남긴 「우인장」에 요괴들의 이름이 묶여 있다는 걸 알게 된 나츠메는, 그 이름을 하나씩 돌려주기로 해요.' },
    2:{ title:'이슬신의 작은 사당', summary:'모시는 사람이 줄어 힘을 잃어 가는 마을의 작은 신이 나츠메를 찾아와요. 그 신을 지금까지 찾아와 기도해 온 사람은 할머니 한 명뿐이에요.' },
  },
  scenes:{
    1:[
      { s:0,    title:'숲속의 추격', art:'forest', chars:['natsume','kitamoto','nishimura'], terms:['yokai'], sum:'외눈 요괴에게 쫓기던 나츠메가 숲에서 뛰쳐나와, 같은 반 키타모토와 니시무라에게 가장 가까운 사당이 어디냐고 물어요.' },
      { s:150,  title:'보이는 소년', art:'forest', chars:['natsume','hishigaki'], terms:['yokai'], sum:'나츠메는 어릴 때부터 요괴가 보였어요. 아무도 믿어 주지 않았고, 그래서 요괴가 싫어요. 요괴는 이름을 돌려 달라며 그를 몰아붙여요.' },
      { s:330,  title:'끊어진 금줄', art:'grave', chars:['natsume','nyanko'], terms:['seal'], sum:'사당에서 넘어지며 봉인 줄을 끊자, 복고양이 모습의 요괴가 튀어나와 나츠메를 「레이코」로 착각해요.' },
      { s:510,  title:'레이코의 손자', art:'grave', chars:['natsume','nyanko','reiko'], terms:['book'], sum:'요괴는 나츠메가 레이코의 손자라는 걸 알고, 레이코도 같은 힘을 가진 외로운 사람이었다며 「우인장」 이야기를 해요.' },
      { s:690,  title:'토코 아주머니', art:'home', chars:['natsume','touko'], terms:[], sum:'집에 돌아오자 나츠메를 맡아 키우는 먼 친척 토코 아주머니가 안색을 걱정해요. 나츠메는 자기 힘을 절대 들키지 않기로 다짐해요.' },
      { s:840,  title:'우인장', art:'home', chars:['natsume','nyanko'], terms:['book','name'], sum:'할머니가 남긴 유일한 유품 우인장에는, 레이코가 이겨서 부하로 삼은 요괴들의 이름이 적혀 있어요. 이름을 쥔 사람은 그 요괴를 부릴 수 있어요.' },
      { s:990,  title:'냥코 선생', art:'home', chars:['natsume','nyanko'], terms:['book'], sum:'우인장을 노리던 요괴는 풀어 준 은혜도 있다며 나츠메의 호위를 자처해요. 나츠메는 그를 「냥코 선생」이라고 불러요.' },
      { s:1110, title:'이름을 돌려주겠어', art:'forest', chars:['natsume','nyanko','hishigaki'], terms:['name'], sum:'외눈 요괴 히시가키가 다시 찾아오고, 나츠메는 할머니의 유산인 이름들을 주인에게 돌려주겠다고 해요. 자기가 죽으면 우인장을 주겠다는 조건으로 냥코 선생에게 방법을 배워요.' },
      { s:1230, title:'레이코의 기억', art:'flowers', chars:['natsume','hishigaki','reiko'], terms:['name'], sum:'이름을 돌려주자 요괴의 기억이 흘러들어와요. 젊은 레이코가 굶주린 히시가키와 승부해 이름을 받아 가던 모습이에요. 히시가키는 레이코가 평안한지만 묻고 사라져요.' },
      { s:1350, title:'만두 가게', art:'town', chars:['natsume','nyanko'], terms:[], sum:'돌아가는 길, 레이코가 말했던 만두 가게를 보자 냥코 선생이 신나서 달려가요.' },
    ],
    2:[
      { s:0,    title:'새 생활', art:'town', chars:['natsume','nyanko'], terms:['yokai','book'], sum:'새 마을에 익숙해진 나츠메에게, 우인장을 노리거나 이름을 돌려받으려는 요괴들이 계속 찾아와요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'작은 신', art:'grave', chars:['natsume','tsuyukami'], terms:['god'], sum:'마을의 작은 신 이슬신이 나츠메를 찾아와요.' },
      { s:420,  title:'믿음이 힘', art:'grave', chars:['tsuyukami','nyanko'], terms:['god'], sum:'신은 사람들이 모시고 기도해 줄 때 힘을 얻어요. 찾는 사람이 줄어든 이슬신은 점점 약해지고 있어요.' },
      { s:600,  title:'이름을 찾아서', art:'field', chars:['natsume','tsuyukami','nyanko'], terms:['name','book'], sum:'나츠메는 이슬신과 함께 시골길을 다니며 이름 문제를 풀기 위해 애써요.' },
      { s:780,  title:'하나 할머니', art:'grave', chars:['hana','tsuyukami'], terms:['god'], sum:'이슬신의 사당을 지금까지 찾아와 기도하는 사람은 하나 할머니 한 명뿐이에요. 그 기도 덕분에 이슬신은 이 세상에 머물러 있어요.' },
      { s:960,  title:'방심하지 마', art:'forest', chars:['nyanko','natsume'], terms:['yokai'], sum:'냥코 선생은 살아남으려면 절대 방심하지 말라고 나츠메에게 말해요.' },
      { s:1110, title:'돌아온 이름', art:'grave', chars:['natsume','tsuyukami'], terms:['name'], sum:'이슬신은 이름을 되찾지만, 그래도 점점 희미해져 가요.' },
      { s:1260, title:'다음 생에는', art:'flowers', chars:['tsuyukami','hana'], terms:['god'], sum:'하나 할머니가 세상을 떠나고, 이슬신의 시간도 함께 끝나 가요. 단 한 번 마주쳤을 뿐인 두 사람이지만, 이슬신은 다음 생에서는 손이 닿을 거라 믿어요.' },
    ],
  },
  chars:{
    natsume:{ name:'나츠메 타카시', short:'나츠메', alias:['나츠메','타카시'], at:[1,0], pos:[300,230], facts:[
      [[1,0],'요괴를 볼 수 있는 전학생이에요.'],
      [[1,150],'아무도 믿어 주지 않아 요괴를 싫어해요.'],
      [[1,1110],'우인장의 이름들을 주인에게 돌려주기로 해요.'],
    ], easy:'보이지 않는 것이 보여서 외로웠던, 마음 여린 소년이에요.' },
    kitamoto:{ name:'키타모토 아츠시', short:'키타모토', alias:['키타모토'], at:[1,0], pos:[110,380], facts:[
      [[1,0],'나츠메의 반 친구예요. 요괴는 못 봐요.'],
    ] },
    nishimura:{ name:'니시무라 사토루', short:'니시무라', alias:['니시무라'], at:[1,0], pos:[200,420], facts:[
      [[1,0],'나츠메의 반 친구예요. 요괴는 못 봐요.'],
    ] },
    hishigaki:{ name:'히시가키', short:'히시가키', alias:['히시가키','외눈 요괴'], at:[1,150], pos:[480,370], facts:[
      [[1,150],'나츠메를 쫓아온 외눈 요괴예요. 이름을 돌려받고 싶어 해요.'],
      [[1,1230],'오래전 레이코에게 승부에서 져 이름을 내줬어요.'],
    ] },
    nyanko:{ name:'냥코 선생', short:'냥코 선생', alias:['냥코 선생','냥코','마다라'], at:[1,330], pos:[470,140], facts:[
      [[1,330],'사당에 봉인돼 있던 강한 요괴예요. 평소엔 복고양이 모습이에요.'],
      [[1,990],'우인장을 노리면서도 나츠메의 호위를 자처해요.'],
      [[1,1350],'만두를 좋아해요.'],
    ], easy:'통통한 고양이 모습의 츤데레 보디가드예요.' },
    reiko:{ name:'나츠메 레이코', short:'레이코', alias:['레이코'], at:[1,330], pos:[130,110], facts:[
      [[1,330],'나츠메의 돌아가신 할머니예요.'],
      [[1,510],'나츠메와 같은 힘을 가졌고, 외로운 사람이었어요.'],
      [[1,840],'요괴들을 이겨 그 이름을 우인장에 받아 냈어요.'],
    ] },
    touko:{ name:'토코', short:'토코', alias:['토코','아주머니'], at:[1,690], pos:[130,280], facts:[
      [[1,690],'나츠메를 맡아 키우는 먼 친척이에요. 다정해요.'],
    ] },
    tsuyukami:{ name:'이슬신', short:'이슬신', alias:['이슬신','츠유카미'], at:[2,240], pos:[540,260], facts:[
      [[2,240],'마을의 작은 신이에요.'],
      [[2,420],'모시는 사람이 줄어 점점 약해지고 있어요.'],
      [[2,1110],'이름을 되찾아요.'],
    ] },
    hana:{ name:'하나', short:'하나', alias:['하나','할머니'], at:[2,780], pos:[300,410], facts:[
      [[2,780],'이슬신의 사당에 끝까지 기도하러 온 할머니예요.'],
    ] },
  },
  rels:[
    ['natsume','nyanko','other','우인장을 지키는 소년과 호위 요괴',[1,990]],
    ['natsume','reiko','family','손자와 할머니',[1,510]],
    ['natsume','touko','family','맡아 키워 주는 친척',[1,690]],
    ['natsume','kitamoto','peer','반 친구',[1,0]],
    ['natsume','nishimura','peer','반 친구',[1,0]],
    ['reiko','hishigaki','other','이름을 받아 간 사람',[1,1230]],
    ['hana','tsuyukami','other','기도하는 사람과 신',[2,780]],
  ],
  terms:{
    yokai:{ name:'요괴', alias:['요괴'], at:[1,0], facts:[[[1,0],'보통 사람 눈에는 보이지 않는 존재예요. 나츠메는 볼 수 있어요.']] },
    seal:{ name:'봉인', alias:['봉인','금줄'], at:[1,330], facts:[[[1,330],'사당에 요괴를 가둬 두던 줄이에요. 나츠메가 넘어지며 끊었어요.']] },
    book:{ name:'우인장', alias:['우인장'], at:[1,510], facts:[[[1,510],'레이코가 남긴 책이에요.'],[[1,840],'레이코가 이긴 요괴들의 이름이 적혀 있어요.']], easy:'요괴들의 이름을 모아 둔 「계약서 묶음」이에요.' },
    name:{ name:'이름 돌려주기', alias:['이름','이름을 돌려'], at:[1,840], facts:[[[1,840],'이름을 쥔 사람은 그 요괴를 부릴 수 있어요.'],[[1,1230],'이름을 돌려주면 그 요괴의 기억이 나츠메에게 흘러들어와요.']] },
    god:{ name:'작은 신', alias:['신','사당'], at:[2,240], facts:[[[2,240],'마을을 지키는 작은 신이에요.'],[[2,420],'사람들의 믿음과 기도로 힘을 얻어요.']] },
  },
  banned:['나토리','타누마','타키','히노에','마토바'],
};

WORKS.saiki.guide = {
  season:'1기', eps:2, startAt:[1,0], core:['psychic','hide','nendou'],
  episodes:{
    1:{ title:'초능력자의 재난', summary:'뭐든 할 수 있는 초능력자 사이키 쿠스오. 바라는 건 남들 눈에 띄지 않는 평범한 생활뿐인데, 마음을 읽을 수 없는 바보 친구, 중2병 친구, 자칭 학교 최고의 미소녀가 차례로 그의 평화를 흔들어요.' },
    2:{ title:'열혈! 피구', summary:'체육 시간 피구에서 열혈 학급위원 하이로가 반 전체를 불태워요. 능력을 숨기려 일찍 아웃되려던 사이키는, 정신을 차려 보니 하이로와 단둘이 코트에 남아 있어요.' },
  },
  scenes:{
    1:[
      { s:0,    title:'초능력자의 고민', art:'classroom', chars:['saiki'], terms:['psychic'], sum:'사이키 쿠스오는 텔레파시, 염력, 투시까지 거의 모든 초능력을 가졌어요. 그래서 오히려 인생이 재미없고 귀찮아요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'튀지 않기', art:'classroom', chars:['saiki'], terms:['hide'], sum:'사이키의 목표는 능력을 숨기고 눈에 띄지 않게 사는 거예요.' },
      { s:390,  title:'사이키의 부모님', art:'home', chars:['saiki','parents'], terms:['psychic'], sum:'태평한 사이키의 부모님이 티격태격하자, 사이키는 몰래 능력을 써서 두 사람을 화해시켜요.' },
      { s:570,  title:'최악의 친구 넨도', art:'classroom', chars:['saiki','nendou'], terms:['nendou'], sum:'친구를 자처하는 넨도는 너무 단순해서 머릿속이 텅 비어 있어요. 사이키가 유일하게 마음을 읽을 수 없는 사람이에요.' },
      { s:750,  title:'넨도의 인공호흡', art:'street', chars:['saiki','nendou'], terms:['nendou'], sum:'넨도는 필요도 없는 사람에게 인공호흡을 하려 들어 한바탕 소동이 벌어져요.' },
      { s:930,  title:'칠흑의 날개 카이도', art:'classroom', chars:['saiki','kaido'], terms:['chuuni'], sum:'중2병 반 친구 카이도는 오른팔에 괴물이 산다고 믿어요.' },
      { s:1080, title:'뱀 소동', art:'classroom', chars:['kaido','saiki'], terms:['chuuni'], sum:'뱀이 탈출하자 카이도는 거창한 이름을 붙이고 비장하게 맞서려 해요. 사이키는 뒤에서 몰래 수습해요.' },
      { s:1230, title:'완벽 미소녀 테루하시', art:'classroom', chars:['teruhashi','saiki'], terms:['hide'], sum:'자칭 학교 최고의 미소녀 테루하시는 사이키에게 반했다고 정하고 다가오지만, 사이키는 그 관심이 귀찮을 뿐이에요.' },
      { s:1350, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
    ],
    2:[
      { s:0,    title:'체육 시간', art:'gym', chars:['saiki','hairo'], terms:['dodgeball'], sum:'체육 시간에 피구를 하게 돼요. 다들 유치하다며 불평하지만, 학급위원 하이로가 진심으로 하자고 뜨겁게 외쳐요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'불타는 반', art:'gym', chars:['hairo','saiki'], terms:['dodgeball'], sum:'하이로의 뜨거운 플레이에 반 전체가 달아올라요.' },
      { s:390,  title:'일찍 아웃되자', art:'gym', chars:['saiki'], terms:['hide','dodgeball'], sum:'사이키는 능력이 들키지 않게 일찍 공에 맞고 나가려 하지만, 이상하게 아웃이 되지 않아요.' },
      { s:540,  title:'단둘이 남다', art:'gym', chars:['saiki','hairo','nendou'], terms:['dodgeball'], sum:'정신을 차려 보니 코트에는 사이키와 하이로 둘만 남았고, 「피구의 넨짱」을 자처하는 넨도까지 승부에 끼어들어요.' },
      { s:780,  title:'승부의 끝', art:'gym', chars:['saiki','hairo','nendou'], terms:['dodgeball'], sum:'사이키는 눈에 띄지 않게 승부를 끝내려 머리를 굴려요.' },
      { s:930,  title:'사랑의 소동', art:'classroom', chars:['saiki'], terms:['psychic'], sum:'이번엔 사랑을 둘러싼 소동이 사이키 주변에서 벌어져요.' },
      { s:1080, title:'사이키네 집 대개조', art:'home', chars:['saiki','parents'], terms:['psychic'], sum:'사이키네 집에 큰일이 생기고, 사이키는 능력을 써서 수습하려 해요.' },
      { s:1230, title:'마인드 컨트롤', art:'classroom', chars:['saiki'], terms:['psychic'], sum:'사이키는 사람들의 기억과 생각을 바꾸는 마인드 컨트롤로 상황을 속여 넘기려 해요.' },
      { s:1350, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
    ],
  },
  chars:{
    saiki:{ name:'사이키 쿠스오', short:'사이키', alias:['사이키','쿠스오'], at:[1,0], pos:[300,230], facts:[
      [[1,0],'거의 모든 초능력을 가진 고등학생이에요.'],
      [[1,240],'능력을 숨기고 평범하게 살고 싶어 해요.'],
    ], easy:'세상 최강인데 소원은 「아무도 나한테 신경 안 쓰기」인 소년이에요.' },
    parents:{ name:'사이키의 부모님', short:'부모님', alias:['부모님','엄마','아빠'], at:[1,390], pos:[120,380], facts:[
      [[1,390],'아들의 초능력을 알고 있지만 늘 태평한 부모님이에요.'],
    ] },
    nendou:{ name:'넨도 리키', short:'넨도', alias:['넨도','리키'], at:[1,570], pos:[470,130], facts:[
      [[1,570],'사이키의 친구를 자처하는 단순한 남학생이에요. 사이키가 마음을 읽지 못해요.'],
    ] },
    kaido:{ name:'카이도 슌', short:'카이도', alias:['카이도','칠흑의 날개'], at:[1,930], pos:[130,120], facts:[
      [[1,930],'오른팔에 괴물이 산다고 믿는 중2병 반 친구예요.'],
    ] },
    teruhashi:{ name:'테루하시 코코미', short:'테루하시', alias:['테루하시','코코미'], at:[1,1230], pos:[480,360], facts:[
      [[1,1230],'자칭 학교 최고의 미소녀예요. 사이키에게 반했다고 정해요.'],
    ] },
    hairo:{ name:'하이로 쿠시', short:'하이로', alias:['하이로'], at:[2,0], pos:[300,410], facts:[
      [[2,0],'뭐든 진심으로 뜨겁게 하는 학급위원이에요.'],
    ] },
  },
  rels:[
    ['saiki','parents','family','아들과 부모님',[1,390]],
    ['saiki','nendou','friend','넨도가 자처하는 친구',[1,570]],
    ['saiki','kaido','friend','반 친구',[1,930]],
    ['teruhashi','saiki','other','일방적인 관심',[1,1230]],
    ['hairo','saiki','peer','학급위원과 반 친구',[2,0]],
  ],
  terms:{
    psychic:{ name:'초능력', alias:['초능력','텔레파시','염력'], at:[1,0], facts:[[[1,0],'사이키는 마음 읽기, 염력, 투시 등 거의 모든 초능력을 가졌어요.']], easy:'뭐든 되니까 오히려 재미가 없는 능력이에요.' },
    hide:{ name:'평범하게 살기', alias:['평범','숨기기'], at:[1,240], facts:[[[1,240],'사이키의 가장 큰 목표예요. 능력을 들키지 않는 것이에요.']] },
    nendou:{ name:'마음이 안 읽히는 남자', alias:['마음이 안 읽히는'], at:[1,570], facts:[[[1,570],'넨도는 생각이 너무 단순해 사이키도 마음을 읽을 수 없어요.']] },
    chuuni:{ name:'중2병', alias:['중2병'], at:[1,930], facts:[[[1,930],'자기가 특별한 힘을 가졌다고 상상하며 행동하는 걸 말해요. 카이도가 그래요.']] },
    dodgeball:{ name:'피구', alias:['피구'], at:[2,0], facts:[[[2,0],'체육 시간 경기예요. 하이로가 열정을 불태워요.']] },
  },
  banned:['토리츠카','치요','아이우라','쿠루미'],
};

WORKS.catcleaner.guide = {
  season:'1기', eps:2, startAt:[1,0], core:['yukichi','saku','house'],
  episodes:{
    1:{ title:'야무진 고양이는 오늘도 우울', summary:'회사원 사쿠의 집에는 커다란 검은 고양이 유키치가 살아요. 유키치는 요리부터 청소까지 집안일을 척척 해내며 사쿠를 돌봐요.' },
    2:{ title:'야무진 고양이는 커졌다', summary:'눈 오는 밤, 사쿠에게 구조된 새끼 고양이 유키치는 그녀를 돌보기로 결심했어요. 회사 상사가 유키치를 직접 봤을지도 모르는 상황에 사쿠가 허둥대요.' },
  },
  scenes:{
    1:[
      { s:0,    title:'도쿄의 아침', art:'city', chars:['saku','yukichi'], terms:['house'], sum:'아침의 도쿄. 도시락이 싸이고, 잠든 사쿠가 깨워져요. 사쿠는 출근길에 나서요.' },
      { s:240,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:330,  title:'회사에서', art:'office', chars:['saku'], terms:[], sum:'회사 동료가 반려동물을 키우면 결혼을 못 한다고 말하자 사쿠는 걱정에 빠져요.' },
      { s:510,  title:'일어나기 싫은 아침', art:'home', chars:['saku','yukichi'], terms:['yukichi'], sum:'출근하기 싫어 버티는 사쿠의 가슴 위에 유키치가 올라앉아요.' },
      { s:690,  title:'요리 방송', art:'home', chars:['yukichi'], terms:['yukichi'], sum:'유키치는 텔레비전 요리 방송을 진지하게 보며 공부해요.' },
      { s:870,  title:'만두와 맥주', art:'home', chars:['saku','yukichi'], terms:['house'], sum:'달걀 요리와 만두, 그리고 맥주. 유키치가 차린 저녁상이에요.' },
      { s:1050, title:'작은 바구니', art:'home', chars:['yukichi'], terms:['yukichi'], sum:'유키치는 자기 몸에 한참 작은 고양이 바구니에 머리만 박은 채 잠들어요.' },
      { s:1200, title:'몸무게 재기', art:'home', chars:['saku','yukichi'], terms:['house'], sum:'유키치는 사쿠의 몸무게를 재겠다며 집 안을 쫓아다니고, 조금 덜 먹으라고 잔소리해요.' },
      { s:1350, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
    ],
    2:[
      { s:0,    title:'눈 오는 밤', art:'night', chars:['yukichi','saku'], terms:['yukichi'], sum:'몇 년 전 눈보라 치던 밤, 사쿠가 새끼 검은 고양이를 데려왔어요. 그 고양이가 유키치예요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'유키치의 결심', art:'home', chars:['yukichi','saku'], terms:['house'], sum:'자신을 구해 준 사쿠를 돌보기로 결심한 유키치. 그게 얼마나 큰일인지는 그땐 몰랐어요.' },
      { s:450,  title:'커져 버린 고양이', art:'home', chars:['yukichi'], terms:['yukichi'], sum:'작던 새끼 고양이는 이제 사쿠보다 훨씬 커다란 고양이가 됐어요.' },
      { s:660,  title:'살림꾼', art:'home', chars:['yukichi'], terms:['house'], sum:'유키치는 요리 솜씨에 자부심이 있고, 마트 할인 소식에 설레요.' },
      { s:870,  title:'상사의 목격?', art:'office', chars:['saku'], terms:[], sum:'회사 상사가 유키치를 직접 봤을지도 모른다는 생각에 사쿠는 혼비백산해요.' },
      { s:1080, title:'진정하세요', art:'home', chars:['saku','yukichi'], terms:['house'], sum:'허둥대는 사쿠를 유키치가 술 한 잔으로 진정시켜요.' },
      { s:1260, title:'오늘도', art:'home', chars:['saku','yukichi'], terms:['house'], sum:'사쿠와 유키치의 하루가 또 이렇게 저물어요.' },
    ],
  },
  chars:{
    saku:{ name:'후쿠자와 사쿠', short:'사쿠', alias:['사쿠','후쿠자와'], at:[1,0], pos:[300,230], facts:[
      [[1,0],'도쿄의 회사원이에요. 생활력은 조금 부족해요.'],
      [[2,0],'눈보라 치던 밤 새끼 고양이 유키치를 데려왔어요.'],
    ], easy:'일은 열심히 하지만 집에선 고양이 신세를 지는 직장인이에요.' },
    yukichi:{ name:'유키치', short:'유키치', alias:['유키치'], at:[1,0], pos:[470,140], facts:[
      [[1,0],'사쿠와 사는 커다란 검은 고양이예요. 집안일을 도맡아요.'],
      [[1,690],'요리 방송으로 공부해요.'],
      [[2,240],'자신을 구해 준 사쿠를 돌보기로 결심했어요.'],
    ], easy:'세상에서 제일 듬직한 살림꾼 고양이예요.' },
  },
  rels:[
    ['saku','yukichi','family','함께 사는 가족',[1,0]],
  ],
  terms:{
    house:{ name:'집안일', alias:['집안일','살림','요리'], at:[1,0], facts:[[[1,0],'유키치가 도맡아 하는 일이에요.']] },
    yukichi:{ name:'커다란 고양이', alias:['고양이'], at:[1,510], facts:[[[1,510],'유키치는 사쿠보다 덩치가 큰 고양이예요.']] },
    saku:{ name:'사쿠의 회사', alias:['회사','상사'], at:[1,330], facts:[[[1,330],'사쿠가 다니는 회사예요.'],[[2,870],'상사가 유키치를 봤을지도 몰라요.']] },
  },
  banned:[],
};

WORKS.apothecary.guide = {
  season:'1기', eps:2, startAt:[1,0], core:['rearpalace','poison','jinshi'],
  episodes:{
    1:{ title:'마오마오', summary:'약사의 딸 마오마오는 납치되어 후궁의 하녀로 팔려 와요. 황제의 아이들이 저주로 쇠약해진다는 소문의 진짜 원인을 알아챈 마오마오는 몰래 경고를 남기고, 그 일로 환관 진시의 눈에 띄어요.' },
    2:{ title:'무뚝뚝한 약사', summary:'교쿠요 비의 시녀가 된 마오마오는 독 시식을 맡아요. 진시는 병사들이 식사 후 쓰러진 사건의 원인을 묻고, 미약을 만들어 달라는 엉뚱한 부탁까지 해요.' },
  },
  scenes:{
    1:[
      { s:0,    title:'팔려 온 소녀', art:'town', chars:['maomao'], terms:['rearpalace'], sum:'도성 변두리 약사의 딸 마오마오는 납치되어 황궁 후궁의 빨래 하녀로 팔려 와요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'후궁', art:'home', chars:['maomao'], terms:['rearpalace'], sum:'후궁에는 황제의 비들과 환관, 시녀들이 살아요. 마오마오는 조용히 일하며 지내요.' },
      { s:420,  title:'두 비의 충돌', art:'home', chars:['maomao','gyokuyou','lihua'], terms:['curse'], sum:'석 달 뒤, 교쿠요 비와 리화 비가 부딪쳐요. 두 비의 아이가 모두 저주로 쇠약해진다는 소문이 돌아요.' },
      { s:600,  title:'저주가 아니야', art:'home', chars:['maomao'], terms:['poison','curse'], sum:'마오마오는 비들이 쓰는 분에 든 독(납)이 원인이라고 짐작해요.' },
      { s:780,  title:'창가의 쪽지', art:'night', chars:['maomao'], terms:['poison'], sum:'마오마오는 두 비의 창가에 이름 없이 경고 쪽지를 남겨요.' },
      { s:930,  title:'갈린 운명', art:'home', chars:['gyokuyou','lihua'], terms:['poison'], sum:'리화 비 쪽 시녀는 경고를 무시해 아이를 잃고, 경고를 따른 교쿠요 비의 딸은 살아나요.' },
      { s:1110, title:'아름다운 환관', art:'home', chars:['jinshi','maomao'], terms:['jinshi'], sum:'아름다운 환관 진시는 자기 필체를 읽을 수 있는 하녀가 마오마오뿐이라는 걸 알아내고, 쪽지를 쓴 사람이 그녀라는 걸 눈치채요.' },
      { s:1260, title:'시녀가 되다', art:'home', chars:['jinshi','gyokuyou','maomao'], terms:['rearpalace'], sum:'진시가 마오마오를 교쿠요 비에게 데려가고, 교쿠요 비는 감사의 뜻으로 그녀를 시녀로 삼아요.' },
    ],
    2:[
      { s:0,    title:'쓰러진 병사들', art:'battle', chars:['jinshi'], terms:['poison'], sum:'바깥 마을에서 병사들이 식사 후 독에 쓰러지고, 진시는 마을 촌장이 범인이라고 판단해요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'독 시식 담당', art:'home', chars:['maomao','gyokuyou'], terms:['taster'], sum:'교쿠요 비의 시녀가 된 마오마오는 음식에 독이 있는지 먼저 먹어 보는 독 시식을 맡아요.' },
      { s:420,  title:'안쓰러운 신입', art:'home', chars:['maomao'], terms:['taster'], sum:'붕대 감은 팔과 독 시식 담당이라는 처지를 안쓰러워한 동료 시녀들이 일을 대신해 주지만, 마오마오는 금세 일을 익혀요.' },
      { s:600,  title:'진시의 질문', art:'home', chars:['jinshi','maomao'], terms:['poison'], sum:'진시가 병사들의 중독 사건에 대해 의견을 묻자, 마오마오는 음식이 아니라 땔감에서 나온 독한 연기가 원인이라고 답해요.' },
      { s:810,  title:'엉뚱한 부탁', art:'home', chars:['jinshi','maomao'], terms:['medicine'], sum:'진시는 마오마오에게 미약을 만들어 달라며 궁중 의관의 약재를 쓸 수 있게 해 줘요.' },
      { s:990,  title:'초콜릿 약', art:'home', chars:['maomao'], terms:['medicine'], sum:'마오마오는 초콜릿을 이용한 약을 만들어요. 그런데 교쿠요 비의 시녀 셋이 시험용을 먼저 먹어 버렸어요.' },
      { s:1140, title:'세 배', art:'home', chars:['maomao','gyokuyou'], terms:['medicine'], sum:'마오마오는 그 약이 보통 미약보다 세 배는 강하다고 밝혀요.' },
      { s:1290, title:'솔직한 경고', art:'home', chars:['gyokuyou','maomao'], terms:['medicine'], sum:'황제께 써도 되겠냐는 교쿠요 비에게 마오마오가 효과를 솔직하게 경고하자, 교쿠요 비는 눈에 띄게 당황해요.' },
    ],
  },
  chars:{
    maomao:{ name:'마오마오', short:'마오마오', alias:['마오마오'], at:[1,0], pos:[300,230], facts:[
      [[1,0],'약사의 딸이에요. 납치되어 후궁 하녀로 팔려 왔어요.'],
      [[1,600],'약과 독에 대한 지식이 뛰어나요.'],
      [[1,1260],'교쿠요 비의 시녀가 돼요.'],
      [[2,240],'독 시식을 맡아요.'],
    ], easy:'독과 약 이야기에만 눈이 반짝이는, 무뚝뚝한 천재 약사예요.' },
    gyokuyou:{ name:'교쿠요 비', short:'교쿠요', alias:['교쿠요','교쿠요 비'], at:[1,420], pos:[470,130], facts:[
      [[1,420],'황제의 비 중 한 명이에요. 딸이 쇠약해져 있었어요.'],
      [[1,930],'경고를 따라 딸을 지켜요.'],
      [[1,1260],'마오마오를 시녀로 삼아요.'],
    ] },
    lihua:{ name:'리화 비', short:'리화', alias:['리화','리화 비'], at:[1,420], pos:[130,110], facts:[
      [[1,420],'황제의 비 중 한 명이에요. 아들이 쇠약해져 있었어요.'],
      [[1,930],'시녀가 경고를 무시해 아이를 잃어요.'],
    ] },
    jinshi:{ name:'진시', short:'진시', alias:['진시'], at:[1,1110], pos:[480,360], facts:[
      [[1,1110],'후궁을 관리하는 아름다운 환관이에요. 쪽지를 쓴 사람이 마오마오라는 걸 알아내요.'],
      [[2,810],'마오마오에게 미약을 만들어 달라고 해요.'],
    ], easy:'모두를 홀리는 미모에 속을 알 수 없는 환관이에요.' },
  },
  rels:[
    ['gyokuyou','maomao','other','비와 시녀',[1,1260]],
    ['gyokuyou','lihua','rival','후궁의 비들',[1,420]],
    ['jinshi','maomao','other','일을 맡기는 환관과 약사',[1,1110]],
  ],
  terms:{
    rearpalace:{ name:'후궁', alias:['후궁'], at:[1,0], facts:[[[1,0],'황제의 비들과 시녀, 환관들이 사는 궁궐 안쪽이에요.']], easy:'수천 명이 사는, 황제를 위한 거대한 궁 안의 마을이에요.' },
    curse:{ name:'저주 소문', alias:['저주'], at:[1,420], facts:[[[1,420],'황제의 아이들이 저주로 쇠약해진다는 소문이에요.']] },
    poison:{ name:'독', alias:['독','납','분'], at:[1,600], facts:[[[1,600],'마오마오는 비들이 쓰는 분에 든 독(납)이 원인이라고 봤어요.'],[[2,600],'병사들의 중독은 땔감 연기 때문이었어요.']] },
    jinshi:{ name:'진시의 필체', alias:['필체','쪽지'], at:[1,1110], facts:[[[1,1110],'진시의 글씨를 읽을 수 있는 하녀는 마오마오뿐이었어요.']] },
    taster:{ name:'독 시식', alias:['독 시식','독견'], at:[2,240], facts:[[[2,240],'비가 먹기 전에 음식에 독이 있는지 먼저 먹어 보는 일이에요.']] },
    medicine:{ name:'미약', alias:['미약','초콜릿'], at:[2,810], facts:[[[2,810],'진시가 부탁한 약이에요.'],[[2,1140],'마오마오의 약은 보통보다 세 배 강해요.']] },
  },
  banned:['라칸','교쿠요의 아이','리슈','아둘','가오슌'],
};

WORKS.gintama.guide = {
  season:'1기', eps:2, startAt:[1,0], core:['amanto','swordban','yorozuya'],
  episodes:{
    1:{ title:'너희들!! 그래도 은혼 달렸냐 (전편)', summary:'외계인 「천인」이 지배하게 된 에도. 칼을 빼앗긴 시대에 목검을 차고 다니는 해결사 긴토키와 동료들이 소개돼요. 1·2화는 이어지는 애니 오리지널 이야기예요.' },
    2:{ title:'너희들!! 그래도 은혼 달렸냐 (후편)', summary:'해결사 일행은 지진으로 에도를 무너뜨리려는 천인들의 음모에 휘말려요. 마지막에 긴토키가 장치를 멈춰 세워요.' },
  },
  scenes:{
    1:[
      { s:0,    title:'천인이 온 에도', art:'city', chars:[], terms:['amanto','swordban'], sum:'에도 시대 말, 외계인 「천인」이 쳐들어와 막부는 항복하고, 사무라이들은 칼을 빼앗겼어요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'해결사 긴짱', art:'office', chars:['gintoki'], terms:['yorozuya'], sum:'은발 곱슬머리의 사카타 긴토키는 뭐든 맡아 주는 「해결사」를 운영해요. 허리에는 목검을 차고 다녀요.' },
      { s:420,  title:'신파치', art:'office', chars:['shinpachi','gintoki'], terms:['yorozuya'], sum:'안경 쓴 소년 신파치는 긴토키 밑에서 일하는 직원이에요. 만담의 태클 담당이에요.' },
      { s:600,  title:'카구라', art:'office', chars:['kagura','gintoki','shinpachi'], terms:['amanto','yorozuya'], sum:'괴력을 가진 외계인 소녀 카구라도 해결사 식구예요.' },
      { s:780,  title:'폐도령', art:'street', chars:['gintoki','shinpachi','kagura'], terms:['swordban'], sum:'칼을 차고 다니면 안 된다는 폐도령 때문에, 해결사 일행은 단속에 쫓기게 돼요.' },
      { s:960,  title:'쫓고 쫓기는', art:'street', chars:['gintoki','shinpachi','kagura'], terms:['swordban'], sum:'에도 거리를 누비는 추격전 속에서, 개성 넘치는 사람들이 잔뜩 얼굴을 비춰요.' },
      { s:1140, title:'수상한 움직임', art:'city', chars:[], terms:['amanto'], sum:'한편, 에도를 무너뜨리려는 천인들의 음모가 꿈틀대요.' },
      { s:1290, title:'후편으로', art:'city', chars:['gintoki'], terms:[], sum:'이야기는 후편으로 이어져요.' },
    ],
    2:[
      { s:0,    title:'다시 시작', art:'city', chars:['gintoki','shinpachi','kagura'], terms:['yorozuya'], sum:'전편에 이어, 해결사 일행의 소동이 계속돼요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'지진 장치', art:'city', chars:[], terms:['amanto','quake'], sum:'천인들은 인공 지진으로 에도를 무너뜨릴 계획을 세워요.' },
      { s:450,  title:'휘말린 해결사', art:'battle', chars:['gintoki','shinpachi','kagura'], terms:['quake'], sum:'해결사 일행은 얼떨결에 그 음모에 휘말려요.' },
      { s:690,  title:'카구라의 괴력', art:'battle', chars:['kagura'], terms:['amanto'], sum:'카구라는 외계인다운 괴력으로 적들을 날려 버려요.' },
      { s:900,  title:'신파치의 태클', art:'battle', chars:['shinpachi','gintoki'], terms:[], sum:'정신없는 상황에도 신파치는 긴토키에게 날카로운 태클을 멈추지 않아요.' },
      { s:1110, title:'긴토키의 한 방', art:'battle', chars:['gintoki'], terms:['quake'], sum:'마지막 순간, 긴토키가 지진 장치를 멈춰 세워요.' },
      { s:1290, title:'평소의 해결사', art:'office', chars:['gintoki','shinpachi','kagura'], terms:['yorozuya'], sum:'소동이 끝나고, 해결사는 다시 평소처럼 돌아가요.' },
    ],
  },
  chars:{
    gintoki:{ name:'사카타 긴토키', short:'긴토키', alias:['긴토키','긴짱','긴상'], at:[1,240], pos:[300,230], facts:[
      [[1,240],'해결사를 운영하는 은발 곱슬머리 사무라이예요. 목검을 차고 다녀요.'],
      [[2,1110],'지진 장치를 멈춰 세워요.'],
    ], easy:'평소엔 게으르고 단 거 좋아하는 아저씨인데, 결정적일 땐 제일 멋진 사람이에요.' },
    shinpachi:{ name:'시무라 신파치', short:'신파치', alias:['신파치','안경'], at:[1,420], pos:[470,140], facts:[
      [[1,420],'해결사에서 일하는 안경 쓴 소년이에요. 태클 담당이에요.'],
    ] },
    kagura:{ name:'카구라', short:'카구라', alias:['카구라'], at:[1,600], pos:[470,340], facts:[
      [[1,600],'괴력을 가진 외계인 소녀예요. 해결사 식구예요.'],
    ] },
  },
  rels:[
    ['gintoki','shinpachi','peer','해결사 사장과 직원',[1,420]],
    ['gintoki','kagura','peer','해결사 식구',[1,600]],
    ['shinpachi','kagura','peer','해결사 동료',[1,600]],
  ],
  terms:{
    amanto:{ name:'천인', alias:['천인','외계인'], at:[1,0], facts:[[[1,0],'에도에 쳐들어와 실권을 쥔 외계인들이에요.']], easy:'사무라이 시대에 갑자기 찾아온 외계인 지배자들이에요.' },
    swordban:{ name:'폐도령', alias:['폐도령','칼'], at:[1,0], facts:[[[1,0],'사무라이들에게서 칼을 빼앗은 법이에요.'],[[1,780],'해결사 일행은 이 때문에 쫓기게 돼요.']] },
    yorozuya:{ name:'해결사', alias:['해결사','요로즈야'], at:[1,240], facts:[[[1,240],'돈만 주면 무슨 일이든 맡아 주는 긴토키의 가게예요.']] },
    quake:{ name:'지진 장치', alias:['지진','장치'], at:[2,240], facts:[[[2,240],'천인들이 에도를 무너뜨리려 만든 장치예요.']] },
  },
  banned:['타카스기','오토세','엘리자베스','하세가와','곤도','히지카타','오키타'],
};

WORKS.cells.guide = {
  season:'1기', eps:2, startAt:[1,0], core:['rbc','wbc','body'],
  episodes:{
    1:{ title:'폐렴구균', summary:'사람 몸속에서 산소를 나르는 적혈구 AE3803이 폐렴구균의 습격을 받고, 백혈구 U-1146이 구해 줘요. 몸속에 숨어든 세균 한 마리가 폐를 노리고 있어요.' },
    2:{ title:'찰과상', summary:'피부가 까지는 찰과상이 생기자 상처 틈으로 세균이 몰려들어요. 백혈구들이 맞서 싸우고, 혈소판들이 상처를 막으러 출동해요.' },
  },
  scenes:{
    1:[
      { s:0,    title:'몸속 세계', art:'city', chars:[], terms:['body'], sum:'사람의 몸속에는 37조 개가 넘는 세포들이 각자 맡은 일을 하며 살아가요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'길치 적혈구', art:'city', chars:['rbc'], terms:['rbc'], sum:'신입 적혈구 AE3803은 산소를 나르는 일을 하지만, 길을 자주 헤매요.' },
      { s:390,  title:'폐렴구균의 습격', art:'street', chars:['rbc'], terms:['bacteria'], sum:'적혈구가 갑자기 폐렴구균의 습격을 받아요.' },
      { s:510,  title:'백혈구 등장', art:'battle', chars:['rbc','wbc'], terms:['wbc','bacteria'], sum:'백혈구 U-1146이 나타나 세균을 해치우고 적혈구를 구해 줘요.' },
      { s:690,  title:'사라진 한 마리', art:'street', chars:['rbc','wbc'], terms:['bacteria'], sum:'세균 한 마리가 달아나 폐를 노리고 있다는 소식이 들려요. 둘은 함께 폐로 향해요.' },
      { s:870,  title:'폐에서', art:'city', chars:['rbc','wbc'], terms:['body'], sum:'폐에서 백혈구와 헤어진 적혈구는 배달을 하려고 짐을 확인해요.' },
      { s:1020, title:'짐 속의 세균', art:'battle', chars:['rbc'], terms:['bacteria'], sum:'달아난 폐렴구균은 내내 적혈구의 짐 속에 숨어 있었어요.' },
      { s:1170, title:'함정', art:'battle', chars:['wbc','rbc'], terms:['wbc','sneeze'], sum:'세균의 속셈을 미리 읽은 백혈구가 함정으로 끌어들이고, 세균은 재채기와 함께 몸 밖으로 날아가요.' },
      { s:1350, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
    ],
    2:[
      { s:0,    title:'평소의 배달', art:'city', chars:['rbc'], terms:['rbc'], sum:'적혈구들은 오늘도 산소를 나르며 혈관을 따라 이동해요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'찰과상', art:'meteor', chars:['rbc'], terms:['wound'], sum:'갑자기 피부가 까지며 혈관이 찢어지고, 적혈구들이 길을 잃어요.' },
      { s:420,  title:'몰려드는 세균', art:'battle', chars:['wbc'], terms:['wound','bacteria'], sum:'상처 틈으로 세균들이 쏟아져 들어오고, 백혈구 U-1146과 동료 백혈구들이 맞서요.' },
      { s:630,  title:'황색포도상구균', art:'battle', chars:['wbc'], terms:['bacteria'], sum:'강한 세균인 황색포도상구균이 지원군이 오기 전에 백혈구들을 쓰러뜨리려 해요.' },
      { s:840,  title:'백혈구의 승리', art:'battle', chars:['wbc','rbc'], terms:['wbc'], sum:'백혈구들은 끈질기게 싸워 세균들을 물리쳐요.' },
      { s:1020, title:'혈소판 출동', art:'street', chars:['platelets'], terms:['platelet'], sum:'작은 아이 모습의 혈소판들이 출동해 상처를 막기 시작해요.' },
      { s:1200, title:'피딱지 공사', art:'street', chars:['platelets','rbc'], terms:['platelet','wound'], sum:'혈소판들은 근처 적혈구들까지 붙잡아 상처를 막는 덩어리에 끼워 넣고, 적혈구들은 울상이 돼요.' },
      { s:1350, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
    ],
  },
  chars:{
    rbc:{ name:'적혈구 AE3803', short:'적혈구', alias:['적혈구','AE3803'], at:[1,240], pos:[300,230], facts:[
      [[1,240],'산소를 나르는 신입 적혈구예요. 길을 자주 헤매요.'],
      [[1,1020],'자기 짐에 세균이 숨어 있었어요.'],
    ], easy:'열심히는 하는데 길치인 배달부예요.' },
    wbc:{ name:'백혈구 U-1146', short:'백혈구', alias:['백혈구','U-1146','호중구'], at:[1,510], pos:[470,140], facts:[
      [[1,510],'몸에 들어온 세균을 해치우는 백혈구(호중구)예요.'],
      [[1,1170],'세균의 속셈을 미리 읽고 함정을 팠어요.'],
    ], easy:'무섭게 생겼지만 누구보다 성실한 경비원이에요.' },
    platelets:{ name:'혈소판', short:'혈소판', alias:['혈소판'], at:[2,1020], pos:[470,360], facts:[
      [[2,1020],'상처를 막는 작은 아이 모습의 세포들이에요.'],
    ] },
  },
  rels:[
    ['rbc','wbc','friend','구해 준 사이',[1,510]],
    ['platelets','rbc','other','상처 막기에 끌려간 적혈구',[2,1200]],
  ],
  terms:{
    body:{ name:'몸속 세계', alias:['몸속','세포'], at:[1,0], facts:[[[1,0],'세포들이 각자 맡은 일을 하며 사는 사람의 몸속이에요.']], easy:'우리 몸을 하나의 거대한 도시로 그린 거예요.' },
    rbc:{ name:'적혈구의 일', alias:['산소','배달'], at:[1,240], facts:[[[1,240],'온몸에 산소를 나르는 일이에요.']] },
    bacteria:{ name:'세균', alias:['세균','폐렴구균','황색포도상구균'], at:[1,390], facts:[[[1,390],'몸에 들어와 세포를 해치는 침입자예요.'],[[2,630],'황색포도상구균처럼 강한 세균도 있어요.']] },
    wbc:{ name:'백혈구의 일', alias:['면역','퇴치'], at:[1,510], facts:[[[1,510],'몸에 들어온 세균을 찾아 없애는 일이에요.']] },
    sneeze:{ name:'재채기', alias:['재채기'], at:[1,1170], facts:[[[1,1170],'몸이 세균을 밖으로 내보내는 방법 중 하나예요.']] },
    wound:{ name:'찰과상', alias:['찰과상','상처'], at:[2,240], facts:[[[2,240],'피부가 까진 상처예요. 세균이 들어오는 길이 돼요.']] },
    platelet:{ name:'혈액 응고', alias:['응고','딱지'], at:[2,1020], facts:[[[2,1020],'혈소판이 모여 상처를 막는 거예요.']] },
  },
  banned:['킬러 T세포','대식세포','수지상세포'],
};

WORKS.cooldoji.guide = {
  season:'1기', eps:2, startAt:[1,0], core:['cool','doji','four'],
  episodes:{
    1:{ title:'이치쿠라 하야테', summary:'겉보기엔 쿨한 대학생 하야테. 그런데 사소한 실수를 할 때마다 혼자 얼굴이 빨개지는, 사실은 허당이에요.' },
    2:{ title:'후타미 슌', summary:'운동 잘하는 고등학생 슌은 실수를 해도 일부러 그런 척 넘어가려 해요. 그래서 더 웃음이 나요.' },
  },
  scenes:{
    1:[
      { s:0,    title:'쿨한 남자들', art:'city', chars:[], terms:['cool'], sum:'멋있어 보이지만 사실은 허당인 남자들의 이야기가 시작돼요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'이치쿠라 하야테', art:'city', chars:['hayate'], terms:['cool'], sum:'경제학과 대학생 하야테는 누가 봐도 쿨한 미남이에요.' },
      { s:420,  title:'앗, 실수', art:'street', chars:['hayate'], terms:['doji'], sum:'그런데 하야테는 일상 곳곳에서 사소한 실수를 연발해요.' },
      { s:600,  title:'혼자 부끄러워', art:'street', chars:['hayate'], terms:['doji'], sum:'하야테는 자기 실수를 스스로 알아채고 혼자 얼굴이 빨개져요. 그 모습이 오히려 매력이에요.' },
      { s:780,  title:'좋아하는 것', art:'home', chars:['hayate'], terms:[], sum:'하야테는 동물과 책을 좋아해요.' },
      { s:960,  title:'진로 고민', art:'classroom', chars:['hayate'], terms:[], sum:'하야테는 아직 자기가 무엇을 하고 싶은지 잘 모르겠어요.' },
      { s:1140, title:'오늘의 실수', art:'street', chars:['hayate'], terms:['doji'], sum:'오늘도 하야테의 작은 실수들이 쌓여 가요.' },
      { s:1290, title:'다음 허당은', art:'city', chars:['shun'], terms:['four'], sum:'다음 회차 주인공이 될 다른 허당 남자가 살짝 모습을 보여요.' },
    ],
    2:[
      { s:0,    title:'후타미 슌', art:'gym', chars:['shun'], terms:['cool'], sum:'고등학생 슌은 농구를 하는 운동 만능 소년이에요.' },
      { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
      { s:240,  title:'실수', art:'gym', chars:['shun'], terms:['doji'], sum:'그런 슌도 엉뚱한 실수를 해요.' },
      { s:420,  title:'일부러 그런 거야', art:'gym', chars:['shun'], terms:['doji'], sum:'슌은 실수를 할 때마다 일부러 그런 척 넘어가려 해요. 그래서 더 우스워져요.' },
      { s:600,  title:'미워할 수 없는', art:'classroom', chars:['shun'], terms:['cool'], sum:'허세 섞인 모습이 우스꽝스럽지만, 미워할 수 없는 소년이에요.' },
      { s:780,  title:'일상의 함정', art:'street', chars:['shun'], terms:['doji'], sum:'일상 곳곳에 숨은 작은 함정들이 슌을 기다려요.' },
      { s:960,  title:'또 다른 허당들', art:'street', chars:['shun'], terms:['four'], sum:'슌 말고도, 다른 허당 남자들의 이야기가 기다리고 있어요.' },
      { s:1140, title:'오늘도 쿨하게', art:'city', chars:['shun'], terms:['cool'], sum:'슌은 오늘도 쿨한 척 하루를 마무리해요.' },
    ],
  },
  chars:{
    hayate:{ name:'이치쿠라 하야테', short:'하야테', alias:['하야테','이치쿠라'], at:[1,240], pos:[300,230], facts:[
      [[1,240],'경제학과 20살 대학생이에요. 겉보기엔 쿨해요.'],
      [[1,600],'실수하면 스스로 알아채고 부끄러워해요.'],
      [[1,780],'동물과 책을 좋아해요.'],
    ], easy:'멋진 얼굴에 마음은 소심한, 부끄럼 많은 대학생이에요.' },
    shun:{ name:'후타미 슌', short:'슌', alias:['슌','후타미'], at:[1,1290], pos:[470,140], facts:[
      [[1,1290],'운동을 잘하는 17살 고등학생이에요.'],
      [[2,420],'실수해도 일부러 그런 척해요.'],
    ], easy:'허세로 실수를 덮으려다 더 귀여워지는 고등학생이에요.' },
  },
  rels:[
    ['hayate','shun','other','1화와 2화의 주인공',[1,1290]],
  ],
  terms:{
    cool:{ name:'쿨한 겉모습', alias:['쿨','멋진'], at:[1,0], facts:[[[1,0],'이 작품의 남자들은 겉보기엔 모두 쿨하고 멋있어요.']] },
    doji:{ name:'허당', alias:['허당','실수','도지'], at:[1,420], facts:[[[1,420],'겉모습과 달리 자꾸 실수하는 모습이에요.']], easy:'완벽해 보이는 사람의 귀여운 빈틈이에요.' },
    four:{ name:'허당 남자들', alias:['네 명','남자들'], at:[1,1290], facts:[[[1,1290],'회차마다 다른 허당 남자가 주인공이 돼요.']] },
  },
  banned:['미마','시키 소마'],
};
