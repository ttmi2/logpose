/* ============================================================
   주력 작품 4~5화 (프리렌·데스노트, 출처 대조)
   ============================================================ */
/* ---------- 장송의 프리렌 4~5화 ---------- */
(() => {
  const g = WORKS.frieren.guide; g.eps = 5;
  g.episodes[4] = { title:'영혼이 잠드는 땅', summary:'새해 일출을 함께 본 뒤 30년 만에 아이젠을 찾아간 프리렌이, 플람메의 진짜 마도서에서 영혼이 잠드는 곳 오레올의 위치를 알아내요.' };
  g.episodes[5] = { title:'죽은 자의 환영', summary:'오레올로 가는 긴 여행을 시작한 두 사람이 환영으로 사람을 꾀는 마물을 물리치고, 용을 상대할 전사로 아이젠의 제자 슈타르크를 찾아가요.' };
  g.scenes[4] = [
    { s:0,    title:'가짜 마도서', art:'street', chars:['frieren','fern'], terms:['flammebook'], sum:'해변 청소를 해 준 대가로 프리렌은 대마법사 플람메의 것이라는 마도서를 받지만, 가짜였어요.' },
    { s:180,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
    { s:270,  title:'새해 일출', art:'hill', chars:['frieren','fern'], terms:[], sum:'새해 첫 일출을 보러 가요. 늦잠꾸러기 프리렌은 예전에 일출을 놓쳐 동료들을 서운하게 한 적이 있어요.' },
    { s:450,  title:'함께 보는 일출', art:'hill', chars:['frieren','fern'], terms:[], sum:'이번엔 제때 일어났지만 일출은 시시해 보여요. 일출을 즐기는 페른을 보고서야, 프리렌은 동료들이 함께 보고 싶어 했다는 걸 깨달아요.' },
    { s:660,  title:'30년 만의 아이젠', art:'home', chars:['frieren','fern','eisen'], terms:['flammebook'], sum:'30년 만에 만난 아이젠은 죽은 사람과 대화하는 법이 적힌 플람메의 진짜 마도서를 함께 찾아 달라고 해요. 프리렌이 힘멜과 다시 이야기해 보길 바라서예요.' },
    { s:840,  title:'스승 플람메', art:'forest', chars:['frieren','flamme'], terms:[], sum:'프리렌은 천 년 전 자신의 스승이 인간 마법사 플람메였다는 걸 떠올려요.' },
    { s:1020, title:'진짜 마도서', art:'forest', chars:['frieren','eisen','fern'], terms:['flammebook','aureole'], sum:'진짜 마도서에는 모든 영혼이 잠드는 곳 "오레올"이 대륙 가장 북쪽, 마왕성이 있던 곳에 있다고 적혀 있어요.' },
    { s:1200, title:'아이젠의 배웅', art:'home', chars:['eisen','frieren','fern'], terms:['aureole'], sum:'아이젠은 프리렌이 사람을 아끼게 됐다며 기뻐하지만, 늙어서 짐이 될 거라며 함께 가지 않아요. 그리고 마왕성까지 10년이 걸렸다는 걸 일깨워요.' },
    { s:1380, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
  ];
  g.scenes[5] = [
    { s:0,    title:'함께 가겠어요', art:'forest', chars:['frieren','fern'], terms:['aureole'], sum:'프리렌은 10년이면 페른 인생의 10분의 1일 수도 있다고 말하지만, 페른은 따라가겠다고 해요.' },
    { s:180,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
    { s:270,  title:'사라진 사람들', art:'street', chars:['frieren','fern'], terms:['einsam'], sum:'죽은 가족의 환영을 본 사람들이 사라지는 마을에 도착해요. 프리렌은 환영으로 사람을 꾀어내는 마물 아인잠의 짓이라고 짐작해요.' },
    { s:480,  title:'환영 속의 하이터', art:'night', chars:['fern','heiter','frieren'], terms:['einsam'], sum:'공격 마법으로 환영을 없앨 수 있지만, 사랑했던 사람의 모습이면 쉽게 공격하지 못해요. 페른은 하이터의 환영 앞에서 위험에 빠져요.' },
    { s:660,  title:'힘멜의 환영', art:'night', chars:['frieren','himmel','fern'], terms:['einsam'], sum:'프리렌은 힘멜의 환영을 쏘아 아인잠의 정체를 드러내고, 페른이 아인잠을 쓰러뜨려요.' },
    { s:900,  title:'용의 둥지', art:'street', chars:['frieren','fern'], terms:['dragon'], sum:'프리렌은 용의 둥지에 있는 마도서를 얻으려면 강한 전사가 필요하다고 판단해요.' },
    { s:1050, title:'아이젠의 제자', art:'home', chars:['stark','frieren','fern'], terms:[], sum:'두 사람은 근처에 사는 아이젠의 제자 슈타르크를 찾아가요. 슈타르크는 용과 눈싸움을 해서 이겼다는 소문이 있어요.' },
    { s:1200, title:'겁쟁이 전사', art:'home', chars:['stark','frieren','fern'], terms:['dragon'], sum:'슈타르크는 마물을 쓰러뜨린 적이 없고, 그때도 무서워서 얼어붙었을 뿐이라고 털어놓아요. 프리렌은 아침까지 생각할 시간을 줘요.' },
    { s:1290, title:'바위를 가르는 힘', art:'forest', chars:['frieren','fern','stark'], terms:[], sum:'페른은 의심하지만, 프리렌은 슈타르크가 아이젠의 훈련으로 도끼로 바위를 가를 만큼 강하다고 믿어요.' },
    { s:1380, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
  ];
  const c = g.chars;
  c.flamme = { name:'플람메', short:'플람메', alias:['플람메'], at:[4,0], pos:[300,70], facts:[[[4,0],'전설로 불리는 대마법사예요. 그의 것이라는 마도서가 많이 떠돌아요.'],[[4,840],'천 년 전 프리렌의 스승이었던 인간 마법사예요.']] };
  c.stark = { name:'슈타르크', short:'슈타르크', alias:['슈타르크'], at:[5,1050], pos:[565,420], facts:[[[5,1050],'아이젠의 제자인 전사예요. 용과 눈싸움을 해서 이겼다는 소문이 있어요.'],[[5,1200],'마물을 쓰러뜨린 적이 없고, 그때도 무서워서 얼어붙었을 뿐이라고 털어놓았어요.'],[[5,1290],'아이젠의 훈련 덕분에 도끼로 바위를 가를 만큼 강해요.']], easy:'실력은 엄청난데 자기만 그걸 모르는 겁 많은 신입이에요.' };
  c.eisen.facts.push([[4,660],'30년 만에 프리렌을 만나 플람메의 마도서를 함께 찾자고 했어요.'],[[4,1200],'나이가 들어 짐이 될 거라며 여행에는 함께하지 않았어요.']);
  c.frieren.facts.push([[4,450],'동료들이 왜 일출을 함께 보고 싶어 했는지 깨달았어요.'],[[5,0],'오레올까지 10년이 걸릴 수도 있는 여행을 시작했어요.'],[[5,660],'힘멜의 환영을 망설임 없이 쏘았어요.']);
  c.fern.facts.push([[5,0],'10년이 걸려도 프리렌을 따라가겠다고 했어요.'],[[5,660],'아인잠을 쓰러뜨렸어요.']);
  g.rels.push(['frieren','flamme','other','스승과 제자',[4,840]],['eisen','stark','other','스승과 제자',[5,1050]],['frieren','stark','other','함께 갈 전사 후보',[5,1050]]);
  g.terms.flammebook = { name:'플람메의 마도서', alias:['플람메의 마도서','가짜 마도서','진짜 마도서'], at:[4,0], facts:[[[4,0],'플람메의 것이라는 마도서는 가짜가 많아요.'],[[4,660],'진짜에는 죽은 사람과 대화하는 법이 적혀 있다고 해요.'],[[4,1020],'진짜 마도서에서 오레올의 위치를 알아냈어요.']] };
  g.terms.aureole = { name:'오레올', alias:['오레올','영혼이 잠드는'], at:[4,1020], facts:[[[4,1020],'모든 영혼이 잠든다는 곳이에요. 대륙 가장 북쪽, 마왕성이 있던 곳에 있어요.'],[[5,0],'프리렌과 페른이 향하는 여행의 목적지예요.']], easy:'세상 끝에 있다는, 떠난 사람을 다시 만날 수 있는 곳이에요.' };
  g.terms.einsam = { name:'아인잠', alias:['아인잠','환영'], at:[5,270], facts:[[[5,270],'죽은 사람의 환영으로 사람을 꾀어내는 마물이에요.'],[[5,480],'사랑했던 사람의 모습이라 공격하기 어려워요.']] };
  g.terms.dragon = { name:'용', alias:['용','드래곤'], at:[5,900], generic:true, facts:[[[5,900],'둥지에 마도서가 있어요. 쓰러뜨리려면 강한 전사가 필요해요.']] };
  g.banned = g.banned.filter(b => !['슈타르크','플람메','오레올','영혼이 잠드는','자인'].includes(b)).concat([' 자인']);
})();

/* ---------- 데스노트 4~5화 ---------- */
(() => {
  const g = WORKS.deathnote.guide; g.eps = 5;
  g.episodes[4] = { title:'추적', summary:'노트의 한계를 실험한 라이토가 버스 납치 소동을 꾸며, 자신을 미행하던 FBI 수사관 레이 펜버의 정체를 알아내요.' };
  g.episodes[5] = { title:'흥정', summary:'라이토는 펜버를 이용해 일본에 온 FBI 수사관들을 한꺼번에 쓰러뜨리고, L에게 암호 메시지를 남겨요.' };
  g.scenes[4] = [
    { s:0,    title:'노트의 한계', art:'darkroom', chars:['light','ryuk'], terms:['rules'], sum:'라이토는 죽음을 얼마나 조종할 수 있는지 알아보려고, 죄수들에게 탈옥을 시도하게 하거나 L의 그림을 그리게 해 봐요.' },
    { s:120,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
    { s:210,  title:'실험의 결과', art:'darkroom', chars:['light','ryuk'], terms:['rules'], sum:'몇몇 실험이 뜻대로 되지 않자, 라이토는 노트로 할 수 있는 일에 한계가 있다는 걸 알게 돼요.' },
    { s:420,  title:'미행자를 찾아라', art:'darkroom', chars:['light'], terms:[], sum:'라이토는 자신을 따라오는 사람의 정체를 알아내려고 계획을 세워요.' },
    { s:600,  title:'버스 납치', art:'street', chars:['light','ryuk'], terms:['deathnote'], sum:'라이토는 범죄자에게 노트 조각을 만지게 하고 버스를 납치하게 해요. 노트를 만진 범인에게는 류크가 보여요.' },
    { s:900,  title:'드러난 미행자', art:'street', chars:['light','penber'], terms:['fbi'], sum:'소동 속에서 라이토는 미행자가 L과 와타리를 위해 일하는 미국 연방 수사관 레이 펜버라는 걸 알아내요.' },
    { s:1200, title:'다음 수', art:'darkroom', chars:['light','ryuk'], terms:[], sum:'라이토는 펜버를 상대할 다음 수를 준비해요.' },
    { s:1350, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
  ];
  g.scenes[5] = [
    { s:0,    title:'일주일 뒤', art:'street', chars:['light','penber'], terms:[], sum:'라이토는 일주일을 기다린 뒤 펜버가 탄 전철에 따라 올라요.' },
    { s:120,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
    { s:210,  title:'전철 안의 협박', art:'street', chars:['light','penber'], terms:['fbi'], sum:'라이토는 펜버의 가족을 빌미로 협박해, 동료 FBI 수사관들의 이름을 적게 만들어요.' },
    { s:480,  title:'동시에 쓰러진 수사관들', art:'street', chars:['penber'], terms:['fbi'], sum:'일본에 있던 FBI 수사관 12명이 한꺼번에 쓰러져요.' },
    { s:690,  title:'멈춰 선 수사', art:'office', chars:['soichiro','lawl'], terms:['fbi','kira'], sum:'겁에 질린 경찰 안에서 수사를 그만두려는 사람들이 나오고, 미국 대통령은 FBI를 키라 사건에서 철수시켜요.' },
    { s:930,  title:'약혼자의 결심', art:'street', chars:[], terms:['fbi'], sum:'펜버의 약혼자였던 전직 FBI 수사관은 키라를 찾아 복수하겠다고 다짐해요.' },
    { s:1140, title:'암호 메시지', art:'office', chars:['lawl','light'], terms:['code'], sum:'라이토는 다른 범죄자를 통해 L에게 암호 메시지를 남기고, L은 고민 끝에 키라가 자신을 놀리는 거라고 판단해요.' },
    { s:1350, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
  ];
  const c = g.chars;
  c.penber = { name:'레이 펜버', short:'펜버', alias:['펜버','레이'], at:[4,900], pos:[215,80], facts:[[[4,900],'L과 와타리를 위해 일하는 미국 연방 수사관(FBI)이에요. 라이토를 미행하고 있었어요.'],[[5,480],'동료 수사관들과 함께 쓰러졌어요.']] };
  c.light.facts.push([[4,210],'노트로 죽음을 조종하는 데 한계가 있다는 걸 알아냈어요.'],[[4,900],'자신을 미행하던 사람의 정체를 알아냈어요.'],[[5,210],'펜버를 협박해 FBI 수사관들의 이름을 적게 했어요.'],[[5,1140],'L에게 암호 메시지를 남겼어요.']);
  c.lawl.facts.push([[4,900],'FBI 수사관들에게 몰래 수사를 맡겼어요.'],[[5,1140],'키라의 암호 메시지를 자신을 놀리는 것이라고 판단했어요.']);
  g.rels.push(['penber','lawl','other','L을 돕는 수사관',[4,900]],['light','penber','rival','자신을 미행하던 수사관',[4,900]]);
  g.terms.fbi = { name:'FBI', alias:['fbi','연방 수사관','수사관'], at:[4,900], facts:[[[4,900],'L의 요청으로 일본에서 몰래 수사하던 미국 연방 수사국이에요.'],[[5,690],'수사관 12명이 쓰러진 뒤 키라 사건에서 철수했어요.']] };
  g.terms.code = { name:'암호 메시지', alias:['암호','메시지'], at:[5,1140], generic:true, facts:[[[5,1140],'라이토가 범죄자를 이용해 L에게 남긴 메시지예요.']] };
  g.terms.deathnote.facts.push([[4,600],'노트 조각만 만져도 류크를 볼 수 있어요.']);
  g.banned = g.banned.filter(b => b !== '펜버');
})();
