/* ============================================================
   바이올렛 에버가든 TV판 4~13화 (회차 요약 자료로 확인한 범위만)
   장면 시각은 줄거리 순서에 맞춘 대략적인 위치예요.
   ============================================================ */
(() => {
  const g = WORKS.violet.guide; g.eps = 13;
  g.banned = g.banned.filter(b => !['클라라','매그놀리아','오스카','레온'].includes(b));
  const C = g.chars, T = g.terms, R = g.rels;
  const fact = (id, at, t) => C[id].facts.push([at, t]);
  const tfact = (id, at, t) => T[id].facts.push([at, t]);

  g.episodes[4] = { title:'당신은 도구가 아니라, 그 이름에 걸맞은 사람이 될 거야', summary:'손을 다친 아이리스를 돕기 위해 바이올렛이 아이리스의 고향으로 함께 가요. 생일 파티 초대장 일로 소동이 벌어지지만, 바이올렛의 사과 편지가 가족의 마음을 풀어 줘요.' };
  g.episodes[5] = { title:'사람과 사람을 잇는 편지를 쓰는 건가요?', summary:'두 나라의 평화를 위한 왕실 결혼. 바이올렛은 샬럿 공주의 공개 연애편지를 대필하다, 두 사람이 직접 진심을 주고받게 해 줘요.' };
  g.episodes[6] = { title:'어딘가의 별하늘 아래에서', summary:'천문대에서 귀한 책을 옮겨 적는 일을 맡은 바이올렛은 학자 레온과 함께 일해요. 함께 혜성을 보며, 레온은 바이올렛이 소령을 사랑하고 있다는 걸 알아채요.' };
  g.episodes[7] = { title:'「　」', summary:'딸을 잃은 극작가 오스카의 대본을 돕던 바이올렛은 전쟁에서 자신이 한 일을 후회하기 시작해요. 라이덴으로 돌아온 그녀는 소령에 대한 소식을 듣고 무너져요.' };
  g.episodes[8] = { title:'「　」', summary:'바이올렛은 디트프리트를 찾아가 소령의 소식을 확인하고, 소령의 저택으로 향해요. 소령에게 이름을 받고 글을 배우던 시절, 그리고 마지막 전투의 기억이 되살아나요.' };
  g.episodes[9] = { title:'바이올렛 에버가든', summary:'마지막 전투의 진실, 그리고 소령이 남긴 「사랑해」. 깊은 절망에 빠졌던 바이올렛은 동료들의 편지를 읽으며 다시 일어서요.' };
  g.episodes[10] = { title:'사랑하는 사람은 언제나 지켜보고 있어', summary:'병든 어머니 클라라가 바이올렛에게 7일 동안 편지를 맡겨요. 어머니와 떨어지는 게 싫은 어린 딸 앤, 그리고 그 편지들이 품은 약속.' };
  g.episodes[11] = { title:'더는 아무도 죽게 하고 싶지 않아', summary:'내전 중인 나라에서 한 병사가 자동 수기 인형을 부르고, 바이올렛은 위험을 무릅쓰고 전장으로 향해요. 그는 부모님과 소꿉친구에게 보낼 마지막 편지를 부탁해요.' };
  g.episodes[12] = { title:'「　」', summary:'평화 조약을 맺으러 가는 특사를 태운 열차를 반란군이 노려요. 열차에 함께 탄 바이올렛은 더는 사람을 죽이지 않겠다는 마음을 지키며 디트프리트와 마주 서요.' };
  g.episodes[13] = { title:'자동 수기 인형과 「사랑해」', summary:'다리 폭파를 막아 낸 바이올렛 덕분에 평화 조약이 맺어져요. 다시 열린 항공 축제를 맞아, 바이올렛은 소령에게 보내는 편지를 써요.' };

  g.scenes[4] = [
    { s:0,    title:'다친 손', art:'office', chars:['iris','violet','hodgins'], terms:['chpost'], sum:'아이리스가 손을 다치고, 하필 고향에서 그녀를 지명한 의뢰가 들어와요. 바이올렛이 함께 가게 돼요.' },
    { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
    { s:240,  title:'아이리스의 고향', art:'hill', chars:['iris','violet'], terms:[], sum:'산골 마을에 도착하자 아이리스는 고향에서 성공한 모습을 보여 주고 싶어 들떠요.' },
    { s:420,  title:'어머니의 속셈', art:'home', chars:['iris','violet'], terms:['birthday'], sum:'의뢰는 아이리스의 생일 파티 초대장이었어요. 어머니는 딸을 집에 데려와 짝을 찾아 주고 싶었어요.' },
    { s:600,  title:'초대장', art:'home', chars:['violet','iris'], terms:['birthday','typewriter'], sum:'다친 아이리스 대신 바이올렛이 초대장을 써요. 아이리스가 부르기 싫어한 사람에게도 초대장이 보내져요.' },
    { s:780,  title:'에이먼', art:'party', chars:['iris','emonn'], terms:['birthday'], sum:'파티에 온 사람 중에는 아이리스가 예전에 고백했다 거절당한 에이먼도 있어요.' },
    { s:960,  title:'뛰쳐나간 아이리스', art:'night', chars:['iris','violet'], terms:['birthday'], sum:'아이리스는 울며 파티장을 빠져나가요. 바이올렛은 자기 실수를 깨달아요.' },
    { s:1110, title:'사과 편지', art:'home', chars:['violet','iris'], terms:['doll'], sum:'바이올렛은 손님들과 아이리스의 부모님께 사과 편지를 써요. 부모님은 아이리스가 계속 자동 수기 인형으로 일하는 걸 허락해요.' },
    { s:1260, title:'꽃의 이름', art:'flowers', chars:['iris','violet','gilbert'], terms:['name'], sum:'아이리스는 자기가 태어날 때 핀 꽃 이름을 따서 이름을 지었다고 말해요. 바이올렛은 소령도 꽃 이름을 붙여 줬다는 걸 떠올려요.' },
    { s:1380, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
  ];
  g.scenes[5] = [
    { s:0,    title:'군의 의뢰', art:'office', chars:['violet','hodgins'], terms:['doll'], sum:'군에서 바이올렛을 지명한 의뢰가 들어와요. 행선지는 드로셀 왕국이에요.' },
    { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
    { s:240,  title:'샬럿 공주', art:'home', chars:['violet','charlotte'], terms:['royalwedding'], sum:'드로셀의 샬럿 공주는 이웃 나라 플뤼겔의 다미안 왕자와 결혼해요. 두 나라의 평화를 위한 결혼이에요.' },
    { s:420,  title:'공개 연애편지', art:'home', chars:['violet','charlotte'], terms:['royalwedding'], sum:'왕실끼리 주고받는 연애편지는 국민에게 공개돼요. 바이올렛이 공주의 편지를, 카틀레야가 왕자의 편지를 대필해요.' },
    { s:600,  title:'텅 빈 답장', art:'home', chars:['charlotte','cattleya','damian'], terms:['royalwedding'], sum:'왕자의 답장이 형식적으로만 느껴지자, 샬럿은 그의 마음을 의심하며 울어요.' },
    { s:780,  title:'왕자를 만났던 날', art:'flowers', chars:['charlotte','damian'], terms:[], sum:'어린 시절 샬럿은 다미안을 처음 만나 첫눈에 반했어요.' },
    { s:960,  title:'직접 쓰는 편지', art:'night', chars:['violet','cattleya','charlotte','damian'], terms:['royalwedding'], sum:'바이올렛은 두 사람이 직접 편지를 써서 주고받게 해요. 솔직한 편지들이 밤새 오가요.' },
    { s:1140, title:'결혼식', art:'party', chars:['charlotte','damian'], terms:['royalwedding'], sum:'편지로 마음을 확인한 두 사람은 결혼식을 올려요.' },
    { s:1260, title:'디트프리트의 말', art:'street', chars:['violet','cattleya','dietfried'], terms:['war'], sum:'라이덴으로 돌아온 바이올렛에게 카틀레야는 그녀가 웃었다고 말해요. 그때 디트프리트가 나타나, 전쟁에서 그녀가 쓰러뜨린 사람들을 상기시켜요.' },
    { s:1380, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
  ];
  g.scenes[6] = [
    { s:0,    title:'천문대', art:'night', chars:['violet'], terms:['observatory'], sum:'바이올렛은 샤하르 천문대에서 낡은 귀한 책들을 옮겨 적는 일을 맡아요.' },
    { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
    { s:240,  title:'인형이 싫은 학자', art:'darkroom', chars:['leon','violet'], terms:['observatory','doll'], sum:'함께 일하게 된 학자 레온은 자동 수기 인형을 탐탁지 않아해요.' },
    { s:420,  title:'둘이 한 조', art:'darkroom', chars:['leon','violet'], terms:['typewriter'], sum:'한 사람이 읽고 한 사람이 받아 적어요. 바이올렛의 빠르고 정확한 타자에 레온은 놀라요.' },
    { s:600,  title:'고아라는 말', art:'darkroom', chars:['leon','violet'], terms:[], sum:'레온은 고아라는 이유로 무시당해 왔어요. 바이올렛이 그의 일만 보고 판단하자 마음을 열어요.' },
    { s:780,  title:'혜성을 기다리며', art:'night', chars:['leon','violet'], terms:['comet'], sum:'두 사람은 아주 드물게 찾아온다는 앨리 혜성을 보러 가요.' },
    { s:960,  title:'떠나 버린 부모', art:'meteor', chars:['leon','violet'], terms:['comet'], sum:'혜성 아래에서 레온은 부모님이 사라진 뒤 사랑을 믿지 못하게 됐다고 털어놓아요.' },
    { s:1110, title:'소령님을 위해', art:'meteor', chars:['violet','leon','gilbert'], terms:['major'], sum:'바이올렛은 소령에게 모든 걸 바쳤다고 말하고, 레온은 그녀가 소령을 사랑하고 있다는 걸 알아채요.' },
    { s:1260, title:'또 만날 수 있을까', art:'street', chars:['leon','violet'], terms:[], sum:'레온은 세상으로 나가 부모님을 찾아보기로 해요. 떠나는 바이올렛을 보며 다시 만날 수 있을지 생각해요.' },
    { s:1380, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
  ];
  g.scenes[7] = [
    { s:0,    title:'호숫가의 극작가', art:'home', chars:['violet','oscar'], terms:['doll'], sum:'바이올렛은 호숫가 별장에서 극작가 오스카의 대본 대필을 맡아요. 그는 술에 빠져 지내요.' },
    { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
    { s:240,  title:'딸을 위한 이야기', art:'home', chars:['oscar','olivia'], terms:['play'], sum:'오스카는 세상을 떠난 딸 올리비아를 위한 동화극을 쓰다 멈춰 있었어요.' },
    { s:450,  title:'우산을 든 소녀', art:'home', chars:['violet','oscar'], terms:['play'], sum:'바이올렛은 주인공 소녀가 마법 우산으로 하늘을 날아 집에 돌아오는 장면을 제안해요.' },
    { s:630,  title:'호수 위를 걷다', art:'boat', chars:['violet','oscar','olivia'], terms:['play'], sum:'바이올렛이 우산을 펴고 호수 위로 뛰어오르자, 오스카는 딸의 모습을 겹쳐 보고 슬픔을 받아들여요.' },
    { s:840,  title:'돌아가는 길', art:'street', chars:['violet'], terms:['war'], sum:'라이덴으로 돌아오는 길, 바이올렛은 전쟁에서 자신이 해친 사람들을 떠올리며 괴로워해요.' },
    { s:1020, title:'에버가든 부인', art:'home', chars:['violet','mrsevergarden'], terms:['major'], sum:'라이덴에서 후견인 에버가든 부인이 바이올렛에게 소령은 돌아오지 못한다고 말해요.' },
    { s:1170, title:'인식표', art:'office', chars:['violet','hodgins'], terms:['dogtags'], sum:'호진스도 소령의 인식표가 발견됐다며, 그가 돌아오지 못할 거라고 확인해 줘요.' },
    { s:1290, title:'믿을 수 없어', art:'street', chars:['violet'], terms:['major'], sum:'바이올렛은 그럴 리 없다며 우편사를 뛰쳐나가요.' },
    { s:1380, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
  ];
  g.scenes[8] = [
    { s:0,    title:'군 본부', art:'office', chars:['violet','dietfried'], terms:['major'], sum:'바이올렛은 군 본부로 디트프리트를 찾아가고, 그는 소령이 돌아오지 못한다는 사실을 확인해 줘요.' },
    { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
    { s:240,  title:'소령의 저택', art:'grave', chars:['violet'], terms:['grave'], sum:'바이올렛은 소령의 저택으로 가서 그의 무덤을 발견해요. 호진스는 그녀를 찾아 나서요.' },
    { s:390,  title:'이름을 받던 날', art:'forest', chars:['violet','gilbert'], terms:['name'], sum:'회상 속에서, 이름도 없이 무기처럼 쓰이던 소녀에게 소령은 「바이올렛」이라는 이름을 지어 줬어요.' },
    { s:570,  title:'글을 배우다', art:'camp', chars:['violet','gilbert'], terms:[], sum:'소령은 바이올렛에게 글을 읽고 쓰는 법을 가르쳐요.' },
    { s:750,  title:'에메랄드 브로치', art:'town', chars:['violet','gilbert'], terms:['brooch'], sum:'시장에서 바이올렛이 바라보던 에메랄드 브로치를 소령이 사 줘요. 소령의 눈과 같은 색이라고 바이올렛은 말해요.' },
    { s:930,  title:'전선의 무기', art:'battle', chars:['violet','gilbert'], terms:['war'], sum:'소령은 원치 않았지만, 바이올렛은 계속 최전선에 내몰려요.' },
    { s:1110, title:'마지막 작전', art:'battle', chars:['violet','gilbert'], terms:['war'], sum:'적 본부를 노리는 결정적인 작전에서 두 사람은 본대에 신호를 보내요.' },
    { s:1260, title:'총성', art:'battle', chars:['violet','gilbert'], terms:['war'], sum:'신호를 보낸 직후, 소령이 총에 맞아요. 바이올렛은 충격에 굳어 버려요.' },
    { s:1380, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
  ];
  g.scenes[9] = [
    { s:0,    title:'소령을 업고', art:'battle', chars:['violet','gilbert'], terms:['war'], sum:'바이올렛은 다친 소령을 안전한 곳으로 옮기려 하지만, 총탄과 수류탄에 맞아 두 팔을 잃어요.' },
    { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
    { s:240,  title:'「사랑해」', art:'battle', chars:['gilbert','violet'], terms:['aishiteru','prosthetic'], sum:'소령은 바이올렛에게 「사랑해」라고 말하지만, 그때의 바이올렛은 그 뜻을 몰라요. 소령은 그녀를 밀어내 살려 보내요.' },
    { s:420,  title:'맡겨진 마음', art:'office', chars:['hodgins','violet'], terms:['major'], sum:'현재로 돌아와, 호진스는 소령이 바이올렛을 자신에게 부탁했다고 들려줘요.' },
    { s:570,  title:'멈춰 버린 시간', art:'darkroom', chars:['violet'], terms:[], sum:'바이올렛은 일을 놓고 방에 틀어박혀 깊은 절망 속에 지내요.' },
    { s:750,  title:'동료들의 편지', art:'darkroom', chars:['violet','erica','iris'], terms:['doll'], sum:'에리카와 아이리스가 보낸 편지를 읽으며, 바이올렛은 편지가 사람에게 기쁨을 줄 수 있다는 걸 느껴요.' },
    { s:930,  title:'스펜서의 의뢰', art:'street', chars:['violet','spencer'], terms:['doll'], sum:'바이올렛은 다시 일을 시작해 스펜서의 편지를 대필해요.' },
    { s:1110, title:'살아가도 될까요', art:'night', chars:['violet','hodgins'], terms:['war'], sum:'바이올렛은 자신이 계속 살아가도 되냐고 호진스에게 물어요.' },
    { s:1260, title:'호진스의 대답', art:'night', chars:['hodgins','violet'], terms:['doll'], sum:'호진스는 전쟁에서 한 일은 지울 수 없지만, 그 뒤 자동 수기 인형으로 한 일도 지워지지 않는다고 답해요.' },
    { s:1380, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
  ];
  g.scenes[10] = [
    { s:0,    title:'커다란 저택', art:'home', chars:['violet','anne'], terms:['doll'], sum:'바이올렛이 한 저택에 도착하자, 어린 앤은 그녀를 살아 움직이는 진짜 인형으로 착각해요.' },
    { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
    { s:240,  title:'7일의 의뢰', art:'home', chars:['clara','violet'], terms:['letters50'], sum:'병든 어머니 클라라는 7일 동안 바이올렛을 고용해 편지를 맡겨요. 누구에게 쓰는지는 비밀이에요.' },
    { s:420,  title:'엄마를 빼앗긴 아이', art:'home', chars:['anne','clara'], terms:[], sum:'앤은 엄마가 바이올렛과 방에 틀어박혀 있는 게 싫어 투정을 부려요.' },
    { s:600,  title:'함께 노는 시간', art:'flowers', chars:['anne','violet'], terms:[], sum:'바이올렛은 짬짬이 앤과 놀아 주며 가까워져요.' },
    { s:780,  title:'앤의 눈물', art:'home', chars:['anne','violet'], terms:[], sum:'앤은 엄마가 곧 떠날 거라는 두려움을 털어놓고, 바이올렛은 앤이 스스로를 탓하지 않도록 위로해요.' },
    { s:960,  title:'떠나는 날', art:'street', chars:['violet','anne','clara'], terms:['letters50'], sum:'7일이 지나 바이올렛은 저택을 떠나요.' },
    { s:1110, title:'해마다 오는 편지', art:'home', chars:['anne','clara'], terms:['letters50'], sum:'클라라가 세상을 떠난 뒤, 앤의 생일마다 엄마의 편지가 도착해요. 50년 동안 이어지는 편지예요.' },
    { s:1260, title:'바이올렛의 눈물', art:'office', chars:['violet','cattleya'], terms:['letters50'], sum:'우편사로 돌아온 바이올렛은 혼자 자라날 앤을 생각하며 눈물을 쏟아요.' },
    { s:1380, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
  ];
  g.scenes[11] = [
    { s:0,    title:'전장의 의뢰', art:'office', chars:['hodgins','violet'], terms:['ctrigal'], sum:'내전 중인 나라에서 병사 에이든이 자동 수기 인형을 요청해요. 호진스는 너무 위험하다며 거절해요.' },
    { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
    { s:240,  title:'혼자 떠난 바이올렛', art:'camp', chars:['violet'], terms:['ctrigal'], sum:'그래도 바이올렛은 혼자 전장으로 향해요.' },
    { s:420,  title:'에이든', art:'battle', chars:['aiden'], terms:['ctrigal'], sum:'에이든의 부대는 매복에 걸려 무너지고, 그는 크게 다쳐요.' },
    { s:600,  title:'하늘에서 내려온 인형', art:'battle', chars:['violet','aiden'], terms:['ctrigal'], sum:'바이올렛은 낙하산을 타고 전장으로 내려가 쓰러진 에이든을 구해 내요.' },
    { s:780,  title:'마지막 편지', art:'camp', chars:['aiden','violet'], terms:['doll'], sum:'에이든은 부모님께 보낼 작별 편지를 부탁해요.' },
    { s:960,  title:'마리아에게', art:'camp', chars:['aiden','violet','maria'], terms:['aishiteru'], sum:'소꿉친구 마리아에게 보내는 편지에는 그동안 하지 못한 「사랑해」를 담아요.' },
    { s:1110, title:'다시 만나는 꿈', art:'flowers', chars:['aiden','maria'], terms:[], sum:'에이든은 마리아와 다시 만나는 장면을 그리며 숨을 거둬요.' },
    { s:1260, title:'지켜 주지 못해서', art:'home', chars:['violet','maria'], terms:[], sum:'바이올렛은 편지를 직접 전하고, 그를 지켜 주지 못했다며 울면서 사과해요.' },
    { s:1380, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
  ];
  g.scenes[12] = [
    { s:0,    title:'평화 조약', art:'office', chars:['dietfried'], terms:['treaty'], sum:'디트프리트는 평화 조약에 서명하러 가는 특사를 지키는 임무를 맡아요.' },
    { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
    { s:240,  title:'반란군의 계획', art:'darkroom', chars:['merkulov'], terms:['treaty'], sum:'조약에 반대하는 반란군 메르쿨로프 장군이 특사의 열차를 습격하려 해요.' },
    { s:420,  title:'같은 열차', art:'street', chars:['cattleya','benedict','violet'], terms:['chpost'], sum:'카틀레야와 베네딕트가 탄 열차에 바이올렛도 올라타요.' },
    { s:600,  title:'습격', art:'battle', chars:['violet','merkulov'], terms:['treaty'], sum:'반란군이 열차를 덮치고, 바이올렛은 더는 사람을 죽이지 않으려다 붙잡혀요.' },
    { s:780,  title:'디트프리트의 구출', art:'battle', chars:['dietfried','violet'], terms:[], sum:'디트프리트가 바이올렛을 구해 내요.' },
    { s:960,  title:'네 탓이다', art:'battle', chars:['dietfried','violet','gilbert'], terms:['major'], sum:'디트프리트는 동생이 돌아오지 못한 게 바이올렛 탓이라고 몰아붙여요.' },
    { s:1110, title:'살아라', art:'battle', chars:['violet','dietfried','gilbert'], terms:['major'], sum:'바이올렛은 소령이 자신에게 살라고 했다고 말해요.' },
    { s:1260, title:'날아온 유탄', art:'battle', chars:['violet','dietfried'], terms:['prosthetic'], sum:'반란군이 디트프리트를 향해 유탄을 쏘고, 바이올렛이 의수로 막아 내요.' },
    { s:1380, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
  ];
  g.scenes[13] = [
    { s:0,    title:'디트프리트를 지키다', art:'battle', chars:['violet','dietfried'], terms:['prosthetic'], sum:'바이올렛은 디트프리트를 지키다 의수 한쪽을 잃어요.' },
    { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
    { s:240,  title:'폭탄이 설치된 다리', art:'battle', chars:['merkulov','violet','benedict'], terms:['treaty'], sum:'앞쪽 다리에 폭탄이 설치돼 있고, 메르쿨로프는 열차에서 뛰어내려요.' },
    { s:420,  title:'폭탄 제거', art:'battle', chars:['violet','benedict'], terms:['prosthetic'], sum:'바이올렛과 베네딕트가 폭탄을 떼어 내고, 바이올렛은 남은 의수까지 잃어요.' },
    { s:600,  title:'조약 체결', art:'office', chars:['dietfried'], terms:['treaty'], sum:'특사는 무사히 도착하고, 평화 조약이 맺어져요.' },
    { s:780,  title:'항공 축제', art:'field', chars:['cattleya','violet'], terms:['airshow'], sum:'다시 열린 항공 축제에서 하늘에 편지를 뿌려요. 카틀레야는 바이올렛에게 소령에게 편지를 써 보라고 해요.' },
    { s:930,  title:'원망하지 않아', art:'home', chars:['dietfried','gilbertmom','violet'], terms:[], sum:'디트프리트와 그의 어머니는 바이올렛을 원망하지 않는다고 말해 줘요.' },
    { s:1080, title:'소령님께', art:'night', chars:['violet','gilbert'], terms:['aishiteru','airshow'], sum:'바이올렛은 소령에게 편지를 써요. 「사랑해」를 조금은 알게 됐고, 다시 만날 날을 바라며 살아가겠다고요.' },
    { s:1260, title:'다음 의뢰', art:'flowers', chars:['violet'], terms:['doll'], sum:'다음 날, 새 대필 의뢰를 받은 바이올렛은 의뢰인에게 자신을 소개해요.' },
    { s:1380, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
  ];

  Object.assign(C, {
    emonn:{ name:'에이먼 스노', short:'에이먼', alias:['에이먼'], at:[4,780], pos:[60,250], facts:[[[4,780],'아이리스가 예전에 고백했다 거절당한 사람이에요.']] },
    charlotte:{ name:'샬럿 공주', short:'샬럿', alias:['샬럿','공주'], at:[5,240], pos:[380,320], facts:[[[5,240],'드로셀 왕국의 공주예요. 이웃 나라 왕자와 결혼해요.'],[[5,780],'어린 시절 다미안에게 첫눈에 반했어요.']] },
    damian:{ name:'다미안 왕자', short:'다미안', alias:['다미안','왕자'], at:[5,240], pos:[250,320], facts:[[[5,240],'플뤼겔 왕국의 왕자예요. 샬럿과 결혼해요.']] },
    leon:{ name:'레온', short:'레온', alias:['레온'], at:[6,240], pos:[60,420], facts:[[[6,240],'샤하르 천문대의 학자예요. 자동 수기 인형을 싫어했어요.'],[[6,960],'부모님이 사라진 뒤 사랑을 믿지 못하게 됐어요.'],[[6,1260],'부모님을 찾아 세상으로 나가기로 해요.']] },
    oscar:{ name:'오스카', short:'오스카', alias:['오스카'], at:[7,0], pos:[420,240], facts:[[[7,0],'술에 빠져 지내는 극작가예요.'],[[7,240],'딸 올리비아를 잃었어요.']] },
    olivia:{ name:'올리비아', short:'올리비아', alias:['올리비아'], at:[7,240], pos:[520,100], facts:[[[7,240],'오스카의 딸이에요. 세상을 떠났어요.']] },
    mrsevergarden:{ name:'에버가든 부인', short:'에버가든 부인', alias:['에버가든 부인','부인'], at:[1,420], pos:[220,90], facts:[[[1,420],'바이올렛의 후견인이 된 에버가든 가의 부인이에요.'],[[7,1020],'소령이 돌아오지 못한다고 바이올렛에게 알려요.']] },
    gilbertmom:{ name:'소령의 어머니', short:'소령의 어머니', alias:['소령의 어머니'], at:[13,930], pos:[300,330], facts:[[[13,930],'디트프리트와 소령의 어머니예요. 바이올렛을 원망하지 않는다고 말해 줘요.']] },
    clara:{ name:'클라라', short:'클라라', alias:['클라라'], at:[10,240], pos:[180,240], facts:[[[10,240],'병든 어머니예요. 바이올렛에게 7일 동안 편지를 맡겨요.'],[[10,1110],'딸의 생일마다 도착할 50통의 편지를 남겨요.']] },
    anne:{ name:'앤', short:'앤', alias:['앤'], at:[10,0], pos:[380,150], facts:[[[10,0],'클라라의 어린 딸이에요. 바이올렛을 진짜 인형으로 착각해요.']] },
    aiden:{ name:'에이든', short:'에이든', alias:['에이든'], at:[11,0], pos:[560,40], facts:[[[11,0],'내전 중인 나라에서 싸우는 병사예요.'],[[11,780],'부모님과 마리아에게 마지막 편지를 남겨요.']] },
    maria:{ name:'마리아', short:'마리아', alias:['마리아'], at:[11,960], pos:[420,430], facts:[[[11,960],'에이든의 소꿉친구예요.']] },
    merkulov:{ name:'메르쿨로프 장군', short:'메르쿨로프', alias:['메르쿨로프'], at:[12,240], pos:[40,140], facts:[[[12,240],'평화 조약에 반대하는 반란군 장군이에요.']] },
  });

  fact('violet', [4,1260], '소령이 꽃 이름을 따서 「바이올렛」이라는 이름을 지어 줬어요.');
  fact('violet', [6,1110], '레온은 그녀가 소령을 사랑하고 있다고 느껴요.');
  fact('violet', [7,840], '전쟁에서 자신이 한 일을 후회하기 시작해요.');
  fact('violet', [9,0], '마지막 전투에서 두 팔을 잃었어요.');
  fact('violet', [9,930], '절망을 딛고 다시 일을 시작해요.');
  fact('violet', [12,600], '더는 사람을 죽이지 않겠다고 마음먹었어요.');
  fact('violet', [13,1080], '다시 만날 날을 바라며 살아가겠다는 편지를 소령에게 써요.');
  fact('gilbert', [7,1170], '인식표가 발견됐고, 돌아오지 못할 거라는 말을 들어요.');
  fact('gilbert', [8,390], '이름 없던 소녀에게 「바이올렛」이라는 이름을 지어 주고 글을 가르쳤어요.');
  fact('gilbert', [8,1260], '마지막 작전에서 총에 맞았어요.');
  fact('gilbert', [9,240], '바이올렛에게 「사랑해」라고 말하고, 그녀를 살려 보냈어요.');
  fact('hodgins', [7,1170], '소령의 인식표 소식을 바이올렛에게 전해요.');
  fact('hodgins', [9,420], '소령에게서 바이올렛을 부탁받았어요.');
  fact('hodgins', [9,1260], '바이올렛에게 그녀가 해 온 일도 지워지지 않는다고 말해 줘요.');
  fact('dietfried', [5,1260], '바이올렛이 전쟁에서 한 일을 잊지 말라고 몰아붙여요.');
  fact('dietfried', [12,0], '평화 조약 특사를 지키는 임무를 맡아요.');
  fact('dietfried', [13,930], '바이올렛을 원망하지 않는다고 말해요.');
  fact('cattleya', [5,420], '다미안 왕자의 편지를 대필해요.');
  fact('cattleya', [13,780], '바이올렛에게 소령에게 편지를 써 보라고 권해요.');
  fact('benedict', [13,420], '바이올렛과 함께 다리의 폭탄을 떼어 내요.');
  fact('iris', [4,0], '손을 다쳐 고향에서 온 의뢰를 바이올렛과 함께 가요.');
  fact('iris', [4,1260], '태어날 때 핀 꽃의 이름을 받았어요.');
  fact('erica', [9,750], '바이올렛에게 편지를 보내요.');
  fact('spencer', [9,930], '다시 일을 시작한 바이올렛에게 편지를 맡겨요.');

  Object.assign(T, {
    birthday:{ name:'생일 파티', alias:['생일','파티','초대장'], at:[4,420], facts:[[[4,420],'아이리스의 어머니가 딸을 불러들이려 연 파티예요.']] },
    name:{ name:'꽃의 이름', alias:['이름','꽃'], at:[4,1260], facts:[[[4,1260],'아이리스와 바이올렛 모두 꽃 이름을 받았어요.'],[[8,390],'소령이 바이올렛에게 지어 준 이름이에요.']] },
    royalwedding:{ name:'왕실 결혼', alias:['결혼','연애편지','드로셀','플뤼겔'], at:[5,240], facts:[[[5,240],'두 나라의 평화를 위한 결혼이에요.'],[[5,420],'왕실의 연애편지는 국민에게 공개돼요.']] },
    observatory:{ name:'샤하르 천문대', alias:['천문대'], at:[6,0], facts:[[[6,0],'귀한 옛 책을 옮겨 적는 곳이에요.']] },
    comet:{ name:'앨리 혜성', alias:['혜성'], at:[6,780], facts:[[[6,780],'아주 오랜만에 한 번 찾아오는 혜성이에요.']] },
    play:{ name:'동화극 대본', alias:['대본','우산','동화극'], at:[7,240], facts:[[[7,240],'오스카가 딸을 위해 쓰다 멈춘 이야기예요.'],[[7,450],'마법 우산으로 집에 돌아오는 소녀의 이야기예요.']] },
    dogtags:{ name:'인식표', alias:['인식표'], at:[7,1170], facts:[[[7,1170],'군인의 이름이 새겨진 표예요. 소령의 것이 발견됐어요.']] },
    grave:{ name:'소령의 무덤', alias:['무덤'], at:[8,240], facts:[[[8,240],'바이올렛이 소령의 저택에서 발견한 무덤이에요.']] },
    letters50:{ name:'50통의 편지', alias:['50통','생일 편지'], at:[10,240], facts:[[[10,240],'클라라가 바이올렛에게 맡긴 편지예요.'],[[10,1110],'앤의 생일마다 50년 동안 한 통씩 도착해요.']], easy:'엄마가 미래의 딸에게 미리 남긴 생일 선물이에요.' },
    ctrigal:{ name:'내전 중인 나라', alias:['내전','전장'], at:[11,0], facts:[[[11,0],'에이든이 싸우는 곳이에요. 아주 위험해요.']] },
    treaty:{ name:'평화 조약', alias:['조약','평화','반란군'], at:[12,0], facts:[[[12,0],'전쟁을 완전히 끝내기 위한 조약이에요.'],[[12,240],'반란군이 이를 막으려 해요.'],[[13,600],'결국 맺어져요.']] },
    airshow:{ name:'항공 축제', alias:['항공 축제','축제'], at:[13,780], facts:[[[13,780],'하늘에서 편지를 뿌리는 축제예요. 전쟁 뒤 다시 열렸어요.']] },
  });
  tfact('aishiteru', [9,240], '소령이 마지막 전투에서 바이올렛에게 한 말이에요.');
  tfact('aishiteru', [13,1080], '바이올렛은 이 말의 뜻을 조금은 알게 됐다고 편지에 써요.');
  tfact('prosthetic', [9,0], '바이올렛은 마지막 전투에서 두 팔을 잃었어요.');
  tfact('war', [8,930], '바이올렛은 최전선에 내몰렸어요.');
  tfact('brooch', [8,750], '소령이 시장에서 사 준 브로치예요. 소령의 눈과 같은 색이에요.');

  R.push(
    ['iris','emonn','other','예전에 고백했던 상대',[4,780]],
    ['charlotte','damian','other','약혼자',[5,600]],
    ['violet','leon','friend','천문대에서 함께 일한 사이',[6,600]],
    ['oscar','olivia','family','아버지와 딸',[7,240]],
    ['mrsevergarden','violet','family','후견인',[1,420]],
    ['gilbertmom','dietfried','family','어머니와 아들',[13,930]],
    ['clara','anne','family','어머니와 딸',[10,240]],
    ['violet','anne','friend','함께 논 사이',[10,600]],
    ['aiden','maria','other','소꿉친구',[11,960]],
    ['merkulov','dietfried','rival','반란군과 특사의 호위',[12,240]],
  );
})();
