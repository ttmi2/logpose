/* ============================================================
   애니 입문자 추천 62선 — 장르 6개 · 장르별 대표작 1 + 나머지 가나다순
   (팀이 정리한 62선 + 기존 가이드북 작품 호리미야)
   ============================================================ */
const GENRES = [
  { id:'action',    zone:'A', name:'액션·배틀',          tag:'화려한 전투와 성장 서사를 즐기고 싶은 분께',      rep:'aot',       hue:6 },
  { id:'adventure', zone:'B', name:'모험·스포츠',        tag:'열정과 팀워크, 가슴 뛰는 승부를 보고 싶은 분께',  rep:'haikyu',    hue:28 },
  { id:'fantasy',   zone:'C', name:'판타지·이세계',      tag:'현실을 벗어난 세계관에 푹 빠지고 싶은 분께',      rep:'frieren',   hue:200 },
  { id:'mystery',   zone:'D', name:'SF·미스터리·스릴러', tag:'치밀한 두뇌 싸움과 반전을 좋아하는 분께',         rep:'deathnote', hue:265 },
  { id:'romance',   zone:'E', name:'로맨스·드라마·청춘', tag:'깊은 여운과 감동, 아름다운 영상미를 원하는 분께',  rep:'violet',    hue:340 },
  { id:'comedy',    zone:'F', name:'코미디·일상·힐링',   tag:'가볍게 웃고 편안하게 쉬어가고 싶은 분께',        rep:'spy',       hue:95 },
];
const GENRE = Object.fromEntries(GENRES.map(g => [g.id, g]));
/* [id, 제목, 한줄 소개] — 대표작은 기존 id 그대로 */
const CATALOG = {
  action:[
    ['kaiju','괴수 8호','괴수 청소부였던 중년 남성이 괴수의 힘을 얻고 방위대에서 싸우는 액션입니다.'],
    ['kimetsu','귀멸의 칼날','작화와 전투 연출이 압도적이고 스토리가 직관적입니다.'],
    ['naruto','나루토','우정과 성장을 다룬 소년만화의 고전입니다.'],
    ['heroaca','나의 히어로 아카데미아','정통 히어로물 성장 이야기입니다.'],
    ['revengers','도쿄 리벤저스','과거로 타임리프해 소중한 사람을 구하려는 불량배 이야기입니다.'],
    ['edgerunners','사이버펑크 엣지러너','스튜디오 트리거의 화려한 연출이 돋보이는 SF 액션입니다.'],
    ['sakamoto','사카모토 데이즈','전설의 킬러가 평범한 가게 주인으로 살며 벌이는 액션 코미디입니다.'],
    ['onepunch','원펀맨','히어로물을 비튼 유머와 액션이 매력입니다.'],
    ['windbreaker','윈드 브레이커','마을을 지키는 불량 학원 후린 고교에서 싸우는 소년의 청춘 액션입니다.'],
    ['jujutsu','주술회전','세련된 연출과 개성 있는 캐릭터가 강점입니다.'],
    ['aot','진격의 거인','충격적인 전개와 반전으로 입문작 1순위로 꼽힙니다.'],
    ['chainsaw','체인소 맨','독특한 감성의 다크 액션입니다.'],
    ['hunter','헌터×헌터 (2011)','두뇌 싸움과 성장 서사가 뛰어납니다.'],
  ],
  adventure:[
    ['slamdunk','더 퍼스트 슬램덩크','극장판이라 2시간 안에 즐길 수 있습니다.'],
    ['bluelock','블루 록','축구 스트라이커 경쟁을 그린 열혈 서바이벌입니다.'],
    ['onepiece','원피스','분량은 방대하지만 입문 후 가장 오래 즐길 수 있습니다.'],
    ['kuroko','쿠로코의 농구','능력자 대결 같은 농구 만화입니다.'],
    ['free','프리!','수영부 소년들의 우정과 성장을 그린 스포츠 드라마입니다.'],
    ['haikyu','하이큐!!','스포츠물 입문작으로, 보다 보면 배구를 응원하게 됩니다.'],
  ],
  fantasy:[
    ['rezero','Re:제로','죽음으로 시간을 되돌리는 몰입감 있는 전개입니다.'],
    ['sololeveling','나 혼자만 레벨업','시원한 성장 서사입니다.'],
    ['ancientbride','마법사의 신부','서정적이고 아름다운 세계관의 판타지입니다.'],
    ['mashle','마슐','마법 세계에서 근육 하나로 맞서는 주인공의 개그 배틀물입니다.'],
    ['sao','소드 아트 온라인','게임 세계 설정의 대표작입니다.'],
    ['kamisama','오늘부터 신령님','신이 된 여고생의 로맨틱 판타지입니다.'],
    ['inuyasha','이누야샤','전국시대와 현대를 오가는 모험 로맨스입니다.'],
    ['frieren','장송의 프리렌','잔잔하고 여운이 긴 이야기로, 최근 호평이 가장 많은 작품 중 하나입니다.'],
    ['slime','전생했더니 슬라임이었던 건에 대하여','이세계물의 대표 격입니다.'],
  ],
  mystery:[
    ['parasyte','기생수 -세이의 격률-','짧은 분량에 몰입도가 높습니다.'],
    ['deathnote','데스노트','두뇌 싸움의 정석으로, 입문자 만족도가 높습니다.'],
    ['ghoul','도쿄 구울','인간과 구울의 공존을 둘러싼 다크 판타지입니다.'],
    ['conan','명탐정 코난','몸이 어려진 고교생 탐정이 사건을 해결하는 추리 애니메이션의 대표작입니다.'],
    ['mobpsycho','모브사이코 100','작화가 독특하고 메시지도 좋습니다.'],
    ['beastars','비스타즈','육식동물과 초식동물이 함께 사는 학원을 그린 드라마입니다.'],
    ['neverland','약속의 네버랜드 (1기)','긴장감 넘치는 탈출 스릴러입니다.'],
    ['hikaru','히카루가 죽은 여름','죽은 친구의 모습으로 돌아온 정체불명의 존재를 다룬 시골 호러 미스터리입니다.'],
  ],
  romance:[
    ['april','4월은 너의 거짓말','음악과 청춘이 어우러진 눈물 버튼 작품입니다.'],
    ['alya','가끔씩 툭하고 러시아어로 부끄러워하는 옆자리의 아랴 양','러시아어로 속마음을 흘리는 옆자리 소녀와의 로맨틱 코미디입니다.'],
    ['bisquedoll','그 비스크돌은 사랑을 한다','코스프레와 인형 제작에 열정을 가진 두 사람의 로맨스입니다.'],
    ['raise','내세에는 남남이 좋겠어','야쿠자 가문의 두 사람이 얽힌 위험하고 아슬아슬한 극도(極道) 로맨스 코미디입니다.'],
    ['kiminitodoke','너에게 닿기를','순수한 소녀의 풋풋한 첫사랑 이야기입니다.'],
    ['silentvoice','목소리의 형태','묵직한 감동을 주는 청춘 드라마입니다.'],
    ['violet','바이올렛 에버가든','교토 애니메이션의 작화가 압도적입니다.'],
    ['firefly','반딧불이의 혼례','메이지 시대, 시한부 영애와 암살자의 계약 결혼을 그린 로맨스 서스펜스입니다.'],
    ['blueperiod','블루 피리어드','입시 미술에 빠진 고교생의 열정과 성장을 그린 드라마입니다.'],
    ['boss','새로운 상사는 귀여운 허당','허당 상사와 부하 직원의 회사 로맨틱 코미디입니다.'],
    ['signal','손끝과 연연','청각장애 대학생과 청년의 섬세한 청춘 로맨스입니다.'],
    ['skiploafer','스킵과 로퍼','수재 소녀의 도쿄 고교 생활을 그린 청춘 학원 드라마입니다.'],
    ['icewall','얼음 성벽','사람을 멀리하는 여고생과 주변 인물들의 청춘 군상극입니다.'],
    ['ouran','오란고 고교 호스트부','가벼운 로맨틱 코미디입니다.'],
    ['kaguya','카구야 님은 고백받고 싶어','연애 두뇌전 코미디입니다.'],
    ['clannad','클라나드','가족과 사랑을 다룬 눈물 바다 명작입니다.'],
    ['bluebox','푸른 상자','동경하는 선배와 한집에서 지내게 된 소녀의 스포츠 로맨스입니다.'],
    ['kaoru','향기로운 꽃은 늠름하게 핀다','두 학교 학생들의 풋풋하고 따뜻한 청춘 로맨스입니다.'],
    ['horimiya','호리미야','학교와 집에서 전혀 다른 얼굴을 가진 두 사람이 서로의 비밀을 알게 되며 가까워지는 학원 로맨스입니다.'],
  ],
  comedy:[
    ['natsume','나츠메 우인장','요괴와의 따뜻한 인연을 그린 힐링물입니다.'],
    ['saiki','사이키 쿠스오의 재난','초능력자의 개그 학원물입니다.'],
    ['spy','스파이 패밀리','온 가족이 함께 볼 수 있는 가족 코미디 액션입니다.'],
    ['catcleaner','야무진 고양이는 오늘도 우울','주워온 고양이가 집안일을 모두 해내는 힐링 코미디입니다.'],
    ['apothecary','약사의 혼잣말','궁중 미스터리와 가벼운 로맨스가 섞여 있습니다.'],
    ['gintama','은혼','개그와 감동을 오가는 장수 명작입니다.'],
    ['cells','일하는 세포','인체 속 세포로 배우는 교양 코미디입니다.'],
    ['cooldoji','쿨하고 바보 같은 남자','쿨한 외모와 엉뚱한 성격의 격차를 그린 개그물입니다.'],
  ],
};
/* 감상 팁(팀 목록 4쪽) */
const EASY_START = ['spy','frieren'], BINGE = ['deathnote','parasyte'], HEAVY = ['raise','aot','chainsaw','ghoul','hikaru'];

/* 가이드북이 없는 목록 밖 작품은 서재에서 뺌 */
for (const id of Object.keys(WORKS)) if (!Object.values(CATALOG).some(list => list.some(r => r[0] === id))) delete WORKS[id];

/* ---------- 색인: 초성 · 가나다순 ---------- */
const CHO_IDX = 'ㄱㄱㄴㄷㄷㄹㅁㅂㅂㅅㅅㅇㅈㅈㅊㅋㅌㅍㅎ';
function indexOf(title){
  const c = title.charCodeAt(0) - 0xAC00;
  if (c >= 0 && c < 11172) return CHO_IDX[Math.floor(c / 588)];
  if (/[0-9]/.test(title[0])) return '0–9';
  return title[0].toUpperCase();
}
const sortKey = t => { const c = t.charCodeAt(0); return (c >= 0xAC00 && c <= 0xD7A3 ? '1' : c >= 48 && c <= 57 ? '0' : '2') + t; };
const byIndex = (a, b) => sortKey(a).localeCompare(sortKey(b), 'ko');
function hsl(h, s, l){ return `hsl(${h},${s}%,${l}%)`; }
let hashN = s => { let h = 0; for (const ch of s) h = (h * 31 + ch.charCodeAt(0)) >>> 0; return h; };
function splitLines(t){
  const clean = t.replace(/\s*\(.*\)\s*/, '');
  if (clean.length <= 6) return [clean];
  const words = clean.split(' ');
  if (words.length === 1) return [clean.slice(0, Math.ceil(clean.length/2)), clean.slice(Math.ceil(clean.length/2))];
  const out = ['']; for (const w of words){ if ((out[out.length - 1] + ' ' + w).trim().length > 8 && out[out.length - 1]) out.push(w); else out[out.length - 1] = (out[out.length - 1] + ' ' + w).trim(); }
  return out.slice(0, 4);
}

/* ---------- 작품 등록 ---------- */
for (const g of GENRES){
  const list = CATALOG[g.id].slice().sort((a, b) => byIndex(a[1], b[1]));
  let seq = 0, curIdx = '', inIdx = 0;
  for (const [id, title, line] of list){
    const ix = indexOf(title);
    if (ix !== curIdx){ curIdx = ix; inIdx = 0; }
    const isRep = id === g.rep;
    if (!isRep){ seq++; inIdx++; }
    const tags = [g.name];
    if (EASY_START.includes(id)) tags.push('부담 없이 시작');
    if (BINGE.includes(id)) tags.push('한 번에 몰아보기');
    if (HEAVY.includes(id)) tags.push('잔혹·무거운 장면 주의');
    const callno = isRep ? `${g.zone}-대표` : `${g.zone}-${ix}-${String(inIdx).padStart(2, '0')}`;
    if (WORKS[id]){
      const W = WORKS[id];
      W.shelf = g.id; W.rep = isRep; W.index = ix; W.line = line;
      W.book.eyebrow = `${g.name} · ${g.zone}구역 ${isRep ? '대표작' : ix}`;
      W.book.callno = callno;
      W.book.tags = [...new Set([...tags, ...W.book.tags])].slice(0, 5);
      continue;
    }
    const h = (g.hue + (hashN(id) % 36) - 18 + 360) % 360, sat = 38 + hashN(id + 's') % 22;
    WORKS[id] = {
      title, shelf:g.id, lite:true, rep:false, index:ix, line, seq,
      cover:{ bg:[hsl(h, sat, 34), hsl(h, sat, 16)], ink:'#f3e8d2', lines:splitLines(title), en:'', motif:'', meta:g.name, no:callno },
      book:{ eyebrow:`${g.name} · ${g.zone}구역 ${ix}`, orig:`애니 입문자 추천 62선 · ${g.name}`, callno, tags, lede:line, recs:[], cast:[], points:[], tips:HEAVY.includes(id) ? ['잔혹하거나 무거운 장면이 있어요. 마음의 준비를 하고 보세요.'] : [] },
    };
  }
}
