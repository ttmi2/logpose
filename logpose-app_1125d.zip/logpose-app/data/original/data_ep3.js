/* ============================================================
   3화 추가 + 진격의 거인 1~2화 보정 (출처 대조)
   ============================================================ */
const addFacts = (o, list) => { o.facts = o.facts.concat(list); };
const drop = (arr, words) => arr.filter(b => !words.includes(b));

/* ---------- 진격의 거인 보정 ---------- */
(() => {
  const g = WORKS.aot.guide;
  const s660 = g.scenes[1].find(s => s.s === 660);
  s660.sum = '미카사가 에렌의 조사병단 꿈을 부모님께 말해요. 어머니 카를라는 강하게 반대하지만, 의사인 아버지 그리샤는 말리지 않아요. 그리샤는 일 때문에 집을 나서며 돌아오면 지하실을 보여 주겠다고 약속해요.';
  addFacts(g.chars.mikasa, [[[1,660],'에렌이 조사병단에 가는 걸 반대해요.']]);
  addFacts(g.chars.grisha, [[[1,660],'에렌이 조사병단에 가고 싶어 하는 걸 말리지 않아요.'],[[2,600],'꿈속에서 에렌에게 주사를 놓고 열쇠를 건넸어요.']]);
  addFacts(g.chars.eren, [[[2,600],'아버지가 자신에게 주사를 놓고 열쇠를 건네는 꿈을 꿨어요.']]);
  addFacts(g.terms.key, [[[2,600],'에렌의 꿈속에서 아버지가 이 열쇠를 에렌에게 건넸어요.']]);
  const i = g.scenes[2].findIndex(s => s.s === 690);
  g.scenes[2].splice(i, 0, { s:600, title:'아버지의 꿈', art:'night', chars:['eren','grisha'], terms:['key'], sum:'에렌은 아버지가 자신에게 주사를 놓고 열쇠를 건네는 꿈을 꿔요.' });
  g.banned = drop(g.banned, ['주사']);
})();

/* ---------- 스파이 패밀리 3화 ---------- */
(() => {
  const g = WORKS.spy.guide; g.eps = 3;
  g.episodes[3] = { title:'면접을 대비하라', summary:'요르가 포저 가에 들어오고, 세 사람은 이든 칼리지 면접에 대비해 상류층 나들이를 하다가 공원에서 소매치기를 잡아요.' };
  g.scenes[3] = [
    { s:0,    title:'서류상 부부', art:'home', chars:['loid','yor'], terms:['certificate'], sum:'로이드는 결혼한 지 1년 된 것처럼 꾸민 혼인 서류를 준비해 둬요.' },
    { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
    { s:240,  title:'이사 온 요르', art:'home', chars:['yor','anya','loid'], terms:[], sum:'짐이 거의 없는 요르가 이사 오고, 아냐가 집 안을 구경시켜 줘요.' },
    { s:420,  title:'모의 면접', art:'home', chars:['loid','anya','yor'], terms:['eden'], sum:'로이드는 차와 쿠키를 앞에 두고 이든 칼리지를 설명하며 모의 면접을 해 보지만, 두 사람의 대답에 실망해요.' },
    { s:600,  title:'오페라 관람', art:'party', chars:['loid','yor','anya'], terms:[], sum:'로이드는 품위를 익히려고 가족을 데리고 오페라를 보러 가지만, 아냐는 잠들고 요르는 지루해해요.' },
    { s:750,  title:'미술관', art:'party', chars:['anya','yor','loid'], terms:[], sum:'미술관에서 아냐의 엉뚱한 감상에 로이드는 진땀을 흘리고, 요르는 그림 속 처형 장면에 감탄해요.' },
    { s:900,  title:'공원의 소매치기', art:'street', chars:['yor','anya','loid'], terms:['telepathy'], sum:'공원에서 할머니의 가방이 소매치기당하고, 요르가 쫓아가지만 놓쳐요. 아냐는 도둑의 마음을 읽고 케이크 핑계를 대며 식당 쪽을 가리켜요.' },
    { s:1080, title:'잡았다', art:'street', chars:['loid','anya','yor'], terms:[], sum:'아냐 덕분에 로이드는 도둑을 잡아 할머니에게 가방을 돌려줘요.' },
    { s:1230, title:'가장 어려운 임무', art:'home', chars:['loid','anya'], terms:['eden'], sum:'집에 돌아와 다시 면접 연습을 한 로이드는 이 면접이 가장 어려운 임무가 되겠다고 느껴요.' },
    { s:1350, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
  ];
  addFacts(g.chars.yor, [[[3,240],'포저 가에 이사 왔어요.'],[[3,750],'그림 속 처형 장면에 감탄할 만큼 무기와 싸움 이야기에 밝아요.']]);
  addFacts(g.chars.anya, [[[3,900],'도둑의 마음을 읽고, 들키지 않게 케이크 핑계로 숨은 곳을 알려 줬어요.']]);
  addFacts(g.chars.loid, [[[3,0],'결혼한 지 1년 된 것처럼 혼인 서류를 꾸며 뒀어요.'],[[3,1230],'면접을 가장 어려운 임무라고 느껴요.']]);
  g.terms.certificate = { name:'혼인 서류', alias:['혼인','서류','결혼 서류'], at:[3,0], generic:true, facts:[[[3,0],'로이드가 결혼한 지 1년 된 것처럼 꾸며 준비한 서류예요.']] };
  addFacts(g.terms.eden, [[[3,420],'면접에서는 부모와 아이 모두 질문을 받아요.']]);
})();

/* ---------- 장송의 프리렌 3화 ---------- */
(() => {
  const g = WORKS.frieren.guide; g.eps = 3;
  g.episodes[3] = { title:'사람을 죽이는 마법', summary:'페른의 생일 선물을 고르던 프리렌이 옛 동료들과 다녔던 길을 다시 걷기로 하고, 80년 전 봉인한 마족 쿠발을 쓰러뜨려요.' };
  g.scenes[3] = [
    { s:0,    title:'수상한 스승', art:'street', chars:['fern','frieren'], terms:[], sum:'프리렌이 수상한 가게들을 몰래 드나들자, 의심이 든 페른이 뒤를 밟아요.' },
    { s:180,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
    { s:270,  title:'생일 선물', art:'street', chars:['frieren','fern'], terms:[], sum:'프리렌은 페른에 대해 아는 게 거의 없다며 생일 선물을 찾고 있었다고 털어놓아요. 페른은 노력해 준 것만으로도 기뻐해요.' },
    { s:480,  title:'추억의 길', art:'forest', chars:['frieren','fern'], terms:[], sum:'프리렌은 힘멜, 하이터, 아이젠과 함께 다녔던 곳들을 다시 찾아가 보기로 해요.' },
    { s:600,  title:'봉인의 마을', art:'street', chars:['frieren','fern','elder'], terms:['seal','demon'], sum:'첫 목적지는 80년 전 프리렌이 마족 쿠발을 봉인한 마을이에요. 그 봉인이 곧 풀리려 해요.' },
    { s:780,  title:'해마다 찾아온 용사', art:'street', chars:['elder','frieren','himmel'], terms:['seal'], sum:'힘멜은 세상을 떠날 때까지 해마다 봉인을 확인하러 왔대요. 프리렌이 제때 돌아올 거라고 믿었기 때문이에요.' },
    { s:960,  title:'사람을 죽이는 마법', art:'night', chars:['frieren','qual'], terms:['zoltraak'], sum:'쿠발이 만든 사람을 죽이는 마법은 결계와 갑옷을 뚫고 몸을 직접 공격해서, 80년 전에는 봉인하는 게 고작이었어요.' },
    { s:1110, title:'80년의 공백', art:'night', chars:['frieren','qual','fern'], terms:['zoltraak'], sum:'쿠발이 잠든 80년 동안 인간 마법사들은 그 마법을 연구해 막는 법을 만들었어요. 프리렌은 쿠발의 마법을 그대로 써서 쓰러뜨려요.' },
    { s:1260, title:'그때의 소년', art:'street', chars:['frieren','elder','fern'], terms:[], sum:'프리렌은 마을의 촌장이 80년 전에 만났던 소년이라는 걸 알아봐요. 페른은 힘멜이 프리렌을 무척 믿었던 것 같다고 말해요.' },
    { s:1380, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
  ];
  g.chars.qual = { name:'쿠발', short:'쿠발', alias:['쿠발','쿠바르'], at:[3,600], pos:[560,250], facts:[[[3,600],'80년 전 프리렌에게 봉인된 **마족**이에요. 봉인이 풀리려 해요.'],[[3,960],'사람을 죽이는 마법을 만들었어요.'],[[3,1110],'프리렌에게 쓰러졌어요.']] };
  g.chars.elder = { name:'마을 촌장', short:'촌장', alias:['촌장'], at:[3,600], pos:[300,425], facts:[[[3,600],'쿠발이 봉인된 마을의 촌장이에요.'],[[3,1260],'80년 전 프리렌이 만났던 소년이었어요.']] };
  addFacts(g.chars.himmel, [[[3,780],'세상을 떠날 때까지 해마다 쿠발의 봉인을 확인하러 왔어요.']]);
  addFacts(g.chars.fern, [[[3,270],'생일 선물을 찾아 준 프리렌의 마음에 기뻐했어요.']]);
  addFacts(g.chars.frieren, [[[3,480],'옛 동료들과 다녔던 길을 다시 걷기로 했어요.'],[[3,1110],'쿠발을 쓰러뜨렸어요.']]);
  g.rels = g.rels.concat([['frieren','qual','rival','80년 전 봉인한 마족',[3,600]],['frieren','elder','other','80년 만에 다시 만난 사이',[3,1260]]]);
  g.terms.seal = { name:'봉인', alias:['봉인'], at:[3,600], facts:[[[3,600],'프리렌이 80년 전 쿠발에게 건 봉인이에요. 곧 풀리려 해요.']] };
  g.terms.demon = { name:'마족', alias:['마족'], at:[3,600], facts:[[[3,600],'사람과 다른 종족이에요. 쿠발도 마족이에요.']] };
  g.terms.zoltraak = { name:'졸트라크', alias:['졸트라크','사람을 죽이는 마법','살인 마법','살해 마법'], at:[3,960], facts:[[[3,960],'쿠발이 만든 마법이에요. 결계와 갑옷을 뚫고 몸을 직접 공격해요.'],[[3,1110],'80년 동안 인간 마법사들이 연구해 막는 법이 생겼고, 이제는 인간 마법사들도 쓰는 마법이 됐어요.']], easy:'한때 아무도 못 막던 필살기가 교과서에 실린 기본기가 된 셈이에요.' };
  g.banned = drop(g.banned, ['쿠발','쿠바르','졸트라크','일반 공격 마법']);
})();

/* ---------- 하이큐!! 2화 보정 + 3화 ---------- */
(() => {
  const g = WORKS.haikyu.guide; g.eps = 3;
  const s780 = g.scenes[2].find(s => s.s === 780);
  s780.title = '도전장';
  s780.sum = '두 사람은 선배들에게 시합을 신청해요. 이기면 정식 부원으로 받아 주지만, 지면 카게야마는 당분간 세터를 할 수 없다는 조건이 붙어요.';
  g.episodes[2].summary = '카라스노 고교에서 카게야마와 다시 만난 히나타가 함께 쫓겨나고, 체육관에 돌아가기 위해 시합을 신청해요.';
  g.terms.threevthree = { name:'시합 조건', alias:['3대3','3대 3','시합','조건','신입'], at:[2,780], facts:[[[2,780],'이기면 정식 부원으로 받아 주고, 지면 카게야마는 당분간 세터를 할 수 없어요.'],[[3,0],'다이치는 시합을 신입끼리의 3대3으로 바꿨어요. 다이치는 상대 팀, 타나카는 두 사람 팀에서 뛰어요.']] };
  g.chars.daichi.facts = [[[2,330],'카라스노 배구부 3학년 **주장**이에요. 평소엔 온화하지만 화나면 무서워요.'],[[2,540],'싸우는 두 사람을 체육관에서 내보냈어요.'],[[2,780],'두 사람의 시합 신청을 받아들였어요.'],[[3,0],'시합을 신입끼리의 3대3으로 바꾸고, 자신은 상대 팀에서 뛰기로 했어요.']];
  g.chars.kageyama.facts = g.chars.kageyama.facts.map(f => f[0][1] === 780 && f[0][0] === 2 ? [[2,780],'시합에서 지면 당분간 세터를 할 수 없다는 조건을 받아들였어요.'] : f);
  g.episodes[3] = { title:'최강의 아군', summary:'다이치가 시합을 신입끼리의 3대3으로 바꾸고, 히나타와 카게야마는 상대 팀 츠키시마와 야마구치의 도발에 불타 새벽 연습에 매달려요.' };
  g.scenes[3] = [
    { s:0,    title:'바뀐 시합 방식', art:'gym', chars:['daichi','hinata','kageyama','tanaka'], terms:['threevthree'], sum:'다이치는 시합을 신입끼리의 3대3으로 바꾸고, 자신은 상대 팀에서, 공격수 타나카는 두 사람 팀에서 뛰게 해요.' },
    { s:180,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
    { s:300,  title:'새벽 연습', art:'gym', chars:['hinata','kageyama'], terms:['setter','spike'], sum:'두 사람은 이른 아침 몰래 체육관에 나와 연습하기 시작해요.' },
    { s:600,  title:'얄미운 신입들', art:'gym', chars:['tsukishima','yamaguchi','hinata','kageyama'], terms:['kingofcourt'], sum:'연습 중에 다른 신입 츠키시마와 야마구치를 만나요. 두 사람은 카게야마의 평판을 들먹이며 "왕"이라고 놀려요.' },
    { s:900,  title:'불붙은 두 사람', art:'gym', chars:['hinata','kageyama'], terms:[], sum:'화가 난 히나타와 카게야마는 그 어느 때보다 독하게 연습해요.' },
    { s:1350, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
  ];
  g.chars.tsukishima = { name:'츠키시마 케이', short:'츠키시마', alias:['츠키시마','츳키'], at:[3,600], pos:[440,395], facts:[[[3,600],'키가 큰 1학년 신입이에요. 비꼬는 말투로 카게야마를 놀려요.']] };
  g.chars.yamaguchi = { name:'야마구치 타다시', short:'야마구치', alias:['야마구치','타다시'], at:[3,600], pos:[560,395], facts:[[[3,600],'츠키시마와 늘 함께 다니는 1학년 신입이에요.']] };
  addFacts(g.chars.tanaka, [[[3,0],'3대3 시합에서 히나타·카게야마 팀으로 뛰게 됐어요.']]);
  addFacts(g.chars.hinata, [[[3,900],'츠키시마의 도발에 불타 새벽 연습에 매달려요.']]);
  addFacts(g.terms.kingofcourt, [[[3,600],'츠키시마는 이 별명으로 카게야마를 놀려요.']]);
  g.rels = g.rels.concat([
    ['tanaka','kageyama','other','같은 팀으로 뛰는 선배',[3,0]],
    ['tsukishima','yamaguchi','friend','늘 함께 다니는 친구',[3,600]],
    ['tsukishima','kageyama','rival','도발하는 상대',[3,600]],
  ]);
  g.banned = drop(g.banned, ['츠키시마','야마구치','츳키','케이','타다시']);
})();

/* ---------- 바이올렛 에버가든 3화 ---------- */
(() => {
  const g = WORKS.violet.guide; g.eps = 3;
  g.episodes[3] = { title:'좋은 자동 수기 인형이 될 수 있기를', summary:'양성 학교에 들어간 바이올렛이 동기 루크리아를 만나고, 루크리아가 오빠에게 전하지 못한 마음을 편지로 대신 전해 줘요.' };
  g.scenes[3] = [
    { s:0,    title:'양성 학교', art:'classroom', chars:['violet','rodante','luculia'], terms:['school'], sum:'라이덴의 자동 수기 인형 양성 학교에 들어간 바이올렛. 교장 로단테는 지각한 루크리아를 꾸짖으며, 이곳은 뛰어난 인형을 길러 내는 곳이라고 말해요.' },
    { s:150,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
    { s:240,  title:'타자 수업', art:'classroom', chars:['violet','luculia'], terms:['typewriter'], sum:'바이올렛은 군인처럼 경례하고, 타자 수업에서 지시를 받자 누구보다 빠르게 타자를 쳐요. 점심시간에 루크리아는 바이올렛이 거의 먹지 않는 걸 알아채요.' },
    { s:450,  title:'보고서 같은 편지', art:'classroom', chars:['violet','rodante'], terms:['doll'], sum:'어휘 시험은 만점이지만, 바이올렛이 쓴 편지는 보고서 같다는 지적을 받아요.' },
    { s:600,  title:'대필 수업', art:'classroom', chars:['violet','luculia'], terms:[], sum:'대필 수업에서 바이올렛은 소령에게 편지를 쓰고, 루크리아는 바이올렛에게 부모님께 보낼 편지를 부탁해요.' },
    { s:750,  title:'회사의 소식', art:'office', chars:['erica','iris','hodgins','benedict','cattleya'], terms:['chpost'], sum:'CH 우편사에서는 에리카와 아이리스가 학교 생활을 궁금해하고, 호진스는 바이올렛의 성적표에 감탄해요.' },
    { s:870,  title:'함께 본 노을', art:'street', chars:['luculia','violet','spencer'], terms:[], sum:'루크리아는 바이올렛과 노을을 보던 일을 떠올려요. 술에 취해 술집에서 쫓겨난 루크리아의 오빠 스펜서에게 바이올렛이 떨어진 목발을 건네줘요.' },
    { s:1050, title:'졸업식', art:'classroom', chars:['luculia','violet','hodgins'], terms:['school'], sum:'루크리아와 동기들은 졸업장을 받지만 바이올렛은 받지 못해요. 호진스는 졸업장이 없어도 대필 일은 할 수 있다고 위로해요.' },
    { s:1170, title:'루크리아의 이야기', art:'night', chars:['luculia','violet','spencer'], terms:['war'], sum:'루크리아는 부모님이 전쟁으로 돌아가셨고, 오빠 스펜서는 다리를 다친 채 돌아왔다고 털어놓아요. 고맙다는 마음을 전하고 싶은 루크리아를 위해 바이올렛이 편지를 써 줘요.' },
    { s:1290, title:'전해진 편지', art:'street', chars:['violet','spencer','rodante'], terms:['badge'], sum:'편지를 받은 스펜서는 눈물을 흘려요. 교장은 바이올렛의 옷깃에 배지를 달아 주며 좋은 자동 수기 인형이 되길 바라요.' },
    { s:1380, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
  ];
  g.chars.luculia = { name:'루크리아 말버러', short:'루크리아', alias:['루크리아','말버러'], at:[3,0], pos:[560,250], facts:[[[3,0],'양성 학교에서 만난 동기예요. 밝고 다정해요.'],[[3,600],'바이올렛에게 부모님께 보낼 편지를 부탁했어요.'],[[3,1170],'부모님을 전쟁으로 잃었고, 오빠에게 고맙다는 말을 하지 못하고 있었어요.']] };
  g.chars.spencer = { name:'스펜서 말버러', short:'스펜서', alias:['스펜서'], at:[3,870], pos:[560,410], facts:[[[3,870],'루크리아의 오빠예요. 술에 기대어 지내요.'],[[3,1170],'전쟁에서 다리를 다친 채 돌아왔어요.'],[[3,1290],'동생의 편지를 받고 눈물을 흘렸어요.']] };
  g.chars.rodante = { name:'로단테 교장', short:'로단테', alias:['로단테','교장'], at:[3,0], pos:[200,435], facts:[[[3,0],'양성 학교의 교장이에요. 엄격해요.'],[[3,1290],'바이올렛에게 배지를 달아 줬어요.']] };
  addFacts(g.chars.violet, [[[3,450],'어휘 시험은 만점이지만 편지는 보고서 같다는 말을 들었어요.'],[[3,1050],'졸업장을 받지 못했어요.'],[[3,1290],'루크리아의 마음을 편지로 전해 주고 교장에게 배지를 받았어요.']]);
  addFacts(g.chars.hodgins, [[[3,1050],'졸업장을 받지 못한 바이올렛을 위로했어요.']]);
  g.rels = g.rels.concat([
    ['violet','luculia','friend','양성 학교 동기',[3,0]],
    ['rodante','violet','other','교장과 학생',[3,0]],
    ['luculia','spencer','family','남매',[3,870]],
  ]);
  addFacts(g.terms.school, [[[3,0],'라이덴에 있는 학교예요. 타자와 편지 쓰기를 배워요.']]);
  g.terms.school.at = [2,1170];
  g.terms.badge = { name:'배지', alias:['배지'], at:[3,1290], generic:true, facts:[[[3,1290],'교장이 바이올렛의 옷깃에 달아 준 배지예요.']] };
  g.banned = drop(g.banned, ['루크리아','스펜서']);
})();

/* ---------- 호리미야 3화 ---------- */
(() => {
  const g = WORKS.horimiya.guide; g.eps = 3;
  g.episodes[3] = { title:'그러니까, 괜찮아', summary:'혼자였던 과거를 떠올린 미야무라가 새 친구들을 진짜 친구로 느끼고, 호리를 둘러싼 일로 토오루와 싸웠다가 화해해요.' };
  g.scenes[3] = [
    { s:0,    title:'혼자였던 날들', art:'classroom', chars:['miyamura'], terms:[], sum:'미야무라는 학교에서 함께 지낼 사람이 없던 외로운 시절을 떠올려요.' },
    { s:120,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
    { s:240,  title:'같은 조', art:'classroom', chars:['hori','toru','yuki','miyamura'], terms:[], sum:'수업 과제에서 호리, 토오루, 유키가 미야무라와 같은 조가 돼요.' },
    { s:420,  title:'진짜 친구', art:'classroom', chars:['miyamura','toru'], terms:[], sum:'미야무라는 이들을 진짜 친구라고 느끼고 토오루에게 마음을 털어놓아요. 토오루도 둘의 우정을 확인해 줘요.' },
    { s:600,  title:'놀리는 레미', art:'classroom', chars:['remi','hori'], terms:[], sum:'레미가 미야무라와 사귈 생각이냐고 놀리자, 호리는 발끈해요.' },
    { s:780,  title:'손 크기 비교', art:'home', chars:['hori','miyamura'], terms:[], sum:'방과 후 호리와 미야무라는 손 크기를 대 보고, 호리는 하마터면 마음을 고백할 뻔해요.' },
    { s:960,  title:'토오루와의 싸움', art:'classroom', chars:['toru','miyamura'], terms:[], sum:'토오루는 호리 일로 미야무라를 따지고, 미야무라는 호리가 자신에게 마음이 없다고 우기다가 둘은 싸우게 돼요.' },
    { s:1140, title:'화해', art:'classroom', chars:['toru','miyamura','yuki'], terms:[], sum:'두 사람은 서로 사과하고, 미야무라는 싸운 이유가 호리였다고 유키에게 말해요.' },
    { s:1350, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
  ];
  addFacts(g.chars.miyamura, [[[3,0],'학교에서 함께 지낼 사람 없이 혼자였던 시절이 있었어요.'],[[3,420],'호리, 토오루, 유키를 진짜 친구라고 느껴요.'],[[3,1140],'토오루와 싸웠다가 화해했어요.']]);
  addFacts(g.chars.hori, [[[3,600],'레미의 놀림에 발끈했어요.'],[[3,780],'미야무라에게 마음을 고백할 뻔했어요.']]);
  addFacts(g.chars.toru, [[[3,960],'호리 일로 미야무라와 싸웠다가 화해했어요.']]);
  addFacts(g.chars.yuki, [[[3,1140],'두 사람이 싸운 이유가 호리였다는 걸 들었어요.']]);
  addFacts(g.chars.remi, [[[3,600],'호리를 미야무라 일로 놀려요.']]);
  g.rels = g.rels.concat([['remi','hori','other','학생회 일로 알게 된 사이',[2,240]]]);
  g.banned = drop(g.banned, ['중학생 시절']);
})();

/* ---------- 데스노트 3화 ---------- */
(() => {
  const g = WORKS.deathnote.guide; g.eps = 3;
  g.episodes[3] = { title:'거래', summary:'L은 키라가 경찰 정보를 볼 수 있는 학생일 거라고 좁혀 오고, 류크는 미행을 경고하며 수명 절반과 사신의 눈을 바꾸는 거래를 제안해요.' };
  g.scenes[3] = [
    { s:0,    title:'L과의 수사 회의', art:'office', chars:['lawl','soichiro'], terms:['kira'], sum:'경찰 간부들이 L과 함께 키라 사건을 논의해요.' },
    { s:120,  title:'오프닝', art:'title', chars:[], terms:[], sum:'' },
    { s:210,  title:'사망 시각의 단서', art:'office', chars:['lawl','soichiro'], terms:['kira'], sum:'희생자들의 사망 시각을 분석한 L은 키라가 학생일 가능성이 높고, 순진한 정의감을 가진 사람이라고 판단해요.' },
    { s:450,  title:'새어 나가는 정보', art:'office', chars:['lawl','soichiro'], terms:['kira'], sum:'L은 희생자들이 언론에 어떻게 보도됐는지 묻고, 키라가 경찰 정보를 볼 수 있는 사람일 거라고 의심하기 시작해요.' },
    { s:660,  title:'아버지의 사건', art:'darkroom', chars:['light','soichiro'], terms:[], sum:'수사를 이끄는 사람이 아버지 소이치로라서, 라이토는 경찰의 움직임을 알 수 있어요.' },
    { s:900,  title:'미행', art:'street', chars:['light','ryuk'], terms:[], sum:'류크는 누군가 라이토를 따라오고 있다고 경고해요.' },
    { s:1080, title:'사신의 눈', art:'darkroom', chars:['ryuk','light'], terms:['shinieyes','lifespan'], sum:'류크는 사신이 일찍 죽은 사람의 남은 수명을 가져갈 수 있고, 사신의 눈에는 모든 사람의 이름과 남은 수명이 보인다고 설명해요.' },
    { s:1230, title:'거래', art:'darkroom', chars:['ryuk','light'], terms:['shinieyes'], sum:'류크는 라이토에게 남은 수명의 절반을 내주면 사신의 눈을 주겠다는 거래를 제안해요.' },
    { s:1350, title:'엔딩', art:'title', chars:[], terms:[], sum:'' },
  ];
  addFacts(g.chars.lawl, [[[3,210],'키라가 학생이고 순진한 정의감을 가졌다고 추리했어요.'],[[3,450],'키라가 경찰 정보를 볼 수 있다고 의심해요.']]);
  addFacts(g.chars.soichiro, [[[3,660],'수사를 이끄는 사람이 아버지라서, 라이토는 경찰의 움직임을 알 수 있어요.']]);
  addFacts(g.chars.light, [[[3,660],'아버지를 통해 수사 상황을 살펴요.']]);
  addFacts(g.chars.ryuk, [[[3,900],'누군가 라이토를 미행한다고 경고했어요.'],[[3,1230],'수명 절반과 사신의 눈을 바꾸는 거래를 제안했어요.']]);
  g.terms.shinieyes = { name:'사신의 눈', alias:['사신의 눈','눈의 거래','사신 눈'], at:[3,1080], facts:[[[3,1080],'사람의 이름과 남은 수명이 보이는 눈이에요.'],[[3,1230],'남은 수명의 절반을 내주면 인간도 이 눈을 얻을 수 있다고 류크가 말했어요.']], easy:'얼굴만 보면 이름표와 남은 시간이 떠 보이는 눈이에요.' };
  g.terms.lifespan = { name:'수명', alias:['수명'], at:[3,1080], generic:true, facts:[[[3,1080],'사신은 제명보다 일찍 죽은 사람의 남은 수명을 가져갈 수 있대요.']] };
  g.banned = drop(g.banned, ['사신의 눈','눈의 거래']);
})();
