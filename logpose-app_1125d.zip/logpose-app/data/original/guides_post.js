/* ============================================================
   가이드북 후처리 — 새로 만든 가이드에서 책 화면(인물·회차 미리보기) 채우기
   ============================================================ */
for (const [id, W] of Object.entries(WORKS)){
  if (!W.lite || !W.guide) continue;
  const G = W.guide, strip = s => String(s).replace(/\*\*/g, '');
  W.book.cast = Object.values(G.chars).filter(c => c.at[0] === 1).slice(0, 4).map(c => [c.short, strip(c.facts[0][1])]);
  W.book.points = Object.entries(G.episodes).map(([e, ep]) => `${e}${G.unit || '화'} 「${ep.title}」 — ${ep.summary}`);
  W.book.orig = `${G.season} · AI 가이드북 1~${G.eps}${G.unit || '화'}`;
  W.cover.meta = `${G.season} · 가이드북 ${G.eps}${G.unit || '화'}`;
  if (!W.book.tags.includes(`가이드북 ${G.eps}${G.unit || '화'}`)) W.book.tags.push(`가이드북 ${G.eps}${G.unit || '화'}`);
}
